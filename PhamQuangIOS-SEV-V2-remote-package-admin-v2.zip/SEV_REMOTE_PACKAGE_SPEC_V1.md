# SEV Remote Feature Package — V1

A feature package is a data-only ZIP (or ZIP-compatible `.vpatch`) consumed by CC365/PhamQuang iOS. It configures a module already compiled into the app; it cannot add Swift code or modify another app's sandbox.

## Required root file

`sev-feature.json`

```json
{
  "schemaVersion": 1,
  "featureID": "feature-center",
  "moduleID": "cc365.feature-center.presentation",
  "settings": {
    "displayTitle": "Feature Center",
    "statusText": "Remote configuration active",
    "accentStyle": "violet"
  }
}
```

## Current allowlist

- `cc365.feature-center.presentation`: `displayTitle`, `statusText`, `accentStyle`
- `cc365.diagnostics.banner`: `message`, `severity`, `visible`
- `cc365.content.visibility`: `showAdvancedOptions`, `showDescriptions`

The module ID and settings are validated against the app's compiled allowlist. Unknown modules or settings are rejected. Values are strings with a 2,048-byte maximum; boolean getters accept `true/false`, `1/0`, `yes/no`, and `on/off`. `feature-center.presentation` is consumed by the Feature Center title/status labels; `diagnostics.banner` is consumed by Diagnostics; `content.visibility.showDescriptions` controls feature descriptions in the Feature Center. `showAdvancedOptions` is reserved until a matching advanced-options view is wired.

## Archive rules

- Maximum download: 50 MiB.
- Only `.zip` and ZIP-compatible `.vpatch` are accepted for automatic feature apply.
- `sev-feature.json` must be at the archive root.
- Relative data paths only; no hidden path components, traversal, absolute paths, or symbolic links.
- No Swift source, scripts, dynamic libraries, frameworks, app bundles, plugins, binaries, or executable content.
- The server reports exact byte size and SHA-256; the app verifies both before staging.

## Apply / Restore

1. SEV Admin uploads the ZIP/VPATCH to Patch Center.
2. The server checks exact file size and SHA-256; the package starts as `draft`.
3. Admin publishes the package.
4. Admin creates/updates a Feature Toggle, selects the published ZIP/VPATCH, and chooses whether it is enabled.
5. CC365 fetches the authenticated feature catalog and downloads the short-lived signed URL when the user turns the toggle ON.
6. The app checks HTTPS host, size, SHA-256, archive paths and manifest, then stores the package under its own `Application Support/SEVManagedFeatures/<feature-id>` directory.
7. Turning OFF restores the preserved baseline and clears the feature's namespaced runtime settings.

## Scope

This mechanism affects only app-owned files and settings. It does not write to Free Fire, another app's container, the app bundle, a process, iOS kernel, Sandbox, Kernel, KExploit, or BQCore. Feature behavior is limited to code that has already been compiled into CC365/PhamQuang iOS and explicitly reads the managed settings.
