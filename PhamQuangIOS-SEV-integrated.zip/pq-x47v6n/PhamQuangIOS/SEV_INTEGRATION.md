# PhamQuang IOS – SEV integration

## Existing services

- Vercel project: `phamquang-ios-sev-admin`
- Vercel production domain: `phamquang-ios-sev-admin.vercel.app`
- Supabase project: `build-sev` (`bpnwzwpqfakwzduiiwvh`, region `ap-southeast-1`)
- Supabase Edge Function used by the iOS app: `sev-control`
- Edge Function URL: `https://bpnwzwpqfakwzduiiwvh.supabase.co/functions/v1/sev-control`

The Vercel project now has the Supabase project URL and public publishable key configured for Production, Preview, and Development. No service-role key is placed in Vercel client variables or in the iOS app.

## iOS behavior

- At launch, the app calls `sev-control` with `action=bootstrap`.
- If SEV key enforcement is enabled and this installation is not authorized, the app presents the SEV key activation screen.
- Successful key validation binds the installation to the key on the server. The raw key is not persisted by the app.
- Maintenance, app-closed, and minimum-version settings are enforced from `sev_control`.
- The existing DeviceAccess/Sandbox/Patch/Kernel code paths are left intact and run only after SEV authorization.

## Admin control

The existing `sev-control` Edge Function supports the existing admin actions for key creation/status, device status, IP blocks, maintenance, key-required mode, app closure, minimum version, update URL, announcement URL, and maintenance message. Admin actions require an authenticated Supabase user with `app_metadata.role = admin`.

## Operational notes

- Current server flags at integration time: `key_required=true`, `maintenance=false`, `app_closed=false`.
- No SEV license keys existed at integration time; issue a key from the existing SEV admin interface before testing activation on a device.
- Vercel environment-variable changes take effect in a new Vercel deployment. The iOS client calls the Supabase Edge Function directly and does not depend on Vercel being online for key validation.
