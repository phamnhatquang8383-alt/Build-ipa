import SwiftUI
import UIKit

struct SEVAccessGateView: View {
    @ObservedObject var sev: SEVAccessManager
    @State private var key = ""
    @FocusState private var keyFocused: Bool

    private var isBlocked: Bool { sev.state == .maintenance || sev.state == .updateRequired }

    var body: some View {
        ZStack {
            LinearGradient(colors: [Color(red: 0.035, green: 0.055, blue: 0.10), Color(red: 0.08, green: 0.10, blue: 0.17), .black], startPoint: .topLeading, endPoint: .bottomTrailing)
                .ignoresSafeArea()
            Circle().fill(Color.blue.opacity(0.16)).frame(width: 280, height: 280).blur(radius: 90).offset(x: 150, y: -260)
            Circle().fill(Color.cyan.opacity(0.10)).frame(width: 240, height: 240).blur(radius: 80).offset(x: -150, y: 250)

            VStack(spacing: 0) {
                Spacer(minLength: 44)
                ZStack {
                    RoundedRectangle(cornerRadius: 25, style: .continuous)
                        .fill(.ultraThinMaterial)
                        .overlay(RoundedRectangle(cornerRadius: 25).stroke(.white.opacity(0.12), lineWidth: 1))
                        .frame(width: 76, height: 76)
                    Image(systemName: isBlocked ? "wrench.and.screwdriver.fill" : "key.horizontal.fill")
                        .font(.system(size: 30, weight: .semibold))
                        .foregroundStyle(Color.cyan)
                }
                .padding(.bottom, 24)

                Text(isBlocked ? (sev.state == .updateRequired ? "Cần cập nhật" : "Đang bảo trì") : "PhamQuang IOS")
                    .font(.system(size: 30, weight: .bold, design: .rounded))
                    .foregroundStyle(.white)
                Text(isBlocked ? "Thông báo từ hệ thống" : "Kích hoạt bằng SEV Key")
                    .font(.system(size: 15, weight: .medium))
                    .foregroundStyle(.white.opacity(0.58))
                    .padding(.top, 7)

                VStack(alignment: .leading, spacing: 16) {
                    if sev.state == .keyRequired {
                        Text("SEV KEY")
                            .font(.system(size: 11, weight: .bold, design: .rounded))
                            .tracking(1.5)
                            .foregroundStyle(.white.opacity(0.55))
                        HStack(spacing: 10) {
                            Image(systemName: "key.fill").foregroundStyle(.cyan)
                            SecureField("Nhập key của bạn", text: $key)
                                .textInputAutocapitalization(.characters)
                                .autocorrectionDisabled()
                                .focused($keyFocused)
                                .submitLabel(.go)
                                .onSubmit { Task { await activate() } }
                                .foregroundStyle(.white)
                        }
                        .padding(.horizontal, 16)
                        .frame(height: 56)
                        .background(.black.opacity(0.22), in: RoundedRectangle(cornerRadius: 16, style: .continuous))
                        .overlay(RoundedRectangle(cornerRadius: 16, style: .continuous).stroke(.white.opacity(0.10), lineWidth: 1))

                        Button { Task { await activate() } } label: {
                            HStack(spacing: 9) {
                                if sev.isWorking { ProgressView().tint(.white) }
                                Text(sev.isWorking ? "Đang xác thực…" : "Kích hoạt")
                                    .font(.system(size: 16, weight: .semibold))
                                if !sev.isWorking { Image(systemName: "arrow.right") }
                            }
                            .frame(maxWidth: .infinity).frame(height: 54)
                            .foregroundStyle(.white)
                            .background(LinearGradient(colors: [Color.blue, Color(red: 0.10, green: 0.58, blue: 0.94)], startPoint: .leading, endPoint: .trailing), in: RoundedRectangle(cornerRadius: 16, style: .continuous))
                        }
                        .disabled(sev.isWorking || key.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty)
                        .opacity(sev.isWorking || key.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty ? 0.65 : 1)
                    }

                    Text(sev.message)
                        .font(.system(size: 13))
                        .foregroundStyle(.white.opacity(0.68))
                        .fixedSize(horizontal: false, vertical: true)
                        .frame(maxWidth: .infinity, alignment: .leading)

                    if sev.state == .error || sev.state == .maintenance {
                        Button { Task { await sev.refresh() } } label: {
                            Label("Thử kết nối lại", systemImage: "arrow.clockwise")
                                .font(.system(size: 14, weight: .semibold))
                                .frame(maxWidth: .infinity).frame(height: 46)
                                .foregroundStyle(.white)
                                .background(.white.opacity(0.09), in: RoundedRectangle(cornerRadius: 14, style: .continuous))
                        }
                        .disabled(sev.isWorking)
                    }
                    if sev.state == .updateRequired, let url = sev.updateURL {
                        Link(destination: url) {
                            Label("Cập nhật ngay", systemImage: "arrow.down.circle.fill")
                                .font(.system(size: 15, weight: .semibold))
                                .frame(maxWidth: .infinity).frame(height: 50)
                                .foregroundStyle(.white)
                                .background(Color.blue, in: RoundedRectangle(cornerRadius: 14, style: .continuous))
                        }
                    }
                    if let url = sev.announcementURL {
                        Link("Xem thông báo", destination: url)
                            .font(.system(size: 13, weight: .medium))
                            .foregroundStyle(.cyan)
                    }
                }
                .padding(22)
                .background(.ultraThinMaterial, in: RoundedRectangle(cornerRadius: 26, style: .continuous))
                .overlay(RoundedRectangle(cornerRadius: 26, style: .continuous).stroke(.white.opacity(0.10), lineWidth: 1))
                .padding(.top, 30)

                Spacer()
                HStack(spacing: 6) {
                    Circle().fill(sev.state == .authorized ? Color.green : Color.cyan).frame(width: 6, height: 6)
                    Text("SEV SECURE ACCESS")
                        .font(.system(size: 10, weight: .bold, design: .rounded)).tracking(1.7)
                        .foregroundStyle(.white.opacity(0.35))
                }
                .padding(.bottom, 24)
            }
            .padding(.horizontal, 24)
            .frame(maxWidth: 480)
        }
        .preferredColorScheme(.dark)
        .animation(.spring(response: 0.42, dampingFraction: 0.86), value: sev.state)
    }

    private func activate() async {
        await sev.activate(key: key)
        if sev.state == .authorized { key = ""; keyFocused = false }
    }
}
