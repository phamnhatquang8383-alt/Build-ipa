# SEV V2 — API bàn giao cho luồng mật khẩu `.vpatch`

## Client request

CC365 gửi POST tới Edge Function `sev-control` (cùng xác thực `apikey`/Bearer và installation ID như bootstrap):

```json
{
  "action": "feature-package-secret",
  "installation_id": "<installation-id>",
  "feature_id": "<feature-id>",
  "package_id": "<package-id>",
  "package_version": "<package-version>"
}
```

## Success response

```json
{
  "package_password": "<password>"
}
```

## Server requirements

1. Xác minh installation tồn tại, đang authorized và chưa bị thu hồi/khóa.
2. Đọc `sev_feature_catalog` bằng quyền server; yêu cầu `enabled_by_admin = true`.
3. Khớp chính xác `feature_id`, `package_id`, `package_version` với bản đang publish.
4. Đọc ciphertext từ `sev_feature_package_secrets`; giải mã bằng khóa chỉ lưu trong secret manager của server.
5. Trả password qua HTTPS; không ghi password/ciphertext vào log và không đưa password vào `feature-catalog`.
6. Áp dụng rate limit và audit metadata (installation, feature, version, thời điểm), tuyệt đối không audit password.

## SEV Admin requirements

Admin form upload `.vpatch` phải có ô password + xác nhận password. Server cần mã hóa password bằng secret quản lý server, ghi ciphertext vào `sev_feature_package_secrets`, đồng bộ package ID/version; không gửi password vào bảng catalogue công khai.

## Giới hạn source đính kèm

ZIP CC365 hiện tại không có source Edge Function hoặc giao diện SEV Admin. File này là API contract để tích hợp vào repository SEV; phần client CC365 đã được cập nhật để gọi endpoint này.
