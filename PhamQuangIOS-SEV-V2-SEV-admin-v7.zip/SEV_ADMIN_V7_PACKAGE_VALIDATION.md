# SEV Admin v7 — Feature package validation

Đã triển khai trực tiếp lên Supabase Edge Function `sev-admin` phiên bản 7 (ACTIVE).

## Thay đổi
- Khu vực Upload & Publish có trường Feature ID tự đọc từ `sev-feature.json`.
- Trước khi upload, trình duyệt kiểm tra ZIP có manifest ở thư mục gốc, `schemaVersion=1`, `featureID` đúng định dạng, `moduleID` thuộc allowlist và các key/value settings hợp lệ.
- Từ chối đường dẫn tuyệt đối, traversal, thành phần ẩn, symbolic link và payload thực thi/nhị phân không được hỗ trợ.
- Khi hợp lệ, Feature ID được tự điền vào form Feature Toggle để liên kết package và công tắc.
- Quy trình server-side xác minh size/SHA-256, trạng thái draft/published và ràng buộc package với feature vẫn được giữ nguyên.

## Cách dùng
1. Mở SEV Admin và đăng nhập tài khoản quản trị.
2. Chọn ZIP/VPATCH dữ liệu có `sev-feature.json` ở thư mục gốc.
3. Điền tên, phiên bản và mô tả rồi Upload.
4. Publish package sau khi kiểm tra.
5. Feature ID đã tự điền; chọn package vừa publish, nhập tên hiển thị, bật Cho phép app tải và lưu Feature Toggle.
6. CC365 tải catalogue; người dùng bật/tắt duy nhất công tắc trong app.

## Giới hạn
Package chỉ cấu hình module đã biên dịch sẵn trong CC365. Nó không chèn mã, không sửa Free Fire, không truy cập sandbox ứng dụng khác và không thay đổi Sandbox/Kernel/KExploit/BQCore.
