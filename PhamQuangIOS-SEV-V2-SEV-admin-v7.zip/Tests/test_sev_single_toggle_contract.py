from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
view = (ROOT / "CC365-Apps/Files/AppPatchView.swift").read_text()
manager = (ROOT / "CC365-Apps/Runtime/SEVFeaturePackageManager.swift").read_text()
runtime = (ROOT / "CC365-Apps/Runtime/SEVFeatureModuleRuntime.swift").read_text()

# One SwiftUI Toggle per catalogue feature; state changes route to apply/restore.
assert "Toggle(isOn: binding(for: feature))" in view
assert "SEVAccessManager.shared.fetchFeatureCatalog()" in view
assert "SEVFeaturePackageManager.apply(current)" in view
assert "SEVFeaturePackageManager.restore(featureID: feature.id)" in view
# Package verification and idempotency happen before activation.
assert "guard digest == expectedHash" in manager
assert "guard !fm.fileExists(atPath: receiptURL.path) else { throw Failure.alreadyApplied }" in manager
assert "SEVFeatureModuleRuntime.validatePackage(at: prepared" in manager
# Runtime only accepts allowlisted settings and rejects executable payloads.
assert "supportedModules" in runtime
assert "executablePayloadRejected" in runtime
# No direct integration with external game/container or exploit APIs in the feature manager.
for forbidden in ("KExploit", "BQCore", "Free Fire.app", "kernel_task"):
    assert forbidden not in manager
print("SEV single-toggle contract checks passed")
