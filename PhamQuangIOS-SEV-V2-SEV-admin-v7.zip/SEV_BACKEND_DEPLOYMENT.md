# SEV V2 backend deployment and connection

## Live project

- Supabase project: `build-sev`
- Project ref: `bpnwzwpqfakwzduiiwvh`
- Admin dashboard Edge Function: `https://bpnwzwpqfakwzduiiwvh.supabase.co/functions/v1/sev-admin`
- Control/API Edge Function: `https://bpnwzwpqfakwzduiiwvh.supabase.co/functions/v1/sev-control`
- Current deployed `sev-admin`: **version 6**, ACTIVE
- Current deployed `sev-control`: **version 10**, ACTIVE
- Vercel project: `phamquang-ios-sev-admin-v2` (`prj_y4aBH0mEx3Gk5f244W46Y5QhGsTw`)
- Vercel production domain: `https://phamquang-ios-sev-admin-v2.vercel.app`

The live SEV Admin dashboard is served by the Supabase `sev-admin` Edge Function. The Vercel project is a separate connected deployment; this package workflow was deployed to the Supabase Edge Functions, not falsely reported as a new Vercel production release.

## Remote package workflow now deployed

1. Sign in to SEV Admin using the existing Supabase Auth admin account (`app_metadata.role = admin`).
2. Open **SEV Remote Packages · Upload & Publish**.
3. Upload a `.zip` or `.vpatch` file (maximum 50 MB), enter package label/version, then upload. The browser calculates SHA-256; the Edge Function downloads the uploaded object and independently verifies exact size and SHA-256. New uploads remain `draft`.
4. Press **Publish** for the package after checking it.
5. In **Feature Toggles**, enter the exact `featureID` that is inside `sev-feature.json`, title, select a published ZIP/VPATCH, and enable/disable it.
6. The server rejects non-ZIP/VPATCH package types, unpublished packages, mismatched SHA-256, and mismatched package versions for feature activation.
7. CC365/PhamQuang iOS fetches the catalog after SEV authorization. ON downloads and verifies the signed package; OFF restores the prior app-owned baseline.

## Client configuration

`CC365-Apps/Runtime/SEVAccessManager.swift` contains the public Supabase endpoint and publishable key. The publishable key is intended for client use. Never put a service-role/secret key in the iOS app or this source archive.

## Security and preservation

- The feature catalogue table has RLS enabled and is accessed by Edge Functions using server-side credentials.
- The public feature-catalog action requires a valid installation and, when key enforcement is on, an active unexpired license bound to that installation.
- Signed download URLs are short-lived (10 minutes).
- Feature package uploads in the Admin UI accept only ZIP/VPATCH; server-side feature binding independently enforces ZIP/VPATCH, published state, version and SHA-256.
- The iOS app checks HTTPS host, exact size, SHA-256, safe paths, symlinks and the root manifest before installing. The Feature Center consumes remote title/status settings; Diagnostics consumes the remote banner module; Feature Center descriptions can be shown/hidden through the content-visibility module.
- No service-role/secret credentials are included in the source archive.
- Sandbox, Kernel, KExploit and BQCore sources are preserved and not modified by this package integration.
- No arbitrary Swift code, dylib, script or executable is downloaded or executed. iOS does not support an app silently replacing its own compiled code at runtime.

## iOS behavior boundary

Packages are stored only under this app's own `Application Support/SEVManagedFeatures` directory. This does not patch Free Fire, another app's private container, iOS kernel, process memory, app bundle or exploit components. A toggle changes app-owned package/configuration state and only changes visible behavior where a precompiled CC365 feature consumes the corresponding settings.


## Latest admin deployment

- `sev-admin` Edge Function: version 7, ACTIVE.
- Upload form now reads `featureID` from the root `sev-feature.json` and validates schema, module/settings allowlist, safe archive paths, symlinks and forbidden executable payloads before upload.
- See `SEV_ADMIN_V7_PACKAGE_VALIDATION.md` for the operator workflow.
