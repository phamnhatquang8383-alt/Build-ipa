import Foundation
import CryptoKit

/// Applies SEV feature content only inside this app's Application Support directory.
/// It never resolves external app containers, game data, bundles, kernels or processes.
enum SEVFeaturePackageManager {
    private static let maximumPackageSize: Int64 = 50 * 1_024 * 1_024
    private static let rootName = "SEVManagedFeatures"

    private struct Receipt: Codable {
        let featureID: String
        let packageID: String
        let packageVersion: String
        let hadPreviousContent: Bool
        let appliedAt: Date
    }

    enum Failure: LocalizedError {
        case invalidFeature, missingDownload, untrustedURL, downloadFailed, tooLarge
        case hashMismatch, unsupportedArchive, alreadyApplied, noReceipt, unsafePath
        var errorDescription: String? {
            switch self {
            case .invalidFeature: return "Mã tính năng SEV không hợp lệ."
            case .missingDownload: return "SEV chưa cấp liên kết tải package cho tính năng này. Hãy tải lại catalogue."
            case .untrustedURL: return "Liên kết package không thuộc máy chủ Supabase HTTPS đã cấu hình."
            case .downloadFailed: return "Không tải được package từ SEV. Hãy kiểm tra kết nối hoặc tải lại catalogue."
            case .tooLarge: return "Package vượt giới hạn 50 MB."
            case .hashMismatch: return "SHA-256 của package không khớp SEV Admin. Package chưa được áp dụng."
            case .unsupportedArchive: return "Package không phải ZIP dữ liệu được hỗ trợ hoặc chứa đường dẫn không hợp lệ."
            case .alreadyApplied: return "Tính năng đã được áp dụng. Hãy khôi phục trước khi áp dụng phiên bản khác."
            case .noReceipt: return "Không tìm thấy biên nhận patch để khôi phục."
            case .unsafePath: return "Package chứa đường dẫn không an toàn. Không có dữ liệu nào được ghi."
            }
        }
    }

    static func isApplied(_ featureID: String) -> Bool {
        guard let folder = try? featureFolder(featureID) else { return false }
        return FileManager.default.fileExists(atPath: folder.appendingPathComponent("receipt.json").path)
    }

    static func appliedFeatureIDs() -> Set<String> {
        guard let root = try? managedRoot(),
              let rows = try? FileManager.default.contentsOfDirectory(at: root, includingPropertiesForKeys: [.isDirectoryKey, .isSymbolicLinkKey]) else { return [] }
        return Set(rows.compactMap { url in
            guard url.lastPathComponent.range(of: "^[a-z0-9][a-z0-9._-]{0,63}$", options: .regularExpression) != nil,
                  FileManager.default.fileExists(atPath: url.appendingPathComponent("receipt.json").path) else { return nil }
            return url.lastPathComponent
        })
    }

    static func apply(_ feature: SEVFeatureManifest.Feature) async throws {
        guard validFeatureID(feature.id) else { throw Failure.invalidFeature }
        guard let rawURL = feature.downloadURL, let url = URL(string: rawURL),
              let fileName = feature.fileName, !fileName.isEmpty,
              let expectedSize = feature.fileSize, expectedSize > 0, expectedSize <= maximumPackageSize,
              let expectedHash = feature.sha256?.lowercased(), expectedHash.range(of: "^[0-9a-f]{64}$", options: .regularExpression) != nil,
              let packageID = feature.packageID, let version = feature.packageVersion else { throw Failure.missingDownload }
        guard url.scheme?.lowercased() == "https", url.host?.lowercased() == "bpnwzwpqfakwzduiiwvh.supabase.co" else {
            throw Failure.untrustedURL
        }
        let folder = try featureFolder(feature.id)
        let fm = FileManager.default
        let receiptURL = folder.appendingPathComponent("receipt.json")
        // Idempotency guard: never download or stage a package again while this feature
        // already has an active receipt, even if a UI binding fires twice.
        guard !fm.fileExists(atPath: receiptURL.path) else { throw Failure.alreadyApplied }

        let (downloadURL, response): (URL, URLResponse)
        do { (downloadURL, response) = try await URLSession.shared.download(from: url) }
        catch { throw Failure.downloadFailed }
        guard let http = response as? HTTPURLResponse, (200..<300).contains(http.statusCode) else { throw Failure.downloadFailed }
        let actualSize = (try? downloadURL.resourceValues(forKeys: [.fileSizeKey]).fileSize).map(Int64.init) ?? -1
        guard actualSize > 0, actualSize <= maximumPackageSize, actualSize == expectedSize else { throw Failure.tooLarge }
        let digest = try sha256(downloadURL)
        guard digest == expectedHash else { throw Failure.hashMismatch }

        let ext = URL(fileURLWithPath: fileName).pathExtension.lowercased()
        guard ["zip", "vpatch"].contains(ext) else { throw Failure.unsupportedArchive }
        let stagedArchive = try FileTransferItem(name: "sev-feature." + ext)
        _ = try FileTransferSupport.copyRegularFile(from: downloadURL, to: stagedArchive.file, limit: UInt64(maximumPackageSize))
        let staged = try await AppPatchSource.stage(stagedArchive.file, app: nil, scope: .bundle)
        guard !staged.files.isEmpty else { throw Failure.unsupportedArchive }

        let prepared = folder.appendingPathComponent("prepared-" + UUID().uuidString, isDirectory: true)
        let active = folder.appendingPathComponent("active", isDirectory: true)
        let baseline = folder.appendingPathComponent("baseline", isDirectory: true)
        let history = folder.appendingPathComponent("history", isDirectory: true)
        try fm.createDirectory(at: prepared, withIntermediateDirectories: false, attributes: [.posixPermissions: 0o700])
        do {
            for item in staged.files {
                try Task.checkCancellation()
                let relative = try safeRelativePath(item.path)
                let destination = prepared.appendingPathComponent(relative, isDirectory: false)
                try fm.createDirectory(at: destination.deletingLastPathComponent(), withIntermediateDirectories: true,
                                       attributes: [.posixPermissions: 0o700])
                _ = try FileTransferSupport.copyRegularFile(from: item.local, to: destination, limit: UInt64(AppPatchSource.perFile))
            }
            // Packages are data-only. Require a manifest for a pre-integrated Swift module;
            // never load or execute Swift, dylib, framework, script, or binary payloads.
            try SEVFeatureModuleRuntime.validatePackage(at: prepared, expectedFeatureID: feature.id)
            try fm.createDirectory(at: history, withIntermediateDirectories: true, attributes: [.posixPermissions: 0o700])
            let hadPrevious = fm.fileExists(atPath: active.path)
            guard !fm.fileExists(atPath: baseline.path) else { throw Failure.alreadyApplied }
            if hadPrevious { try fm.moveItem(at: active, to: baseline) }
            do {
                try fm.moveItem(at: prepared, to: active)
                let receipt = Receipt(featureID: feature.id, packageID: packageID, packageVersion: version,
                                      hadPreviousContent: hadPrevious, appliedAt: Date())
                let data = try JSONEncoder().encode(receipt)
                try data.write(to: receiptURL, options: [.atomic, .completeFileProtection])
                try SEVFeatureModuleRuntime.activate(featureID: feature.id, packageDirectory: active)
            } catch {
                try? fm.removeItem(at: receiptURL)
                SEVFeatureModuleRuntime.deactivate(featureID: feature.id)
                if fm.fileExists(atPath: active.path) {
                    try? fm.moveItem(at: active, to: history.appendingPathComponent("failed-" + UUID().uuidString, isDirectory: true))
                }
                if hadPrevious, fm.fileExists(atPath: baseline.path), !fm.fileExists(atPath: active.path) {
                    try? fm.moveItem(at: baseline, to: active)
                }
                throw error
            }
        } catch {
            try? fm.removeItem(at: prepared)
            throw error
        }
    }

    static func restore(featureID: String) throws {
        guard validFeatureID(featureID) else { throw Failure.invalidFeature }
        let folder = try featureFolder(featureID)
        let fm = FileManager.default
        let receiptURL = folder.appendingPathComponent("receipt.json")
        guard let data = try? Data(contentsOf: receiptURL),
              let receipt = try? JSONDecoder().decode(Receipt.self, from: data), receipt.featureID == featureID else {
            throw Failure.noReceipt
        }
        let active = folder.appendingPathComponent("active", isDirectory: true)
        let baseline = folder.appendingPathComponent("baseline", isDirectory: true)
        let history = folder.appendingPathComponent("history", isDirectory: true)
        try fm.createDirectory(at: history, withIntermediateDirectories: true, attributes: [.posixPermissions: 0o700])
        if receipt.hadPreviousContent && !fm.fileExists(atPath: baseline.path) { throw Failure.noReceipt }
        let archivedActive = history.appendingPathComponent("applied-" + UUID().uuidString, isDirectory: true)
        let archivedReceipt = history.appendingPathComponent("receipt-" + UUID().uuidString + ".json")
        let hadActive = fm.fileExists(atPath: active.path)
        var movedBaseline = false
        var movedReceipt = false
        do {
            if hadActive { try fm.moveItem(at: active, to: archivedActive) }
            if receipt.hadPreviousContent {
                try fm.moveItem(at: baseline, to: active)
                movedBaseline = true
                try SEVFeatureModuleRuntime.activate(featureID: featureID, packageDirectory: active)
            } else {
                SEVFeatureModuleRuntime.deactivate(featureID: featureID)
            }
            try fm.moveItem(at: receiptURL, to: archivedReceipt)
            movedReceipt = true
        } catch {
            // Roll back the directory transaction and the receipt if any step failed.
            if movedReceipt, fm.fileExists(atPath: archivedReceipt.path) {
                try? fm.moveItem(at: archivedReceipt, to: receiptURL)
            }
            SEVFeatureModuleRuntime.deactivate(featureID: featureID)
            if movedBaseline, fm.fileExists(atPath: active.path) {
                try? fm.moveItem(at: active, to: baseline)
            }
            if hadActive, fm.fileExists(atPath: archivedActive.path), !fm.fileExists(atPath: active.path) {
                try? fm.moveItem(at: archivedActive, to: active)
                try? SEVFeatureModuleRuntime.activate(featureID: featureID, packageDirectory: active)
            }
            throw error
        }
    }

    private static func validFeatureID(_ value: String) -> Bool {
        value.range(of: "^[a-z0-9][a-z0-9._-]{0,63}$", options: .regularExpression) != nil
    }

    private static func safeRelativePath(_ value: String) throws -> String {
        let parts = value.split(separator: "/", omittingEmptySubsequences: false).map(String.init)
        guard !parts.isEmpty, parts.count <= 32, value.utf8.count <= 1024,
              parts.allSatisfy({ !$0.isEmpty && $0 != "." && $0 != ".." && !$0.hasPrefix(".") && FileTransferSupport.validName($0) }) else {
            throw Failure.unsafePath
        }
        return parts.joined(separator: "/")
    }

    private static func managedRoot() throws -> URL {
        let base = try FileManager.default.url(for: .applicationSupportDirectory, in: .userDomainMask, appropriateFor: nil, create: true)
        let root = base.appendingPathComponent(rootName, isDirectory: true)
        let fm = FileManager.default
        if fm.fileExists(atPath: root.path) {
            let values = try root.resourceValues(forKeys: [.isDirectoryKey, .isSymbolicLinkKey])
            guard values.isDirectory == true, values.isSymbolicLink != true else { throw Failure.unsafePath }
        } else {
            try fm.createDirectory(at: root, withIntermediateDirectories: false, attributes: [.posixPermissions: 0o700])
        }
        return root
    }

    private static func featureFolder(_ id: String) throws -> URL {
        guard validFeatureID(id) else { throw Failure.invalidFeature }
        let folder = try managedRoot().appendingPathComponent(id, isDirectory: true)
        if FileManager.default.fileExists(atPath: folder.path) {
            let values = try folder.resourceValues(forKeys: [.isDirectoryKey, .isSymbolicLinkKey])
            guard values.isDirectory == true, values.isSymbolicLink != true else { throw Failure.unsafePath }
        } else {
            try FileManager.default.createDirectory(at: folder, withIntermediateDirectories: false, attributes: [.posixPermissions: 0o700])
        }
        return folder
    }

    private static func sha256(_ url: URL) throws -> String {
        let handle = try FileHandle(forReadingFrom: url)
        defer { try? handle.close() }
        var hash = SHA256()
        while let chunk = try handle.read(upToCount: 1_048_576), !chunk.isEmpty { hash.update(data: chunk) }
        return hash.finalize().map { String(format: "%02x", $0) }.joined()
    }
}
