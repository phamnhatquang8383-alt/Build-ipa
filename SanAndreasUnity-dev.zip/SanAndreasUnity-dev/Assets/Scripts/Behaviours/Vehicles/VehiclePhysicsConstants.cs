using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;
using UnityEngine;

namespace SanAndreasUnity.Behaviours.Vehicles
{
    public class VehiclePhysicsConstants : MonoBehaviour
    {
        public static VehiclePhysicsConstants Instance { get; private set; }

        [AttributeUsage(AttributeTargets.Field)]
        private class WatchedAttribute : Attribute { }

        private Dictionary<FieldInfo, object> _fields;

        public static event Action<VehiclePhysicsConstants> Changed;

        [Watched] public float DragScale = 1 / 100f;
        [Watched] public float AccelerationScale = 75f; // Tăng gia tốc cơ bản
        [Watched] public float BreakingScale = 1.2f;
        [Watched] public float SuspensionForceScale = 10000f;
        [Watched] public float SuspensionDampingScale = 1000f;
        [Watched] public float MassScale = 1f;

        [Watched] public float ForwardFrictionExtremumSlip = 0.5f;
        [Watched] public float ForwardFrictionExtremumValue = 1.6f;
        [Watched] public float ForwardFrictionAsymptoteSlip = 20.0f;
        [Watched] public float ForwardFrictionAsymptoteValue = 0.6f;

        [Watched] public float SideFrictionExtremumSlip = 0.5f;
        [Watched] public float SideFrictionExtremumValue = 1.6f;
        [Watched] public float SideFrictionAsymptoteSlip = 20.0f;
        [Watched] public float SideFrictionAsymptoteValue = 0.6f;

        [Watched] public float AntiRollScale = 1.2f;

        // Cấu hình nâng cấp tốc độ người chơi đạt 200 - 250 km/h
        [Watched] public float TopSpeedKmH = 240f; // Vận tốc mục tiêu: 200 - 250 km/h
        [Watched] public float HighSpeedAccelerationBoost = 3.2f; // Hệ số trợ lực gia tốc dải tốc độ cao
        [Watched] public float HighSpeedDownforce = 14f; // Khí động học ép xe xuống đường tránh bay xe ở tốc độ 200+
        [Watched] public float NitroBoostForce = 28f; // Lực đẩy Nitro siêu tốc
        [Watched] public bool EnableHighSpeedTuning = true; // Bật tính năng nâng cấp tốc độ cao

        public bool HasChanged { get; private set; }

        public VehiclePhysicsConstants()
        {
            Instance = this;
        }

        private void DiscoverFields()
        {
            _fields = new Dictionary<FieldInfo, object>();
            foreach (var field in GetType().GetFields())
            {
                if (field.DeclaringType != GetType()) continue;
                if (field.FieldType.IsClass) continue;
                if (field.GetCustomAttributes(typeof(WatchedAttribute), false).Length == 0) continue;
                _fields.Add(field, null);
            }
        }

        private void CheckForChanges()
        {
            HasChanged = false;

            if (_fields == null)
            {
                DiscoverFields();
            }

            foreach (var field in _fields)
            {
                var cur = field.Key.GetValue(this);
                if (!cur.Equals(field.Value))
                {
                    HasChanged = true;
                    break;
                }
            }

            if (!HasChanged) return;

            foreach (var field in _fields.Keys.ToArray())
            {
                _fields[field] = field.GetValue(this);
            }

            if (Changed != null)
            {
                Changed(this);
            }
        }

        private void FixedUpdate()
        {
            CheckForChanges();
        }
    }
}
