using System.IO;
using System.Linq;
using UnityEditor;
using UnityEditor.Build.Reporting;
using UnityEngine;

namespace SanAndreasUnity.Editor
{
    public class iOSBuilder
    {
        [MenuItem("SanAndreasUnity/Build/Build iOS Xcode Project")]
        public static void Build()
        {
            Debug.Log("=== Starting iOS Build for SanAndreasUnity ===");

            // Thiết lập thông tin gói ứng dụng iOS
            PlayerSettings.SetApplicationIdentifier(BuildTargetGroup.iOS, "com.sanandreasunity.game");
            PlayerSettings.bundleVersion = "1.0.0";
            PlayerSettings.iOS.buildNumber = "1";
            PlayerSettings.productName = "San Andreas Unity";
            PlayerSettings.companyName = "SanAndreasUnity";

            // Kiến trúc ARM64 cho iPhone & iPad
            PlayerSettings.SetArchitecture(BuildTargetGroup.iOS, 1); // 1 = ARM64
            PlayerSettings.iOS.targetDevice = iOSTargetDevice.iPhoneAndiPad;
            PlayerSettings.iOS.sdkVersion = iOSSdkVersion.DeviceSDK;
            PlayerSettings.iOS.targetOSVersionString = "14.0";

            // Hướng màn hình chuẩn game đua xe/hành động trên iPhone
            PlayerSettings.defaultInterfaceOrientation = UIOrientation.LandscapeLeft;
            PlayerSettings.allowedAutorotateToLandscapeLeft = true;
            PlayerSettings.allowedAutorotateToLandscapeRight = true;
            PlayerSettings.allowedAutorotateToPortrait = false;
            PlayerSettings.allowedAutorotateToPortraitUpsideDown = false;

            // Tối ưu hiệu năng iOS 60 FPS
            PlayerSettings.accelerometerFrequency = 60;
            PlayerSettings.iOS.hideHomeButton = true;
            PlayerSettings.iOS.statusBarStyle = iOSStatusBarStyle.Hidden;

            // Quyền riêng tư theo tiêu chuẩn iOS
            PlayerSettings.iOS.cameraUsageDescription = "Game camera access";
            PlayerSettings.iOS.microphoneUsageDescription = "Voice chat access";
            PlayerSettings.iOS.locationUsageDescription = "Location features";

            // Đường dẫn xuất project Xcode để đóng gói IPA
            string buildPath = Path.Combine(Application.dataPath, "../Build/iOS");
            if (Directory.Exists(buildPath))
            {
                Directory.Delete(buildPath, true);
            }
            Directory.CreateDirectory(buildPath);

            var scenes = EditorBuildSettings.scenes.Where(s => s.enabled).Select(s => s.path).ToArray();
            if (scenes.Length == 0)
            {
                scenes = Directory.GetFiles("Assets", "*.unity", SearchOption.AllDirectories);
            }

            Debug.Log($"Building {scenes.Length} scenes to {buildPath}...");

            BuildReport report = BuildPipeline.BuildPlayer(scenes, buildPath, BuildTarget.iOS, BuildOptions.None);
            BuildSummary summary = report.summary;

            if (summary.result == BuildResult.Succeeded)
            {
                Debug.Log($"✅ Xuất project Xcode thành công tại: {buildPath} ({summary.totalSize} bytes)");
            }
            else
            {
                Debug.LogError($"❌ Xuất project Xcode thất bại: {summary.result}");
            }
        }
    }
}
