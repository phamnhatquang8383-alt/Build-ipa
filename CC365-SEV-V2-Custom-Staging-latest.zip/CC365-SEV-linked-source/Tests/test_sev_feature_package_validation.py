#!/usr/bin/env python3
import io, json, hashlib, zipfile, pathlib, sys
from cryptography.hazmat.primitives.kdf.pbkdf2 import PBKDF2HMAC
from cryptography.hazmat.primitives import hashes
from cryptography.hazmat.primitives.ciphers.aead import AESGCM

ROOT = pathlib.Path(__file__).resolve().parent
TEMPLATE = ROOT.parent / "SEV_FEATURE_PACKAGE_TEMPLATE.zip"
TESS = pathlib.Path(sys.argv[1]) if len(sys.argv) > 1 else None
PASSWORD = sys.argv[2] if len(sys.argv) > 2 else None
MANIFEST = {"schemaVersion": 1, "featureID": "feature-center", "moduleID": "cc365.feature-center.presentation", "settings": {"displayTitle": "Feature Center"}}

def check_feature_zip(blob):
    z = zipfile.ZipFile(io.BytesIO(blob))
    names = z.namelist()
    if "sev-feature.json" not in names:
        raise ValueError("manifest-not-at-root")
    if any(n == "Application" or n.startswith("Application/") for n in names):
        raise ValueError("external-application-data")
    m = json.loads(z.read("sev-feature.json"))
    if m.get("schemaVersion") != 1 or not m.get("featureID") or not m.get("moduleID"):
        raise ValueError("invalid-manifest")
    return names

def decrypt_v99(raw, password):
    if len(raw) < 45 or raw[:8] != b"V99PATCH" or raw[8] != 1:
        raise ValueError("invalid-vpatch-header")
    header, salt, prefix = raw[:45], raw[9:25], raw[25:33]
    chunk_size = int.from_bytes(raw[33:37], "big")
    expected = int.from_bytes(raw[37:45], "big")
    if chunk_size != 1048576 or expected <= 0 or expected > 264*1024*1024:
        raise ValueError("invalid-vpatch-metadata")
    kdf = PBKDF2HMAC(algorithm=hashes.SHA256(), length=32, salt=salt, iterations=600000)
    key = kdf.derive(password.encode())
    aes = AESGCM(key)
    off, index, out = 45, 0, bytearray()
    while off < len(raw):
        if off + 4 > len(raw) or index >= 512: raise ValueError("truncated-vpatch")
        n = int.from_bytes(raw[off:off+4], "big"); off += 4
        if n < 28 or n > chunk_size+28 or off+n > len(raw): raise ValueError("invalid-vpatch-chunk")
        combined = raw[off:off+n]; off += n
        nonce, plain_len = combined[:12], n-28
        if nonce != prefix + index.to_bytes(4,"big"): raise ValueError("invalid-vpatch-nonce")
        aad = header + index.to_bytes(4,"big") + plain_len.to_bytes(4,"big")
        out.extend(aes.decrypt(nonce, combined[12:], aad))
        index += 1
    if len(out) != expected: raise ValueError("vpatch-size-mismatch")
    return bytes(out)

# PASS: correct root-manifest ZIP.
assert "sev-feature.json" in check_feature_zip(TEMPLATE.read_bytes())
print("PASS valid-root-manifest.zip")

# FAIL: manifest nested one directory down.
nested = io.BytesIO()
with zipfile.ZipFile(nested,"w",zipfile.ZIP_DEFLATED) as z:
    z.writestr("package/sev-feature.json",json.dumps(MANIFEST))
try: check_feature_zip(nested.getvalue()); raise AssertionError("nested manifest unexpectedly accepted")
except ValueError as e: assert str(e)=="manifest-not-at-root"
print("PASS reject-nested-manifest.zip")

# FAIL: external application tree is not a feature package.
external = io.BytesIO()
with zipfile.ZipFile(external,"w",zipfile.ZIP_DEFLATED) as z:
    z.writestr("sev-feature.json",json.dumps(MANIFEST))
    z.writestr("Application/com.garena.ffvn/data.bin",b"x")
try: check_feature_zip(external.getvalue()); raise AssertionError("external app payload unexpectedly accepted")
except ValueError as e: assert str(e)=="external-application-data"
print("PASS reject-external-Application-tree")

if TESS and PASSWORD:
    raw=TESS.read_bytes()
    # FAIL: incorrect password must fail GCM authentication.
    try: decrypt_v99(raw, PASSWORD + "-wrong"); raise AssertionError("wrong key unexpectedly decrypted")
    except Exception: print("PASS reject-wrong-vpatch-key")
    plain=decrypt_v99(raw,PASSWORD)
    names=zipfile.ZipFile(io.BytesIO(plain)).namelist()
    assert any(n.startswith("Application/com.garena.ffvn/") for n in names)
    try: check_feature_zip(plain); raise AssertionError("Tess package unexpectedly accepted")
    except ValueError as e: assert str(e)=="manifest-not-at-root" or str(e)=="external-application-data"
    print("PASS decrypt-vpatch-but-reject-as-SEV-feature")

# SHA-256 tamper check.
good=hashlib.sha256(TEMPLATE.read_bytes()).hexdigest()
bad=hashlib.sha256(TEMPLATE.read_bytes()+b"tamper").hexdigest()
assert good != bad
print("PASS sha256-tamper-detection")
