# SEV Admin backend deployment record

Supabase project: `bpnwzwpqfakwzduiiwvh`

- `sev-admin`: version 9, ACTIVE (existing admin API).
- `sev-control`: version 22, ACTIVE.
- Vercel project: `phamquang-ios-sev-admin-v2`.
- Production deployment: `dpl_6C7ipWvka1xhXM6x3a8RQqFw3Bsm`, READY.
- GitHub commit: `bd01149e089c1650d420830501801f35979f3886` on `main`.

## Custom Payload Staging

1. Added admin-only `/custom-payload.html` for `.vpatch` V99PATCH decryption and ZIP central-directory inventory.
2. The admin page verifies the password via PBKDF2-HMAC-SHA256 (600,000 rounds) and AES-256-GCM chunk authentication in-browser. It rejects malformed headers/chunks, ZIP64, traversal paths, duplicate paths, symlinks, nested ZIP encryption, and inventories above 50 MiB expanded size.
3. The original encrypted VPATCH is uploaded to the private `sev-patches` bucket. The server verifies the uploaded size and SHA-256, and stores the password in Vault through the existing RPC. The package description is marked `[CUSTOM-PAYLOAD-STAGING-ONLY]`; it remains a draft.
4. `sev-control` v22 rejects publishing a marked custom-staging package and rejects linking one to a Feature Toggle.
5. The iOS source now includes a separate **Custom Payload · Staging** screen. It decrypts/inspects the ZIP using existing safe import code and copies regular files only into `Application Support/SEVCustomPayloadStaging/<UUID>` with restrictive permissions and a receipt.

## Safety boundary

Custom staging is not an apply operation. It does not write into Free Fire or another app's sandbox, does not replace runtime binaries, does not inject process memory, and does not execute payload code. The existing SEV Feature flow remains manifest-based and data-only.

## Vercel

The Vercel Production deployment was triggered from GitHub `main` commit `bd01149`. Build events reported `Build Completed` and `Deployment completed`; deployment state is `READY`. The project continues to use its existing SSO protection.

## Verification limits

- JavaScript module syntax and Swift parser checks passed.
- Custom ZIP inventory was tested against a generated ZIP containing an `Application/<bundle-id>/Documents/` path.
- No full Xcode/iOS SDK build or on-device test was possible in this environment.
- No live admin upload was performed, so end-to-end authenticated upload, Vault retrieval, and device staging still require a real admin/device smoke test.
- The catalog currently verifies HTTPS and SHA-256. No detached Ed25519 signature key/configuration was found; no signature verification is claimed.
