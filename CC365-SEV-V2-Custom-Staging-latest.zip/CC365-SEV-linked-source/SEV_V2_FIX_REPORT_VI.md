# CC365 SEV V2 — báo cáo sửa và staging

## Bổ sung trong lượt này
- `AppPatchView.swift`: thêm màn hình **Custom Payload · Staging** riêng.
- `SEVCustomPayloadStager`: mở `.zip`/`.vpatch` bằng luồng import hiện hữu, giải mã VPATCH nếu cần, kiểm tra archive, sau đó chỉ sao chép regular files vào `Application Support/SEVCustomPayloadStaging/<UUID>`; lưu receipt JSON.
- Admin web: thêm `admin-web/custom-payload.html` để giải mã VPATCH trong trình duyệt, kiểm tra metadata ZIP, xem danh sách file và upload bản VPATCH mã hóa vào bucket private.
- `sev-control` v22: chặn publish gói có marker `[CUSTOM-PAYLOAD-STAGING-ONLY]` và chặn liên kết gói đó vào Feature Toggle.
- Vercel Production deploy từ commit `bd01149e089c1650d420830501801f35979f3886` đã ở trạng thái READY.

## Các sửa đổi trước đó vẫn giữ
- `SEVFeaturePackageManager.swift`: retry tải tối đa 3 lần khi lỗi mạng/HTTP 5xx; giữ giới hạn kích thước, SHA-256 và kiểm tra archive.
- `SEVFeatureModuleRuntime.swift`: manifest phải là regular file, không symlink, tối đa 64 KiB.
- `PatchCreationStore.swift`: làm rõ `.vpatch` app-target không phải SEV Feature package.
- SEV Feature chuẩn vẫn cần `sev-feature.json` ở root, chỉ cấu hình module đã biên dịch sẵn và không nạp executable.

## Ranh giới Custom Payload
- Không ghi vào sandbox Free Fire hoặc ứng dụng khác.
- Không thay thế executable/dylib/framework/runtime binary.
- Không inject bộ nhớ, không thực thi script/binary.
- Không tạo Feature Toggle và không tự động apply.
- VPATCH decrypt success chỉ xác thực password/tính toàn vẹn; không chứng minh payload an toàn hoặc tương thích.

## Bảo toàn source
Không sửa file Sandbox, Kernel, KExploit, BQCore hoặc Patch Center trong lượt staging này.

## Giới hạn xác minh
- Swift parser và JavaScript syntax checks đã qua.
- ZIP inventory test đã qua với ZIP kiểm thử có `Application/<bundle-id>/Documents/`.
- Chưa có full Xcode/iOS SDK build hoặc kiểm thử thiết bị thật.
- Chưa chạy end-to-end upload bằng tài khoản admin thật; Vault retrieval và staging trên thiết bị cần smoke test.
- Hiện xác minh HTTPS + SHA-256; không có detached Ed25519 signature/public key trong cấu hình.
