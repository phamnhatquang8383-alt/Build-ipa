# SEV Custom Payload Staging (V99PATCH)

## Mục đích

Custom Payload là loại gói riêng để tiếp nhận `.vpatch` mã hóa V99PATCH, giải mã xác thực, kiểm tra metadata ZIP và lưu bản mã hóa trong private storage ở trạng thái Nháp. Gói không cần `sev-feature.json` vì không phải SEV Feature.

## Luồng quản trị

1. Admin đăng nhập tại SEV Admin V2.
2. Mở `/custom-payload.html` trên cùng domain.
3. Chọn `.vpatch`, nhập mật khẩu, chọn **Giải mã và kiểm tra ZIP**.
4. Công cụ kiểm tra V99PATCH (PBKDF2-HMAC-SHA256 600.000 vòng, AES-256-GCM theo chunk), kích thước, central directory, đường dẫn traversal, symlink, entry trùng và tổng dung lượng.
5. Chọn **Lưu bản mã hóa vào SEV Staging**. Bản gốc mã hóa được upload; server xác minh SHA-256 và lưu secret trong Vault. Mô tả được gắn marker `[CUSTOM-PAYLOAD-STAGING-ONLY]`.
6. Gói ở trạng thái Nháp. Backend từ chối xuất bản marker custom staging và Feature Toggle không thể nhận gói này.

## Luồng trong iOS app

Màn hình **Custom Payload · Staging** dùng `SEVCustomPayloadStager` để mở ZIP/VPATCH do người quản trị cung cấp, giải nén bằng bộ kiểm tra ZIP hiện hữu, rồi sao chép các tệp vào `Application Support/SEVCustomPayloadStaging/<UUID>` với quyền thư mục 0700 và file 0600. Receipt JSON ghi tên gói, số tệp, tổng dung lượng, bundle ID nếu có.

## Ranh giới an toàn

- Không ghi vào sandbox của Free Fire hay ứng dụng khác.
- Không thay thế executable, dylib, framework hoặc runtime binary.
- Không inject bộ nhớ, không gọi kernel exploit, không chạy script hay payload.
- Không tạo Feature Toggle và không kích hoạt gói.
- Việc giải mã VPATCH chỉ xác thực tính toàn vẹn/đúng mật khẩu, không xác nhận nội dung an toàn hoặc tương thích.

## Kiểm thử cần làm trên thiết bị

- ZIP hợp lệ và VPATCH hợp lệ: tạo staging receipt, kiểm tra file count/size.
- Sai password, header hỏng, chunk bị cắt, ZIP traversal, duplicate path, symlink: phải từ chối và xóa thư mục staging tạm.
- Kiểm tra thư mục app/container Free Fire không bị thay đổi trước/sau staging.
