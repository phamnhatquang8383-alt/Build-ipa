import Foundation

/// Runtime bridge for data-driven modules that are compiled into CC365/PhamQuang iOS.
/// Remote packages may configure these modules but may never add executable code.
enum SEVFeatureModuleRuntime {
    struct PackageManifest: Decodable {
        let schemaVersion: Int
        let featureID: String
        let moduleID: String
        let settings: [String: String]
    }

    private static let preferencePrefix = "com.phamquang.cc365.sev-module."
    private static let supportedModules: [String: Set<String>] = [
        "cc365.feature-center.presentation": ["displayTitle", "statusText", "accentStyle"],
        "cc365.diagnostics.banner": ["message", "severity", "visible"],
        "cc365.content.visibility": ["showAdvancedOptions", "showDescriptions"]
    ]

    static func validatePackage(at directory: URL, expectedFeatureID: String) throws {
        let manifest = try readManifest(at: directory)
        guard manifest.schemaVersion == 1,
              manifest.featureID == expectedFeatureID,
              let allowedKeys = supportedModules[manifest.moduleID],
              Set(manifest.settings.keys).isSubset(of: allowedKeys) else {
            throw RuntimeError.unsupportedModule
        }
        for (key, value) in manifest.settings {
            guard !key.isEmpty, value.utf8.count <= 2_048 else { throw RuntimeError.invalidSetting }
        }
        guard directory.standardizedFileURL == directory.resolvingSymlinksInPath().standardizedFileURL else {
            throw RuntimeError.executablePayloadRejected
        }
        guard let enumerator = FileManager.default.enumerator(
            at: directory,
            includingPropertiesForKeys: [.isRegularFileKey, .isDirectoryKey, .isSymbolicLinkKey],
            options: [.skipsHiddenFiles]
        ) else { throw RuntimeError.invalidManifest }
        let forbiddenExtensions: Set<String> = [
            "dylib", "framework", "appex", "app", "sh", "command", "bin", "so",
            "a", "o", "xcframework", "bundle", "plugin", "wasm", "js", "py"
        ]
        for case let url as URL in enumerator {
            let values = try url.resourceValues(forKeys: [.isRegularFileKey, .isDirectoryKey, .isSymbolicLinkKey])
            guard values.isSymbolicLink != true else { throw RuntimeError.executablePayloadRejected }
            if values.isRegularFile == true && forbiddenExtensions.contains(url.pathExtension.lowercased()) {
                throw RuntimeError.executablePayloadRejected
            }
        }
    }

    static func activate(featureID: String, packageDirectory: URL) throws {
        let manifest = try readManifest(at: packageDirectory)
        try validatePackage(at: packageDirectory, expectedFeatureID: featureID)
        let defaults = UserDefaults.standard
        let prefix = preferencePrefix + featureID + "."
        // Clear only this feature's namespaced values, then install its allowlisted settings.
        for key in defaults.dictionaryRepresentation().keys where key.hasPrefix(prefix) {
            defaults.removeObject(forKey: key)
        }
        for (key, value) in manifest.settings {
            defaults.set(value, forKey: prefix + key)
        }
        defaults.set(manifest.moduleID, forKey: preferencePrefix + featureID + ".moduleID")
    }

    static func deactivate(featureID: String) {
        let defaults = UserDefaults.standard
        let prefix = preferencePrefix + featureID + "."
        for key in defaults.dictionaryRepresentation().keys where key.hasPrefix(prefix) {
            defaults.removeObject(forKey: key)
        }
    }

    static func string(_ key: String, featureID: String) -> String? {
        UserDefaults.standard.string(forKey: preferencePrefix + featureID + "." + key)
    }

    static func bool(_ key: String, featureID: String) -> Bool? {
        let name = preferencePrefix + featureID + "." + key
        guard UserDefaults.standard.object(forKey: name) != nil else { return nil }
        if let value = UserDefaults.standard.object(forKey: name) as? Bool { return value }
        if let value = UserDefaults.standard.string(forKey: name)?.lowercased() {
            if ["true", "1", "yes", "on"].contains(value) { return true }
            if ["false", "0", "no", "off"].contains(value) { return false }
        }
        return nil
    }


    static func string(_ key: String, moduleID: String) -> String? {
        guard let featureID = activeFeatureIDs(for: moduleID).first else { return nil }
        return string(key, featureID: featureID)
    }

    static func bool(_ key: String, moduleID: String) -> Bool? {
        guard let featureID = activeFeatureIDs(for: moduleID).first else { return nil }
        return bool(key, featureID: featureID)
    }

    private static func activeFeatureIDs(for moduleID: String) -> [String] {
        let defaults = UserDefaults.standard
        let suffix = ".moduleID"
        return defaults.dictionaryRepresentation().keys.compactMap { key in
            guard key.hasPrefix(preferencePrefix), key.hasSuffix(suffix),
                  defaults.string(forKey: key) == moduleID else { return nil }
            let start = key.index(key.startIndex, offsetBy: preferencePrefix.count)
            let end = key.index(key.endIndex, offsetBy: -suffix.count)
            return String(key[start..<end])
        }.sorted()
    }

    private static func readManifest(at directory: URL) throws -> PackageManifest {
        let url = directory.appendingPathComponent("sev-feature.json", isDirectory: false)
        guard FileManager.default.fileExists(atPath: url.path) else { throw RuntimeError.manifestMissing }
        let values = try url.resourceValues(forKeys: [.isRegularFileKey, .isSymbolicLinkKey, .fileSizeKey])
        guard values.isRegularFile == true, values.isSymbolicLink != true,
              let size = values.fileSize, size > 0, size <= 64 * 1_024 else {
            throw RuntimeError.invalidManifest
        }
        do {
            let data = try Data(contentsOf: url, options: [.mappedIfSafe])
            guard data.count <= 64 * 1_024 else { throw RuntimeError.invalidManifest }
            return try JSONDecoder().decode(PackageManifest.self, from: data)
        } catch {
            throw RuntimeError.invalidManifest
        }
    }

    enum RuntimeError: LocalizedError {
        case manifestMissing, invalidManifest, unsupportedModule, invalidSetting, executablePayloadRejected
        var errorDescription: String? {
            switch self {
            case .manifestMissing: return "Package thiếu sev-feature.json."
            case .invalidManifest: return "Manifest package không hợp lệ."
            case .unsupportedModule: return "Module hoặc trường cấu hình chưa được tích hợp trong phiên bản app này."
            case .invalidSetting: return "Giá trị cấu hình vượt giới hạn cho phép."
            case .executablePayloadRejected: return "Package chứa mã thực thi không được hỗ trợ. Chỉ nhận dữ liệu cấu hình."
            }
        }
    }
}
