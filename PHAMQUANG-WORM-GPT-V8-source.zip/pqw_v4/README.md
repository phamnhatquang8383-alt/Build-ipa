# PHAMQUANG WORM GPT — iOS source project

SwiftUI iPhone/iPad app. Open `PHAMQUANG-WORM-GPT.xcodeproj` in Xcode 15+ (recommended Xcode 16+) and select an iOS 16+ simulator or device.

## V5 work included in this source update

- AI Chat using an OpenAI-compatible `POST /chat/completions` endpoint.
- AI persona tuned for direct, technical, code-first answers and project-analysis workflows. A system prompt cannot disable safety rules, account restrictions, quotas, or provider-side safeguards.
- PDF and UTF-8 text/source import with multi-file context (8 MB per file).
- GitHub repository listing, file read, create/update, and commit through the GitHub Contents API.
- Vercel project listing, deployment history, and redeploy of an existing deployment.
- Single-owner device mode: tokens in iOS Keychain, confirmation dialogs before GitHub writes and Vercel redeploys, and a local activity log in UserDefaults.
- Dark SwiftUI dashboard and Cyber Lab prompt library.

## Connect services

### AI provider
1. Open **AI Chat → settings**.
2. Enter the provider Base URL, model ID, and API key.
3. The Base URL should normally end at `/v1`; the app appends `/chat/completions`.
4. The provider must support the OpenAI-compatible Chat Completions schema used by this client.

### GitHub
1. Create a GitHub personal access token with repository metadata/read access and **Contents: Read and write** for the repositories you intend to edit.
2. Paste it in **Projects & Deploy → GitHub** and load repositories.
3. Select a repository, enter a file path, and choose **Đọc file** to load its current UTF-8 contents.
4. Edit the content and select **Ghi file & commit**. Confirm the operation in the confirmation dialog.
5. Existing files are updated using their current blob SHA; paths that do not exist are created. The commit is made on the selected branch or the repository default branch.

### Vercel
1. Create a Vercel access token with permission to read projects/deployments and redeploy deployments in the intended team/account.
2. Paste it in **Projects & Deploy → Vercel** and load projects.
3. Select **Xem deployment** for a project, then choose **Redeploy** beside an existing deployment and confirm.

## Owner mode and security

This build is designed for one owner on one device; it does not implement multiple accounts or a remote role system. GitHub and Vercel tokens are stored in iOS Keychain. GitHub writes and Vercel redeploys require an explicit in-app confirmation. The local activity log records successful GitHub reads/commits and Vercel redeploy requests. The log is local to the device and is not tamper-proof or remotely synchronized.

For personal testing, device-local tokens may be acceptable. For a public release, use OAuth and a backend that protects provider credentials, applies least-privilege scopes, rate limits requests, and stores tamper-resistant audit logs. Never commit real tokens to source control.

## Current limitations

- The GitHub editor reads and writes individual UTF-8 text files. It does not yet provide a full repository tree browser, branch creation UI, pull-request workflow, or multi-file atomic commits.
- Vercel currently lists projects/deployments and redeploys an existing deployment. It does not create a new deployment from arbitrary local files or run build commands on the device.
- AI Agent behavior is currently a prompt/workflow inside chat with uploaded-file context; it does not autonomously execute shell commands or directly edit a repository without the GitHub editor workflow.
- File import supports PDF text extraction and UTF-8 text/source formats. It does not provide OCR for scanned PDFs or general image/video/audio analysis.
- The AI settings screen currently configures one active OpenAI-compatible provider/model at a time. Provider-side model availability and policy are controlled by that provider.
- No signed IPA is included. Building/signing requires macOS, Xcode, and the owner's Apple signing identity/provisioning profile.

## Build

1. Open `PHAMQUANG-WORM-GPT.xcodeproj` on macOS with Xcode 15 or newer.
2. Choose the app target and set the Apple Developer Team under **Signing & Capabilities**.
3. Select an iOS 16+ simulator or device and build/run.
4. For an IPA, use **Product → Archive → Distribute App** and follow Apple's signing workflow.


## V6 additions
- Multi-provider profiles: each profile stores its Base URL, model ID and API key independently; API keys are kept in iOS Keychain.
- Provider selector and add/remove controls in AI Chat settings.
- AI Agent workflow toggle in chat. It requests repository/file analysis, per-file change plans, patch-ready output and test steps from the selected model. It does not silently execute arbitrary code or claim a commit/deployment occurred.
- Existing GitHub file read/write+commit and Vercel deployment history/redeploy actions remain behind explicit confirmation.
- The AI persona is direct and code-first. System prompts cannot disable safeguards enforced by the model/API provider.


## V7: GitHub AI Agent file proposal
- The Projects tab now has an AI Agent action in the GitHub file editor.
- Load a UTF-8 file from a repository, enter a focused change request, and let the configured active AI provider propose the complete updated file.
- The proposal is placed in the editor for review. It is NOT committed automatically; the existing confirmation dialog is required before the GitHub Contents API write/commit.
- The Agent uses the active provider's configured system prompt and API key from Keychain. It does not bypass provider-side model policies or execute arbitrary code.
- Validation performed for this source update: Swift frontend syntax parsing for all `.swift` files. A full iOS build/run still requires Xcode on macOS and a configured signing team.


## V8: Multi-file GitHub AI Agent
- The Projects workspace includes a multi-file workflow for up to five explicitly listed UTF-8 repository paths.
- The app reads only the listed files, sends their contents plus the requested coding task to the selected AI provider, and parses a structured JSON response.
- The proposal must contain exactly the requested paths; unexpected, missing, duplicate, empty, or oversized file contents are rejected before any write.
- The app displays per-file summaries and requires an explicit confirmation before applying the batch.
- Each file is committed separately through the GitHub Contents API. If a later commit fails, earlier successful commits remain; the app reports the partial result and does not claim atomic rollback.
- This is a code-editing workflow for repositories the owner is authorized to access. The AI system prompt does not remove provider-side safety controls.
- Validation: source-level structural checks and Swift parser checks where the Swift toolchain is available. Full device build/run and live GitHub/API tests require Xcode, valid credentials, and network access.
