import Foundation

struct GitHubRepository: Decodable, Identifiable {
    let id: Int
    let full_name: String
    let html_url: String
    let description: String?
    let privateRepo: Bool?
    enum CodingKeys: String, CodingKey { case id, full_name, html_url, description; case privateRepo = "private" }
}

struct VercelProject: Decodable, Identifiable {
    let id: String
    let name: String
    let framework: String?
    let link: VercelLink?
    struct VercelLink: Decodable { let repo: String? }
}

struct VercelProjectsResponse: Decodable { let projects: [VercelProject] }

struct VercelDeployment: Decodable, Identifiable {
    let uid: String
    let name: String?
    let url: String?
    let state: String?
    let created: Double?
    var id: String { uid }
}
struct VercelDeploymentsResponse: Decodable { let deployments: [VercelDeployment] }

struct GitHubContentResponse: Decodable { let sha: String }

enum IntegrationError: LocalizedError {
    case missingToken, invalidResponse(Int, String)
    var errorDescription: String? {
        switch self {
        case .missingToken: return "Bạn chưa nhập access token."
        case .invalidResponse(let code, let message): return "Dịch vụ trả về HTTP \(code): \(message)"
        }
    }
}

enum IntegrationService {
    static func githubRepositories(token: String) async throws -> [GitHubRepository] {
        guard !token.isEmpty else { throw IntegrationError.missingToken }
        var request = URLRequest(url: URL(string: "https://api.github.com/user/repos?per_page=100&sort=updated")!)
        request.setValue("Bearer \(token)", forHTTPHeaderField: "Authorization")
        request.setValue("application/vnd.github+json", forHTTPHeaderField: "Accept")
        request.setValue("2022-11-28", forHTTPHeaderField: "X-GitHub-Api-Version")
        let (data, response) = try await URLSession.shared.data(for: request)
        try validate(data, response)
        return try JSONDecoder().decode([GitHubRepository].self, from: data)
    }

    static func vercelProjects(token: String) async throws -> [VercelProject] {
        guard !token.isEmpty else { throw IntegrationError.missingToken }
        var request = URLRequest(url: URL(string: "https://api.vercel.com/v9/projects?limit=100")!)
        request.setValue("Bearer \(token)", forHTTPHeaderField: "Authorization")
        let (data, response) = try await URLSession.shared.data(for: request)
        try validate(data, response)
        return try JSONDecoder().decode(VercelProjectsResponse.self, from: data).projects
    }

    static func readGitHubFile(token: String, repository: String, path: String, branch: String?) async throws -> String {
        guard !token.isEmpty else { throw IntegrationError.missingToken }
        let parts = repository.split(separator: "/")
        guard parts.count == 2,
              let encodedPath = path.addingPercentEncoding(withAllowedCharacters: .urlPathAllowed),
              var components = URLComponents(string: "https://api.github.com/repos/\(parts[0])/\(parts[1])/contents/\(encodedPath)") else { throw URLError(.badURL) }
        if let branch, !branch.isEmpty { components.queryItems = [URLQueryItem(name: "ref", value: branch)] }
        var request = URLRequest(url: components.url!)
        request.setValue("Bearer \(token)", forHTTPHeaderField: "Authorization")
        request.setValue("application/vnd.github.raw+json", forHTTPHeaderField: "Accept")
        request.setValue("2022-11-28", forHTTPHeaderField: "X-GitHub-Api-Version")
        let (data, response) = try await URLSession.shared.data(for: request)
        try validate(data, response)
        guard let content = String(data: data, encoding: .utf8) else { throw URLError(.cannotDecodeContentData) }
        return content
    }

    static func writeGitHubFile(token: String, repository: String, path: String, content: String, message: String, branch: String?) async throws -> String {
        guard !token.isEmpty else { throw IntegrationError.missingToken }
        let parts = repository.split(separator: "/")
        guard parts.count == 2, !path.isEmpty,
              let encodedPath = path.addingPercentEncoding(withAllowedCharacters: .urlPathAllowed),
              let url = URL(string: "https://api.github.com/repos/\(parts[0])/\(parts[1])/contents/\(encodedPath)") else { throw URLError(.badURL) }
        var existingSHA: String?
        var get = URLRequest(url: url)
        get.setValue("Bearer \(token)", forHTTPHeaderField: "Authorization")
        get.setValue("application/vnd.github+json", forHTTPHeaderField: "Accept")
        get.setValue("2022-11-28", forHTTPHeaderField: "X-GitHub-Api-Version")
        let (existingData, existingResponse) = try await URLSession.shared.data(for: get)
        if let http = existingResponse as? HTTPURLResponse, http.statusCode == 200 {
            existingSHA = try JSONDecoder().decode(GitHubContentResponse.self, from: existingData).sha
        } else if let http = existingResponse as? HTTPURLResponse, http.statusCode != 404 {
            try validate(existingData, existingResponse)
        }
        var payload: [String: Any] = ["message": message, "content": Data(content.utf8).base64EncodedString()]
        if let existingSHA { payload["sha"] = existingSHA }
        if let branch, !branch.isEmpty { payload["branch"] = branch }
        var put = URLRequest(url: url)
        put.httpMethod = "PUT"
        put.setValue("Bearer \(token)", forHTTPHeaderField: "Authorization")
        put.setValue("application/vnd.github+json", forHTTPHeaderField: "Accept")
        put.setValue("2022-11-28", forHTTPHeaderField: "X-GitHub-Api-Version")
        put.setValue("application/json", forHTTPHeaderField: "Content-Type")
        put.httpBody = try JSONSerialization.data(withJSONObject: payload)
        let (data, response) = try await URLSession.shared.data(for: put)
        try validate(data, response)
        let object = try JSONSerialization.jsonObject(with: data) as? [String: Any]
        let commit = object?["commit"] as? [String: Any]
        return commit?["sha"] as? String ?? "Đã ghi file"
    }

    static func vercelDeployments(token: String, projectID: String) async throws -> [VercelDeployment] {
        guard !token.isEmpty else { throw IntegrationError.missingToken }
        var components = URLComponents(string: "https://api.vercel.com/v6/deployments")!
        components.queryItems = [URLQueryItem(name: "projectId", value: projectID), URLQueryItem(name: "limit", value: "10")]
        var request = URLRequest(url: components.url!)
        request.setValue("Bearer \(token)", forHTTPHeaderField: "Authorization")
        let (data, response) = try await URLSession.shared.data(for: request)
        try validate(data, response)
        return try JSONDecoder().decode(VercelDeploymentsResponse.self, from: data).deployments
    }

    static func redeployVercel(token: String, deploymentID: String) async throws -> String {
        guard !token.isEmpty else { throw IntegrationError.missingToken }
        guard let url = URL(string: "https://api.vercel.com/v13/deployments/\(deploymentID)/redeploy") else { throw URLError(.badURL) }
        var request = URLRequest(url: url)
        request.httpMethod = "POST"
        request.setValue("Bearer \(token)", forHTTPHeaderField: "Authorization")
        let (data, response) = try await URLSession.shared.data(for: request)
        try validate(data, response)
        let object = try JSONSerialization.jsonObject(with: data) as? [String: Any]
        return object?["id"] as? String ?? "Redeploy request accepted"
    }

    private static func validate(_ data: Data, _ response: URLResponse) throws {
        guard let http = response as? HTTPURLResponse else { throw URLError(.badServerResponse) }
        guard (200...299).contains(http.statusCode) else {
            let body = String(data: data.prefix(1000), encoding: .utf8) ?? "Request failed"
            throw IntegrationError.invalidResponse(http.statusCode, body)
        }
    }
}
