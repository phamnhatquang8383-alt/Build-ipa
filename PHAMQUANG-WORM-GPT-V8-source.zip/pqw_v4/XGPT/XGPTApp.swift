import SwiftUI

@main
struct PhamQuangWormGPTApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
                .preferredColorScheme(.dark)
        }
    }
}
