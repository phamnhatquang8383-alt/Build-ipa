import SwiftUI
import UIKit
import UniformTypeIdentifiers
import PDFKit

private enum PQTheme {
    static let bg = Color(red: 0.025, green: 0.035, blue: 0.055)
    static let panel = Color(red: 0.055, green: 0.075, blue: 0.095)
    static let neon = Color(red: 0.20, green: 0.96, blue: 0.72)
    static let cyan = Color(red: 0.20, green: 0.78, blue: 1.0)
    static let muted = Color.white.opacity(0.55)
}

struct ContentView: View {
    @State private var tab = 0
    @State private var searchText = ""
    @State private var selected: PromptPreset?

    var body: some View {
        TabView(selection: $tab) {
            DashboardView(onOpenChat: { tab = 1 }, onOpenLibrary: { tab = 3 })
                .tabItem { Label("Tổng quan", systemImage: "square.grid.2x2.fill") }.tag(0)
            ChatLabView()
                .tabItem { Label("AI Chat", systemImage: "bubble.left.and.bubble.right.fill") }.tag(1)
            CyberLabView()
                .tabItem { Label("Cyber Lab", systemImage: "shield.lefthalf.filled") }.tag(2)
            library
                .tabItem { Label("Thư viện", systemImage: "terminal.fill") }.tag(3)
            IntegrationsView()
                .tabItem { Label("Projects", systemImage: "arrow.triangle.branch") }.tag(4)
        }
        .tint(PQTheme.neon)
        .preferredColorScheme(.dark)
        .sheet(item: $selected) { preset in
            PromptDetailView(preset: preset)
                .presentationDetents([.medium, .large])
                .presentationDragIndicator(.visible)
        }
    }

    private var library: some View {
        NavigationStack {
            ZStack {
                PQTheme.bg.ignoresSafeArea()
                ScrollView {
                    VStack(alignment: .leading, spacing: 18) {
                        pageHeader("PROMPT DATABASE", title: "Thư viện kỹ thuật", subtitle: "Persona và bộ hướng dẫn chuyên môn")
                        HStack {
                            Image(systemName: "magnifyingglass").foregroundStyle(PQTheme.muted)
                            TextField("Tìm công cụ hoặc persona...", text: $searchText).autocorrectionDisabled()
                        }
                        .padding(13).background(PQTheme.panel, in: RoundedRectangle(cornerRadius: 14))
                        ForEach(filteredPresets) { preset in
                            Button { selected = preset } label: { PresetCard(preset: preset) }.buttonStyle(.plain)
                        }
                    }.padding(20)
                }
            }
            .toolbar(.hidden, for: .navigationBar)
        }
    }

    private var filteredPresets: [PromptPreset] {
        guard !searchText.isEmpty else { return PromptPreset.all }
        return PromptPreset.all.filter { $0.title.localizedCaseInsensitiveContains(searchText) || $0.subtitle.localizedCaseInsensitiveContains(searchText) }
    }
}

private struct DashboardView: View {
    let onOpenChat: () -> Void
    let onOpenLibrary: () -> Void

    var body: some View {
        NavigationStack {
            ZStack {
                PQTheme.bg.ignoresSafeArea()
                ScrollView {
                    VStack(alignment: .leading, spacing: 22) {
                        HStack(alignment: .top) {
                            VStack(alignment: .leading, spacing: 6) {
                                Text("PHAMQUANG").font(.system(size: 12, weight: .black, design: .monospaced)).tracking(3).foregroundStyle(PQTheme.neon)
                                Text("WORM GPT").font(.system(size: 34, weight: .black, design: .rounded)).foregroundStyle(.white)
                                Text("AI • SOFTWARE • CYBERSECURITY").font(.system(size: 10, weight: .bold, design: .monospaced)).tracking(1.3).foregroundStyle(PQTheme.muted)
                            }
                            Spacer()
                            Image(systemName: "cpu.fill").font(.system(size: 27)).foregroundStyle(PQTheme.neon)
                                .frame(width: 58, height: 58).background(PQTheme.neon.opacity(0.10), in: RoundedRectangle(cornerRadius: 18))
                                .overlay(RoundedRectangle(cornerRadius: 18).stroke(PQTheme.neon.opacity(0.35)))
                        }.padding(.top, 18)

                        HStack(spacing: 10) {
                            StatusPill(title: "CORE", value: "LOCAL UI", color: PQTheme.neon)
                            StatusPill(title: "MODE", value: "TECH LAB", color: PQTheme.cyan)
                        }

                        VStack(alignment: .leading, spacing: 10) {
                            Text("CONTROL CENTER").font(.system(size: 10, weight: .bold, design: .monospaced)).tracking(2).foregroundStyle(PQTheme.neon)
                            Text("Xin chào, Quang.").font(.title2.bold()).foregroundStyle(.white)
                            Text("Không gian làm việc cho lập trình, phân tích hệ thống và nghiên cứu bảo mật có ủy quyền.").font(.subheadline).foregroundStyle(PQTheme.muted)
                            Button(action: onOpenChat) {
                                HStack { Image(systemName: "bubble.left.and.bubble.right.fill"); Text("Mở AI Chat"); Spacer(); Image(systemName: "arrow.up.right") }
                                    .font(.headline).foregroundStyle(PQTheme.bg).padding(16).background(PQTheme.neon, in: RoundedRectangle(cornerRadius: 14))
                            }.padding(.top, 6)
                        }.padding(18).background(PQTheme.panel, in: RoundedRectangle(cornerRadius: 20)).overlay(RoundedRectangle(cornerRadius: 20).stroke(PQTheme.neon.opacity(0.18)))

                        Text("MODULES").font(.system(size: 10, weight: .bold, design: .monospaced)).tracking(2).foregroundStyle(PQTheme.neon)
                        LazyVGrid(columns: [GridItem(.flexible()), GridItem(.flexible())], spacing: 12) {
                            ModuleTile(icon: "chevron.left.forwardslash.chevron.right", title: "Code Engineer", detail: "Viết & rà soát mã", color: PQTheme.cyan)
                            ModuleTile(icon: "shield.checkered", title: "Security Lab", detail: "Phòng lab được phép", color: PQTheme.neon)
                            ModuleTile(icon: "magnifyingglass", title: "Code Analysis", detail: "Phân tích & debug", color: .orange)
                            ModuleTile(icon: "shippingbox.fill", title: "Project Architect", detail: "Thiết kế dự án lớn", color: .purple)
                        }
                        Button(action: onOpenLibrary) {
                            HStack { Text("Mở thư viện prompt").font(.subheadline.weight(.semibold)); Spacer(); Image(systemName: "arrow.right") }
                                .foregroundStyle(.white).padding(16).background(.white.opacity(0.055), in: RoundedRectangle(cornerRadius: 14))
                        }
                        Text("AI CHAT • FILE CONTEXT • PROJECT INTEGRATIONS")
                            .font(.system(size: 9, weight: .medium, design: .monospaced)).foregroundStyle(PQTheme.muted)
                    }.padding(20)
                }
            }.toolbar(.hidden, for: .navigationBar)
        }
    }
}

private struct ChatLabView: View {
    @StateObject private var store = AISettingsStore()
    @State private var input = ""
    @State private var messages: [ChatMessage] = []
    @State private var history: [APIChatMessage] = []
    @State private var isSending = false
    @State private var showSettings = false
    @State private var errorText: String?
    @State private var showImporter = false
    @State private var attachedText = ""
    @State private var attachedName: String?

    var body: some View {
        NavigationStack {
            ZStack {
                PQTheme.bg.ignoresSafeArea()
                VStack(spacing: 0) {
                    HStack {
                        pageHeader("MODEL WORKSPACE", title: "AI Chat", subtitle: "OpenAI-compatible API • \(store.settings.model)")
                        Spacer()
                        Button { showSettings = true } label: {
                            Image(systemName: "slider.horizontal.3").font(.title3).foregroundStyle(PQTheme.neon)
                                .frame(width: 42, height: 42).background(PQTheme.panel, in: RoundedRectangle(cornerRadius: 12))
                        }
                    }.padding(.horizontal, 20).padding(.top, 18).padding(.bottom, 12)

                    if let errorText {
                        Text(errorText).font(.caption).foregroundStyle(.orange).frame(maxWidth: .infinity, alignment: .leading)
                            .padding(.horizontal, 18).padding(.bottom, 8)
                    }
                    ScrollViewReader { proxy in
                        ScrollView {
                            VStack(spacing: 12) {
                                if messages.isEmpty {
                                    VStack(spacing: 10) {
                                        Image(systemName: "cpu.fill").font(.system(size: 36)).foregroundStyle(PQTheme.neon)
                                        Text("PHAMQUANG WORM GPT sẵn sàng").font(.headline).foregroundStyle(.white)
                                        Text("Nhập API key và model trong cài đặt để bắt đầu trò chuyện.").font(.caption).foregroundStyle(PQTheme.muted).multilineTextAlignment(.center)
                                    }.frame(maxWidth: .infinity).padding(.vertical, 60)
                                }
                                ForEach(messages) { msg in
                                    HStack {
                                        if msg.isUser { Spacer(minLength: 42) }
                                        Text(msg.text).font(.system(.subheadline, design: .rounded)).foregroundStyle(.white.opacity(0.92))
                                            .textSelection(.enabled).padding(13)
                                            .background(msg.isUser ? PQTheme.neon.opacity(0.16) : PQTheme.panel, in: RoundedRectangle(cornerRadius: 15))
                                            .overlay(RoundedRectangle(cornerRadius: 15).stroke(msg.isUser ? PQTheme.neon.opacity(0.28) : .white.opacity(0.06)))
                                        if !msg.isUser { Spacer(minLength: 30) }
                                    }.id(msg.id)
                                }
                                if isSending {
                                    HStack { ProgressView().tint(PQTheme.neon); Text("Đang suy nghĩ...").font(.caption).foregroundStyle(PQTheme.muted); Spacer() }.padding(.horizontal, 8)
                                }
                            }.padding(18)
                        }
                        .onChange(of: messages.count) { _ in
                            if let last = messages.last { withAnimation { proxy.scrollTo(last.id, anchor: .bottom) } }
                        }
                    }
                    if let attachedName {
                        HStack(spacing: 8) {
                            Image(systemName: "paperclip").foregroundStyle(PQTheme.neon)
                            Text(attachedName).font(.caption).lineLimit(1).foregroundStyle(.white)
                            Spacer()
                            Button { self.attachedName = nil; attachedText = "" } label: {
                                Image(systemName: "xmark.circle.fill").foregroundStyle(PQTheme.muted)
                            }
                        }.padding(.horizontal, 16).padding(.top, 8)
                    }
                    HStack(spacing: 9) {
                        Button { showImporter = true } label: {
                            Image(systemName: "paperclip").font(.headline).foregroundStyle(PQTheme.neon)
                                .frame(width: 42, height: 44).background(PQTheme.panel, in: RoundedRectangle(cornerRadius: 13))
                        }.disabled(isSending)
                        Button { agentMode.toggle() } label: {
                            Image(systemName: agentMode ? "cpu.fill" : "cpu")
                                .font(.headline).foregroundStyle(agentMode ? PQTheme.bg : PQTheme.cyan)
                                .frame(width: 42, height: 44)
                                .background(agentMode ? PQTheme.neon : PQTheme.panel, in: RoundedRectangle(cornerRadius: 13))
                        }.disabled(isSending)
                        TextField(agentMode ? "Giao nhiệm vụ cho AI Agent..." : "Nhập câu hỏi...", text: $input, axis: .vertical).lineLimit(1...5)
                            .padding(12).background(PQTheme.panel, in: RoundedRectangle(cornerRadius: 13))
                            .disabled(isSending)
                        Button(action: send) {
                            Image(systemName: isSending ? "hourglass" : "arrow.up").font(.headline).foregroundStyle(PQTheme.bg)
                                .frame(width: 44, height: 44).background(PQTheme.neon, in: RoundedRectangle(cornerRadius: 13))
                        }.disabled((input.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty && attachedText.isEmpty) || isSending)
                            .opacity((input.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty && attachedText.isEmpty) || isSending ? 0.45 : 1)
                    }.padding(14)
                }
            }.toolbar(.hidden, for: .navigationBar)
                .fileImporter(isPresented: $showImporter, allowedContentTypes: [.item], allowsMultipleSelection: true, onCompletion: importFile)
                .sheet(isPresented: $showSettings) { AISettingsView(store: store).presentationDetents([.large]) }
        }
    }

    private func send() {
        let question = input.trimmingCharacters(in: .whitespacesAndNewlines)
        let agentInstructions = agentMode ? """
        [AGENT WORKFLOW]
        Làm việc như trợ lý kỹ thuật cho dự án. Đọc toàn bộ ngữ cảnh được cung cấp; xác định cấu trúc, mục tiêu và ràng buộc; đề xuất kế hoạch theo từng file; cung cấp patch hoặc nội dung file hoàn chỉnh; nêu lệnh kiểm thử và kết quả mong đợi. Không khẳng định đã ghi file, commit hoặc deploy nếu chưa có thao tác tương ứng thành công. Nếu thiếu nội dung repository, yêu cầu cung cấp file hoặc kết nối phù hợp.
        """ : ""
        let text = [agentInstructions, attachedText, question].filter { !$0.isEmpty }.joined(separator: "\n\n")
        guard !text.isEmpty, !isSending else { return }
        let displayText = [attachedName.map { "Tệp đính kèm: \($0)" }, question].compactMap { $0 }.filter { !$0.isEmpty }.joined(separator: "\n")
        input = ""
        attachedText = ""
        attachedName = nil
        errorText = nil
        messages.append(ChatMessage(isUser: true, text: displayText.isEmpty ? "Đã gửi nội dung tệp" : displayText))
        history.append(APIChatMessage(role: "user", content: text))
        isSending = true
        let currentHistory = history
        let currentSettings = store.settings
        let currentKey = store.apiKey
        Task {
            do {
                let answer = try await AIService.reply(messages: currentHistory, settings: currentSettings, apiKey: currentKey)
                history.append(APIChatMessage(role: "assistant", content: answer))
                messages.append(ChatMessage(isUser: false, text: answer))
            } catch {
                errorText = error.localizedDescription
                messages.append(ChatMessage(isUser: false, text: "Không thể gọi AI: \(error.localizedDescription)"))
                if !history.isEmpty { history.removeLast() }
            }
            isSending = false
        }
    }

    private func importFile(_ result: Result<[URL], Error>) {
        do {
            let urls = try result.get()
            guard !urls.isEmpty else { return }
            var imported: [String] = []
            var names: [String] = []
            for url in urls {
                let allowed = url.startAccessingSecurityScopedResource()
                defer { if allowed { url.stopAccessingSecurityScopedResource() } }
                let data = try Data(contentsOf: url)
                guard data.count <= 8 * 1024 * 1024 else {
                    throw NSError(domain: "PQWFile", code: 4, userInfo: [NSLocalizedDescriptionKey: "Tệp \(url.lastPathComponent) vượt giới hạn 8 MB."])
                }
                let ext = url.pathExtension.lowercased()
                let extracted: String
                if ext == "pdf" {
                    guard let pdf = PDFDocument(data: data), let text = pdf.string, !text.isEmpty else {
                        throw NSError(domain: "PQWFile", code: 2, userInfo: [NSLocalizedDescriptionKey: "Không trích xuất được văn bản PDF: \(url.lastPathComponent)"])
                    }
                    extracted = text
                } else if ["txt", "md", "swift", "py", "js", "ts", "tsx", "jsx", "json", "xml", "html", "css", "c", "h", "cpp", "hpp", "rs", "go", "java", "kt", "sql", "yaml", "yml", "toml", "sh", "log", "csv"].contains(ext),
                          let text = String(data: data, encoding: .utf8) {
                    extracted = text
                } else {
                    throw NSError(domain: "PQWFile", code: 3, userInfo: [NSLocalizedDescriptionKey: "Định dạng chưa hỗ trợ: \(url.lastPathComponent). Dùng PDF hoặc văn bản/mã nguồn UTF-8."])
                }
                names.append(url.lastPathComponent)
                imported.append("--- FILE: \(url.lastPathComponent) ---\n\(String(extracted.prefix(90000)))")
            }
            attachedName = names.joined(separator: ", ")
            attachedText = "Các tệp đính kèm dưới đây là ngữ cảnh dự án. Hãy đọc, tóm tắt cấu trúc, xác định vấn đề và thực hiện yêu cầu của người dùng dựa trên nội dung. Nếu cần sửa code, trả về thay đổi cụ thể theo tệp.\n\n" + imported.joined(separator: "\n\n")
            errorText = nil
        } catch {
            errorText = "Không thể đọc tệp: \(error.localizedDescription)"
        }
    }
}

private struct AISettingsView: View {
    @ObservedObject var store: AISettingsStore
    @Environment(\.dismiss) private var dismiss
    @State private var revealKey = false
    @State private var newProviderName = ""

    var body: some View {
        NavigationStack {
            Form {
                Section("Danh sách nhà cung cấp") {
                    Picker("Provider đang dùng", selection: Binding(
                        get: { store.activeProfileID },
                        set: { store.activateProvider($0) }
                    )) {
                        ForEach(store.providerProfiles) { profile in
                            Text(profile.name).tag(profile.id)
                        }
                    }
                    HStack {
                        TextField("Tên provider mới", text: $newProviderName)
                        Button("Thêm") {
                            store.addProvider(name: newProviderName.trimmingCharacters(in: .whitespacesAndNewlines))
                            newProviderName = ""
                        }
                    }
                    if store.providerProfiles.count > 1 {
                        Button("Xóa provider hiện tại", role: .destructive) {
                            store.removeProvider(store.activeProfileID)
                        }
                    }
                    Text("Mỗi provider có Base URL, Model ID và API key riêng; khóa được lưu trong Keychain.")
                        .font(.caption).foregroundStyle(.secondary)
                }
                Section("Nhà cung cấp API") {
                    TextField("Base URL", text: $store.settings.baseURL).textInputAutocapitalization(.never).autocorrectionDisabled().keyboardType(.URL)
                    TextField("Model ID", text: $store.settings.model).textInputAutocapitalization(.never).autocorrectionDisabled()
                    HStack {
                        Group {
                            if revealKey { TextField("API key", text: $store.apiKey) }
                            else { SecureField("API key", text: $store.apiKey) }
                        }.textInputAutocapitalization(.never).autocorrectionDisabled()
                        Button { revealKey.toggle() } label: { Image(systemName: revealKey ? "eye.slash" : "eye") }
                    }
                    Text("Hỗ trợ endpoint tương thích OpenAI: Base URL + /chat/completions. Tên model phụ thuộc nhà cung cấp và quyền API của bạn.")
                        .font(.caption).foregroundStyle(.secondary)
                }
                Section("Chỉ dẫn hệ thống") {
                    TextEditor(text: $store.settings.systemPrompt).frame(minHeight: 180)
                    Button("Khôi phục chỉ dẫn mặc định") { store.settings.systemPrompt = AISettings().systemPrompt }
                }
                Section {
                    Label("API key được lưu trong iOS Keychain trên thiết bị này.", systemImage: "lock.shield")
                    Text("Đối với ứng dụng phát hành cho nhiều người, không đặt khóa dùng chung trong app. Hãy dùng backend riêng để giữ bí mật API key và kiểm soát chi phí.")
                        .font(.caption).foregroundStyle(.secondary)
                }
            }
            .scrollContentBackground(.hidden).background(PQTheme.bg)
            .navigationTitle("Cài đặt AI").navigationBarTitleDisplayMode(.inline)
            .toolbar { ToolbarItem(placement: .topBarTrailing) { Button("Xong") { dismiss() }.tint(PQTheme.neon) } }
        }.preferredColorScheme(.dark)
    }
}

private struct AgentBatchChange: Codable, Identifiable {
    let path: String
    let content: String
    let summary: String
    var id: String { path }
}

private struct AgentBatchResponse: Codable {
    let changes: [AgentBatchChange]
}

private struct IntegrationsView: View {
    @State private var githubToken = KeychainStore.read(account: "github-token")
    @State private var vercelToken = KeychainStore.read(account: "vercel-token")
    @State private var repositories: [GitHubRepository] = []
    @State private var projects: [VercelProject] = []
    @State private var status = "Nhập token để kết nối GitHub và Vercel."
    @State private var loading = false
    @State private var editRepository = ""
    @State private var filePath = ""
    @State private var fileContent = ""
    @State private var commitMessage = "Update via PHAMQUANG WORM GPT"
    @State private var branchName = ""
    @State private var selectedProject: VercelProject?
    @State private var deployments: [VercelDeployment] = []
    @State private var showCommitConfirm = false
    @State private var pendingRedeploy: VercelDeployment?
    @State private var showRedeployConfirm = false
    @State private var activity = UserDefaults.standard.stringArray(forKey: "pqw.owner.activity") ?? []
    @StateObject private var aiStore = AISettingsStore()
    @State private var agentInstruction = "Rà soát file này, sửa lỗi rõ ràng và cải thiện chất lượng mà không thay đổi hành vi ngoài yêu cầu."
    @State private var agentBusy = false
    @State private var batchPaths = ""
    @State private var batchProposals: [AgentBatchChange] = []
    @State private var showBatchCommitConfirm = false

    var body: some View {
        NavigationStack {
            ZStack {
                PQTheme.bg.ignoresSafeArea()
                ScrollView {
                    VStack(alignment: .leading, spacing: 18) {
                        pageHeader("DEVELOPER WORKSPACE", title: "Projects & Deploy", subtitle: "Tệp • GitHub • Vercel")
                        VStack(alignment: .leading, spacing: 10) {
                            Label("TỆP ĐÍNH KÈM", systemImage: "doc.badge.plus").font(.caption.bold()).foregroundStyle(PQTheme.neon)
                            Text("Trong AI Chat, chạm biểu tượng kẹp giấy để tải PDF hoặc mã nguồn lên. Ứng dụng trích xuất văn bản và gửi làm ngữ cảnh cho model.").font(.subheadline).foregroundStyle(PQTheme.muted)
                            Text("Hỗ trợ PDF và tệp văn bản/mã nguồn UTF-8, tối đa 8 MB mỗi tệp.").font(.caption).foregroundStyle(PQTheme.muted)
                        }.padding(16).frame(maxWidth: .infinity, alignment: .leading).background(PQTheme.panel, in: RoundedRectangle(cornerRadius: 16))

                        VStack(alignment: .leading, spacing: 10) {
                            Label("GITHUB", systemImage: "chevron.left.forwardslash.chevron.right").font(.headline).foregroundStyle(PQTheme.neon)
                            Text("Personal Access Token — chỉ cần quyền đọc repository cho thao tác hiện có.").font(.caption).foregroundStyle(PQTheme.muted)
                            SecureField("GitHub token", text: $githubToken).textInputAutocapitalization(.never).autocorrectionDisabled().padding(12).background(PQTheme.bg, in: RoundedRectangle(cornerRadius: 10))
                            Button { KeychainStore.save(githubToken, account: "github-token"); Task { await loadGitHub() } } label: {
                                Label("Lưu & tải repositories", systemImage: "arrow.down.circle").frame(maxWidth: .infinity).padding(12).background(PQTheme.neon, in: RoundedRectangle(cornerRadius: 11)).foregroundStyle(PQTheme.bg).font(.subheadline.bold())
                            }
                            ForEach(repositories) { repo in
                                VStack(alignment: .leading, spacing: 4) {
                                    Text(repo.full_name).font(.subheadline.bold()).foregroundStyle(.white)
                                    Text(repo.description ?? "Không có mô tả").font(.caption).foregroundStyle(PQTheme.muted)
                                    HStack {
                                        Link("Mở repository", destination: URL(string: repo.html_url)!).font(.caption).foregroundStyle(PQTheme.neon)
                                        Spacer()
                                        Button("Chọn để sửa") { editRepository = repo.full_name }
                                            .font(.caption.bold()).tint(PQTheme.cyan)
                                    }
                                }.padding(11).frame(maxWidth: .infinity, alignment: .leading).background(PQTheme.bg, in: RoundedRectangle(cornerRadius: 10))
                            }
                            Divider().overlay(.white.opacity(0.12))
                            Text("GITHUB FILE EDITOR").font(.caption.bold()).foregroundStyle(PQTheme.neon)
                            TextField("owner/repository", text: $editRepository).textInputAutocapitalization(.never).autocorrectionDisabled().padding(10).background(PQTheme.bg, in: RoundedRectangle(cornerRadius: 9))
                            TextField("Đường dẫn file, ví dụ Sources/App.swift", text: $filePath).textInputAutocapitalization(.never).autocorrectionDisabled().padding(10).background(PQTheme.bg, in: RoundedRectangle(cornerRadius: 9))
                            TextField("Branch (để trống = default branch)", text: $branchName).textInputAutocapitalization(.never).autocorrectionDisabled().padding(10).background(PQTheme.bg, in: RoundedRectangle(cornerRadius: 9))
                            TextField("Commit message", text: $commitMessage).padding(10).background(PQTheme.bg, in: RoundedRectangle(cornerRadius: 9))
                            HStack {
                                Button { Task { await readGitHubFile() } } label: { Label("Đọc file", systemImage: "arrow.down.doc").font(.caption.bold()) }.tint(PQTheme.cyan)
                                Spacer()
                                Text("Editor UTF-8").font(.caption2).foregroundStyle(PQTheme.muted)
                            }
                            TextEditor(text: $fileContent).frame(minHeight: 150).scrollContentBackground(.hidden).padding(8).background(PQTheme.bg, in: RoundedRectangle(cornerRadius: 10))
                            TextField("Yêu cầu sửa file cho AI Agent", text: $agentInstruction, axis: .vertical)
                                .lineLimit(2...4).padding(10).background(PQTheme.bg, in: RoundedRectangle(cornerRadius: 9))
                            Button { Task { await runAgentOnCurrentFile() } } label: {
                                HStack {
                                    if agentBusy { ProgressView().tint(PQTheme.bg) }
                                    Label(agentBusy ? "AI Agent đang phân tích..." : "AI Agent phân tích & đề xuất sửa", systemImage: "cpu")
                                }.frame(maxWidth: .infinity).padding(11)
                                    .background(PQTheme.cyan, in: RoundedRectangle(cornerRadius: 10))
                                    .foregroundStyle(PQTheme.bg).font(.subheadline.bold())
                            }.disabled(agentBusy || fileContent.isEmpty || aiStore.apiKey.isEmpty)
                            Text("Agent thay nội dung trong editor bằng bản đề xuất. Hãy kiểm tra diff/nội dung trước khi commit.")
                                .font(.caption2).foregroundStyle(PQTheme.muted)
                            Button { showCommitConfirm = true } label: {
                                Label("Ghi file & commit", systemImage: "arrow.up.doc").frame(maxWidth: .infinity).padding(12).background(PQTheme.neon, in: RoundedRectangle(cornerRadius: 11)).foregroundStyle(PQTheme.bg).font(.subheadline.bold())
                            }.disabled(editRepository.isEmpty || filePath.isEmpty || fileContent.isEmpty || githubToken.isEmpty)
                        }.padding(16).background(PQTheme.panel, in: RoundedRectangle(cornerRadius: 16))

                        VStack(alignment: .leading, spacing: 10) {
                            Label("MULTI-FILE AI AGENT", systemImage: "square.stack.3d.up.fill")
                                .font(.headline).foregroundStyle(PQTheme.neon)
                            Text("Nhập tối đa 5 đường dẫn, mỗi dòng một file. Agent sẽ đọc các file hiện có trong repository, đề xuất thay đổi và tạo bản xem trước.")
                                .font(.caption).foregroundStyle(PQTheme.muted)
                            TextEditor(text: $batchPaths)
                                .frame(minHeight: 90).scrollContentBackground(.hidden).padding(8)
                                .background(PQTheme.bg, in: RoundedRectangle(cornerRadius: 10))
                            Button { Task { await generateBatchProposal() } } label: {
                                HStack {
                                    if agentBusy { ProgressView().tint(PQTheme.bg) }
                                    Label(agentBusy ? "Đang xử lý..." : "Đọc nhiều file & tạo kế hoạch sửa", systemImage: "cpu")
                                }.frame(maxWidth: .infinity).padding(12)
                                    .background(PQTheme.cyan, in: RoundedRectangle(cornerRadius: 11))
                                    .foregroundStyle(PQTheme.bg).font(.subheadline.bold())
                            }.disabled(agentBusy || batchPaths.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty || githubToken.isEmpty || aiStore.apiKey.isEmpty)

                            if !batchProposals.isEmpty {
                                Divider().overlay(.white.opacity(0.12))
                                Text("BẢN ĐỀ XUẤT • \(batchProposals.count) FILE")
                                    .font(.caption.bold()).foregroundStyle(PQTheme.neon)
                                ForEach(batchProposals) { change in
                                    VStack(alignment: .leading, spacing: 5) {
                                        Text(change.path).font(.caption.bold()).foregroundStyle(.white)
                                        Text(change.summary).font(.caption).foregroundStyle(PQTheme.muted)
                                        Text("Nội dung mới: \(change.content.count) ký tự")
                                            .font(.caption2).foregroundStyle(PQTheme.cyan)
                                    }.padding(10).frame(maxWidth: .infinity, alignment: .leading)
                                        .background(PQTheme.bg, in: RoundedRectangle(cornerRadius: 9))
                                }
                                Button { showBatchCommitConfirm = true } label: {
                                    Label("Xác nhận commit tất cả file", systemImage: "checkmark.icloud")
                                        .frame(maxWidth: .infinity).padding(12)
                                        .background(PQTheme.neon, in: RoundedRectangle(cornerRadius: 11))
                                        .foregroundStyle(PQTheme.bg).font(.subheadline.bold())
                                }.disabled(loading)
                                Button("Hủy bản đề xuất", role: .cancel) { batchProposals = [] }
                                    .font(.caption).tint(PQTheme.muted)
                            }
                            Text("Mỗi file được commit riêng qua GitHub Contents API; nếu một commit lỗi, các commit trước đó sẽ không tự động được hoàn tác.")
                                .font(.caption2).foregroundStyle(PQTheme.muted)
                        }.padding(16).background(PQTheme.panel, in: RoundedRectangle(cornerRadius: 16))

                        VStack(alignment: .leading, spacing: 10) {
                            Label("VERCEL", systemImage: "triangle.fill").font(.headline).foregroundStyle(PQTheme.cyan)
                            Text("Vercel access token — dùng để liệt kê projects trong tài khoản.").font(.caption).foregroundStyle(PQTheme.muted)
                            SecureField("Vercel token", text: $vercelToken).textInputAutocapitalization(.never).autocorrectionDisabled().padding(12).background(PQTheme.bg, in: RoundedRectangle(cornerRadius: 10))
                            Button { KeychainStore.save(vercelToken, account: "vercel-token"); Task { await loadVercel() } } label: {
                                Label("Lưu & tải projects", systemImage: "arrow.down.circle").frame(maxWidth: .infinity).padding(12).background(PQTheme.cyan, in: RoundedRectangle(cornerRadius: 11)).foregroundStyle(PQTheme.bg).font(.subheadline.bold())
                            }
                            ForEach(projects) { project in
                                VStack(alignment: .leading, spacing: 7) {
                                    Text(project.name).font(.subheadline.bold()).foregroundStyle(.white)
                                    Text("Framework: \(project.framework ?? "Không xác định") • ID: \(project.id)").font(.caption).foregroundStyle(PQTheme.muted)
                                    if let repo = project.link?.repo { Text("GitHub: \(repo)").font(.caption2).foregroundStyle(PQTheme.cyan) }
                                    Button { Task { await loadDeployments(for: project) } } label: { Label("Xem deployment", systemImage: "clock.arrow.circlepath").font(.caption.bold()) }.tint(PQTheme.cyan)
                                }.padding(11).frame(maxWidth: .infinity, alignment: .leading).background(PQTheme.bg, in: RoundedRectangle(cornerRadius: 10))
                            }
                            if let selectedProject {
                                Divider().overlay(.white.opacity(0.12))
                                Text("DEPLOYMENTS • \(selectedProject.name)").font(.caption.bold()).foregroundStyle(PQTheme.cyan)
                                ForEach(deployments) { deployment in
                                    HStack {
                                        VStack(alignment: .leading, spacing: 3) {
                                            Text(deployment.url ?? deployment.uid).font(.caption.bold()).foregroundStyle(.white)
                                            Text(deployment.state ?? "Unknown").font(.caption2).foregroundStyle(PQTheme.muted)
                                        }
                                        Spacer()
                                        Button("Redeploy") { pendingRedeploy = deployment; showRedeployConfirm = true }.font(.caption.bold()).tint(PQTheme.cyan)
                                    }.padding(9).background(PQTheme.bg, in: RoundedRectangle(cornerRadius: 9))
                                }
                            }
                        }.padding(16).background(PQTheme.panel, in: RoundedRectangle(cornerRadius: 16))

                        if loading { ProgressView().tint(PQTheme.neon) }
                        Text(status).font(.caption).foregroundStyle(PQTheme.muted)
                        VStack(alignment: .leading, spacing: 8) {
                            Label("OWNER ACTIVITY LOG", systemImage: "list.bullet.rectangle").font(.caption.bold()).foregroundStyle(PQTheme.neon)
                            if activity.isEmpty { Text("Chưa có hoạt động.").font(.caption).foregroundStyle(PQTheme.muted) }
                            ForEach(activity.prefix(12), id: \.self) { item in Text(item).font(.caption2).foregroundStyle(PQTheme.muted) }
                        }.padding(14).frame(maxWidth: .infinity, alignment: .leading).background(PQTheme.panel, in: RoundedRectangle(cornerRadius: 14))
                        Text("Chế độ cá nhân một chủ sở hữu: token lưu trong Keychain; thao tác ghi file và redeploy yêu cầu xác nhận. Nhật ký lưu cục bộ trên thiết bị. Không gửi token vào chat hoặc commit token lên GitHub.")
                            .font(.caption2).foregroundStyle(PQTheme.muted).padding(12).background(PQTheme.neon.opacity(0.07), in: RoundedRectangle(cornerRadius: 12))
                    }.padding(20)
                }
            }.toolbar(.hidden, for: .navigationBar)
                .confirmationDialog("Xác nhận ghi file lên GitHub?", isPresented: $showCommitConfirm, titleVisibility: .visible) {
                    Button("Ghi file và tạo commit", role: .destructive) { Task { await commitGitHubFile() } }
                    Button("Hủy", role: .cancel) {}
                } message: { Text("Repository: \(editRepository)\nFile: \(filePath)\nThao tác sẽ cập nhật file trên branch đã chọn.") }
                .confirmationDialog("Xác nhận redeploy?", isPresented: $showRedeployConfirm, titleVisibility: .visible) {
                    Button("Redeploy deployment", role: .destructive) { if let pendingRedeploy { Task { await redeploy(pendingRedeploy) } } }
                    Button("Hủy", role: .cancel) {}
                } message: { Text("Vercel sẽ tạo deployment mới từ deployment đã chọn.") }
                .confirmationDialog("Xác nhận commit nhiều file?", isPresented: $showBatchCommitConfirm, titleVisibility: .visible) {
                    Button("Commit tất cả \(batchProposals.count) file", role: .destructive) { Task { await commitBatchProposals() } }
                    Button("Hủy", role: .cancel) {}
                } message: {
                    Text("Repository: \(editRepository)\nBranch: \(branchName.isEmpty ? "default" : branchName)\nMỗi file sẽ tạo một commit riêng. Kiểm tra bản đề xuất trước khi tiếp tục.")
                }
        }
    }

    private func record(_ message: String) {
        let entry = "\(Date().formatted(date: .abbreviated, time: .shortened)) — \(message)"
        activity.insert(entry, at: 0)
        activity = Array(activity.prefix(40))
        UserDefaults.standard.set(activity, forKey: "pqw.owner.activity")
    }

    @MainActor private func generateBatchProposal() async {
        let requestedPaths = batchPaths
            .split(whereSeparator: \.isNewline)
            .map { $0.trimmingCharacters(in: .whitespacesAndNewlines) }
            .filter { !$0.isEmpty }
        let uniquePaths = Array(NSOrderedSet(array: requestedPaths)) as? [String] ?? requestedPaths
        guard !githubToken.isEmpty, !aiStore.apiKey.isEmpty else {
            status = "Cần GitHub token và API key AI đã cấu hình."
            return
        }
        guard !editRepository.isEmpty else {
            status = "Hãy chọn hoặc nhập owner/repository trước."
            return
        }
        guard !uniquePaths.isEmpty, uniquePaths.count <= 5, uniquePaths.count == requestedPaths.count else {
            status = "Nhập từ 1 đến 5 đường dẫn khác nhau, mỗi đường dẫn một dòng."
            return
        }
        guard uniquePaths.allSatisfy({ !$0.hasPrefix("/") && !$0.split(separator: "/").contains("..") }) else {
            status = "Đường dẫn file không hợp lệ."
            return
        }

        agentBusy = true
        loading = true
        batchProposals = []
        defer {
            agentBusy = false
            loading = false
        }

        do {
            var sourceFiles: [(String, String)] = []
            var totalCharacters = 0
            for path in uniquePaths {
                let content = try await IntegrationService.readGitHubFile(
                    token: githubToken,
                    repository: editRepository,
                    path: path,
                    branch: branchName.isEmpty ? nil : branchName
                )
                guard content.count <= 40_000 else {
                    throw NSError(domain: "WormGPTAgent", code: 1, userInfo: [NSLocalizedDescriptionKey: "File \(path) vượt giới hạn 40.000 ký tự."])
                }
                totalCharacters += content.count
                guard totalCharacters <= 100_000 else {
                    throw NSError(domain: "WormGPTAgent", code: 2, userInfo: [NSLocalizedDescriptionKey: "Tổng nội dung vượt giới hạn 100.000 ký tự. Chia thành nhiều lượt."])
                }
                sourceFiles.append((path, content))
                record("AI Agent read \(editRepository)/\(path)")
            }

            let fileContext = sourceFiles.map { path, content in
                "FILE: \(path)\n----- BEGIN FILE -----\n\(content)\n----- END FILE -----"
            }.joined(separator: "\n\n")

            let prompt = """
            Hãy làm coding task sau trên các file của repository \(editRepository).
            YÊU CẦU: \(agentInstruction)
            CHỈ ĐƯỢC sửa các đường dẫn đã cung cấp: \(uniquePaths.joined(separator: ", ")).
            Trả về DUY NHẤT JSON hợp lệ theo schema:
            {"changes":[{"path":"đường dẫn chính xác","summary":"mô tả ngắn","content":"toàn bộ nội dung file sau sửa"}]}
            Ràng buộc:
            - Phải có đúng một phần tử cho mỗi file đầu vào, giữ nguyên path.
            - content phải là toàn bộ file hoàn chỉnh, escape newline và ký tự JSON đúng chuẩn.
            - Giữ nguyên nội dung không liên quan; không tự thêm file hoặc sửa path khác.
            - Không chèn API key, token, mật khẩu hoặc bí mật vào nội dung.
            - Nếu không thể đáp ứng, trả về {"changes":[]}.
            NỘI DUNG FILE:
            \(fileContext)
            """

            var settings = aiStore.settings
            settings.systemPrompt += "\n\nChế độ coding agent nhiều file: thay đổi tối thiểu, giữ tương thích, không bịa nội dung file."
            let raw = try await AIService.reply(
                messages: [APIChatMessage(role: "user", content: prompt)],
                settings: settings,
                apiKey: aiStore.apiKey
            )
            let jsonText = Self.extractJSONObject(raw)
            let decoded = try JSONDecoder().decode(AgentBatchResponse.self, from: Data(jsonText.utf8))
            let returnedPaths = decoded.changes.map(\.path)
            guard decoded.changes.count == uniquePaths.count,
                  Set(returnedPaths) == Set(uniquePaths),
                  Set(returnedPaths).count == returnedPaths.count,
                  decoded.changes.allSatisfy({ !$0.content.isEmpty && $0.content.count <= 80_000 }) else {
                throw NSError(domain: "WormGPTAgent", code: 3, userInfo: [NSLocalizedDescriptionKey: "Agent trả về danh sách file không khớp hoặc nội dung không hợp lệ. Chưa có file nào được ghi."])
            }
            batchProposals = decoded.changes
            status = "Đã tạo bản đề xuất cho \(batchProposals.count) file. Chưa có thay đổi nào được commit."
            record("AI Agent proposed \(batchProposals.count) files in \(editRepository)")
        } catch {
            status = "Multi-file Agent lỗi: \(error.localizedDescription)"
        }
    }

    private static func extractJSONObject(_ text: String) -> String {
        guard let start = text.firstIndex(of: "{"),
              let end = text.range(of: "}", options: .backwards),
              end.lowerBound >= start else { return text }
        return String(text[start...end.lowerBound])
    }

    @MainActor private func commitBatchProposals() async {
        guard !batchProposals.isEmpty else { return }
        loading = true
        defer { loading = false }
        var completed: [String] = []
        do {
            for change in batchProposals {
                let sha = try await IntegrationService.writeGitHubFile(
                    token: githubToken,
                    repository: editRepository,
                    path: change.path,
                    content: change.content,
                    message: commitMessage + " — " + change.path,
                    branch: branchName.isEmpty ? nil : branchName
                )
                completed.append(change.path)
                record("GitHub batch commit \(editRepository)/\(change.path) • \(sha)")
            }
            status = "Đã commit thành công \(completed.count) file."
            batchProposals = []
        } catch {
            status = "Dừng ở lỗi: \(error.localizedDescription). Đã commit trước đó: \(completed.joined(separator: ", ")). Các commit đã thành công không tự hoàn tác."
            record("GitHub batch partial failure • \(completed.count)/\(batchProposals.count)")
        }
    }

    @MainActor private func runAgentOnCurrentFile() async {
        guard !fileContent.isEmpty else {
            status = "Hãy đọc file GitHub trước khi chạy Agent."
            return
        }
        guard !aiStore.apiKey.isEmpty else {
            status = "Hãy cấu hình API provider trong tab AI Chat → Cài đặt AI trước."
            return
        }
        agentBusy = true
        defer { agentBusy = false }
        let agentPrompt = """
        Bạn là AI coding agent đang sửa một file trong repository được người dùng kết nối.
        YÊU CẦU: \(agentInstruction)
        FILE: \(filePath)
        Quy tắc đầu ra:
        - Trả về TOÀN BỘ nội dung file sau khi sửa, không trả diff.
        - Không dùng markdown code fence, không thêm lời dẫn hoặc giải thích ngoài file.
        - Giữ nguyên các phần không liên quan; không chèn secrets, token hoặc dữ liệu giả.
        - Nếu yêu cầu không thể thực hiện an toàn hoặc thiếu thông tin thiết yếu, trả lời ngắn gọn lý do thay vì bịa nội dung.
        NỘI DUNG HIỆN TẠI:
        \(fileContent)
        """
        do {
            var agentSettings = aiStore.settings
            agentSettings.systemPrompt += "\n\nBạn đang ở chế độ sửa một file. Ưu tiên tính đúng đắn, thay đổi tối thiểu và giữ nguyên tương thích."
            let proposed = try await AIService.reply(
                messages: [APIChatMessage(role: "user", content: agentPrompt)],
                settings: agentSettings,
                apiKey: aiStore.apiKey
            )
            let cleaned = Self.unwrapSingleCodeFence(proposed)
            guard !cleaned.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty else {
                status = "Agent trả về nội dung rỗng; file chưa thay đổi."
                return
            }
            fileContent = cleaned
            status = "Agent đã tạo bản đề xuất cho \(filePath). Kiểm tra nội dung rồi mới commit."
            record("AI Agent proposal \(editRepository)/\(filePath)")
        } catch {
            status = "AI Agent lỗi: \(error.localizedDescription)"
        }
    }

    private static func unwrapSingleCodeFence(_ text: String) -> String {
        let trimmed = text.trimmingCharacters(in: .whitespacesAndNewlines)
        guard trimmed.hasPrefix("```"), let firstNewline = trimmed.firstIndex(of: "\n"),
              let closing = trimmed.range(of: "```", options: .backwards),
              closing.lowerBound > firstNewline else { return text }
        return String(trimmed[trimmed.index(after: firstNewline)..<closing.lowerBound])
    }

    @MainActor private func readGitHubFile() async {
        loading = true
        defer { loading = false }
        do {
            fileContent = try await IntegrationService.readGitHubFile(token: githubToken, repository: editRepository, path: filePath, branch: branchName.isEmpty ? nil : branchName)
            status = "Đã đọc file \(editRepository)/\(filePath)."
            record("GitHub read \(editRepository)/\(filePath)")
        } catch { status = error.localizedDescription }
    }

    @MainActor private func commitGitHubFile() async {
        loading = true
        defer { loading = false }
        do {
            let sha = try await IntegrationService.writeGitHubFile(token: githubToken, repository: editRepository, path: filePath, content: fileContent, message: commitMessage, branch: branchName.isEmpty ? nil : branchName)
            status = "GitHub commit thành công: \(sha)"
            record("GitHub commit \(editRepository)/\(filePath) • \(sha)")
        } catch { status = error.localizedDescription }
    }

    @MainActor private func loadDeployments(for project: VercelProject) async {
        loading = true
        defer { loading = false }
        do {
            selectedProject = project
            deployments = try await IntegrationService.vercelDeployments(token: vercelToken, projectID: project.id)
            status = "Đã tải \(deployments.count) deployments của \(project.name)."
        } catch { status = error.localizedDescription }
    }

    @MainActor private func redeploy(_ deployment: VercelDeployment) async {
        loading = true
        defer { loading = false }
        do {
            let result = try await IntegrationService.redeployVercel(token: vercelToken, deploymentID: deployment.uid)
            status = "Đã gửi yêu cầu redeploy: \(result)"
            record("Vercel redeploy \(deployment.uid)")
            if let selectedProject { await loadDeployments(for: selectedProject) }
        } catch { status = error.localizedDescription }
    }

    @MainActor private func loadGitHub() async {
        loading = true
        defer { loading = false }
        do {
            repositories = try await IntegrationService.githubRepositories(token: githubToken)
            status = "GitHub kết nối thành công: \(repositories.count) repositories."
        } catch { status = error.localizedDescription }
    }

    @MainActor private func loadVercel() async {
        loading = true
        defer { loading = false }
        do {
            projects = try await IntegrationService.vercelProjects(token: vercelToken)
            status = "Vercel kết nối thành công: \(projects.count) projects."
        } catch { status = error.localizedDescription }
    }
}

private struct CyberLabView: View {
    private let topics: [(String, String, String)] = [
        ("shield.lefthalf.filled", "Phạm vi kiểm thử", "Xác định tài sản, quyền hạn và giới hạn của bài kiểm thử."),
        ("ladybug.fill", "Phân tích lỗ hổng", "Hiểu nguyên nhân, mức độ ảnh hưởng và cách khắc phục."),
        ("doc.text.magnifyingglass", "Phân tích mã", "Rà soát mã nguồn, dependency và cấu hình bảo mật."),
        ("cross.case.fill", "Phòng thủ hệ thống", "Checklist hardening, logging, backup và phản ứng sự cố.")
    ]
    var body: some View {
        NavigationStack {
            ZStack {
                PQTheme.bg.ignoresSafeArea()
                ScrollView {
                    VStack(alignment: .leading, spacing: 18) {
                        pageHeader("AUTHORIZED RESEARCH", title: "Cyber Lab", subtitle: "Không gian học tập và kiểm thử có ủy quyền")
                        ForEach(topics, id: \.1) { item in
                            HStack(alignment: .top, spacing: 14) {
                                Image(systemName: item.0).font(.title3).foregroundStyle(PQTheme.neon).frame(width: 42, height: 42).background(PQTheme.neon.opacity(0.10), in: RoundedRectangle(cornerRadius: 12))
                                VStack(alignment: .leading, spacing: 5) {
                                    Text(item.1).font(.headline).foregroundStyle(.white)
                                    Text(item.2).font(.subheadline).foregroundStyle(PQTheme.muted)
                                }
                            }.padding(15).frame(maxWidth: .infinity, alignment: .leading).background(PQTheme.panel, in: RoundedRectangle(cornerRadius: 16))
                        }
                        Text("Chỉ thực hiện kiểm thử trên hệ thống bạn sở hữu hoặc được cho phép. Ứng dụng hiện cung cấp nội dung giao diện, chưa chạy công cụ quét hay khai thác.")
                            .font(.caption).foregroundStyle(PQTheme.muted).padding(14).background(PQTheme.neon.opacity(0.07), in: RoundedRectangle(cornerRadius: 14))
                    }.padding(20)
                }
            }.toolbar(.hidden, for: .navigationBar)
        }
    }
}

private struct PromptDetailView: View {
    let preset: PromptPreset
    @Environment(\.dismiss) private var dismiss
    @State private var copied = false
    var body: some View {
        NavigationStack {
            VStack(alignment: .leading, spacing: 16) {
                HStack { Image(systemName: preset.symbol).foregroundStyle(PQTheme.neon); Text(preset.title).font(.title2.bold()) }
                Text(preset.subtitle).font(.subheadline).foregroundStyle(PQTheme.muted)
                ScrollView {
                    Text(preset.prompt).font(.system(.body, design: .monospaced)).foregroundStyle(.white.opacity(0.85)).frame(maxWidth: .infinity, alignment: .leading).textSelection(.enabled)
                }
                Button {
                    UIPasteboard.general.string = preset.prompt
                    copied = true
                } label: {
                    Label(copied ? "Đã sao chép" : "Sao chép prompt", systemImage: copied ? "checkmark" : "doc.on.doc")
                        .fontWeight(.semibold).frame(maxWidth: .infinity).padding().foregroundStyle(PQTheme.bg).background(PQTheme.neon, in: RoundedRectangle(cornerRadius: 14))
                }.buttonStyle(.plain)
            }.padding(20).background(PQTheme.bg.ignoresSafeArea()).foregroundStyle(.white)
                .toolbar { ToolbarItem(placement: .topBarTrailing) { Button("Đóng") { dismiss() } } }
        }.preferredColorScheme(.dark)
    }
}

private struct PresetCard: View {
    let preset: PromptPreset
    var body: some View {
        HStack(spacing: 14) {
            Image(systemName: preset.symbol).font(.title3).foregroundStyle(PQTheme.neon).frame(width: 46, height: 46).background(PQTheme.neon.opacity(0.10), in: RoundedRectangle(cornerRadius: 13))
            VStack(alignment: .leading, spacing: 4) {
                Text(preset.title).font(.headline).foregroundStyle(.white)
                Text(preset.subtitle).font(.caption).foregroundStyle(PQTheme.muted)
            }
            Spacer()
            Image(systemName: "chevron.right").font(.caption.bold()).foregroundStyle(PQTheme.muted)
        }.padding(14).background(PQTheme.panel, in: RoundedRectangle(cornerRadius: 16)).overlay(RoundedRectangle(cornerRadius: 16).stroke(.white.opacity(0.06)))
    }
}

private struct StatusPill: View {
    let title: String; let value: String; let color: Color
    var body: some View {
        VStack(alignment: .leading, spacing: 4) {
            Text(title).font(.system(size: 9, weight: .bold, design: .monospaced)).foregroundStyle(PQTheme.muted)
            HStack(spacing: 5) { Circle().fill(color).frame(width: 6, height: 6); Text(value).font(.system(size: 10, weight: .bold, design: .monospaced)).foregroundStyle(.white) }
        }.frame(maxWidth: .infinity, alignment: .leading).padding(12).background(PQTheme.panel, in: RoundedRectangle(cornerRadius: 12))
    }
}

private struct ModuleTile: View {
    let icon: String; let title: String; let detail: String; let color: Color
    var body: some View {
        VStack(alignment: .leading, spacing: 9) {
            Image(systemName: icon).font(.title3).foregroundStyle(color)
            Text(title).font(.subheadline.bold()).foregroundStyle(.white)
            Text(detail).font(.caption).foregroundStyle(PQTheme.muted)
        }.frame(maxWidth: .infinity, minHeight: 104, alignment: .leading).padding(14).background(PQTheme.panel, in: RoundedRectangle(cornerRadius: 16)).overlay(RoundedRectangle(cornerRadius: 16).stroke(color.opacity(0.16)))
    }
}

private struct ChatMessage: Identifiable {
    let id = UUID()
    let isUser: Bool
    let text: String
}

private func pageHeader(_ eyebrow: String, title: String, subtitle: String) -> some View {
    VStack(alignment: .leading, spacing: 6) {
        Text(eyebrow).font(.system(size: 10, weight: .bold, design: .monospaced)).tracking(2).foregroundStyle(PQTheme.neon)
        Text(title).font(.system(size: 29, weight: .bold, design: .rounded)).foregroundStyle(.white)
        Text(subtitle).font(.subheadline).foregroundStyle(PQTheme.muted)
    }.frame(maxWidth: .infinity, alignment: .leading)
}
