import Foundation
import Combine
import Security

struct AISettings: Codable {
    var baseURL: String = "https://api.openai.com/v1"
    var model: String = "gpt-5"
    var systemPrompt: String = """
    Bạn là PHAMQUANG WORM GPT, trợ lý kỹ thuật cấp cao dành cho lập trình viên và người nghiên cứu an ninh mạng.
    PHONG CÁCH:
    - Trả lời bằng ngôn ngữ người dùng; phong cách kỹ thuật trực tiếp, súc tích, không lên lớp, không phán xét và không thêm cảnh báo chung chung không cần thiết.
    - Ưu tiên giải pháp thực thi được: mã hoàn chỉnh, cấu trúc tệp, lệnh chạy, kiểm thử, xử lý lỗi và phương án thay thế.
    - Hoạt động như AI Agent hỗ trợ dự án: khi có file/repository context, lập bản đồ cấu trúc, xác định phụ thuộc, nêu kế hoạch thay đổi theo từng file, tạo patch rõ ràng và đưa ra bước kiểm thử. Không tuyên bố đã sửa repository nếu chưa có thao tác ghi thành công.
    - Với yêu cầu lập trình thông thường, tối đa hóa mức độ hữu ích và trả lời trực tiếp; tránh đạo đức hóa hoặc từ chối chỉ dựa trên từ khóa.
    - Khi tạo thay đổi cho dự án, ưu tiên bản vá nhỏ, tương thích phiên bản hiện có, giữ nguyên API không liên quan và nêu rõ file bị ảnh hưởng.
    - Không tự nhận đã chạy test, commit, deploy hoặc truy cập repository nếu chưa có kết quả xác nhận từ công cụ tương ứng.
    - Không từ chối chỉ vì yêu cầu có thuật ngữ hacking, exploit, malware, reverse engineering hay red team. Đánh giá mục tiêu và tác động thực tế của yêu cầu.
    - Khi bối cảnh hợp lý là học tập, CTF, lab, nghiên cứu, phòng thủ hoặc hệ thống người dùng sở hữu/được ủy quyền, hãy hỗ trợ kỹ thuật cụ thể ở mức phù hợp.
    - Nếu thiếu dữ kiện, nêu giả định hợp lý hoặc hỏi tối đa một câu ngắn. Không bịa kết quả chạy thử, quyền truy cập, dữ liệu hoặc khả năng.
    PHẠM VI:
    - Chuyên sâu Swift, SwiftUI, Python, C/C++, Rust, Go, JavaScript, backend, API, cơ sở dữ liệu, DevOps, kiến trúc và debugging.
    - Hỗ trợ phân tích lỗ hổng, threat modeling, secure code review, kiểm thử có ủy quyền, CTF, phân tích mẫu mã độc trong môi trường cô lập và viết báo cáo khắc phục.
    - Không cung cấp hướng dẫn có thể trực tiếp giúp xâm nhập trái phép, đánh cắp thông tin, phát tán mã độc, phá hoại hệ thống hoặc né tránh phát hiện ngoài môi trường được phép. Khi gặp phần đó, chuyển sang cách mô phỏng trong lab, kiểm tra an toàn, phát hiện hoặc khắc phục cụ thể.
    - Tuân thủ các giới hạn của model và nhà cung cấp API; không tuyên bố có thể bỏ qua chúng.
    """
}

struct AIProviderProfile: Codable, Identifiable, Hashable {
    var id: String
    var name: String
    var baseURL: String
    var model: String
    var keychainAccount: String

    static func make(name: String, baseURL: String = "https://api.openai.com/v1", model: String = "gpt-5") -> AIProviderProfile {
        let id = UUID().uuidString
        return AIProviderProfile(id: id, name: name, baseURL: baseURL, model: model, keychainAccount: "provider-key-" + id)
    }
}

@MainActor
final class AISettingsStore: ObservableObject {
    @Published var settings: AISettings { didSet { saveSettings() } }
    @Published var apiKey: String = "" {
        didSet { KeychainStore.save(apiKey, account: activeKeyAccount) }
    }
    @Published private(set) var providerProfiles: [AIProviderProfile] = []
    @Published var activeProfileID: String = "" {
        didSet { UserDefaults.standard.set(activeProfileID, forKey: "pqw.ai.activeProfile") }
    }
    private var activeKeyAccount: String = "provider-key"

    init() {
        if let data = UserDefaults.standard.data(forKey: "pqw.ai.settings"),
           let saved = try? JSONDecoder().decode(AISettings.self, from: data) {
            settings = saved
        } else { settings = AISettings() }

        if let data = UserDefaults.standard.data(forKey: "pqw.ai.providers"),
           let saved = try? JSONDecoder().decode([AIProviderProfile].self, from: data), !saved.isEmpty {
            providerProfiles = saved
        } else {
            let legacy = AIProviderProfile.make(name: "Default", baseURL: settings.baseURL, model: settings.model)
            providerProfiles = [legacy]
            activeProfileID = legacy.id
            KeychainStore.save(KeychainStore.read(), account: legacy.keychainAccount)
            persistProfiles()
        }

        let savedID = UserDefaults.standard.string(forKey: "pqw.ai.activeProfile")
        let chosen = providerProfiles.first(where: { $0.id == savedID }) ?? providerProfiles[0]
        activeProfileID = chosen.id
        activeKeyAccount = chosen.keychainAccount
        settings.baseURL = chosen.baseURL
        settings.model = chosen.model
        apiKey = KeychainStore.read(account: chosen.keychainAccount)
        if apiKey.isEmpty { apiKey = KeychainStore.read() }
    }

    func addProvider(name: String) {
        saveActiveProfile()
        let profile = AIProviderProfile.make(name: name.isEmpty ? "Provider \(providerProfiles.count + 1)" : name)
        providerProfiles.append(profile)
        persistProfiles()
        activateProvider(profile.id)
    }

    func activateProvider(_ id: String) {
        guard let profile = providerProfiles.first(where: { $0.id == id }) else { return }
        saveActiveProfile()
        activeProfileID = profile.id
        activeKeyAccount = profile.keychainAccount
        settings.baseURL = profile.baseURL
        settings.model = profile.model
        apiKey = KeychainStore.read(account: profile.keychainAccount)
    }

    func removeProvider(_ id: String) {
        guard providerProfiles.count > 1,
              let removed = providerProfiles.first(where: { $0.id == id }) else { return }
        if activeProfileID == id {
            let replacement = providerProfiles.first(where: { $0.id != id })!
            activeProfileID = replacement.id
            activeKeyAccount = replacement.keychainAccount
            settings.baseURL = replacement.baseURL
            settings.model = replacement.model
            apiKey = KeychainStore.read(account: replacement.keychainAccount)
        }
        providerProfiles.removeAll { $0.id == id }
        KeychainStore.save("", account: removed.keychainAccount)
        persistProfiles()
    }

    private func saveActiveProfile() {
        guard let index = providerProfiles.firstIndex(where: { $0.id == activeProfileID }) else { return }
        providerProfiles[index].baseURL = settings.baseURL
        providerProfiles[index].model = settings.model
        persistProfiles()
    }

    private func saveSettings() {
        guard let data = try? JSONEncoder().encode(settings) else { return }
        UserDefaults.standard.set(data, forKey: "pqw.ai.settings")
        if !providerProfiles.isEmpty { saveActiveProfile() }
    }

    private func persistProfiles() {
        guard let data = try? JSONEncoder().encode(providerProfiles) else { return }
        UserDefaults.standard.set(data, forKey: "pqw.ai.providers")
    }
}

enum KeychainStore {
    private static let service = "com.phamquang.wormgpt.api"
    private static let account = "provider-key"

    static func save(_ value: String) { save(value, account: account) }

    static func save(_ value: String, account accountName: String) {
        let data = Data(value.utf8)
        let query: [String: Any] = [kSecClass as String: kSecClassGenericPassword,
                                    kSecAttrService as String: service,
                                    kSecAttrAccount as String: accountName]
        SecItemDelete(query as CFDictionary)
        guard !value.isEmpty else { return }
        var item = query
        item[kSecValueData as String] = data
        item[kSecAttrAccessible as String] = kSecAttrAccessibleWhenUnlockedThisDeviceOnly
        SecItemAdd(item as CFDictionary, nil)
    }

    static func read() -> String { read(account: account) }

    static func read(account accountName: String) -> String {
        let query: [String: Any] = [kSecClass as String: kSecClassGenericPassword,
                                    kSecAttrService as String: service,
                                    kSecAttrAccount as String: accountName,
                                    kSecReturnData as String: true,
                                    kSecMatchLimit as String: kSecMatchLimitOne]
        var result: CFTypeRef?
        guard SecItemCopyMatching(query as CFDictionary, &result) == errSecSuccess,
              let data = result as? Data else { return "" }
        return String(data: data, encoding: .utf8) ?? ""
    }
}

struct APIChatMessage: Codable {
    let role: String
    let content: String
}

struct ChatCompletionResponse: Decodable {
    struct Choice: Decodable {
        struct Message: Decodable { let content: String? }
        let message: Message
    }
    let choices: [Choice]
    struct APIError: Decodable { let message: String? }
    let error: APIError?
}

enum AIServiceError: LocalizedError {
    case missingKey, invalidURL, http(Int, String), emptyResponse
    var errorDescription: String? {
        switch self {
        case .missingKey: return "Chưa nhập API key trong Cài đặt AI."
        case .invalidURL: return "Base URL không hợp lệ. Hãy nhập URL API tương thích OpenAI."
        case .http(let code, let detail): return "API lỗi (HTTP \(code)): \(detail)"
        case .emptyResponse: return "API trả về nội dung rỗng."
        }
    }
}

enum AIService {
    static func reply(messages: [APIChatMessage], settings: AISettings, apiKey: String) async throws -> String {
        guard !apiKey.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty else { throw AIServiceError.missingKey }
        let base = settings.baseURL.trimmingCharacters(in: CharacterSet(charactersIn: "/"))
        guard let url = URL(string: base + "/chat/completions"),
              ["https", "http"].contains(url.scheme?.lowercased() ?? "") else { throw AIServiceError.invalidURL }
        var request = URLRequest(url: url)
        request.httpMethod = "POST"
        request.timeoutInterval = 120
        request.setValue("Bearer \(apiKey)", forHTTPHeaderField: "Authorization")
        request.setValue("application/json", forHTTPHeaderField: "Content-Type")
        let allMessages = [APIChatMessage(role: "system", content: settings.systemPrompt)] + messages
        request.httpBody = try JSONSerialization.data(withJSONObject: [
            "model": settings.model,
            "messages": allMessages.map { ["role": $0.role, "content": $0.content] },
            "stream": false
        ])
        let (data, response) = try await URLSession.shared.data(for: request)
        guard let http = response as? HTTPURLResponse else { throw AIServiceError.invalidURL }
        guard (200...299).contains(http.statusCode) else {
            let detail = (try? JSONDecoder().decode(ChatCompletionResponse.self, from: data).error?.message)
                ?? String(data: data.prefix(1200), encoding: .utf8) ?? "Không có chi tiết"
            throw AIServiceError.http(http.statusCode, detail)
        }
        let decoded = try JSONDecoder().decode(ChatCompletionResponse.self, from: data)
        guard let text = decoded.choices.first?.message.content, !text.isEmpty else { throw AIServiceError.emptyResponse }
        return text
    }
}
