import SwiftUI

@main
struct PhamQuangIOSApp: App {
    @StateObject private var access = DeviceAccessModel.shared
    @StateObject private var sev = SEVAccessManager.shared
    @Environment(\.scenePhase) private var scenePhase

    var body: some Scene {
        WindowGroup {
            Group {
                if sev.state != .authorized {
                    SEVAccessGateView(sev: sev)
                } else if access.enteredApp {
                    ContentView()
                } else {
                    NavigationStack { DeviceAccessView(access: access, onboarding: true) }
                }
            }
            .task {
                await sev.start()
                if sev.state == .authorized { await access.start() }
            }
            .onChange(of: sev.state) { state in
                if state == .authorized { Task { await access.start() } }
            }
            .onChange(of: scenePhase) { phase in
                if phase == .active {
                    Task {
                        await sev.refresh()
                        if sev.state == .authorized { await access.start() }
                    }
                }
            }
        }
    }
}
