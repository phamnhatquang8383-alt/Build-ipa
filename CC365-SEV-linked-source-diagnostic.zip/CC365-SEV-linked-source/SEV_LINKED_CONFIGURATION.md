# CC365 / PhamQuang iOS — SEV linked source

This source bundle is linked to the active SEV V2 backend:

- Supabase project: `bpnwzwpqfakwzduiiwvh`
- Edge Function: `sev-control`
- Endpoint: `https://bpnwzwpqfakwzduiiwvh.supabase.co/functions/v1/sev-control`
- SEV Admin (Vercel): `https://phamquang-ios-sev-admin-v2.vercel.app`
- Admin source repository: `https://github.com/phamnhatquang8383-alt/Build-sev-`

## Password retrieval alignment

`CC365-Apps/Runtime/SEVAccessManager.swift` now calls the deployed `get-feature-secret` action with `installation_id` and `feature_id`, reads the `password` response field, and verifies the returned `packageID` and `packageVersion` against the selected feature package.

The server only returns the password when the installation passes SEV authorization and the feature/package is enabled and published. The admin password is stored through the server-side Vault RPC; it is not included in the public feature catalog.

## Upload behavior

The SEV Admin Patch Center accepts files of any extension up to 50 MB. Files are stored in the private `sev-patches` bucket, SHA-256 is verified, and each upload starts as a draft. Published files can be downloaded as inert files. They are not executed, injected, or applied to another app. Feature Toggle integration remains limited to supported CC365 configuration archives (`.zip` / `.vpatch`).

## Build note

This is an Xcode source project, not a signed IPA. It has not been built or device-tested in this environment. Open `PhamQuangIOS.xcodeproj` in Xcode, select the app scheme and a valid signing team, then build/test on an iOS device. The app-side automatic prefetch and feature-package application are limited to the CC365-owned configuration workflow.
