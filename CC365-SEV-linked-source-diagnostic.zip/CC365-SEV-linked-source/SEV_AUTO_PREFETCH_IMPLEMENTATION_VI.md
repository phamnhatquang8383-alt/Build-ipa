# SEV V2 — tự tải package vào CC365

## Đã chỉnh sửa

- `CC365-Apps/Runtime/SEVAccessManager.swift`: sau khi bootstrap hoặc kích hoạt key thành công, tạo tác vụ nền lấy `feature-catalog` và tự tải các package đang bật. Tác vụ nền không chặn giao diện khởi động.
- `CC365-Apps/Runtime/SEVFeaturePackageManager.swift`: thêm prefetch có kiểm tra URL HTTPS/Supabase, giới hạn 50 MiB, kích thước, SHA-256, định dạng ZIP/VPATCH, manifest gốc `sev-feature.json`, và đường dẫn archive. Cache nằm trong `Application Support/SEVManagedFeatures/<feature-id>` của CC365. Có coordinator để gộp các yêu cầu tải trùng nhau.
- `CC365-Apps/Files/AppPatchView.swift`: Feature Center hiển thị trạng thái đã tự tải/xác minh; mở màn hình sẽ đồng bộ catalogue và các package còn thiếu. Bật dùng cache đã xác minh; tắt gọi quy trình restore hiện có.
- `SEV-FEATURE-CATALOG-INTEGRATION.md` và `UPGRADE_NOTES_VI.md`: cập nhật hướng dẫn.

## Định dạng được hỗ trợ

- `.zip` hoặc `.vpatch` tương thích ZIP, có `sev-feature.json` ở thư mục gốc.
- `.vailon` không được dùng làm SEV Feature package. Archive chứa `Application/<bundle-id>/` bị loại bỏ ở bước kiểm tra.
- Gói chỉ được cài trong thư mục dữ liệu riêng của CC365; receipt/baseline/history giữ nguyên quy trình khôi phục.

## Kiểm tra đã chạy

- `swiftc -frontend -parse` trên ba file Swift đã chỉnh sửa: thành công (kiểm tra cú pháp, không phải build iOS).
- `python3 -m unittest discover -s Tests -p 'test_package_ipa.py' -v`: 9/9 tests passed.
- Chưa chạy được Xcode/iOS build hoặc tạo IPA trong môi trường này vì không có `xcodebuild`/iOS SDK.


## Bổ sung: tự giải mã `.vpatch` bằng mật khẩu SEV (CC365 client)

- Mọi file có đuôi `.vpatch` được yêu cầu dùng container mã hóa `V99PATCH`; `.vpatch` không mã hóa sẽ bị từ chối.
- CC365 tải và xác minh SHA-256 của **bytes mã hóa** trước khi giải mã.
- Sau khi xác minh, CC365 gọi action `feature-package-secret` trên Edge Function `sev-control` với `installation_id`, `feature_id`, `package_id`, `package_version`.
- Edge Function chỉ trả `package_password` khi installation đã được cấp quyền và bộ ba feature/package/version khớp catalogue đang publish.
- CC365 giữ mật khẩu trong bộ nhớ, giải mã ra tệp tạm có file protection, staging/kiểm tra `sev-feature.json`, rồi xóa tệp tạm. Bản cache lâu dài vẫn là `.vpatch` mã hóa.
- Mật khẩu không được ghi vào UserDefaults, receipt, log hoặc catalogue công khai.
- Migration `20261116100000_sev_feature_package_secrets.sql` tạo bảng chỉ dành cho `service_role`, lưu ciphertext và key id. Edge Function phải mã hóa mật khẩu admin trước khi ghi và giải mã bằng secret quản lý phía máy chủ (ví dụ Supabase secret/KMS); không lưu plaintext trong bảng.
- **Backend contract cần triển khai trong Edge Function `sev-control` (không có trong ZIP này):**
  - Request: `{"action":"feature-package-secret","installation_id":"...","feature_id":"...","package_id":"...","package_version":"..."}`
  - Response thành công: `{"package_password":"<password>"}`.
  - Bắt buộc xác minh installation đang authorized, package đang enabled/published, và `package_id` + `package_version` khớp chính xác. Không cho phép đọc bảng secret từ client.
- Trang SEV Admin cần có trường password khi publish `.vpatch`, gửi password tới endpoint quản trị đã xác thực để server mã hóa và lưu ciphertext. Không đưa password vào `sev_feature_catalog` hoặc response `feature-catalog`.
- `.zip` không mã hóa tiếp tục dùng luồng hiện tại. Package sau giải mã vẫn phải qua kiểm tra feature manifest/data-only; không thực thi mã hoặc ghi vào container ứng dụng khác.

## Phạm vi triển khai trong source ZIP

Đã cập nhật phía CC365 để gọi action secret, yêu cầu `.vpatch` có magic mã hóa, xác minh hash trước giải mã, và staging nội dung đã giải mã qua validator hiện có. ZIP không chứa mã nguồn Edge Function hoặc trang quản trị SEV Admin; do đó migration và API contract được cung cấp, nhưng phần giao diện/admin endpoint cần được tích hợp trong repository SEV riêng.
