# PhamQuang IOS – SEV V2 integration

## Connected production services

- Vercel admin project: `phamquang-ios-sev-admin-v2`
- Production admin: `https://phamquang-ios-sev-admin-v2.vercel.app`
- Supabase project: `build-sev` (`bpnwzwpqfakwzduiiwvh`, region `ap-southeast-1`)
- Supabase Edge Function: `sev-control` (deployed version 6)
- Edge Function URL: `https://bpnwzwpqfakwzduiiwvh.supabase.co/functions/v1/sev-control`

The iOS client uses only the public Supabase publishable key. Service-role/secret credentials remain inside the Edge Function. Admin access is verified server-side against canonical `app_metadata.role = admin`.

## iOS behavior

- At launch, the app calls `sev-control` with `action=bootstrap`.
- If SEV key enforcement is enabled and this installation is not authorized, the app presents the SEV key activation screen.
- Successful key validation binds the installation to the license on the server. The raw key is not persisted by the app.
- Maintenance, app-closed, minimum-version and update/announcement settings are enforced from `sev_control`.
- The Free Fire VN Feature Center fetches its feature catalogue from `action=feature-catalog` after SEV authorization.
- Feature catalogue access checks the installation, license status, maintenance/app-closed policy and IP block list.
- The app only unlocks a catalogue toggle when the admin enabled it and linked a published Patch Center package with a matching SHA-256.
- The catalogue toggle stores a user preference only. It does not execute exploit/kernel actions or apply a patch by itself; a separately verified, allowlisted patch runtime is still required.

## Admin control

The V2 admin page provides overview, app controls, license keys, devices, IP blocks, Patch Center, Feature Toggles and audit log. Admin actions require an authenticated Supabase user with `app_metadata.role = admin`.

Patch Center accepts `.vpatch`, `.vailon` and `.zip` files up to 50 MB. Files remain in a private bucket; SHA-256 is checked by the server; packages start as drafts and must be explicitly published.

## Preservation constraints

Sandbox, Kernel, KExploit, BQCore, LegacyDirect, AirLift, VPN, patch creation/recovery and existing device-access paths are preserved. SEV integration is additive. The SEV admin has no IPA build feature; Patch Center manages patch artifacts only.

## Operational notes

- `key_required` controls whether an unlicensed installation must activate a key.
- A key is generated in the admin panel and is bound to the device on its first successful activation, subject to expiry and device-count limits.
- The iOS app calls Supabase directly for authorization and catalogue data; Vercel is the admin UI and does not need to proxy iOS requests.
