-- Encrypted per-package secrets used by the SEV Edge Function.
-- Admin clients and ordinary app clients must never read this table directly.
create table if not exists public.sev_feature_package_secrets (
  feature_id text primary key
    references public.sev_feature_catalog(feature_id) on delete cascade,
  package_id text not null,
  package_version text not null,
  password_ciphertext text not null,
  encryption_key_id text not null,
  updated_at timestamptz not null default now(),
  updated_by uuid references auth.users(id),
  check (char_length(password_ciphertext) between 1 and 8192),
  check (char_length(encryption_key_id) between 1 and 128)
);

alter table public.sev_feature_package_secrets enable row level security;
revoke all on table public.sev_feature_package_secrets from anon, authenticated;
grant all on table public.sev_feature_package_secrets to service_role;

comment on table public.sev_feature_package_secrets is
  'Server-only encrypted .vpatch passwords. Read/decrypt only in the authenticated SEV Edge Function; never expose ciphertext or plaintext in the public feature catalogue.';
