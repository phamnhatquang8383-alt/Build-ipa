create table if not exists public.sev_feature_catalog (
  feature_id text primary key check (feature_id ~ '^[a-z0-9][a-z0-9._-]{0,63}$'),
  title text not null check (char_length(title) between 1 and 100),
  detail text,
  package_id text,
  package_version text,
  enabled_by_admin boolean not null default false,
  sha256 text check (sha256 is null or sha256 ~ '^[0-9a-f]{64}$'),
  sort_order integer not null default 0,
  updated_at timestamptz not null default now(),
  updated_by uuid references auth.users(id)
);
alter table public.sev_feature_catalog enable row level security;
revoke all on table public.sev_feature_catalog from anon, authenticated;
grant all on table public.sev_feature_catalog to service_role;
create index if not exists sev_feature_catalog_sort_idx
  on public.sev_feature_catalog (sort_order, feature_id);
