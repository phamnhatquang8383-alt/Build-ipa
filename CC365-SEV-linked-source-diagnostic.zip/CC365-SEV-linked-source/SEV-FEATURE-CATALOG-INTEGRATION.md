# SEV V2 Feature Catalog integration

The Free Fire VN Feature Center is now connected to the SEV V2 `feature-catalog` action (Edge Function version 6).

## Data flow

1. The app completes the existing SEV bootstrap/key authorization.
2. `SEVAccessManager.fetchFeatureCatalog()` sends the persistent installation ID to the Supabase Edge Function.
3. The Edge Function checks maintenance/app-closed state, IP blocks and the installation's active, unexpired license when key enforcement is enabled.
4. The Edge Function returns the admin-managed `sev_feature_catalog` rows.
5. The app displays a toggle only as ready when `enabledByAdmin`, package identity/version, SHA-256, signed download URL, file name and file size are present.
6. The app receives the short-lived `downloadURL`, `fileName` and `fileSize` fields for each published package.
7. When the Feature Center opens after authorization, it automatically prefetches each enabled/published package into the app-owned `Application Support/SEVManagedFeatures/<feature-id>` directory. It verifies exact size, SHA-256, archive structure, root `sev-feature.json`, and rejects `Application/<bundle-id>` paths before marking the package ready.
8. Turning a feature ON uses the verified cached package (or refreshes it if its package ID/version/hash changed), validates the data-only manifest, then atomically installs its files under the app-owned `active` directory.
9. Turning a feature OFF moves the applied package into a local history folder and restores the previous contents from the preserved baseline. The UI state is refreshed from the on-disk receipt, not from a preference toggle.

## Admin workflow

1. Upload a patch in Patch Center (`.vpatch`, `.vailon` or `.zip`, max 50 MB).
2. Verify the server-side SHA-256 and explicitly publish the package.
3. Open Feature Toggles in SEV V2.
4. Add/update a feature ID, title, description and select the published package. The UI fills its package version and SHA-256 from the published package.
5. Enable the feature and save. The backend independently verifies that the selected package is published and the hash matches.

## Important runtime boundary

The feature package manager only writes beneath this app's own `Application Support/SEVManagedFeatures` directory. It does not resolve or open another app's container, game data, app bundle, process, Sandbox, Kernel, KExploit or BQCore. Package files are data only; no executable code or scripts are launched. The feature toggle represents installation into this managed data directory, not modification of Free Fire's runtime or game files.

The signed URL is short-lived (10 minutes) and comes from the existing `feature-catalog` response. The app refreshes the catalogue before applying and reuses a cached archive only when package ID, version and SHA-256 all match the current publication. The deployed `sev-control` Edge Function v11 already filters Feature packages to `.zip`/`.vpatch` in both catalogue generation and admin upsert validation; `.vailon` remains available in Patch Center storage but cannot be attached to a Feature toggle. Package archives must contain relative data-file paths (no `Application/<bundle-id>` prefixes, absolute paths, hidden path components or traversal). The app enforces HTTPS and the configured Supabase host, a 50 MiB download limit, exact server-reported size, SHA-256, safe archive paths and the existing ZIP extractor's limits. Only `.zip` and ZIP-compatible `.vpatch` are currently accepted by this automatic flow; encrypted `.vailon` packages need a separate password/key UX and are rejected rather than guessed.

Sandbox, Kernel, KExploit, BQCore, LegacyDirect, AirLift and the existing patch/recovery implementation are not modified by this feature manager.


## Automatic package prefetch

After SEV authorization succeeds during app startup (and after a successful key activation), enabled packages are prefetched in a background task without blocking the launch screen. Opening the Feature Center also refreshes the catalogue and fills any missing cache. Packages are downloaded one by one. A package is marked as downloaded only after exact size, SHA-256, ZIP/VPATCH structure and CC365 feature-manifest checks pass. The verified archive and a small receipt are stored in the app-owned feature directory. The feature toggle then applies that cached package; a changed package identity/version/hash forces a new download. `.vailon` is rejected by this feature flow, and archives containing `Application/` entries are rejected during archive staging.
