#!/usr/bin/env python3

from pathlib import Path
import os
import subprocess
import tempfile

root = Path(__file__).resolve().parents[1]
source = (root / 'CC365-Apps/Files/BQCore/BQCore.m').read_text()
start = source.index('NSArray<NSString *> *BQDiscoverLSStorePaths(')
brace = source.index('{', start)
depth = 1
end = brace + 1
while depth:
    if source[end] == '{': depth += 1
    elif source[end] == '}': depth -= 1
    end += 1
actual = source[start:end]
fixture = r'''
#import <Foundation/Foundation.h>
#import <sys/stat.h>
#import <sys/mount.h>
#import <fcntl.h>
#import <unistd.h>
#import <limits.h>
static NSArray<NSString *> *observed;
static NSUInteger calls, checks;
static uint64_t previous;
static void check(BOOL ok) { checks++; if (!ok) abort(); }
static ssize_t fixture_fsgetpath(char *buffer, size_t size, fsid_t *fsid, uint64_t inode) {
    (void)fsid;
    if (calls) check(previous == inode + 1);
    previous = inode;
    NSString *value = calls < observed.count ? observed[calls] : nil;
    calls++;
    if (!value) return -1;
    const char *bytes = value.fileSystemRepresentation;
    check(strlen(bytes) + 1 < size);
    strcpy(buffer, bytes); return (ssize_t)strlen(bytes) + 1;
}
#define fsgetpath fixture_fsgetpath
ACTUAL
int main(void) { @autoreleasepool {
    NSString *store = @"/private/var/mobile/Containers/Data/InternalDaemon/AAAAAAAA-BBBB-CCCC-DDDD-EEEEEEEEEEEE/Library/Caches/com.apple.LaunchServices-test.csstore";
    observed = @[@"/private/var/mobile/Containers/Data/Application/AAAAAAAA-BBBB-CCCC-DDDD-EEEEEEEEEEEE/Library/Caches/com.apple.LaunchServices-x.csstore",
        [store stringByReplacingOccurrencesOfString:@"AAAAAAAA-BBBB-CCCC-DDDD-EEEEEEEEEEEE" withString:@"not-a-uuid"],
        [store stringByReplacingOccurrencesOfString:@"test.csstore" withString:@".csstore"], store];
    NSString *error = nil; BOOL stopped = NO;
    NSArray *paths = BQDiscoverLSStorePaths(0.2, 1, nil, &stopped, &error);
    check(paths.count == 1 && [paths[0] isEqual:[store substringFromIndex:8]] && calls == 4 && !error);
    calls = 0;
    check(BQDiscoverLSStorePaths(0.2, 4, ^BOOL { return YES; }, &stopped, &error).count == 0 && calls == 0);
    check(BQDiscoverLSStorePaths(0, 4, nil, &stopped, &error).count == 0 && calls == 0);
    check(BQDiscoverLSStorePaths(0.2, 0, nil, &stopped, &error).count == 0 && calls == 0);
    calls = 0; observed = @[];
    NSTimeInterval began = NSProcessInfo.processInfo.systemUptime;
    check(BQDiscoverLSStorePaths(0.002, 4, nil, &stopped, &error).count == 0 && stopped);
    check(NSProcessInfo.processInfo.systemUptime - began < 0.5);
    printf("BQLSStoreDiscoveryTests: bounded path, ordering, cancellation and deadline checks passed\n");
} return 0; }
'''.replace('ACTUAL', actual)
build = Path(os.environ.get('BUILD_DIR', root / 'build')) / 'Tests'
build.mkdir(parents=True, exist_ok=True)
with tempfile.TemporaryDirectory(prefix='bq-ls-discovery-') as scratch:
    src = Path(scratch) / 'fixture.m'
    src.write_text(fixture)
    binary = build / 'BQLSStoreDiscoveryTests'
    subprocess.run(['xcrun', '--sdk', 'macosx', 'clang', '-fobjc-arc', '-fblocks', '-Wall', '-Wextra', '-Werror', str(src), '-framework', 'Foundation', '-o', str(binary)], check=True)
    subprocess.run([str(binary)], check=True)
