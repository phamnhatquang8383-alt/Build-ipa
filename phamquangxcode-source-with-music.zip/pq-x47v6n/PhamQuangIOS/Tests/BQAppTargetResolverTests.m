#import <Foundation/Foundation.h>
#import <sys/stat.h>
#import <stdatomic.h>
#import <errno.h>
static NSString *fixtureID, *fixturePath, *fixtureMCM;
static int fixtureErrno;
static mode_t fixtureMode;
static atomic_uint lsCalls, mcmCalls, optionalCalls;
static dispatch_semaphore_t blocked;
static atomic_bool blockStarted;
@interface FixtureApplicationProxy : NSObject
+ (id)applicationProxyForIdentifier:(NSString *)identifier;
- (id)bundleIdentifier;
- (id)dataContainerURL;
- (id)localizedName;
- (id)bundleURL;
@end
@implementation FixtureApplicationProxy
+ (id)applicationProxyForIdentifier:(NSString *)identifier {
    atomic_fetch_add(&lsCalls, 1);
    if (blocked && !atomic_exchange(&blockStarted, true)) dispatch_semaphore_wait(blocked, DISPATCH_TIME_FOREVER);
    return [self new];
}
- (id)bundleIdentifier { return fixtureID; }
- (id)dataContainerURL { return fixturePath ? [NSURL fileURLWithPath:fixturePath] : nil; }
- (id)localizedName { atomic_fetch_add(&optionalCalls, 1); return @"Verified app"; }
- (id)bundleURL { atomic_fetch_add(&optionalCalls, 1); return nil; }
@end
static int FixtureLstat(const char *path, struct stat *st) {
    if (fixtureErrno) { errno = fixtureErrno; return -1; }
    memset(st, 0, sizeof(*st)); st->st_mode = fixtureMode; return 0;
}
NSString *BQLookupApplicationDataPath(NSString *bundleID) { atomic_fetch_add(&mcmCalls, 1); return fixtureMCM; }
static Class FixtureClass(NSString *name) { return [name isEqual:@"LSApplicationProxy"] ? FixtureApplicationProxy.class : Nil; }
#define BQ_RESOLVER_TESTING 1
#define lstat FixtureLstat
#define NSClassFromString FixtureClass
#import "../CC365-Apps/Files/BQCore/BQAppTargetResolver.m"
#undef lstat
#undef NSClassFromString



typedef void *bq_xpc_object_t;
typedef const char *(*fn_get_path)(void *);
static struct {
    void *h; void *(*create)(void); void (*set_class)(void *, uint64_t);
    void (*set_ids)(void *, void *); void (*set_part)(void *, uint64_t);
    void (*set_flags)(void *, uint64_t); void *(*get_one)(void *);
    const char *(*get_path)(void *); void (*query_free)(void *);
} g;
static NSUInteger queryCalls, queryFreed, xpcFreed, queryClass, queryPart;
static uint64_t queryFlags;
static BOOL queryReady, xpcReady;
static const char *queryIdentifier;
static BOOL BQCoreInit(void) { return queryReady; }
static void *QueryCreate(void) { queryCalls++; return &g; }
static void QueryClass(void *q, uint64_t c) { queryClass = c; }
static void QueryPart(void *q, uint64_t p) { queryPart = p; }
static void QueryFlags(void *q, uint64_t f) { queryFlags = f; }
static void QueryIDs(void *q, void *x) { }
static void *QueryGet(void *q) { return &g; }
static const char *QueryPath(void *r) { return "/var/mobile/Containers/Data/Application/11111111-2222-3333-4444-555555555555"; }
static const char *QueryID(void *r) { return queryIdentifier; }
static void QueryFree(void *q) { queryFreed++; }
static void *p_xpc_string_create(const char *s) { return xpcReady ? &g : NULL; }
static void p_xpc_release(void *x) { xpcFreed++; }
static void *QuerySymbol(void *h, const char *s) { return strcmp(s, "container_object_get_identifier") == 0 ? (void *)QueryID : NULL; }
#define dlsym QuerySymbol
#define BQLookupApplicationDataPath ActualMCMDataPath
#include "BQAppTargetMCM.inc"
#undef BQLookupApplicationDataPath
#undef dlsym

static NSUInteger checks;
static void Check(BOOL ok, NSString *name) { if (!ok) { fprintf(stderr, "FAIL %s\n", name.UTF8String); exit(1); } checks++; printf("PASS %s\n", name.UTF8String); }
static void Reset(void) {
    fixtureID = @"com.cc365.test"; fixturePath = @"/var/mobile/Containers/Data/Application/11111111-2222-3333-4444-555555555555";
    fixtureMCM = nil; fixtureErrno = 0; fixtureMode = S_IFDIR | 0700; atomic_store(&lsCalls, 0); atomic_store(&mcmCalls, 0); atomic_store(&optionalCalls, 0); blocked = nil; atomic_store(&blockStarted, false);
}
static NSDictionary *Resolve(NSError **error) { return BQResolveApplicationTarget(@"com.cc365.test", nil, error); }
int main(void) { @autoreleasepool {
    Reset(); NSError *error = nil; NSDictionary *result = Resolve(&error);
    Check(result && !error && [result[@"bundle_id"] isEqual:fixtureID] && [result[@"name"] isEqual:fixtureID] && atomic_load(&mcmCalls) == 0, @"known-id-LS-query-returns-observed-root-without-MCM");
    Check(atomic_load(&optionalCalls) == 0 && !result[@"bundle_path"], @"data-only-LS-lookup-does-not-call-optional-display-or-bundle-getters");
    fixturePath = [@"/private" stringByAppendingString:fixturePath]; error = nil; result = Resolve(&error);
    Check([result[@"data_path"] hasPrefix:@"/var/mobile/"] && [result[@"target_id"] isEqual:[@"path:" stringByAppendingString:result[@"data_path"]]], @"canonical-private-var-alias-keeps-stable-path-identity");
    Reset(); fixtureID = @"com.wrong.app"; error = nil; result = Resolve(&error);
    Check(!result && [error.domain isEqual:CCBQResolveErrorDomain] && error.code == CCBQResolveConflict && atomic_load(&mcmCalls) == 0, @"LS-proxy-identifier-mismatch-is-terminal-conflict-not-fallback");
    Reset(); fixturePath = nil; fixtureMCM = @"/var/mobile/Containers/Data/Application/11111111-2222-3333-4444-555555555555"; error = nil; result = Resolve(&error);
    Check(result && atomic_load(&mcmCalls) == 1, @"targeted-MCM-observation-can-resolve-hidden-LS-data-url");
    Check(atomic_load(&optionalCalls) == 0, @"missing-data-url-falls-back-without-optional-getter-IPC");
    for (NSString *invalid in @[@"/var/mobile/Containers/Data/Application/not-a-uuid", @"/var/mobile/Containers/Shared/AppGroup/11111111-2222-3333-4444-555555555555", @"/var/mobile/Containers/Data/Application/11111111-2222-3333-4444-555555555555/Documents", @"/var/mobile/Containers/Data/Application/../Application/11111111-2222-3333-4444-555555555555"]) {
        Reset(); fixturePath = invalid; fixtureMCM = invalid; error = nil; result = Resolve(&error);
        Check(!result && error.code == CCBQResolveConflict, @"reject-noncanonical-or-nonapplication-root");
    }
    Reset(); fixtureMode = S_IFLNK | 0700; error = nil; result = Resolve(&error);
    Check(!result && error, @"native-root-symlink-is-rejected");
    Reset(); fixtureErrno = ENOENT; error = nil; result = Resolve(&error);
    Check(!result && error, @"missing-native-root-is-rejected");
    Reset(); fixtureErrno = EPERM; error = nil; result = Resolve(&error);
    Check(result && !error, @"observed-root-denial-can-proceed-to-normal-BQ-access-check");
    Reset(); error = nil; result = BQResolveApplicationTarget(@"com.app/../target", nil, &error);
    Check(!result && error && atomic_load(&lsCalls) == 0 && atomic_load(&mcmCalls) == 0, @"invalid-bundle-cannot-start-private-query");
    error = nil; result = BQResolveApplicationTarget(@"com..app", nil, &error);
    Check(!result && error && atomic_load(&lsCalls) == 0, @"empty-bundle-component-rejected");
    Reset(); blocked = dispatch_semaphore_create(0); error = nil;
    result = BQResolveApplicationTarget(@"com.cc365.test", ^BOOL { return atomic_load(&blockStarted); }, &error);
    Check(!result && error.code == NSUserCancelledError, @"cancellation-returns-without-waiting-for-private-IPC");
    error = nil; result = Resolve(&error);
    Check(!result && error && atomic_load(&lsCalls) == 1, @"retry-does-not-spawn-another-blocked-private-query");
    dispatch_semaphore_signal(blocked);
    NSTimeInterval deadline = NSProcessInfo.processInfo.systemUptime + 1;
    do { [NSThread sleepForTimeInterval:0.01]; error = nil; result = Resolve(&error); } while (!result && NSProcessInfo.processInfo.systemUptime < deadline);

    Check(result != nil, @"finished-abandoned-query-releases-single-worker-slot");

    Reset(); fixtureID = nil; fixturePath = nil; error = nil; result = Resolve(&error);
    Check(!result && [error.domain isEqual:CCBQResolveErrorDomain] && error.code == CCBQResolveUnavailable,
        @"no-native-mapping-has-distinct-recoverable-domain-and-code");

    g.create = QueryCreate; g.set_class = QueryClass; g.set_ids = QueryIDs; g.set_part = QueryPart;
    g.set_flags = QueryFlags; g.get_one = QueryGet; g.get_path = QueryPath; g.query_free = QueryFree;
    queryReady = xpcReady = YES; queryIdentifier = "com.cc365.test";
    NSString *path = ActualMCMDataPath(@"com.cc365.test");
    Check(path && queryClass == 2 && queryPart == 0 && queryFlags == 0x100000000ULL && queryFreed == 1 && xpcFreed == 1, @"actual-MCM-helper-queries-exact-root-with-include-path-and-releases-it");
    queryIdentifier = "com.wrong.app";
    Check(!ActualMCMDataPath(@"com.cc365.test") && queryFreed == 2, @"actual-MCM-helper-rejects-different-returned-identifier");
    xpcReady = NO;
    Check(!ActualMCMDataPath(@"com.cc365.test") && queryFreed == 3 && xpcFreed == 2, @"MCM-identifier-allocation-failure-cannot-become-unfiltered-query");
    NSUInteger before = queryCalls;
    Check(!ActualMCMDataPath(@"com.bad/target") && queryCalls == before, @"invalid-MCM-identifier-never-queries");
    printf("%lu target resolver checks passed.\n", (unsigned long)checks); return 0;
}}
