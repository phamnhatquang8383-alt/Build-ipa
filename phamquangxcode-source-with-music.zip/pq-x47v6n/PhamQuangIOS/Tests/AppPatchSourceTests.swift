import Foundation

@main struct AppPatchSourceTests {
    static func main() async throws {
        let fm = FileManager.default
        let sandbox = fm.temporaryDirectory.appendingPathComponent(UUID().uuidString)
        defer { try? fm.removeItem(at: sandbox) }
        let root = "/var/containers/Bundle/Application/UUID/Game.app"
        let dataRoot = "/private/var/mobile/Containers/Data/Application/DATA-UUID"
        let app = PatchTargetApp(bundleID: "com.example.game", name: "Game", bundlePath: root, dataPath: dataRoot)
        let selected = sandbox.appendingPathComponent("Locale")
        for lang in ["vi", "en"] {
            let folder = selected.appendingPathComponent(lang)
            try fm.createDirectory(at: folder, withIntermediateDirectories: true)
            try Data(lang.utf8).write(to: folder.appendingPathComponent("words.json"))
        }
        let staged = try await AppPatchSource.stage(selected)
        let paths = try staged.mappings(destination: "/private" + root + "/Resources/", app: app, scope: .bundle)
        precondition(paths.map(\.destination) == ["Resources/en/words.json", "Resources/vi/words.json"])
        precondition(paths[0].local != paths[1].local)
        let bytes = try paths.map { try Data(contentsOf: $0.local) }
        precondition(bytes == ["en", "vi"].map { Data($0.utf8) })
        for invalid in [root + ".other/Resources", root + "/../Other", root + "//Other",
                        "/other/Game.app/file", "Resources/../Other", "/var/mobile/Containers/Data/Application/UUID/file"] {
            let result = try? staged.mappings(destination: invalid, app: app, scope: .bundle)
            precondition(result == nil, "Accepted path outside the selected target: \(invalid)")
        }

        let one = try await AppPatchSource.stage(selected.appendingPathComponent("vi/words.json"))
        let renamed = try one.mappings(destination: root + "/Game.plist", app: app, scope: .bundle)
        precondition(renamed.count == 1 && renamed[0].destination == "Game.plist")
        let missingFilename = try? one.mappings(destination: root, app: app, scope: .bundle)
        precondition(missingFilename == nil)

        let cacheFile = "Library/Caches/vi/words.json"
        for input in ["Application//" + cacheFile, "Application/com.example.game/" + cacheFile, cacheFile,
                      dataRoot + "/" + cacheFile, String(dataRoot.dropFirst(8)) + "/" + cacheFile] {
            let mappings = try one.mappings(destination: input, app: app, scope: .data)
            precondition(mappings.count == 1 && mappings[0].destination == cacheFile)
        }
        let cacheFolder = try staged.mappings(destination: "Application//Library/Caches/", app: app, scope: .data)
        precondition(cacheFolder.map(\.destination) == ["Library/Caches/en/words.json", "Library/Caches/vi/words.json"])
        for invalid in ["Application/com.other.game/" + cacheFile, "Application//Documents",
                        "Application//Library/Caches2/file", "Application//Library/Caches/",
                        "Application//Library/Caches", "Application///Library/Caches/file",
                        "Application//Library/Caches/../Preferences/config", "Application//Library/Caches//file",
                        "Application//Library/Caches/.temp/file", root + "/file"] {
            let mapping = try? one.mappings(destination: invalid, app: app, scope: .data)
            precondition(mapping == nil, "Accepted invalid cache target: \(invalid)")
        }
        let aliasInBundle = try? one.mappings(destination: "Application//" + cacheFile, app: app, scope: .bundle)
        precondition(aliasInBundle == nil)
        for path in ["Application//Documents/words.json", "Application/com.example.game/Documents/words.json", "Documents/words.json"] {
            let docs = try one.mappings(destination: path, app: app, scope: .data)
            precondition(docs[0].destination == "Documents/words.json")
        }
        try await checkUnidentifiedTarget(in: sandbox, file: one)
        try await checkObservedContainerBinding(in: sandbox)
        try await checkWorkspace(in: sandbox, app: app)
        try await checkZIP(in: sandbox, app: app)
        try await checkSourceFirst(in: sandbox, app: app)
        if CommandLine.arguments.count == 3 { try await checkRealZIP(archive: CommandLine.arguments[1], tree: CommandLine.arguments[2]) }
        try await checkFileImports(in: sandbox, app: app)
        try await checkLocalPicker(in: sandbox)

        try fm.createSymbolicLink(at: selected.appendingPathComponent("link"), withDestinationURL: sandbox)
        let unsafeSource = try? await AppPatchSource.stage(selected)
        precondition(unsafeSource == nil, "A selected patch must reject symlinks")
        print("AppPatchSourceTests: file and folder imports, target isolation, document/cache aliases and symlink rejection passed")
    }
    private static func expectFailure(_ operation: () async throws -> Void) async {
        do { try await operation(); preconditionFailure("Expected patch import rejection") }
        catch {}
    }

    private static func checkObservedContainerBinding(in sandbox: URL) async throws {
        let tree = sandbox.appendingPathComponent("explicit/Application/com.example.game/Documents")
        try FileManager.default.createDirectory(at: tree, withIntermediateDirectories: true)
        try Data([1, 2, 3]).write(to: tree.appendingPathComponent("game.bin"))
        let source = try await AppPatchSource.stage(tree)
        let root = "/var/mobile/Containers/Data/Application/11111111-2222-4333-8444-555555555555"
        let unknown = PatchTargetApp(bundleID: nil, name: "Container", bundlePath: nil, dataPath: root, targetID: "path:" + root)
        await expectFailure { _ = try source.mappings(destination: "", app: unknown, scope: .data) }
        let bound = try source.binding(toObservedContainer: unknown)
        let mapped = try bound.mappings(destination: "", app: unknown, scope: .data)
        precondition(bound.usesExplicitContainerSelection && bound.embeddedBundleID == "com.example.game")
        precondition(unknown.bundleID == nil && mapped.map(\.destination) == ["Documents/game.bin"])
        let content = try Data(contentsOf: mapped[0].local)
        precondition(content == Data([1, 2, 3]))
        await expectFailure { _ = try bound.binding(toObservedContainer: unknown) }
        await expectFailure { _ = try bound.mappings(destination: "", app: unknown, scope: .bundle) }
        let changed = PatchTargetApp(bundleID: nil, name: "Changed", bundlePath: nil, dataPath: root + "-new", targetID: unknown.id)
        await expectFailure { _ = try bound.mappings(destination: "", app: changed, scope: .data) }
        let changedID = PatchTargetApp(bundleID: nil, name: "Changed", bundlePath: nil, dataPath: root, targetID: "path:other")
        await expectFailure { _ = try bound.mappings(destination: "", app: changedID, scope: .data) }
        let wrong = PatchTargetApp(bundleID: "com.other.app", name: "Other", bundlePath: nil, dataPath: root, targetID: unknown.id)
        await expectFailure { _ = try source.binding(toObservedContainer: wrong) }
        await expectFailure { _ = try bound.mappings(destination: "", app: wrong, scope: .data) }
        let forged = PatchTargetApp(bundleID: nil, name: "Invalid", bundlePath: nil, dataPath: root, targetID: nil)
        await expectFailure { _ = try source.binding(toObservedContainer: forged) }
        let known = PatchTargetApp(bundleID: "com.example.game", name: "Known", bundlePath: nil, dataPath: root, targetID: unknown.id)
        let knownBound = try source.binding(toObservedContainer: known)
        let knownMappings = try knownBound.mappings(destination: "", app: known, scope: .data)
        precondition(knownMappings.count == 1)
        let alreadyBound = try await AppPatchSource.stage(tree, app: known)
        await expectFailure { _ = try alreadyBound.binding(toObservedContainer: unknown) }
        print("Observed-container binding: unknown owner stays nil, exact root/target, conflict, scope and rebinding checks passed")
    }

    private static func checkUnidentifiedTarget(in sandbox: URL, file: AppPatchSource) async throws {
        let path = "/var/mobile/Containers/Data/Application/00000000-0000-4000-8000-000000000001"
        let payload = try JSONSerialization.data(withJSONObject: ["target_id": "path:" + path,
            "name": "Container 00000000-0000-4000-8000-000000000001", "data_path": path])
        let unknown = try JSONDecoder().decode(PatchTargetApp.self, from: payload)
        precondition(unknown.bundleID == nil && unknown.id == "path:" + path)
        precondition(unknown.identityDescription == path && unknown.displayName.hasPrefix("Container "))
        let mapped = try file.mappings(destination: "Application//Documents/unknown.bin", app: unknown, scope: .data)
        precondition(mapped[0].destination == "Documents/unknown.bin")
        await expectFailure { _ = try file.mappings(destination: "Application/com.example.game/Documents/unknown.bin", app: unknown, scope: .data) }
        await expectFailure { _ = try file.mappings(destination: "/var/mobile/Containers/Data/Application/OTHER/Documents/file", app: unknown, scope: .data) }
        let tree = sandbox.appendingPathComponent("unidentified-source/Application/com.example.game/Documents")
        try FileManager.default.createDirectory(at: tree, withIntermediateDirectories: true)
        try Data([1, 2]).write(to: tree.appendingPathComponent("resource.bin"))
        await expectFailure { _ = try await AppPatchSource.stage(tree, app: unknown) }
        let archiveRoot = sandbox.appendingPathComponent("unidentified-zip/Documents")
        try FileManager.default.createDirectory(at: archiveRoot, withIntermediateDirectories: true)
        try Data([4, 5]).write(to: archiveRoot.appendingPathComponent("resource.bin"))
        let archive = sandbox.appendingPathComponent("unidentified.zip")
        let zip = Process()
        zip.executableURL = URL(fileURLWithPath: "/usr/bin/zip")
        zip.currentDirectoryURL = archiveRoot.deletingLastPathComponent()
        zip.arguments = ["-q", archive.path, "Documents/resource.bin"]
        try zip.run(); zip.waitUntilExit(); precondition(zip.terminationStatus == 0)
        let staged = try await AppPatchSource.stage(archive, app: unknown)
        let paths = try staged.mappings(destination: "", app: unknown, scope: .data)
        precondition(staged.hasEmbeddedDestinations && paths[0].destination == "Documents/resource.bin")

        let sameTarget = PatchTargetApp(bundleID: "com.example.game", name: "Game", bundlePath: nil,
            dataPath: path, targetID: unknown.id)
        let remapped = try staged.mappings(destination: "", app: sameTarget, scope: .data)
        precondition(remapped.count == 1)
        let other = PatchTargetApp(bundleID: nil, name: "Other", bundlePath: nil,
            dataPath: path + "-other", targetID: "path:" + path + "-other")
        await expectFailure { _ = try staged.mappings(destination: "", app: other, scope: .data) }
    }

    private static func checkLocalPicker(in sandbox: URL) async throws {
        let fm = FileManager.default
        let documents = sandbox.appendingPathComponent("PickerDocuments")
        try fm.createDirectory(at: documents, withIntermediateDirectories: false)
        let picker = LocalPatchDirectory(root: documents)
        try picker.prepareDropFolderIfEmpty()
        let root = try picker.url(for: [], isDirectory: true)
        precondition(root.path == documents.path)
        let folder = try picker.url(for: ["Patch"], isDirectory: true)
        let file = folder.appendingPathComponent("sample.bytes")
        try Data([7, 8, 9]).write(to: file)
        for name in [".Trashes", "__MACOSX"] {
            try fm.createDirectory(at: folder.appendingPathComponent(name), withIntermediateDirectories: false)
        }
        try fm.createSymbolicLink(at: folder.appendingPathComponent("linked"), withDestinationURL: sandbox)
        let entries = try picker.contents(of: ["Patch"])
        precondition(entries.map(\.name) == ["sample.bytes"])
        let selection = try picker.url(for: ["Patch", entries[0].name], isDirectory: false)
        let source = try await AppPatchSource.stage(selection, expectDirectory: false)
        precondition(source.size == 3 && source.files.count == 1)
        await expectFailure { _ = try await AppPatchSource.stage(selection, expectDirectory: true) }
        await expectFailure { _ = try await AppPatchSource.stage(folder, expectDirectory: false) }
        for invalid in [["..", "sample.bytes"], ["Patch/sample.bytes"], ["Patch", "linked", "sample.bytes"],
                        ["Patch", ".Trashes"], ["Patch", "__MACOSX"]] {
            await expectFailure { _ = try picker.url(for: invalid, isDirectory: false) }
        }
        try fm.removeItem(at: folder)
        try fm.createSymbolicLink(at: folder, withDestinationURL: sandbox)
        await expectFailure { _ = try picker.url(for: ["Patch"], isDirectory: true) }
        let remaining = try picker.contents(of: [])
        precondition(remaining.isEmpty)
    }

    private static func checkWorkspace(in sandbox: URL, app: PatchTargetApp) async throws {
        let fm = FileManager.default
        let outer = sandbox.appendingPathComponent("unpacked")
        let apps = outer.appendingPathComponent("Application")
        let owner = apps.appendingPathComponent(app.bundleID!)
        let inner = owner.appendingPathComponent("Documents/Resources/1.2.3")
        try fm.createDirectory(at: inner, withIntermediateDirectories: true)
        let file = inner.appendingPathComponent("asset.bytes")
        try Data([0, 0xff, 4]).write(to: file)
        try Data([0]).write(to: outer.appendingPathComponent(".DS_Store"))
        for url in [outer, apps, owner, inner, file] {
            let src = try await AppPatchSource.stage(url, app: app)
            let result = try src.mappings(destination: "Library/Caches/untrusted", app: app, scope: .data)
            precondition(src.hasEmbeddedDestinations && result.count == 1)
            precondition(result[0].destination == "Documents/Resources/1.2.3/asset.bytes" && result[0].size == 3)
            let wrongScope = try? src.mappings(destination: "", app: app, scope: .bundle)
            precondition(wrongScope == nil)
        }
        let other = PatchTargetApp(bundleID: "com.example.other", name: "Other", bundlePath: nil, dataPath: "/other")
        await expectFailure { _ = try await AppPatchSource.stage(outer, app: other) }
        try fm.createDirectory(at: owner.appendingPathComponent("Library/Caches"), withIntermediateDirectories: true)
        try Data([3]).write(to: owner.appendingPathComponent("Library/Caches/mixed.bin"))
        let mixed = try await AppPatchSource.stage(outer, app: app)
        let mixedPaths = try mixed.mappings(destination: "", app: app, scope: .data).map(\.destination)
        precondition(mixedPaths.contains("Library/Caches/mixed.bin") && mixedPaths.count == 2)
    }

    private static func checkZIP(in sandbox: URL, app: PatchTargetApp) async throws {
        let root = sandbox.appendingPathComponent("zip-fixtures")
        let relative = "Wrapper/Application/" + app.bundleID! + "/Documents/Assets/hello.bytes"
        let original = root.appendingPathComponent(relative)
        try FileManager.default.createDirectory(at: original.deletingLastPathComponent(), withIntermediateDirectories: true)
        let data = Data(repeating: 61, count: 200_000)
        try data.write(to: original)
        func compress(name: String, member: String) throws -> URL {
            let archive = sandbox.appendingPathComponent(name)
            let proc = Process()
            proc.executableURL = URL(fileURLWithPath: "/usr/bin/zip")
            proc.currentDirectoryURL = root
            proc.arguments = ["-q", archive.path, member]
            try proc.run(); proc.waitUntilExit()
            precondition(proc.terminationStatus == 0)
            return archive
        }
        let archive = try compress(name: "wrapped.ZIP", member: relative)
        let alias = root.appendingPathComponent("wrapped.VAILON")
        try FileManager.default.copyItem(at: archive, to: alias)
        let aliasSource = try await AppPatchSource.stage(alias, app: app)
        precondition(aliasSource.hasEmbeddedDestinations && aliasSource.files.count == 1)
        let staged = try await AppPatchSource.stage(archive, app: app, expectDirectory: false)
        let mappings = try staged.mappings(destination: "", app: app, scope: .data)
        let contents = try Data(contentsOf: mappings[0].local)
        precondition(staged.isDirectory && staged.hasEmbeddedDestinations && staged.name == "wrapped.ZIP")
        precondition(mappings.count == 1 && mappings[0].destination == "Documents/Assets/hello.bytes" && contents == data)
        let wrong = PatchTargetApp(bundleID: "com.example.another", name: "Other", bundlePath: nil, dataPath: "/d")
        await expectFailure { _ = try await AppPatchSource.stage(archive, app: wrong) }
        await expectFailure { _ = try await AppPatchSource.stage(archive, app: app, scope: .bundle) }
        let sub = root.appendingPathComponent("Textures")
        try FileManager.default.createDirectory(at: sub, withIntermediateDirectories: true)
        try data.write(to: sub.appendingPathComponent("A"))
        let plain = try compress(name: "assets.zip", member: "Textures/A")
        let manual = try await AppPatchSource.stage(plain, app: app)
        let paths = try manual.mappings(destination: "Documents/Game", app: app, scope: .data)
        precondition(manual.isDirectory && !manual.hasEmbeddedDestinations && paths[0].destination == "Documents/Game/Textures/A")
        let invalid = sandbox.appendingPathComponent("bad.zip")
        try Data("not an archive".utf8).write(to: invalid)
        await expectFailure { _ = try await AppPatchSource.stage(invalid, app: app) }
    }

    private static func checkRealZIP(archive: String, tree: String) async throws {
        let owner = "com.garena.game.kgvn"
        let app = PatchTargetApp(bundleID: owner, name: "", bundlePath: nil, dataPath: "/fixture")
        let staged = try await AppPatchSource.stage(URL(fileURLWithPath: archive), expectDirectory: false)
        precondition(staged.embeddedBundleID == owner && staged.hasEmbeddedDestinations)
        let mappings = try staged.mappings(destination: "", app: app, scope: .data)
        let base = URL(fileURLWithPath: tree).appendingPathComponent("Application/" + owner)
        for row in mappings {
            let original = try Data(contentsOf: base.appendingPathComponent(row.destination))
            let unpacked = try Data(contentsOf: row.local)
            precondition(unpacked == original)
        }
        precondition(mappings.count == 522 && Set(mappings.map(\.destination)).count == 522 && staged.size == 39_200_485)
        let folder = try await AppPatchSource.stage(URL(fileURLWithPath: tree), expectDirectory: true)
        let folderMappings = try folder.mappings(destination: "", app: app, scope: .data)
        precondition(folder.embeddedBundleID == owner && folder.size == staged.size && folderMappings.map(\.destination) == mappings.map(\.destination))
        print("Real archive and folder, imported before target selection: 522 distinct destinations; 39,200,485 decoded bytes match original files.")
    }

    private static func checkSourceFirst(in sandbox: URL, app: PatchTargetApp) async throws {
        let fm = FileManager.default
        let base = sandbox.appendingPathComponent("source-first")
        let owner = app.bundleID!
        let relative = "Outer/Inner/Application/" + owner + "/Documents/Resources/file.bytes"
        func write(_ path: String, under directory: URL) throws {
            let file = directory.appendingPathComponent(path)
            try fm.createDirectory(at: file.deletingLastPathComponent(), withIntermediateDirectories: true)
            try Data([0, 255, 1]).write(to: file)
        }
        func archive(_ folder: URL, name: String) throws -> URL {
            let result = sandbox.appendingPathComponent(name + ".zip")
            let process = Process()
            process.executableURL = URL(fileURLWithPath: "/usr/bin/zip")
            process.currentDirectoryURL = folder
            process.arguments = ["-q", "-r", result.path, "."]
            try process.run(); process.waitUntilExit()
            precondition(process.terminationStatus == 0)
            return result
        }
        try write(relative, under: base)
        let zip = try archive(base, name: "source-first")
        let container = base.appendingPathComponent("Outer/Inner/Application/" + owner)
        let choices = [zip, base, base.appendingPathComponent("Outer"),
            base.appendingPathComponent("Outer/Inner/Application"), container,
            container.appendingPathComponent("Documents/Resources"), container.appendingPathComponent("Documents/Resources/file.bytes")]
        for choice in choices {
            let source = try await AppPatchSource.stage(choice)
            precondition(source.embeddedBundleID == owner && source.hasEmbeddedDestinations)
            let mapped = try source.mappings(destination: "", app: app, scope: .data)
            precondition(mapped.count == 1 && mapped[0].destination == "Documents/Resources/file.bytes")
            let bytes = try Data(contentsOf: mapped[0].local)
            precondition(bytes == Data([0, 255, 1]))
            let wrong = PatchTargetApp(bundleID: "com.example.other", name: "Other", bundlePath: nil, dataPath: app.dataPath)
            let unknown = PatchTargetApp(bundleID: nil, name: "Unknown", bundlePath: nil, dataPath: app.dataPath)
            let missing = PatchTargetApp(bundleID: owner, name: "Missing", bundlePath: nil, dataPath: nil)
            for target in [wrong, unknown, missing] {
                await expectFailure { _ = try source.mappings(destination: "", app: target, scope: .data) }
            }
            await expectFailure { _ = try source.mappings(destination: "", app: app, scope: .bundle) }
        }


        let nestedPath = "Documents/Assets/Application/com.example.other/Documents/nested.bytes"
        try write(nestedPath, under: container)
        let innerApplication = container.appendingPathComponent("Documents/Assets/Application")
        let innerOwner = innerApplication.appendingPathComponent("com.example.other")
        for choice in [innerApplication, innerOwner, innerOwner.appendingPathComponent("Documents"), innerOwner.appendingPathComponent("Documents/nested.bytes")] {
            for selectedApp in [nil, app] as [PatchTargetApp?] {
                let source = try await AppPatchSource.stage(choice, app: selectedApp)
                precondition(source.embeddedBundleID == owner && source.hasEmbeddedDestinations)
                let mapped = try source.mappings(destination: "", app: app, scope: .data)
                precondition(mapped.count == 1 && mapped[0].destination == nestedPath)
                let other = PatchTargetApp(bundleID: "com.example.other", name: "Other", bundlePath: nil, dataPath: "/other")
                await expectFailure { _ = try source.mappings(destination: "", app: other, scope: .data) }
            }
        }
        let providerOwned = sandbox.appendingPathComponent("NestedProvider/Data/Application/00000000-0000-4000-8000-000000000003/Documents/Patch/Application/" + owner)
        try write(nestedPath, under: providerOwned)
        let providerNested = providerOwned.appendingPathComponent(nestedPath)
        for choice in [providerNested.deletingLastPathComponent(), providerNested] {
            let source = try await AppPatchSource.stage(choice)
            let mapped = try source.mappings(destination: "", app: app, scope: .data)
            precondition(source.embeddedBundleID == owner && mapped[0].destination == nestedPath)
        }

        let firstPath = PatchTargetApp(bundleID: owner, name: "Game", bundlePath: nil, dataPath: "/first", targetID: "path:/first")
        let nextPath = PatchTargetApp(bundleID: owner, name: "Game", bundlePath: nil, dataPath: "/second", targetID: "path:/second")
        let bound = try await AppPatchSource.stage(zip, app: firstPath)
        await expectFailure { _ = try bound.mappings(destination: "", app: nextPath, scope: .data) }


        let standalone = sandbox.appendingPathComponent("standalone/" + owner)
        try write("Library/Caches/assets/file.bytes", under: standalone)
        let cache = try await AppPatchSource.stage(standalone)
        let cachePaths = try cache.mappings(destination: "", app: app, scope: .data)
        precondition(cache.embeddedBundleID == owner && cachePaths[0].destination == "Library/Caches/assets/file.bytes")


        let provider = sandbox.appendingPathComponent("Provider/Data/Application/00000000-0000-4000-8000-000000000002/Documents/Patch")
        try write("assets/file.bytes", under: provider)
        let providerSource = try await AppPatchSource.stage(provider)
        precondition(providerSource.embeddedBundleID == nil && !providerSource.hasEmbeddedDestinations)
        let unowned = sandbox.appendingPathComponent("unowned")
        try write("Documents/Resources/file.bytes", under: unowned)
        let manual = try await AppPatchSource.stage(unowned)
        precondition(manual.embeddedBundleID == nil && !manual.hasEmbeddedDestinations)

        let badTrees: [[String]] = [
            ["Application/com.example.one/Documents/a", "Application/com.example.two/Documents/b"],
            ["Application/bad owner/Documents/a"],
            ["Application/com..example/Documents/a"],
            ["Application/" + owner + "/Library/Preferences/a"],
            ["First/Application/" + owner + "/Documents/a", "Second/Application/" + owner + "/Documents/b"],
            ["Wrapper/Application/" + owner + "/Documents/a", "README.txt"],
            ["Application/" + owner + "/Documents/a", "other.txt"]
        ]
        for (index, paths) in badTrees.enumerated() {
            let directory = sandbox.appendingPathComponent("source-invalid-\(index)")
            for path in paths { try write(path, under: directory) }
            let zipped = try archive(directory, name: "source-invalid-\(index)")
            for choice in [directory, zipped] {
                await expectFailure { _ = try await AppPatchSource.stage(choice) }
            }
        }
        let invalidOwner = sandbox.appendingPathComponent("source-invalid-1/Application/bad owner")
        for choice in [invalidOwner, invalidOwner.appendingPathComponent("Documents"), invalidOwner.appendingPathComponent("Documents/a")] {
            await expectFailure { _ = try await AppPatchSource.stage(choice) }
        }

        let ordinary = sandbox.appendingPathComponent("ordinary-content")
        try write("Documents/Assets/Application/graphics.bytes", under: ordinary)
        let ordinarySource = try await AppPatchSource.stage(ordinary)
        precondition(ordinarySource.embeddedBundleID == nil && !ordinarySource.hasEmbeddedDestinations)
        print("Source-first imports: explicit owners, deferred target validation, wrappers, manual fallback and 14 malformed folder/ZIP rejection cases passed.")
    }

    private static func checkFileImports(in sandbox: URL, app: PatchTargetApp) async throws {
        let folder = sandbox.appendingPathComponent("Downloads")
        try FileManager.default.createDirectory(at: folder, withIntermediateDirectories: true)
        let renamed = folder.appendingPathComponent("renamed.bin")

        for data in [Data(), Data([0, 255, 1, 128]), Data("payload".utf8)] {
            try data.write(to: renamed)
            let staged = try await AppPatchSource.stage(renamed, app: app)
            let contents = try Data(contentsOf: staged.files[0].local)
            precondition(contents == data && staged.size == data.count)
            let imported = try await FileTransferSupport.stageImport(renamed)
            let importedBytes = try Data(contentsOf: imported.file)
            precondition(importedBytes == data)
        }
    }
}
