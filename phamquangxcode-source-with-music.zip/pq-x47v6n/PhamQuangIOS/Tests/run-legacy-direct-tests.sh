#!/bin/bash
set -euo pipefail
root="$(cd "$(dirname "$0")/.." && pwd)"
scratch="$(mktemp -d "${TMPDIR:-/tmp}/viet99-legacy-tests.XXXXXX")"
trap 'rm -rf "$scratch"' EXIT
clang -fobjc-arc -fblocks -O2 -framework Foundation \
    "$root/Tests/LegacyDirectAccessTests.m" -o "$scratch/legacy-tests"
"$scratch/legacy-tests"
