import Foundation

@MainActor final class MockVPNDriver: LegacyVPNDriver {
    var status = LegacyVPNStatus.disconnected
    var configured = false
    var denied = false
    var stalls = false
    var stopStalls = false
    var calls: [String] = []
    func load(providerIdentifier: String) async throws -> Bool {
        calls.append("load:" + providerIdentifier)
        return configured
    }
    func configure(providerIdentifier: String) async throws {
        calls.append("configure:" + providerIdentifier)
        if denied { throw LegacyVPNError(message: "User denied VPN permission") }
        configured = true
    }
    func start() throws { calls.append("start"); status = stalls ? .connecting : .connected }
    func stop() { calls.append("stop"); status = stopStalls ? .disconnecting : .disconnected }
}

@MainActor @main struct LegacyInternalVPNTests {
    static var count = 0
    static let provider = "sato.cc365.file.tunnel"
    static func check(_ condition: Bool, _ name: String) {
        precondition(condition, name); count += 1; print("PASS " + name)
    }
    static func controller(_ driver: MockVPNDriver, mode: DeviceAccessMode = .airLift,
                           instant: Bool = true, polls: Int = 12) -> LegacyInternalVPN {
        LegacyInternalVPN(driver: driver, mode: { mode }, providerIdentifier: { provider },
                          sleep: { if !instant { try await Task.sleep(nanoseconds: $0) } },
                          connectPolls: polls, stopPolls: polls)
    }
    static func main() async throws {
        let firstDriver = MockVPNDriver(), first = controller(firstDriver)
        do { try await first.ensureConnected(); preconditionFailure("Auto-start must not request first consent") } catch { }
        check(firstDriver.calls == ["load:" + provider] && !first.isBusy,
              "first-network-use-does-not-save-or-start-without-explicit-consent")
        firstDriver.calls = []
        try await first.authorizeAndConnect()
        check(firstDriver.calls == ["load:" + provider, "configure:" + provider, "start"] && first.isConnected,
              "setup-button-configures-exact-own-provider-before-start")
        firstDriver.calls = []
        try await first.ensureConnected()
        check(firstDriver.calls.isEmpty, "connected-tunnel-is-reused-without-resaving-profile")
        await first.disconnectAfterPatch()
        check(firstDriver.calls == ["stop"] && !first.isConnected && !first.isBusy,
              "post-patch-cleanup-stops-own-tunnel-and-releases-busy-state")
        firstDriver.calls = []
        try await first.ensureConnected()
        check(firstDriver.calls == ["load:" + provider, "start"], "later-job-autoconnects-approved-profile-without-consent-save")

        for mode in [DeviceAccessMode.bqCore, .directLegacy, .unsupported] {
            let driver = MockVPNDriver(), vpn = controller(driver, mode: mode)
            do { try await vpn.ensureConnected(); preconditionFailure("Unsupported mode") } catch { }
            do { try await vpn.authorizeAndConnect(); preconditionFailure("Unsupported mode") } catch { }
            vpn.stop(); await vpn.disconnectAfterPatch()
            check(driver.calls.isEmpty, "\(mode)-never-loads-saves-starts-or-stops-vpn")
        }
        let deniedDriver = MockVPNDriver(); deniedDriver.denied = true
        let denied = controller(deniedDriver)
        do { try await denied.authorizeAndConnect(); preconditionFailure("Must propagate permission denial") } catch { }
        check(!denied.isBusy && !denied.isConnected && !deniedDriver.calls.contains("start") && denied.error != nil,
              "denied-system-permission-clears-busy-and-never-starts")

        let stalledDriver = MockVPNDriver(); stalledDriver.configured = true; stalledDriver.stalls = true
        let stalled = controller(stalledDriver)
        do { try await stalled.ensureConnected(); preconditionFailure("Must time out") } catch { }
        check(stalledDriver.calls.last == "stop" && !stalled.isBusy && stalled.error != nil,
              "bounded-start-timeout-stops-only-the-owned-start")

        let cancelDriver = MockVPNDriver(); cancelDriver.configured = true; cancelDriver.stalls = true
        let cancel = controller(cancelDriver, instant: false)
        let pending = Task { try await cancel.ensureConnected() }
        while !cancelDriver.calls.contains("start") { await Task.yield() }
        pending.cancel()
        do { try await pending.value; preconditionFailure("Must cancel") } catch is CancellationError { }
        check(cancelDriver.calls.last == "stop" && !cancel.isBusy && cancel.error == nil,
              "startup-task-cancellation-stops-owned-tunnel-without-stale-busy-error")

        let stopDriver = MockVPNDriver(); stopDriver.configured = true; stopDriver.stalls = true
        let stopped = controller(stopDriver, instant: false)
        let starting = Task { try await stopped.ensureConnected() }
        while !stopDriver.calls.contains("start") { await Task.yield() }
        stopped.stop()
        do { try await starting.value; preconditionFailure("Explicit stop must defeat pending start") } catch is CancellationError { }
        check(!stopped.isConnected && !stopped.isBusy, "explicit-stop-invalidates-in-flight-start-generation")

        let cleanupDriver = MockVPNDriver(); cleanupDriver.configured = true
        let cleanup = controller(cleanupDriver)
        try await cleanup.ensureConnected()
        let canceledCleanup = Task { await cleanup.disconnectAfterPatch() }
        canceledCleanup.cancel()
        await canceledCleanup.value
        check(!cleanup.isConnected && cleanupDriver.calls.last == "stop",
              "already-canceled-patch-task-still-waits-for-vpn-shutdown")
        print("Internal VPN lifecycle: \(count) checks passed")
    }
}
