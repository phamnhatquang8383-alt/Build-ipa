#!/bin/bash
set -euo pipefail
cd "$(dirname "$0")/.."
browser_build="${BUILD_DIR:-$PWD/build}"
mkdir -p "$browser_build/Tests"
xcrun --sdk macosx swiftc -O -swift-version 5 -strict-concurrency=complete -warnings-as-errors \
  -I Vendor/cc365 CC365-Apps/Files/AppFileSettings.swift CC365-Apps/Files/FileTransferSupport.swift \
  CC365-Apps/Files/FileBrowserOperations.swift Tests/FileBrowserOperationsTests.swift \
  "$browser_build/rust/host/debug/libcc365_core.a" -o "$browser_build/Tests/FileBrowserOperationsTests"
"$browser_build/Tests/FileBrowserOperationsTests"
