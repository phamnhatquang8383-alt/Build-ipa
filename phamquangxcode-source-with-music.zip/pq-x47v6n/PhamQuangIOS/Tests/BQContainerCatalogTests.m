#import <Foundation/Foundation.h>
#import <dirent.h>
#import <fcntl.h>
#import <sys/stat.h>
#import <unistd.h>
#import <errno.h>
#import <stdatomic.h>
#import <sys/xattr.h>
#import "BQContainerCatalog.h"

static NSString *fixture;
static NSArray *applicationRecords;
static NSArray *installedRecords;
static NSArray *storeRecords;
static NSDictionary<NSString *, NSData *> *attributes;
static int storeReads;
NSArray<NSDictionary *> *BQReadLSApplicationRecords(BOOL (^cancelled)(void), NSString **notice) {
    storeReads++;
    if (notice) *notice = nil;
    return cancelled && cancelled() ? @[] : (storeRecords ?: @[]);
}
static int lookups, installedLookups, scans, checks;
static Class fixture_class(NSString *name) { return NSClassFromString([name isEqualToString:@"LSApplicationWorkspace"] ? @"FixtureApplicationWorkspace" : name); }
static BOOL denyRoots, slowLookup;
static BOOL denyMetadata, failLeasedRead, throwLeasedRead, cancelOnLease, cancelOnRead, fixtureCancelled, expireOnLease;
static int leaseCalls, releaseCalls, activeLeases, metadataFD = -1, metadataCloses;
static int64_t rootLeaseFailure, everyLeaseFailure;
static NSTimeInterval clockOffset;
static atomic_int pendingSlowGetters;
static int injectedStatFD = -1, injectedReadFD = -1;
static NSMutableArray<NSString *> *diagnosticLogs;
void BQLog(NSString *format, ...) {
    va_list args; va_start(args, format);
    NSString *line = [[NSString alloc] initWithFormat:format arguments:args];
    va_end(args);
    if (!diagnosticLogs) diagnosticLogs = [NSMutableArray array];
    [diagnosticLogs addObject:line];
}

@interface FixtureProcessInfo : NSObject
+ (instancetype)processInfo;
@property (nonatomic, readonly) NSTimeInterval systemUptime;
@property (nonatomic, readonly) NSOperatingSystemVersion operatingSystemVersion;
@end
@implementation FixtureProcessInfo
+ (instancetype)processInfo { return [self new]; }
- (NSTimeInterval)systemUptime { return NSProcessInfo.processInfo.systemUptime + clockOffset; }
- (NSOperatingSystemVersion)operatingSystemVersion { return NSProcessInfo.processInfo.operatingSystemVersion; }
@end
static NSDictionary *rootMap(void) {
    return @{@"/var/mobile/Containers/Data/Application": @"apps",
             @"/var/mobile/Containers/Data/PluginKitPlugin": @"plugins",
             @"/var/mobile/Containers/Shared/AppGroup": @"groups",
             @"/var/containers/Shared/SystemGroup": @"system"};
}
static NSString *mapped(const char *raw) {
    NSString *path = [NSString stringWithUTF8String:raw];
    if ([path hasPrefix:@"/private/var/"]) path = [path substringFromIndex:8];
    for (NSString *root in rootMap()) {
        if ([path isEqualToString:root] || [path hasPrefix:[root stringByAppendingString:@"/"]])
            return [[fixture stringByAppendingPathComponent:rootMap()[root]] stringByAppendingString:[path substringFromIndex:root.length]];
    }
    return path;
}
static int fixture_lstat(const char *path, struct stat *st) {
    if ([[NSString stringWithUTF8String:path] hasSuffix:@"/DeniedUUID"] || [[NSString stringWithUTF8String:path] hasSuffix:@"/Denied.app"]) { errno = EACCES; return -1; }
    return lstat(mapped(path).fileSystemRepresentation, st);
}
static int fixture_access(const char *path, int flags) { return access(mapped(path).fileSystemRepresentation, flags); }
static ssize_t fixture_getxattr(const char *path, __unused const char *name, void *buffer, size_t size, __unused uint32_t position, __unused int options) {
    NSData *value = attributes[[NSString stringWithUTF8String:path]];
    if (!value) { errno = ENOATTR; return -1; }
    if (value.length > size) { errno = ERANGE; return -1; }
    memcpy(buffer, value.bytes, value.length);
    return (ssize_t)value.length;
}
static DIR *fixture_opendir(const char *path) {
    if (denyRoots && rootMap()[[NSString stringWithUTF8String:path]]) { errno = EACCES; return NULL; }
    return opendir(mapped(path).fileSystemRepresentation);
}
static int fixture_open(const char *path, int flags) {
    NSString *name = [NSString stringWithUTF8String:path];
    BOOL metadata = [name.lastPathComponent isEqualToString:@".com.apple.mobile_container_manager.metadata.plist"];
    if (metadata && denyMetadata && [name hasPrefix:@"/var/mobile/Containers/Data/Application/"]) { errno = EACCES; return -1; }
    if (metadata && activeLeases && throwLeasedRead) [NSException raise:@"FixtureRead" format:@"metadata read threw"];
    if (metadata && activeLeases && failLeasedRead) { errno = EACCES; return -1; }
    int fd = open(mapped(path).fileSystemRepresentation, flags);
    if (metadata && activeLeases && fd >= 0) metadataFD = fd;
    return fd;
}
static int fixture_openat(int directory, const char *path, int flags) {
    BOOL metadata = !strcmp(path, ".com.apple.mobile_container_manager.metadata.plist");
    if (metadata && activeLeases && throwLeasedRead) [NSException raise:@"FixtureRead" format:@"metadata read threw"];
    if (metadata && activeLeases && failLeasedRead) { errno = EACCES; return -1; }
    int fd = openat(directory, path, flags);
    if (metadata && activeLeases && fd >= 0) metadataFD = fd;
    return fd;
}
static ssize_t fixture_read(int fd, void *buffer, size_t count) {
    if (fd == injectedReadFD) { errno = EIO; return -1; }
    ssize_t result = read(fd, buffer, count);
    if (fd == metadataFD && result > 0 && cancelOnRead) fixtureCancelled = YES;
    return result;
}
static int fixture_fstat(int fd, struct stat *st) {
    if (fd == injectedStatFD) { errno = EIO; return -1; }
    return fstat(fd, st);
}
static int fixture_close(int fd) {
    if (fd == metadataFD) { metadataFD = -1; metadataCloses++; }
    return close(fd);
}

int64_t BQEscape(NSString *target, NSString **accessible) {
    leaseCalls++;
    NSCAssert(activeLeases == 0, @"leases never overlap");
    NSString *root = @"/var/mobile/Containers/Data/Application";
    NSCAssert([target isEqualToString:root] || [target.stringByDeletingLastPathComponent isEqualToString:root], @"only observed app-data locations are read");
    if (everyLeaseFailure) return everyLeaseFailure;
    if (rootLeaseFailure && [target isEqualToString:root]) return rootLeaseFailure;
    activeLeases++;
    *accessible = mapped(target.fileSystemRepresentation);
    if (cancelOnLease) fixtureCancelled = YES;
    if (expireOnLease) clockOffset += 9;
    return 42;
}
void BQEndEscape(int64_t lease) {
    NSCAssert(lease == 42 && activeLeases == 1, @"release exactly the acquired lease");
    activeLeases--; releaseCalls++;
}

@interface FixtureProxy : NSObject
@property id bundleIdentifier;
@property id localizedName;
@property id dataContainerURL;
@property id groupContainerURLs;
@property id bundleURL;
@end
@implementation FixtureProxy
@end
@interface SlowProxy : FixtureProxy
@end
@implementation SlowProxy
- (id)localizedName { atomic_fetch_add(&pendingSlowGetters, 1); [NSThread sleepForTimeInterval:2.3]; atomic_fetch_sub(&pendingSlowGetters, 1); return @"Delayed"; }
@end
@interface SlowBundleProxy : FixtureProxy
@end
@implementation SlowBundleProxy
- (id)bundleURL { atomic_fetch_add(&pendingSlowGetters, 1); [NSThread sleepForTimeInterval:2.3]; atomic_fetch_sub(&pendingSlowGetters, 1); return nil; }
@end
@interface ScalarProxy : NSObject
- (NSInteger)dataContainerURL;
@end
@implementation ScalarProxy
- (NSInteger)dataContainerURL { return 42; }
@end
@interface ThrowingProxy : NSObject
- (id)dataContainerURL;
@end
@implementation ThrowingProxy
- (id)dataContainerURL { [NSException raise:@"Fixture" format:@"Getter failed"]; return nil; }
@end
@interface FixtureApplicationWorkspace : NSObject
+ (instancetype)defaultWorkspace;
- (NSArray *)allApplications;
- (NSArray *)allInstalledApplications;
@end
@implementation FixtureApplicationWorkspace
+ (instancetype)defaultWorkspace { return [self new]; }
- (NSArray *)allApplications { lookups++; if (slowLookup) { atomic_fetch_add(&pendingSlowGetters, 1); [NSThread sleepForTimeInterval:1.2]; atomic_fetch_sub(&pendingSlowGetters, 1); } return applicationRecords; }
- (NSArray *)allInstalledApplications { installedLookups++; return installedRecords; }
@end

NSArray<NSString *> *BQDiscoverContainerPaths(NSString *root, NSTimeInterval seconds, NSUInteger limit,
    BOOL (^cancelled)(void), __unused BOOL *stopped, __unused NSString **err) {
    scans++;
    NSCAssert(rootMap()[root] && seconds <= 1.0 && limit <= 1024, @"bounded known-root scan");
    if (cancelled && cancelled()) return @[];
    if ([root hasSuffix:@"Application"]) return @[[root stringByAppendingPathComponent:@"DeniedUUID"], [root stringByAppendingPathComponent:@"MissingUUID"]];
    return @[];
}
#define lstat fixture_lstat
#define getxattr fixture_getxattr
#define access fixture_access
#define opendir fixture_opendir
#define open fixture_open
#define openat fixture_openat
#define read fixture_read
#define fstat fixture_fstat
#define close fixture_close
#define NSClassFromString fixture_class
#define NSProcessInfo FixtureProcessInfo
#import "../CC365-Apps/Files/BQCore/BQContainerCatalog.m"
#undef NSProcessInfo
#undef NSClassFromString
#undef lstat
#undef getxattr
#undef access
#undef opendir
#undef open
#undef openat
#undef read
#undef fstat
#undef close

static void check(BOOL ok, NSString *name) { if (!ok) { NSLog(@"FAIL: %@", name); exit(1); } checks++; }
static void awaitSlowGetter(void) {
    NSTimeInterval deadline = NSProcessInfo.processInfo.systemUptime + 3;
    while (atomic_load(&pendingSlowGetters) && NSProcessInfo.processInfo.systemUptime < deadline) [NSThread sleepForTimeInterval:0.02];
    [NSThread sleepForTimeInterval:0.05];  
}
static FixtureProxy *proxy(id name, id identifier, id path, id groups) {
    FixtureProxy *p = [FixtureProxy new]; p.localizedName=name; p.bundleIdentifier=identifier; p.dataContainerURL=path; p.groupContainerURLs=groups; return p;
}
static BQContainerEntry *find(NSArray<BQContainerEntry *> *items, NSString *leaf) {
    for (BQContainerEntry *entry in items) if ([entry.path.lastPathComponent isEqualToString:leaf]) return entry;
    return nil;
}
int main(void) { @autoreleasepool {
    NSFileManager *fm = NSFileManager.defaultManager;
    fixture = [NSTemporaryDirectory() stringByAppendingPathComponent:NSUUID.UUID.UUIDString];
    for (NSString *p in @[@"apps/AlphaUUID", @"apps/BetaUUID", @"groups/GroupUUID", @"system/SystemUUID"])
        [fm createDirectoryAtPath:[fixture stringByAppendingPathComponent:p] withIntermediateDirectories:YES attributes:nil error:nil];
    [@{@"MCMMetadataIdentifier": @"com.example.beta"} writeToFile:[fixture stringByAppendingPathComponent:@"apps/BetaUUID/.com.apple.mobile_container_manager.metadata.plist"] atomically:YES];
    [@"ordinary file" writeToFile:[fixture stringByAppendingPathComponent:@"apps/FileUUID"] atomically:YES encoding:NSUTF8StringEncoding error:nil];
    [fm createSymbolicLinkAtPath:[fixture stringByAppendingPathComponent:@"apps/LinkUUID"] withDestinationPath:[fixture stringByAppendingPathComponent:@"apps/AlphaUUID"] error:nil];
    NSString *appRoot=@"/var/mobile/Containers/Data/Application";
    applicationRecords = @[
        proxy(@"Alpha App", @"com.example.alpha", [NSURL fileURLWithPath:@"/private/var/mobile/Containers/Data/Application/AlphaUUID"], @{@"group.example.shared": [NSURL fileURLWithPath:@"/var/mobile/Containers/Shared/AppGroup/GroupUUID"]}),
        proxy(@"Restricted", @"com.example.restricted", [NSURL fileURLWithPath:[appRoot stringByAppendingPathComponent:@"DeniedUUID"]], nil),
        proxy(@"Stale", @"com.example.stale", [NSURL fileURLWithPath:[appRoot stringByAppendingPathComponent:@"MissingUUID"]], nil),
        proxy(@"Not a directory", nil, [NSURL fileURLWithPath:[appRoot stringByAppendingPathComponent:@"FileUUID"]], nil),
        proxy(@"Link", nil, [NSURL fileURLWithPath:[appRoot stringByAppendingPathComponent:@"LinkUUID"]], nil),
        proxy(@[@"invalid name"], @42, @"not an NSURL", @[]),
        proxy(@"Remote", nil, [NSURL URLWithString:@"https://example.com/file"], nil),
        proxy(@"Outside", nil, [NSURL fileURLWithPath:@"/tmp"], nil),
        [ScalarProxy new], [ThrowingProxy new], NSNull.null
    ];
    NSString *notice=nil;
    NSArray *items=BQDiscoverContainers(nil, &notice);
    check(lookups == 1 && scans == 0, @"one API lookup and no unnecessary inode scan");
    check(find(items, @"AlphaUUID") && [find(items, @"AlphaUUID").name isEqualToString:@"Alpha App"], @"localized name retained");
    NSUInteger alphaCount=0; for(BQContainerEntry *e in items) if([e.path hasSuffix:@"/AlphaUUID"]) alphaCount++;
    check(alphaCount == 1 && [find(items,@"AlphaUUID").path hasPrefix:@"/var/"], @"private var alias deduplication");
    check(find(items,@"DeniedUUID").accessRestricted, @"observed denied directory retained");
    check(!find(items,@"MissingUUID") && !find(items,@"FileUUID") && !find(items,@"LinkUUID"), @"missing and known nondirectory paths rejected");
    check([find(items,@"BetaUUID").identifier isEqualToString:@"com.example.beta"], @"direct readable metadata used");
    check([find(items,@"GroupUUID").kind isEqualToString:@"group"] && [find(items,@"SystemUUID").kind isEqualToString:@"system"], @"all three container categories");
    check([notice containsString:@"may not include every"] && [notice containsString:@"cannot be checked"], @"honest partial-access notice");
    check([items indexOfObject:find(items,@"AlphaUUID")] < [items indexOfObject:find(items,@"GroupUUID")], @"deterministic category ordering");
    NSUInteger own=0; for(BQContainerEntry *e in items) if([e.path isEqualToString:NSHomeDirectory()]) own++;
    check(own==1, @"own app always included");
    check(!BQCatalogPath(@"relative") && !BQCatalogPath(@"/var/../tmp"), @"invalid paths rejected");
    check(BQCatalogGetter([ScalarProxy new],@"dataContainerURL")==nil && BQCatalogGetter([ThrowingProxy new],@"dataContainerURL")==nil, @"scalar and throwing selectors guarded");

    int previousInstalled = installedLookups;
    installedRecords=@[applicationRecords.firstObject]; applicationRecords=@[];
    items=BQDiscoverContainers(nil,&notice);
    check(installedLookups==previousInstalled+1 && [find(items,@"AlphaUUID").name isEqualToString:@"Alpha App"], @"empty primary catalog uses installed-app fallback");
    applicationRecords=@[installedRecords.firstObject,[SlowProxy new]]; installedRecords=nil;
    NSTimeInterval partialStart=NSProcessInfo.processInfo.systemUptime;
    items=BQDiscoverContainers(nil,&notice);
    check(NSProcessInfo.processInfo.systemUptime-partialStart<2.25 && [find(items,@"AlphaUUID").name isEqualToString:@"Alpha App"] && [notice containsString:@"stopped early"], @"slow lookup retains already observed names at timeout");
    awaitSlowGetter();

    int previous=lookups;
    items=BQDiscoverContainers(^BOOL{ return YES; }, &notice);
    check(items.count==1 && lookups==previous && [notice containsString:@"cancelled"], @"early cancellation keeps own entry and avoids APIs");
    denyRoots=YES; applicationRecords=@[];
    items=BQDiscoverContainers(nil,&notice);
    check(scans==3 && find(items,@"DeniedUUID").accessRestricted && !find(items,@"MissingUUID"), @"denied roots use bounded observed-path fallback");
    denyRoots=NO; slowLookup=YES;
    NSTimeInterval start=NSProcessInfo.processInfo.systemUptime;
    items=BQDiscoverContainers(^BOOL { return NSProcessInfo.processInfo.systemUptime-start>0.05; },&notice);
    check(NSProcessInfo.processInfo.systemUptime-start<0.8 && items.count==1,
        [NSString stringWithFormat:@"cancellation does not wait for private IPC (%.3fs, %lu items, %@)", NSProcessInfo.processInfo.systemUptime-start, (unsigned long)items.count, notice]);
    previous=lookups;
    items=BQDiscoverContainers(nil,&notice);
    check(lookups==previous && [notice containsString:@"still finishing"], @"cancelled IPC cannot accumulate lookup workers");
    awaitSlowGetter(); slowLookup=NO;
    NSString *validBundle=[fixture stringByAppendingPathComponent:@"Observed.app"];
    NSString *invalidBundle=[fixture stringByAppendingPathComponent:@"Regular.app"];
    NSString *linkedBundle=[fixture stringByAppendingPathComponent:@"Linked.app"];
    [fm createDirectoryAtPath:validBundle withIntermediateDirectories:YES attributes:nil error:nil];
    [@"file" writeToFile:invalidBundle atomically:YES encoding:NSUTF8StringEncoding error:nil];
    [fm createSymbolicLinkAtPath:linkedBundle withDestinationPath:validBundle error:nil];
    check([BQObservedBundlePath(validBundle) isEqualToString:validBundle], @"observed app directory accepted");
    check(!BQObservedBundlePath(invalidBundle) && !BQObservedBundlePath(linkedBundle) && !BQObservedBundlePath([fixture stringByAppendingPathComponent:@"Missing.app"]), @"bundle path rejects known files, symlinks and missing directories");
    check(!BQObservedBundlePath(fixture) && !BQObservedBundlePath(@"relative.app"), @"bundle must be absolute observed app directory");
    check(BQObservedBundlePath([fixture stringByAppendingPathComponent:@"Denied.app"]) != nil, @"observed bundle with permission-denied stat remains usable on explicit open");
    FixtureProxy *withBundle=proxy(@"Alpha App", @"com.example.alpha", [NSURL fileURLWithPath:[appRoot stringByAppendingPathComponent:@"AlphaUUID"]], nil);
    withBundle.bundleURL=[NSURL fileURLWithPath:validBundle]; applicationRecords=@[withBundle];
    items=BQDiscoverContainers(nil,&notice);
    check([find(items,@"AlphaUUID").bundlePath isEqualToString:validBundle], @"bundleURL carried into returned data entry");
    withBundle.bundleURL=[NSURL URLWithString:@"https://example.com/Remote.app"];
    items=BQDiscoverContainers(nil,&notice);
    check(find(items,@"AlphaUUID").bundlePath==nil, @"remote bundleURL ignored");
    SlowBundleProxy *slowBundle=[SlowBundleProxy new]; slowBundle.localizedName=@"Alpha Slow";
    slowBundle.bundleIdentifier=@"com.example.alpha"; slowBundle.dataContainerURL=withBundle.dataContainerURL;
    applicationRecords=@[slowBundle]; start=NSProcessInfo.processInfo.systemUptime;
    items=BQDiscoverContainers(nil,&notice);
    check(NSProcessInfo.processInfo.systemUptime-start<2.25 && [find(items,@"AlphaUUID").name isEqualToString:@"Alpha Slow"] && find(items,@"AlphaUUID").bundlePath==nil, @"blocked optional bundle getter retains already observed data entry");
    awaitSlowGetter();
    check(leaseCalls == 0, @"ordinary catalog discovery never obtains protected metadata leases");



    applicationRecords = @[]; installedRecords = nil; denyMetadata = YES;
    items = BQDiscoverContainers(nil, &notice);
    check(find(items,@"BetaUUID") && find(items,@"BetaUUID").identifier.length == 0 && leaseCalls == 0,
        @"read-only catalog preserves denied app UUID without guessing its identifier");
    items = BQDiscoverPatchTargets(nil, &notice);
    check([find(items,@"BetaUUID").identifier isEqualToString:@"com.example.beta"] && [find(items,@"BetaUUID").name isEqualToString:@"com.example.beta"],
        @"explicit patch discovery identifies denied metadata through the existing root lease");
    check(find(items,@"AlphaUUID") && !find(items,@"AlphaUUID").identifier.length && !find(items,@"GroupUUID") && !find(items,@"SystemUUID"),
        @"unknown app targets remain present, groups and system containers are not patch apps");
    check(leaseCalls == 1 && releaseCalls == 1 && activeLeases == 0 && metadataFD == -1 && metadataCloses > 0,
        @"one root lease identifies all readable observed apps and closes every metadata descriptor");
    check([notice containsString:@"chưa xác định được bundle ID"], @"unknown identity notice is explicit");

    int previousLeases = leaseCalls, previousReleases = releaseCalls;
    rootLeaseFailure = -2;
    items = BQDiscoverPatchTargets(nil, &notice);
    check([find(items,@"BetaUUID").identifier isEqualToString:@"com.example.beta"] && leaseCalls > previousLeases + 1,
        @"root lease failure falls back to exact observed app-data containers");
    check(releaseCalls - previousReleases == leaseCalls - previousLeases - 1 && activeLeases == 0,
        @"fallback releases each acquired lease and never releases the failed root attempt");
    rootLeaseFailure = 0;

    previousLeases = leaseCalls; previousReleases = releaseCalls; everyLeaseFailure = -7;
    items = BQDiscoverPatchTargets(nil, &notice);
    check(leaseCalls == previousLeases + 1 && releaseCalls == previousReleases && find(items,@"BetaUUID") && !find(items,@"BetaUUID").identifier.length,
        @"unavailable runtime stops repeated attempts and preserves unknown observed apps");
    everyLeaseFailure = 0;

    previousLeases = leaseCalls; previousReleases = releaseCalls; cancelOnLease = YES;
    items = BQDiscoverPatchTargets(^BOOL { return fixtureCancelled; }, &notice);
    check(leaseCalls == previousLeases + 1 && releaseCalls == previousReleases + 1 && activeLeases == 0 && find(items,@"BetaUUID"),
        @"cancellation after acquisition releases the lease and keeps observed targets");
    fixtureCancelled = NO; cancelOnLease = NO; cancelOnRead = YES;
    previousLeases = leaseCalls; previousReleases = releaseCalls;
    items = BQDiscoverPatchTargets(^BOOL { return fixtureCancelled; }, &notice);
    check(leaseCalls == previousLeases + 1 && releaseCalls == previousReleases + 1 && metadataFD == -1 && !find(items,@"BetaUUID").identifier.length,
        @"cancellation during metadata read closes the descriptor, releases lease, and avoids partial identity");
    fixtureCancelled = NO; cancelOnRead = NO;

    previousLeases = leaseCalls; previousReleases = releaseCalls; throwLeasedRead = YES;
    items = BQDiscoverPatchTargets(nil, &notice);
    check(leaseCalls == previousLeases + 1 && releaseCalls == previousReleases + 1 && activeLeases == 0 && find(items,@"BetaUUID"),
        @"metadata exception still releases root lease and preserves targets");
    throwLeasedRead = NO;

    previousLeases = leaseCalls; previousReleases = releaseCalls; expireOnLease = YES;
    items = BQDiscoverPatchTargets(nil, &notice);
    check(leaseCalls == previousLeases + 1 && releaseCalls == previousReleases + 1 && activeLeases == 0 && [notice containsString:@"giới hạn thời gian"],
        @"elapsed enrichment budget prevents reads and further attempts after releasing the active lease");
    expireOnLease = NO; clockOffset = 0;

    for (NSUInteger i = 0; i < 20; i++) {
        NSString *container = [fixture stringByAppendingPathComponent:[NSString stringWithFormat:@"apps/Limit%02lu", (unsigned long)i]];
        [fm createDirectoryAtPath:container withIntermediateDirectories:YES attributes:nil error:nil];
        [@{@"MCMMetadataIdentifier": [NSString stringWithFormat:@"com.fixture.limit%lu", (unsigned long)i]} writeToFile:[container stringByAppendingPathComponent:@".com.apple.mobile_container_manager.metadata.plist"] atomically:YES];
    }
    previousLeases = leaseCalls; previousReleases = releaseCalls; rootLeaseFailure = -2;
    items = BQDiscoverPatchTargets(nil, &notice);
    check(leaseCalls - previousLeases == 16 && releaseCalls - previousReleases == 15 && items.count >= 23 && [notice containsString:@"giới hạn thời gian"],
        @"per-container fallback has a fixed attempt cap and keeps all unprocessed observed apps");
    rootLeaseFailure = 0;
    previousLeases = leaseCalls; previousReleases = releaseCalls;
    items = BQDiscoverPatchTargets(nil, &notice);
    check(leaseCalls == previousLeases + 1 && releaseCalls == previousReleases + 1 && [find(items,@"Limit19").identifier isEqualToString:@"com.fixture.limit19"],
        @"one root lease resolves many app identities beyond the per-container attempt cap");

    int rootFD = open([fixture stringByAppendingPathComponent:@"apps"].fileSystemRepresentation, O_RDONLY | O_DIRECTORY);
    int readError = 0;
    check(BQReadObservedChildIdentifier(rootFD, @"LinkUUID", nil, &readError) == nil && (readError == ELOOP || readError == ENOTDIR),
        @"root lease metadata lookup never follows a child-directory symlink");
    close(rootFD);
    NSString *oversized = [fixture stringByAppendingPathComponent:@"oversized"];
    [fm createDirectoryAtPath:oversized withIntermediateDirectories:YES attributes:nil error:nil];
    [[NSMutableData dataWithLength:64 * 1024 + 1] writeToFile:[oversized stringByAppendingPathComponent:@".com.apple.mobile_container_manager.metadata.plist"] atomically:YES];
    check(BQReadContainerIdentifier(oversized, nil, &readError) == nil && readError == EFBIG, @"metadata reads enforce the 64 KiB cap");
    [@{@"MCMMetadataIdentifier": @[@"invalid"]} writeToFile:[oversized stringByAppendingPathComponent:@".com.apple.mobile_container_manager.metadata.plist"] atomically:YES];
    check(BQReadContainerIdentifier(oversized, nil, &readError) == nil && readError == EINVAL, @"malformed identifier types never become bundle IDs");
    previousLeases = leaseCalls;
    items = BQDiscoverPatchTargets(^BOOL { return YES; }, &notice);
    check(leaseCalls == previousLeases && activeLeases == 0, @"already-cancelled patch discovery never acquires a lease");



    FixtureProxy *selfOnly = proxy(@"Fixture Caller", @"com.fixture.caller", nil, nil);
    FixtureProxy *hiddenData = proxy(@"Beta Friendly", @"com.example.beta", nil, nil);
    hiddenData.bundleURL = [NSURL fileURLWithPath:validBundle];
    FixtureProxy *unmappedIdentity = proxy(@"Unmapped App", @"com.fixture.unmapped", nil, nil);
    applicationRecords = @[selfOnly]; installedRecords = @[hiddenData, unmappedIdentity];
    denyMetadata = NO; previous = lookups; previousInstalled = installedLookups; previousLeases = leaseCalls;
    items = BQDiscoverContainers(nil, &notice);
    BQContainerEntry *beta = find(items, @"BetaUUID");
    check(lookups == previous + 1 && installedLookups == previousInstalled + 1 && [beta.name isEqualToString:@"Beta Friendly"],
        @"nonempty self-only primary catalog merges installed identities and joins friendly names through proven metadata ID");
    check([beta.path isEqualToString:[appRoot stringByAppendingPathComponent:@"BetaUUID"]] && [beta.bundlePath isEqualToString:validBundle] && leaseCalls == previousLeases,
        @"directly proven identity join preserves exact data path and supports repeatable observed bundle validation without escape");
    BOOL invented = NO;
    for (BQContainerEntry *entry in items) if ([entry.identifier isEqualToString:@"com.fixture.unmapped"]) invented = YES;
    check(!invented && find(items,@"AlphaUUID") && !find(items,@"AlphaUUID").identifier.length,
        @"identity-only observations never invent data paths or rename unrelated unknown UUIDs");

    denyMetadata = YES; previous = lookups; previousInstalled = installedLookups; previousLeases = leaseCalls;
    items = BQDiscoverPatchTargets(nil, &notice); beta = find(items, @"BetaUUID");
    check([beta.name isEqualToString:@"Beta Friendly"] && [beta.identifier isEqualToString:@"com.example.beta"] && leaseCalls == previousLeases + 1,
        @"lease-recovered MCM identifier joins the retained friendly name when LaunchServices hides the data URL");
    check(lookups == previous + 1 && installedLookups == previousInstalled + 1,
        @"metadata enrichment reuses one identity index with no second or per-container LaunchServices lookup");
    check(beta.bundlePath == nil && [beta.path isEqualToString:[appRoot stringByAppendingPathComponent:@"BetaUUID"]],
        @"lease-only name join does not advertise an unrepeatable bundle scope or change target path");

    denyMetadata = NO; applicationRecords = @[hiddenData]; installedRecords = @[hiddenData];
    items = BQDiscoverContainers(nil, &notice);
    check([find(items,@"BetaUUID").name isEqualToString:@"Beta Friendly"], @"identical observations across both APIs merge without false ambiguity");
    FixtureProxy *conflictingName = proxy(@"Different App", @"com.example.beta", nil, nil);
    installedRecords = @[conflictingName];
    items = BQDiscoverContainers(nil, &notice); beta = find(items, @"BetaUUID");
    check([beta.identifier isEqualToString:@"com.example.beta"] && [beta.name isEqualToString:@"com.example.beta"] && beta.bundlePath == nil && [notice containsString:@"không thống nhất"],
        @"conflicting name observations keep the proven identifier but do not assign a guessed friendly identity");
    NSString *otherBundle = [fixture stringByAppendingPathComponent:@"Different.app"];
    [fm createDirectoryAtPath:otherBundle withIntermediateDirectories:YES attributes:nil error:nil];
    FixtureProxy *conflictingBundle = proxy(@"Beta Friendly", @"com.example.beta", nil, nil);
    conflictingBundle.bundleURL = [NSURL fileURLWithPath:otherBundle]; installedRecords = @[conflictingBundle];
    items = BQDiscoverContainers(nil, &notice); beta = find(items, @"BetaUUID");
    check([beta.name isEqualToString:@"com.example.beta"] && beta.bundlePath == nil, @"conflicting observed bundle directories prevent an ambiguous identity join");

    FixtureProxy *pathBundleA = proxy(@"Beta Friendly", @"com.example.beta", [NSURL fileURLWithPath:[appRoot stringByAppendingPathComponent:@"BetaUUID"]], nil);
    pathBundleA.bundleURL = [NSURL fileURLWithPath:validBundle];
    FixtureProxy *pathBundleB = proxy(@"Beta Friendly", @"com.example.beta", pathBundleA.dataContainerURL, nil);
    pathBundleB.bundleURL = [NSURL fileURLWithPath:otherBundle];
    applicationRecords = @[pathBundleA]; installedRecords = @[pathBundleB];
    items = BQDiscoverContainers(nil, &notice); beta = find(items, @"BetaUUID");
    check([beta.identifier isEqualToString:@"com.example.beta"] && [beta.name isEqualToString:@"com.example.beta"] && beta.bundlePath == nil,
        @"path-bearing records cannot bypass ambiguity rejection with the last conflicting bundle URL");
    pathBundleB.bundleIdentifier = @"com.fixture.other";
    items = BQDiscoverContainers(nil, &notice); beta = find(items, @"BetaUUID");
    check([beta.identifier isEqualToString:@"com.example.beta"] && [beta.name isEqualToString:@"com.example.beta"] && beta.bundlePath == nil,
        @"conflicting IDs for one observed path keep only its directly proven metadata identity");
    pathBundleA.dataContainerURL = [NSURL fileURLWithPath:[appRoot stringByAppendingPathComponent:@"AlphaUUID"]];
    pathBundleB.dataContainerURL = pathBundleA.dataContainerURL;
    items = BQDiscoverContainers(nil, &notice);
    check(find(items,@"AlphaUUID") && !find(items,@"AlphaUUID").identifier.length && find(items,@"AlphaUUID").bundlePath == nil,
        @"path-bearing ID conflict without readable metadata retains UUID and never picks the first ID or last bundle");

    applicationRecords = @[proxy(@"Explicit Other Path", @"com.example.beta", [NSURL fileURLWithPath:[appRoot stringByAppendingPathComponent:@"AlphaUUID"]], nil)];
    installedRecords = @[];
    items = BQDiscoverContainers(nil, &notice);
    check([find(items,@"BetaUUID").name isEqualToString:@"com.example.beta"] && [find(items,@"AlphaUUID").name isEqualToString:@"Explicit Other Path"],
        @"an identity explicitly tied to a different observed data path never relabels another metadata-matching container");
    NSString *duplicate = [fixture stringByAppendingPathComponent:@"apps/DuplicateBeta"];
    [fm createDirectoryAtPath:duplicate withIntermediateDirectories:YES attributes:nil error:nil];
    [@{@"MCMMetadataIdentifier": @"com.example.beta"} writeToFile:[duplicate stringByAppendingPathComponent:@".com.apple.mobile_container_manager.metadata.plist"] atomically:YES];
    applicationRecords = @[hiddenData]; installedRecords = @[];
    items = BQDiscoverContainers(nil, &notice);
    check([find(items,@"BetaUUID").name isEqualToString:@"com.example.beta"] && [find(items,@"DuplicateBeta").name isEqualToString:@"com.example.beta"],
        @"multiple containers with the same metadata ID require an exact observed data-path match before friendly identity association");
    [fm removeItemAtPath:duplicate error:nil];

    SlowBundleProxy *hiddenSlowBundle = [SlowBundleProxy new];
    hiddenSlowBundle.bundleIdentifier = @"com.example.beta"; hiddenSlowBundle.localizedName = @"Retained Before Timeout";
    applicationRecords = @[hiddenSlowBundle]; installedRecords = @[];
    items = BQDiscoverContainers(nil, &notice);
    check([find(items,@"BetaUUID").name isEqualToString:@"Retained Before Timeout"] && [notice containsString:@"stopped early"],
        @"name-only record is published before a blocked optional bundle getter");
    awaitSlowGetter();



    applicationRecords = @[]; installedRecords = @[];
    [fm removeItemAtPath:[fixture stringByAppendingPathComponent:@"apps/AlphaUUID"] error:nil];
    NSString *betaMetadata = [fixture stringByAppendingPathComponent:@"apps/BetaUUID/.com.apple.mobile_container_manager.metadata.plist"];
    denyMetadata = YES; rootLeaseFailure = -2;
    [@"unrecognized property list" writeToFile:betaMetadata atomically:YES encoding:NSUTF8StringEncoding error:nil];
    [diagnosticLogs removeAllObjects];
    items = BQDiscoverPatchTargets(nil, &notice);
    NSString *logged = [diagnosticLogs componentsJoinedByString:@"\n"];
    check([logged containsString:@"phase=child stage=plist errno=22"] && [logged containsString:@"child.plist:1"], @"granted child lease logs final plist failure instead of dropping metadata errno/stage");
    check([notice containsString:@"Chưa nhận diện được thông tin"] && ![notice containsString:@"iOS chưa cho đọc thông tin"], @"direct denial does not dominate a later leased parse failure notice");
    check([logged containsString:@"stopped_count=1"] && [logged containsString:@"child_attempts=15 child_grants=15 child_reads=15"] && [logged containsString:@"unknown_unread="], @"summary separates count-limited unread containers from attempted metadata failures");
    check([logged containsString:@"start app="] && [logged containsString:@" os_build="] && [logged containsString:@"ls state=complete all_returned=0"] && [logged containsString:@"installed_returned=0"], @"scan marker captures only app and OS versions plus aggregate LS availability");

    [@{@"MCMMetadataIdentifier": @"com.example.beta"} writeToFile:betaMetadata atomically:YES];
    [diagnosticLogs removeAllObjects];
    items = BQDiscoverPatchTargets(nil, &notice); logged = [diagnosticLogs componentsJoinedByString:@"\n"];
    check([find(items,@"BetaUUID").identifier isEqualToString:@"com.example.beta"] && [logged containsString:@"failed_reads=0"] && ![notice containsString:@"iOS chưa cho đọc thông tin"], @"direct denial followed by leased success produces no false permission notice");
    failLeasedRead = YES; [diagnosticLogs removeAllObjects];
    BQDiscoverPatchTargets(nil, &notice); logged = [diagnosticLogs componentsJoinedByString:@"\n"];
    NSUInteger sampleCount = 0;
    for (NSString *line in diagnosticLogs) if ([line containsString:@" failure ordinal="]) sampleCount++;
    check(sampleCount == 8 && diagnosticLogs.count == 11 && [logged containsString:@"stage=open errno=13 size=-1"], @"open-denial diagnostics emit at most eight ordinal samples and no metadata contents");
    check([logged containsString:@"failed_reads=15"] && [notice containsString:@"iOS chưa cho đọc thông tin"], @"only final leased permission failures produce the permission notice");
    for (NSString *privateValue in @[fixture, @"BetaUUID", @"Limit00", @"com.example.beta", @"/var/mobile", @"group.example.shared", @"Beta Friendly", @"MCMMetadataIdentifier", @"token="]) {
        check(![logged containsString:privateValue], [@"diagnostic log excludes private value: " stringByAppendingString:privateValue]);
    }
    failLeasedRead = NO; throwLeasedRead = YES; rootLeaseFailure = 0; [diagnosticLogs removeAllObjects];
    previousReleases = releaseCalls;
    BQDiscoverPatchTargets(nil, &notice); logged = [diagnosticLogs componentsJoinedByString:@"\n"];
    check([logged containsString:@"phase=root stage=exception"] && [logged containsString:@"failed_reads=1"] && releaseCalls == previousReleases + 1 && activeLeases == 0, @"root metadata exception is a final failed read and still releases its lease");
    rootLeaseFailure = -2; [diagnosticLogs removeAllObjects]; previousReleases = releaseCalls;
    BQDiscoverPatchTargets(nil, &notice); logged = [diagnosticLogs componentsJoinedByString:@"\n"];
    check([logged containsString:@"phase=child stage=exception"] && [logged containsString:@"failed_reads=15"] && releaseCalls == previousReleases + 15 && activeLeases == 0, @"child metadata exceptions replace prior outcomes and preserve lease cleanup");
    throwLeasedRead = NO; rootLeaseFailure = 0; denyMetadata = NO;

    NSString *diagnosticDirectory = [fixture stringByAppendingPathComponent:@"diagnostic-read"];
    [fm createDirectoryAtPath:diagnosticDirectory withIntermediateDirectories:YES attributes:nil error:nil];
    NSString *diagnosticFile = [diagnosticDirectory stringByAppendingPathComponent:@".com.apple.mobile_container_manager.metadata.plist"];
    NSMutableDictionary *detail = [NSMutableDictionary dictionary];
    BQReadContainerIdentifierDetailed(diagnosticDirectory, nil, &readError, detail);
    check([detail[@"stage"] isEqual:@"open"] && readError == ENOENT, @"missing metadata file has distinct open/ENOENT stage");
    [@{@"unrelated": @1} writeToFile:diagnosticFile atomically:YES]; [detail removeAllObjects];
    BQReadContainerIdentifierDetailed(diagnosticDirectory, nil, &readError, detail);
    check([detail[@"stage"] isEqual:@"missing-id"] && readError == EINVAL, @"missing identity key is distinct from parse failure without changing its errno");
    [@{@"MCMMetadataIdentifier": @[@"invalid"]} writeToFile:diagnosticFile atomically:YES]; [detail removeAllObjects];
    BQReadContainerIdentifierDetailed(diagnosticDirectory, nil, &readError, detail);
    check([detail[@"stage"] isEqual:@"invalid-id"] && readError == EINVAL, @"invalid identity type has its own diagnostic stage");
    [[NSMutableData dataWithLength:64 * 1024 + 1] writeToFile:diagnosticFile atomically:YES]; [detail removeAllObjects];
    BQReadContainerIdentifierDetailed(diagnosticDirectory, nil, &readError, detail);
    check([detail[@"stage"] isEqual:@"size"] && [detail[@"size"] isEqual:@65537] && readError == EFBIG, @"size rejection logs only file size and unchanged errno");
    [fm removeItemAtPath:diagnosticFile error:nil]; [fm createDirectoryAtPath:diagnosticFile withIntermediateDirectories:NO attributes:nil error:nil]; [detail removeAllObjects];
    BQReadContainerIdentifierDetailed(diagnosticDirectory, nil, &readError, detail);
    check([detail[@"stage"] isEqual:@"type"] && readError == EINVAL, @"nonregular metadata retains its rejection and type stage");
    [fm removeItemAtPath:diagnosticFile error:nil]; [@{@"MCMMetadataIdentifier": @"com.fixture.valid"} writeToFile:diagnosticFile atomically:YES];
    injectedStatFD = open(diagnosticFile.fileSystemRepresentation, O_RDONLY); [detail removeAllObjects];
    BQReadIdentifierDescriptor(injectedStatFD, nil, &readError, detail); injectedStatFD = -1;
    check([detail[@"stage"] isEqual:@"stat"] && readError == EIO, @"fstat errors retain errno and distinct stage");
    injectedReadFD = open(diagnosticFile.fileSystemRepresentation, O_RDONLY); [detail removeAllObjects];
    BQReadIdentifierDescriptor(injectedReadFD, nil, &readError, detail); injectedReadFD = -1;
    check([detail[@"stage"] isEqual:@"read"] && readError == EIO, @"read errors retain errno and distinct stage");
    [detail removeAllObjects]; BQReadContainerIdentifierDetailed(diagnosticDirectory, ^BOOL { return YES; }, &readError, detail);
    check([detail[@"stage"] isEqual:@"cancel"] && readError == ECANCELED, @"cancellation is recorded without another access attempt");


    denyMetadata = YES; denyRoots = NO; applicationRecords = @[]; installedRecords = @[];
    NSString *storedPath = [appRoot stringByAppendingPathComponent:@"11111111-2222-4333-8444-555555555555"];
    NSString *missingPath = [appRoot stringByAppendingPathComponent:@"AAAAAAAA-BBBB-4CCC-8DDD-EEEEEEEEEEEE"];
    NSString *pluginPath = @"/var/mobile/Containers/Data/PluginKitPlugin/22222222-3333-4444-8555-666666666666";
    for (NSString *path in @[storedPath, pluginPath]) [fm createDirectoryAtPath:mapped(path.fileSystemRepresentation) withIntermediateDirectories:YES attributes:nil error:nil];
    storeRecords = @[@{@"path":[@"/private" stringByAppendingString:storedPath], @"kind":@"app", @"identifier":@"com.example.stored", @"name":@"Stored App", @"source":@"csstore"},
        @{@"path":missingPath, @"kind":@"app", @"identifier":@"com.example.removed", @"name":@"Removed App"},
        @{@"path":pluginPath, @"kind":@"plugin", @"identifier":@"com.example.stored.widget", @"name":@"Stored Widget"}];
    items = BQDiscoverContainers(nil, &notice);
    BQContainerEntry *stored = find(items, storedPath.lastPathComponent);
    check([stored.name isEqual:@"Stored App"] && [stored.identifier isEqual:@"com.example.stored"] && [stored.path isEqual:storedPath], @"fresh local store supplies exact app owner and name with unreadable metadata");
    check(stored.bundlePath == nil, @"store identity does not invent bundle write scope");
    check(find(items, missingPath.lastPathComponent) == nil, @"obsolete deleted store path is removed");
    check([find(items, pluginPath.lastPathComponent).kind isEqual:@"plugin"] && [find(items, pluginPath.lastPathComponent).name isEqual:@"Stored Widget"], @"extension store record remains distinct from application data");
    applicationRecords = @[proxy(@"Localized App", @"com.example.stored", [NSURL fileURLWithPath:storedPath], nil)];
    items = BQDiscoverContainers(nil, &notice);
    check([find(items, storedPath.lastPathComponent).name isEqual:@"Localized App"], @"localized API label and store bundle name do not create false ownership conflict");
    applicationRecords = @[];
    attributes = @{storedPath:[@"com.example.actual" dataUsingEncoding:NSUTF8StringEncoding]};
    FixtureProxy *obsolete = proxy(@"Old Owner", @"com.example.stored", [NSURL fileURLWithPath:storedPath], nil);
    obsolete.bundleURL = [NSURL fileURLWithPath:otherBundle];
    applicationRecords = @[obsolete];
    items = BQDiscoverContainers(nil, &notice); stored = find(items, storedPath.lastPathComponent);
    check([stored.identifier isEqual:@"com.example.actual"] && ![stored.name isEqual:@"Stored App"], @"current container attribute overrides obsolete store owner and discards its friendly name");
    check(stored.bundlePath == nil, @"obsolete API bundle path cannot be attached to current metadata owner");
    NSMutableDictionary *changing = [NSMutableDictionary dictionary];
    attributes = nil;
    BQAddContainer(changing, storedPath, @"Old Owner", @"com.example.stored", @"app", YES, NO);
    ((BQContainerEntry *)changing[storedPath]).bundlePath = otherBundle;
    attributes = @{storedPath:[@"com.example.actual" dataUsingEncoding:NSUTF8StringEncoding]};
    BQAddContainer(changing, storedPath, nil, nil, @"app", YES, NO);
    stored = changing[storedPath];
    check([stored.identifier isEqual:@"com.example.actual"] && [stored.name isEqual:@"com.example.actual"] && stored.bundlePath == nil,
        @"later direct identity change clears old name and bundle scope within one lookup");
    attributes = nil; storeRecords = @[]; applicationRecords = @[];
    items = BQDiscoverContainers(nil, &notice); stored = find(items, storedPath.lastPathComponent);
    check(stored.identifier.length == 0 && [stored.name isEqual:storedPath.lastPathComponent], @"unavailable next store read cannot retain stale app identity or name");
    int previousStoreReads = storeReads;
    BQDiscoverContainers(^BOOL { return YES; }, &notice);
    check(storeReads == previousStoreReads, @"pre-cancelled catalog never starts local store read");
    check(BQAttributeIdentifier("invalid/owner", 13) == nil && BQAttributeIdentifier("bad\0owner", 9) == nil &&
        [BQAttributeIdentifier("com.valid.app\0", 14) isEqual:@"com.valid.app"], @"attribute identifiers reject path/control content and accept terminal NUL");
    [fm removeItemAtPath:fixture error:nil];
    NSLog(@"PASS: %d catalog checks",checks);
} return 0; }
