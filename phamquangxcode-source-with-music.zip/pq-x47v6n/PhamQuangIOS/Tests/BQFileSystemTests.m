#import <Foundation/Foundation.h>
#import <fcntl.h>
#import <dlfcn.h>
#import <stdio.h>
#import <sys/stat.h>
#import <unistd.h>
#import "CCBQFileSystem.h"
#import "BQContainerCatalog.h"

@interface CCBQFileSystem (TestEntry)
+ (NSDictionary *)request:(NSDictionary *)request progress:(NSProgress *)progress error:(NSError **)error;
@end

@interface BQContainerEntry ()
@property (nonatomic, copy, readwrite) NSString *name;
@property (nonatomic, copy, readwrite) NSString *identifier;
@property (nonatomic, copy, readwrite) NSString *path;
@property (nonatomic, copy, readwrite) NSString *kind;
@property (nonatomic, readwrite) BOOL accessRestricted;
@end
@implementation BQContainerEntry
@end

static NSString *documents;
static NSString *fixtureRoot;
static NSUInteger assertions, escapes, releases, discoveries;
static int64_t escapeResult = 42;
static void (^afterSwap)(int, const char *, int, const char *);


int CCBQTestRename(int from, const char *source, int to, const char *destination, unsigned int flags) {
    int (*realRename)(int, const char *, int, const char *, unsigned int) = dlsym(RTLD_DEFAULT, "renameatx_np");
    int result = realRename(from, source, to, destination, flags);
    if (!result && flags == RENAME_SWAP && afterSwap) afterSwap(from, source, to, destination);
    return result;
}
NSString *BQDocuments(void) { return documents; }
dispatch_queue_t BQWorkQueue(void) {
    static dispatch_queue_t queue;
    static dispatch_once_t once;
    dispatch_once(&once, ^{ queue = dispatch_queue_create("cc365.files.tests", DISPATCH_QUEUE_SERIAL); });
    return queue;
}
int64_t BQEscape(__unused NSString *path, NSString **accessible) {
    escapes++;
    if (escapeResult >= 0) *accessible = documents;
    return escapeResult;
}
void BQEndEscape(int64_t handle) { if (handle == 42) releases++; }
NSArray<BQContainerEntry *> *BQDiscoverContainers(BOOL (^cancelled)(void), NSString **notice) {
    discoveries++;
    if (cancelled && cancelled()) return @[];
    BQContainerEntry *entry = [BQContainerEntry new];
    entry.name = @"Fixture App"; entry.identifier = @"test.cc365";
    entry.path = fixtureRoot; entry.kind = @"app";
    if (notice) *notice = @"Fixture: only directly observed locations.";
    return @[entry];
}
NSArray<NSString *> *BQDiscoverContainerPaths(__unused NSString *root, __unused NSTimeInterval seconds,
    __unused NSUInteger limit, __unused BOOL (^cancelled)(void), __unused BOOL *stopped, __unused NSString **error) {
    return @[];
}

@interface TickProgress : NSProgress
@property (nonatomic, copy) void (^tick)(int64_t);
@end
@implementation TickProgress
- (void)setCompletedUnitCount:(int64_t)value {
    [super setCompletedUnitCount:value];
    if (self.tick) self.tick(value);
}
@end

static void Check(BOOL condition, NSString *label) {
    assertions++;
    if (!condition) { fprintf(stderr, "FAIL: %s\n", label.UTF8String); exit(1); }
}
static BOOL Exists(NSString *path) { return [NSFileManager.defaultManager fileExistsAtPath:path]; }
static NSDictionary *Request(NSDictionary *request, NSProgress *progress, NSError **error) {
    __block NSDictionary *result;
    __block NSError *failure;
    dispatch_sync(BQWorkQueue(), ^{ result = [CCBQFileSystem request:request progress:progress ?: [NSProgress progressWithTotalUnitCount:1] error:&failure]; });
    if (error) *error = failure;
    return result;
}
static NSDictionary *Success(NSDictionary *request) {
    NSError *error;
    NSDictionary *result = Request(request, nil, &error);
    Check(result != nil && error == nil, [NSString stringWithFormat:@"%@ succeeds: %@", request[@"action"], error]);
    Check([NSJSONSerialization isValidJSONObject:result], @"result is Codable-compatible JSON");
    return result;
}
static NSError *Failure(NSDictionary *request) {
    NSError *error;
    Check(Request(request, nil, &error) == nil && error != nil, [NSString stringWithFormat:@"%@ fails explicitly", request[@"action"]]);
    return error;
}
static BOOL HasTemporaryParts(void) {
    for (NSString *name in [NSFileManager.defaultManager contentsOfDirectoryAtPath:documents error:nil])
        if ([name hasPrefix:@".cc365-bq-part-"]) return YES;
    return NO;
}

int main(void) {
    @autoreleasepool {
        fixtureRoot = [NSTemporaryDirectory() stringByAppendingPathComponent:[@"cc365-bq-fixture-" stringByAppendingString:NSUUID.UUID.UUIDString]];
        documents = [fixtureRoot stringByAppendingPathComponent:@"Documents"];
        Check([NSFileManager.defaultManager createDirectoryAtPath:fixtureRoot withIntermediateDirectories:YES attributes:nil error:nil], @"fixture created");
        @try {
            Success(@{@"action": @"ensureWorkspace"});
            Success(@{@"action": @"ensureWorkspace"});
            Check(Exists(documents), @"workspace maps to own Documents");
            Success(@{@"action": @"mkdir", @"parent": @"/CC365", @"name": @"Folder"});
            Success(@{@"action": @"mkdir", @"path": @"/CC365/Folder/Nested"});
            NSDictionary *page = Success(@{@"action": @"list", @"path": @"/CC365/Folder"});
            Check([page[@"entries"][0][@"path"] isEqual:@"/CC365/Folder/Nested"], @"nested entries retain virtual writable path");
            Check([page[@"entries"][0][@"kind"] isEqual:@"directory"], @"directory kind is accurate");
            Check(Failure(@{@"action": @"mkdir", @"path": @"/outside"}).code == EPERM, @"external writes refused");
            Failure(@{@"action": @"mkdir", @"path": @"/CC365/../escape"});
            Failure(@{@"action": @"mkdir", @"path": @"/CC365/.cc365-bq-part-user"});
            Failure(@{@"action": @"delete", @"path": @"/CC365"});

            NSError *serializationError;
            NSData *original = [NSPropertyListSerialization dataWithPropertyList:@{@"binary": @[@1, @"unchanged"], @"bytes": [NSData dataWithBytes:"\0\1\2" length:3]}
                format:NSPropertyListBinaryFormat_v1_0 options:0 error:&serializationError];
            Check(original != nil && serializationError == nil, @"binary plist fixture generated");
            NSString *source = [fixtureRoot stringByAppendingPathComponent:@"source.plist"];
            Check([original writeToFile:source atomically:YES], @"source staged");
            NSDictionary *receipt = Success(@{@"action": @"import", @"path": @"/CC365/Folder/source.plist", @"local_path": source});
            Check([receipt[@"bytes"] unsignedLongLongValue] == original.length, @"import reports exact bytes");
            Check([[NSData dataWithContentsOfFile:[documents stringByAppendingPathComponent:@"Folder/source.plist"]] isEqual:original], @"import preserves binary plist bytes");
            Check(Failure(@{@"action": @"import", @"path": @"/CC365/Folder/source.plist", @"local_path": source}).code == EEXIST, @"import cannot clobber existing file");
            Check(!HasTemporaryParts(), @"no staged files remain after existing-target failure");
            NSString *download = [fixtureRoot stringByAppendingPathComponent:@"download.plist"];
            receipt = Success(@{@"action": @"download", @"path": @"/CC365/Folder/source.plist", @"local_path": download});
            Check([receipt[@"bytes"] unsignedLongLongValue] == original.length && [[NSData dataWithContentsOfFile:download] isEqual:original], @"export preserves exact binary bytes");
            Check(Failure(@{@"action": @"download", @"path": @"/CC365/Folder/source.plist", @"local_path": download}).code == EEXIST, @"export cannot clobber temp target");
            Failure(@{@"action": @"download", @"path": @"/CC365/Folder/source.plist", @"local_path": @"/etc/cc365-outside-temp"});
            Check(Failure(@{@"action": @"delete", @"path": @"/CC365/Folder"}).code == ENOTEMPTY, @"delete only removes empty directories");

            NSString *linked = [documents stringByAppendingPathComponent:@"linked"];
            Check(symlink([documents stringByAppendingPathComponent:@"Folder"].fileSystemRepresentation, linked.fileSystemRepresentation) == 0, @"symlink fixture made");
            Failure(@{@"action": @"list", @"path": @"/CC365/linked/Nested"});
            Failure(@{@"action": @"download", @"path": @"/CC365/linked/source.plist", @"local_path": [fixtureRoot stringByAppendingPathComponent:@"link-out"]});
            Failure(@{@"action": @"mkdir", @"path": @"/CC365/linked/forbidden"});
            Failure(@{@"action": @"delete", @"path": @"/CC365/linked"});
            Check(!Exists([documents stringByAppendingPathComponent:@"Folder/forbidden"]), @"workspace symlink cannot redirect writes");
            NSString *fifo = [documents stringByAppendingPathComponent:@"fifo"];
            Check(mkfifo(fifo.fileSystemRepresentation, 0600) == 0, @"FIFO fixture made");
            Failure(@{@"action": @"download", @"path": @"/CC365/fifo", @"local_path": [fixtureRoot stringByAppendingPathComponent:@"fifo-out"]});
            Check(!Exists([fixtureRoot stringByAppendingPathComponent:@"fifo-out"]), @"nonregular export leaves no output");
            Failure(@{@"action": @"delete", @"path": @"/CC365/fifo"});

            Success(@{@"action": @"mkdir", @"path": @"/CC365/Pages"});
            for (NSUInteger i = 0; i < 205; i++) {
                NSString *name = [NSString stringWithFormat:@"Pages/item-%03lu", (unsigned long)i];
                [NSData.data writeToFile:[documents stringByAppendingPathComponent:name] atomically:NO];
            }
            page = Success(@{@"action": @"list", @"path": @"/CC365/Pages", @"offset": @0});
            Check([page[@"entries"] count] == 100 && [page[@"nextOffset"] isEqual:@100] && [page[@"total"] isEqual:@205], @"first page is 100 rows");
            page = Success(@{@"action": @"list", @"path": @"/CC365/Pages", @"offset": @200});
            Check([page[@"entries"] count] == 5 && page[@"nextOffset"] == NSNull.null, @"last page has no continuation");
            page = Success(@{@"action": @"list", @"path": @"/CC365/Pages", @"offset": @999});
            Check([page[@"entries"] count] == 0, @"past-end page is empty");
            Failure(@{@"action": @"list", @"path": @"/CC365", @"offset": @-1});
            [NSData.data writeToFile:[documents stringByAppendingPathComponent:@".visible-dotfile"] atomically:NO];
            page = Success(@{@"action": @"list", @"path": @"/CC365"});
            NSMutableDictionary *kinds = [NSMutableDictionary dictionary];
            for (NSDictionary *row in page[@"entries"]) kinds[row[@"name"]] = row[@"kind"];
            Check([kinds[@"linked"] isEqual:@"symlink"] && [kinds[@"fifo"] isEqual:@"other"] && [kinds[@".visible-dotfile"] isEqual:@"file"], @"links, special files and dotfiles classified accurately");
            Check([page[@"entries"][0][@"kind"] isEqual:@"directory"], @"folders sort before files");

            NSString *large = [fixtureRoot stringByAppendingPathComponent:@"large"];
            int fd = open(large.fileSystemRepresentation, O_RDWR | O_CREAT | O_EXCL, 0600);
            Check(fd >= 0 && ftruncate(fd, 256LL * 1024 * 1024 + 1) == 0, @"oversize sparse file fixture");
            close(fd);
            Check(Failure(@{@"action": @"import", @"path": @"/CC365/large", @"local_path": large}).code == EFBIG, @"256 MiB import limit enforced");
            Check(!Exists([documents stringByAppendingPathComponent:@"large"]) && !HasTemporaryParts(), @"oversize import cleans up");
            NSString *largeOut = [fixtureRoot stringByAppendingPathComponent:@"large-out"];
            Check(Failure(@{@"action": @"download", @"path": large, @"local_path": largeOut}).code == EFBIG, @"256 MiB export limit enforced");
            Check(!Exists(largeOut), @"oversize export removes temporary output");

            NSMutableData *megabyte = [NSMutableData dataWithLength:1024 * 1024];
            [megabyte writeToFile:source atomically:YES];
            TickProgress *cancelProgress = [[TickProgress alloc] initWithParent:nil userInfo:nil];
            __weak TickProgress *weakCancel = cancelProgress;
            cancelProgress.tick = ^(int64_t count) { if (count >= 64 * 1024) [weakCancel cancel]; };
            NSError *failure;
            Check(Request(@{@"action": @"import", @"path": @"/CC365/cancelled", @"local_path": source}, cancelProgress, &failure) == nil && failure.code == NSUserCancelledError, @"copy cancellation reported");
            Check(!Exists([documents stringByAppendingPathComponent:@"cancelled"]) && !HasTemporaryParts(), @"cancelled import has no target or staging file");
            TickProgress *changingProgress = [[TickProgress alloc] initWithParent:nil userInfo:nil];
            __block BOOL changed = NO;
            changingProgress.tick = ^(int64_t count) {
                if (count > 0 && !changed) { changed = YES; int sourceFD = open(source.fileSystemRepresentation, O_WRONLY); ftruncate(sourceFD, 1024 * 1024 + 123); close(sourceFD); }
            };
            Check(Request(@{@"action": @"import", @"path": @"/CC365/changed", @"local_path": source}, changingProgress, &failure) == nil && failure.code == EBUSY, @"file changing during copy is rejected");
            Check(!Exists([documents stringByAppendingPathComponent:@"changed"]) && !HasTemporaryParts(), @"changed source leaves no partial import");
            NSProgress *alreadyCancelled = [NSProgress progressWithTotalUnitCount:1]; [alreadyCancelled cancel];
            Check(Request(@{@"action": @"mkdir", @"path": @"/CC365/no-create"}, alreadyCancelled, &failure) == nil && !Exists([documents stringByAppendingPathComponent:@"no-create"]), @"cancelled request never mutates");

            page = Success(@{@"action": @"list", @"path": @"/CC365/Pages", @"query": @"ITEM-204", @"show_hidden": @NO, @"sort": @"name"});
            Check([page[@"total"] isEqual:@1] && [page[@"entries"][0][@"name"] isEqual:@"item-204"], @"search covers full listing before pagination and ignores case");
            page = Success(@{@"action": @"list", @"path": @"/CC365/Pages", @"sort": @"name", @"ascending": @NO});
            Check([page[@"entries"][0][@"name"] isEqual:@"item-204"], @"reverse sorting happens before pagination");
            page = Success(@{@"action": @"list", @"path": @"/CC365", @"query": @"visible-dotfile", @"show_hidden": @NO});
            Check([page[@"total"] isEqual:@0], @"hidden toggle filters dotfiles");
            page = Success(@{@"action": @"list", @"path": @"/CC365", @"query": @"visible-dotfile", @"show_hidden": @YES});
            Check([page[@"total"] isEqual:@1], @"hidden toggle can reveal dotfiles");
            Failure(@{@"action": @"list", @"path": @"/CC365", @"sort": @"bogus"});
            NSDictionary *details = Success(@{@"action": @"details", @"path": @"/CC365/Folder/source.plist"});
            Check([details[@"size"] unsignedIntegerValue] == original.length && [details[@"permissions"] isEqual:@"0600"] && details[@"inode"], @"details exposes real bounded stat metadata");
            Check([Success(@{@"action": @"details", @"path": @"/CC365/linked"})[@"kind"] isEqual:@"symlink"], @"details inspects symlink itself without following");
            Success(@{@"action": @"move", @"path": @"/CC365/Folder/source.plist", @"destination": @"/CC365/Folder/renamed.plist"});
            Check(!Exists([documents stringByAppendingPathComponent:@"Folder/source.plist"]) && Exists([documents stringByAppendingPathComponent:@"Folder/renamed.plist"]), @"rename moves bytes without creating duplicate");
            Check(Failure(@{@"action": @"move", @"path": @"/CC365/Folder/renamed.plist", @"destination": @"/CC365/.visible-dotfile"}).code == EEXIST, @"move never overwrites existing destination");
            Failure(@{@"action": @"move", @"path": @"/CC365/Folder", @"destination": @"/CC365/Folder/Nested/self"});
            Failure(@{@"action": @"move", @"path": @"/CC365/linked", @"destination": @"/CC365/link-moved"});
            Failure(@{@"action": @"move", @"path": @"/CC365/Folder", @"destination": [fixtureRoot stringByAppendingPathComponent:@"outside"]});
            Success(@{@"action": @"move", @"path": @"/CC365/Folder/Nested", @"destination": @"/CC365/MovedEmpty"});
            Check(Exists([documents stringByAppendingPathComponent:@"MovedEmpty"]), @"empty folder move succeeds atomically");

            NSString *tree = [fixtureRoot stringByAppendingPathComponent:@"tree"];
            [NSFileManager.defaultManager createDirectoryAtPath:[tree stringByAppendingPathComponent:@"empty"] withIntermediateDirectories:YES attributes:nil error:nil];
            [original writeToFile:[tree stringByAppendingPathComponent:@".hidden"] atomically:NO];
            [NSData.data writeToFile:[tree stringByAppendingPathComponent:@"zero"] atomically:NO];
            Success(@{@"action": @"importTree", @"path": @"/CC365/Imported", @"local_path": tree});
            Check(Exists([documents stringByAppendingPathComponent:@"Imported/empty"]) &&
                  [[NSData dataWithContentsOfFile:[documents stringByAppendingPathComponent:@"Imported/.hidden"]] isEqual:original] &&
                  [[NSData dataWithContentsOfFile:[documents stringByAppendingPathComponent:@"Imported/zero"]] length] == 0,
                  @"tree publication preserves empty directories, hidden names and zero bytes");
            Check(Failure(@{@"action": @"importTree", @"path": @"/CC365/Imported", @"local_path": tree}).code == EEXIST, @"tree import no-clobber preserves existing directory");
            Check(symlink(source.fileSystemRepresentation, [tree stringByAppendingPathComponent:@"link"].fileSystemRepresentation) == 0, @"tree symlink fixture created");
            Failure(@{@"action": @"importTree", @"path": @"/CC365/UnsafeTree", @"local_path": tree});
            Check(!Exists([documents stringByAppendingPathComponent:@"UnsafeTree"]) && !HasTemporaryParts(), @"failed tree import publishes nothing and cleans only staged tree");
            unlink([tree stringByAppendingPathComponent:@"link"].fileSystemRepresentation);
            [megabyte writeToFile:[tree stringByAppendingPathComponent:@"large"] atomically:NO];
            TickProgress *treeCancel = [[TickProgress alloc] initWithParent:nil userInfo:nil];
            __weak TickProgress *weakTree = treeCancel;
            treeCancel.tick = ^(int64_t count) { if (count > 0) [weakTree cancel]; };
            Check(!Request(@{@"action": @"importTree", @"path": @"/CC365/CancelledTree", @"local_path": tree}, treeCancel, &failure), @"tree cancellation reported");
            Check(!Exists([documents stringByAppendingPathComponent:@"CancelledTree"]) && !HasTemporaryParts(), @"tree cancellation leaves no published partial directory");

            NSString *expected = [fixtureRoot stringByAppendingPathComponent:@"expected"];
            NSString *replacement = [fixtureRoot stringByAppendingPathComponent:@"replacement"];
            [original writeToFile:expected atomically:NO];
            NSData *edited = [@"edited text" dataUsingEncoding:NSUTF8StringEncoding];
            [edited writeToFile:replacement atomically:NO];
            NSString *editPath = [documents stringByAppendingPathComponent:@"Folder/renamed.plist"];
            Success(@{@"action": @"replace", @"path": @"/CC365/Folder/renamed.plist", @"local_path": replacement, @"expected_path": expected});
            Check([[NSData dataWithContentsOfFile:editPath] isEqual:edited] && !HasTemporaryParts(), @"exact-original replacement atomically installs edited bytes and cleans backup");
            Check(Failure(@{@"action": @"replace", @"path": @"/CC365/Folder/renamed.plist", @"local_path": replacement, @"expected_path": expected}).code == EBUSY, @"stale editor original cannot overwrite newer bytes");
            [edited writeToFile:expected atomically:NO];
            [megabyte writeToFile:replacement atomically:NO];
            TickProgress *editRace = [[TickProgress alloc] initWithParent:nil userInfo:nil];
            __block BOOL changedEdit = NO;
            NSData *otherEdit = [@"concurrent edit" dataUsingEncoding:NSUTF8StringEncoding];
            editRace.tick = ^(int64_t count) { if (count > 0 && !changedEdit) { changedEdit = YES; [otherEdit writeToFile:editPath atomically:NO]; } };
            Check(!Request(@{@"action": @"replace", @"path": @"/CC365/Folder/renamed.plist", @"local_path": replacement, @"expected_path": expected}, editRace, &failure), @"target changed while staging replacement is rejected");
            Check([[NSData dataWithContentsOfFile:editPath] isEqual:otherEdit] && !HasTemporaryParts(), @"concurrent edit survives rejected replacement");
            [otherEdit writeToFile:expected atomically:NO];
            [edited writeToFile:replacement atomically:NO];
            __block BOOL swapEdited = NO;
            afterSwap = ^(int from, const char *temporary, __unused int to, __unused const char *target) {
                if (swapEdited) return;
                swapEdited = YES;
                int oldFD = openat(from, temporary, O_WRONLY | O_TRUNC | O_NOFOLLOW);
                write(oldFD, "late original edit", 18); close(oldFD);
            };
            Check(!Request(@{@"action": @"replace", @"path": @"/CC365/Folder/renamed.plist", @"local_path": replacement, @"expected_path": expected}, nil, &failure), @"late edit of displaced original prevents destructive cleanup");
            afterSwap = nil;
            Check([[NSData dataWithContentsOfFile:editPath] isEqual:[@"late original edit" dataUsingEncoding:NSUTF8StringEncoding]], @"late original edit is restored intact after atomic-swap conflict");
            [[NSData dataWithContentsOfFile:editPath] writeToFile:expected atomically:NO];
            __block BOOL swappedTarget = NO;
            afterSwap = ^(__unused int from, __unused const char *temporary, int to, const char *target) {
                if (swappedTarget) return;
                swappedTarget = YES;
                unlinkat(to, target, 0);
                int other = openat(to, target, O_WRONLY | O_CREAT | O_EXCL, 0600);
                write(other, "new target identity", 19); close(other);
            };
            Check(!Request(@{@"action": @"replace", @"path": @"/CC365/Folder/renamed.plist", @"local_path": replacement, @"expected_path": expected}, nil, &failure), @"changed destination identity after swap triggers recovery");
            afterSwap = nil;
            Check([[NSData dataWithContentsOfFile:editPath] isEqual:[@"new target identity" dataUsingEncoding:NSUTF8StringEncoding]], @"recovery never overwrites different destination identity");
            NSString *recovered = nil;
            for (NSString *name in [NSFileManager.defaultManager contentsOfDirectoryAtPath:editPath.stringByDeletingLastPathComponent error:nil])
                if ([name hasPrefix:@"Recovered-"]) recovered = [editPath.stringByDeletingLastPathComponent stringByAppendingPathComponent:name];
            Check(recovered && [[NSData dataWithContentsOfFile:recovered] isEqual:[NSData dataWithContentsOfFile:expected]] &&
                  [failure.localizedDescription containsString:@"/CC365/Folder/Recovered-"], @"unconfirmed commit retains old bytes at visible full recovery path");
            Check(!HasTemporaryParts(), @"recovery file does not use hidden reserved temporary prefix");
            [[NSData dataWithContentsOfFile:editPath] writeToFile:expected atomically:NO];
            [megabyte writeToFile:replacement atomically:NO];
            TickProgress *tempRace = [[TickProgress alloc] initWithParent:nil userInfo:nil];
            __block NSString *foreignTemporary = nil;
            NSString *heldReplacement = [fixtureRoot stringByAppendingPathComponent:@"held-replacement"];
            tempRace.tick = ^(int64_t count) {
                if (count <= 0 || foreignTemporary) return;
                for (NSString *name in [NSFileManager.defaultManager contentsOfDirectoryAtPath:editPath.stringByDeletingLastPathComponent error:nil]) {
                    if (![name hasPrefix:@".cc365-bq-part-"]) continue;
                    foreignTemporary = [editPath.stringByDeletingLastPathComponent stringByAppendingPathComponent:name];
                    rename(foreignTemporary.fileSystemRepresentation, heldReplacement.fileSystemRepresentation);
                    [@"unrelated temporary bytes" writeToFile:foreignTemporary atomically:NO encoding:NSUTF8StringEncoding error:nil];
                    break;
                }
            };
            Check(!Request(@{@"action": @"replace", @"path": @"/CC365/Folder/renamed.plist", @"local_path": replacement, @"expected_path": expected}, tempRace, &failure), @"substituted staged file is rejected before swap");
            Check(foreignTemporary && [[NSString stringWithContentsOfFile:foreignTemporary encoding:NSUTF8StringEncoding error:nil] isEqual:@"unrelated temporary bytes"] &&
                  [[NSData dataWithContentsOfFile:editPath] isEqual:[NSData dataWithContentsOfFile:expected]], @"cleanup does not delete substituted temporary bytes or change original");
            unlink(foreignTemporary.fileSystemRepresentation);
            TickProgress *treeRace = [[TickProgress alloc] initWithParent:nil userInfo:nil];
            __block NSString *foreignTree = nil;
            NSString *heldTree = [fixtureRoot stringByAppendingPathComponent:@"held-tree"];
            treeRace.tick = ^(int64_t count) {
                if (count <= 0 || foreignTree) return;
                for (NSString *name in [NSFileManager.defaultManager contentsOfDirectoryAtPath:documents error:nil]) {
                    if (![name hasPrefix:@".cc365-bq-part-"]) continue;
                    foreignTree = [documents stringByAppendingPathComponent:name];
                    rename(foreignTree.fileSystemRepresentation, heldTree.fileSystemRepresentation);
                    mkdir(foreignTree.fileSystemRepresentation, 0700);
                    [@"keep this" writeToFile:[foreignTree stringByAppendingPathComponent:@"foreign"] atomically:NO encoding:NSUTF8StringEncoding error:nil];
                    break;
                }
            };
            Check(!Request(@{@"action": @"importTree", @"path": @"/CC365/TreeRace", @"local_path": tree}, treeRace, &failure), @"substituted tree root is rejected before publication");
            Check(foreignTree && Exists([foreignTree stringByAppendingPathComponent:@"foreign"]) && !Exists([documents stringByAppendingPathComponent:@"TreeRace"]), @"tree cleanup never traverses substituted root");
            [NSFileManager.defaultManager removeItemAtPath:foreignTree error:nil];
            Failure(@{@"action": @"replace", @"path": source, @"local_path": replacement, @"expected_path": expected});

            Check(escapes == 0, @"local operations never invoke protected-access fallback");
            NSDictionary *check = Success(@{@"action": @"check"});
            Check([check[@"exactBytesRecovered"] boolValue] && [check[@"cleanupComplete"] boolValue] && ![check[@"recoveryOnly"] boolValue] && check[@"booksRestored"] == NSNull.null, @"diagnostic receipt describes only successful local test");
            Check(!HasTemporaryParts() && escapes == 0, @"diagnostic cleans up and never escapes");
            page = Success(@{@"action": @"list", @"path": @"/"});
            Check([page[@"entries"] count] == 6 && [page[@"entries"][0][@"path"] isEqual:@"/var/containers/Data/System"] && !page[@"notice"], @"virtual root exposes six fixed locations");
            Check(discoveries == 1, @"root listing does not discover containers; explicit check remains separate");




            NSString *removedRoot = [fixtureRoot stringByAppendingPathComponent:@"removed-container"];
            Check([NSFileManager.defaultManager createDirectoryAtPath:removedRoot withIntermediateDirectories:NO attributes:nil error:nil], @"removable root fixture created");
            Check([NSFileManager.defaultManager removeItemAtPath:removedRoot error:nil], @"stale root fixture removed before open");
            dispatch_sync(BQWorkQueue(), ^{
                for (NSString *root in @[removedRoot, linked]) {
                    __block NSUInteger calls = 0;
                    NSUInteger beforeEscapes = escapes, beforeReleases = releases;
                    NSError *error = nil;
                    BOOL ok = [CCBQFileSystem withDirectory:root progress:[NSProgress progressWithTotalUnitCount:1] operation:^BOOL(__unused NSString *path, __unused NSError **failure) {
                        calls++; return YES;
                    } error:&error];
                    if ([root isEqual:removedRoot]) {
                        Check(!ok && error.code == ENOENT, @"missing root fails with actual filesystem ENOENT");
                    } else {
                        Check(!ok && (error.code == ELOOP || error.code == ENOTDIR), @"root symlink fails no-follow directory open");
                    }
                    Check(calls == 0 && escapes == beforeEscapes && releases == beforeReleases,
                          @"invalid root never enters operation or acquires a BQ lease");
                }
            });

            dispatch_sync(BQWorkQueue(), ^{
                NSError *error;
                __block NSUInteger calls = 0;
                BOOL ok = [CCBQFileSystem withDirectory:documents progress:[NSProgress progressWithTotalUnitCount:1] operation:^BOOL(__unused NSString *path, NSError **err) {
                    calls++; *err = [NSError errorWithDomain:NSPOSIXErrorDomain code:EACCES userInfo:@{}]; return NO;
                } error:&error];
                Check(!ok && calls == 1 && escapes == 0, @"unsafe callback failure is never retried");
                calls = 0;
                ok = [CCBQFileSystem withDirectory:documents progress:[NSProgress progressWithTotalUnitCount:1] operation:^BOOL(NSString *path, NSError **err) {
                    calls++; if (calls == 1) { *err = [NSError errorWithDomain:NSPOSIXErrorDomain code:EACCES userInfo:@{CCBQRetrySafeKey: @YES}]; return NO; }
                    return [path isEqual:documents];
                } error:&error];
                Check(ok && calls == 2 && escapes == 1 && releases == 1, @"safe permission failure retries once and releases lease");
                calls = 0;
                @try {
                    [CCBQFileSystem withDirectory:documents progress:[NSProgress progressWithTotalUnitCount:1] operation:^BOOL(__unused NSString *path, NSError **err) {
                        calls++; if (calls == 1) { *err = [NSError errorWithDomain:NSPOSIXErrorDomain code:EPERM userInfo:@{CCBQRetrySafeKey: @YES}]; return NO; }
                        [NSException raise:@"Fixture" format:@"callback throws"]; return NO;
                    } error:&error];
                } @catch (__unused NSException *exception) {}
                Check(escapes == 2 && releases == 2, @"exception still releases active lease");
                escapeResult = -7;
                ok = [CCBQFileSystem withDirectory:documents progress:[NSProgress progressWithTotalUnitCount:1] operation:^BOOL(__unused NSString *path, NSError **err) {
                    *err = [NSError errorWithDomain:NSPOSIXErrorDomain code:EACCES userInfo:@{CCBQRetrySafeKey: @YES}]; return NO;
                } error:&error];
                Check(!ok && error.code == EACCES && releases == 2, @"unsupported core fails closed without bogus release");
            });

            __block NSUInteger completions = 0;
            [CCBQFileSystem performRequest:@{@"action": @"list", @"path": @"/CC365"} progress:[NSProgress progressWithTotalUnitCount:1] completion:^(NSDictionary *result, NSError *error) {
                completions++; Check(NSThread.isMainThread && result && !error, @"async result arrives on main thread");
            }];
            NSDate *deadline = [NSDate dateWithTimeIntervalSinceNow:3];
            while (completions == 0 && deadline.timeIntervalSinceNow > 0) [NSRunLoop.currentRunLoop runUntilDate:[NSDate dateWithTimeIntervalSinceNow:0.01]];
            [NSRunLoop.currentRunLoop runUntilDate:[NSDate dateWithTimeIntervalSinceNow:0.05]];
            Check(completions == 1, @"async completion fires exactly once");
            printf("BQFileSystem: %lu assertions passed (inert core/catalog fixtures).\n", (unsigned long)assertions);
        } @finally { [NSFileManager.defaultManager removeItemAtPath:fixtureRoot error:nil]; }
    }
    return 0;
}
