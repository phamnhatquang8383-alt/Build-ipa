import importlib.util
from pathlib import Path
import plistlib
import subprocess
import tempfile
import unittest
from unittest.mock import patch
import zipfile

spec = importlib.util.spec_from_file_location('package_ipa', Path(__file__).resolve().parents[1] / 'scripts/package_ipa.py')
packager = importlib.util.module_from_spec(spec)
spec.loader.exec_module(packager)

class PackageTests(unittest.TestCase):
    def setUp(self):
        temporary = tempfile.TemporaryDirectory()
        self.addCleanup(temporary.cleanup)
        self.root = Path(temporary.name)
        self.app = self.root / 'PhamQuangIOS.app'
        self.app.mkdir()
        self.info = dict(CFBundleExecutable='PhamQuangIOS', CFBundlePackageType='APPL', CFBundleSupportedPlatforms=['iPhoneOS'], CFBundleIdentifier='sato.cc365.file', CFBundleDisplayName='PhamQuang IOS', CFBundleVersion='3', CFBundleShortVersionString='1.2.0')
        self.write_info()
        self.executable = self.app / 'PhamQuangIOS'
        self.executable.write_bytes(b'fixture only')
        self.executable.chmod(0o755)
        mocked = patch.object(packager.subprocess, 'run', return_value=subprocess.CompletedProcess([], 1, '', 'code object is not signed at all'))
        self.signing = mocked.start()
        self.addCleanup(mocked.stop)

    def write_info(self):
        (self.app / 'Info.plist').write_bytes(plistlib.dumps(self.info))

    def test_unsigned_metadata(self):
        self.assertEqual(packager.validate_app(self.app, expected_bundle_id='sato.cc365.file', expected_display_name='PhamQuang IOS', expected_version='1.2.0', expected_build='3'), 'PhamQuangIOS')
        for key in ['expected_bundle_id','expected_display_name','expected_version','expected_build']:
            with self.subTest(key=key), self.assertRaisesRegex(ValueError, 'Unexpected'):
                packager.validate_app(self.app, **{key:'wrong'})

    def test_archive_layout_permissions(self):
        output = self.root / 'out.ipa'
        digest = packager.archive_app(self.app, output, 'PhamQuangIOS')
        with zipfile.ZipFile(output) as archive:
            self.assertIsNone(archive.testzip())
            self.assertEqual(set(archive.namelist()), {'Payload/PhamQuangIOS.app/Info.plist','Payload/PhamQuangIOS.app/PhamQuangIOS'})
            self.assertTrue(archive.getinfo('Payload/PhamQuangIOS.app/PhamQuangIOS').external_attr >> 16 & 0o111)
        self.assertIn(digest, output.with_suffix('.ipa.sha256').read_text())

    def test_rejects_permissions_and_simulator(self):
        self.executable.chmod(0o644)
        with self.assertRaisesRegex(ValueError, 'executable permission'): packager.validate_app(self.app)
        self.executable.chmod(0o755)
        self.info['CFBundleSupportedPlatforms'] = ['iPhoneSimulator']; self.write_info()
        with self.assertRaisesRegex(ValueError, 'iPhoneOS'): packager.validate_app(self.app)

    def test_rejects_extensions_and_pairing_permissions(self):
        plugin = self.app / 'PlugIns/Unwanted.appex'; plugin.mkdir(parents=True)
        with self.assertRaisesRegex(ValueError, 'extension'): packager.validate_app(self.app)
        plugin.rmdir(); plugin.parent.rmdir()
        for key in ['NSBonjourServices','CFBundleURLTypes']:
            self.info[key] = 'fixture'; self.write_info()
            with self.subTest(key=key), self.assertRaisesRegex(ValueError, 'pairing/network'): packager.validate_app(self.app)
            del self.info[key]

    def test_airlift_network_permission_requires_explanation(self):
        self.info['NSLocalNetworkUsageDescription'] = 'AirLift connects to this device through LocalDevVPN.'
        self.write_info()
        self.assertEqual(packager.validate_app(self.app), 'PhamQuangIOS')
        for invalid in ['', '   ', ['unexpected']]:
            self.info['NSLocalNetworkUsageDescription'] = invalid
            self.write_info()
            with self.assertRaisesRegex(ValueError, 'Local network usage'):
                packager.validate_app(self.app)

    def test_rejects_signing_material(self):
        for name in ['embedded.mobileprovision','cert.cer','signer.p12','signer.PFX']:
            path = self.app / name; path.touch()
            with self.subTest(name=name), self.assertRaisesRegex(ValueError, 'signing material'): packager.validate_app(self.app)
            path.unlink()
        self.signing.return_value = subprocess.CompletedProcess([], 0, '', '')
        with self.assertRaisesRegex(ValueError, 'is signed'): packager.validate_app(self.app)
        self.signing.return_value = subprocess.CompletedProcess([], 1, '', 'unknown failure')
        with self.assertRaisesRegex(ValueError, 'Cannot establish'): packager.validate_app(self.app)

    def test_internal_tunnel_identity_version_and_unsigned_state(self):
        expected = 'sato.cc365.file.tunnel'
        with self.assertRaisesRegex(ValueError, 'missing'):
            packager.validate_app(self.app, expected_tunnel_bundle_id=expected)
        tunnel = self.app / 'PlugIns/Viet99Tunnel.appex'
        tunnel.mkdir(parents=True)
        metadata = dict(CFBundleExecutable='Viet99Tunnel', CFBundleIdentifier=expected,
            CFBundlePackageType='XPC!', CFBundleSupportedPlatforms=['iPhoneOS'],
            CFBundleVersion=self.info['CFBundleVersion'], CFBundleShortVersionString=self.info['CFBundleShortVersionString'],
            MinimumOSVersion='16.0', NSExtension={'NSExtensionPointIdentifier':'com.apple.networkextension.packet-tunnel'})
        binary = tunnel / 'Viet99Tunnel'; binary.write_bytes(b'fixture only'); binary.chmod(0o755)
        def save(): (tunnel / 'Info.plist').write_bytes(plistlib.dumps(metadata))
        save()
        self.assertEqual(packager.validate_app(self.app, expected_tunnel_bundle_id=expected), 'PhamQuangIOS')
        self.assertEqual(Path(self.signing.call_args.args[0][-1]), tunnel)
        for key, invalid in [('CFBundleIdentifier','other.tunnel'),('CFBundleVersion','wrong'),('MinimumOSVersion','18.0')]:
            original = metadata[key]; metadata[key] = invalid; save()
            with self.assertRaisesRegex(ValueError, 'metadata'):
                packager.validate_app(self.app, expected_tunnel_bundle_id=expected)
            metadata[key] = original
        save()
        metadata['NSExtension']['NSExtensionPointIdentifier'] = 'unwanted'
        save()
        with self.assertRaisesRegex(ValueError, 'extension point'):
            packager.validate_app(self.app, expected_tunnel_bundle_id=expected)

    def test_bad_archive_preserves_prior_file(self):
        output = self.root / 'existing.ipa'; output.write_bytes(b'previous')
        (self.app / 'bad-link').symlink_to(self.executable)
        with self.assertRaisesRegex(ValueError, 'symlink'): packager.archive_app(self.app, output, 'PhamQuangIOS')
        self.assertEqual(output.read_bytes(), b'previous')
        self.assertFalse(list(self.root.glob('.PhamQuangIOS-*')))

    def test_clean_is_project_local_only(self):
        for path in [self.root, Path.home(), Path('/'), Path(packager.__file__).resolve().parents[1] / 'build-mha']:
            with self.subTest(path=path), self.assertRaises(ValueError): packager.clean(path)

if __name__ == '__main__': unittest.main()
