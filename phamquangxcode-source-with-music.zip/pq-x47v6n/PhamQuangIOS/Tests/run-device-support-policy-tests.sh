#!/bin/bash
set -euo pipefail
cd "$(dirname "$0")/.."
build_dir="${CC365_TEST_BUILD_DIR:-$PWD/build/Tests}"
mkdir -p "$build_dir"
xcrun --sdk macosx swiftc -swift-version 5 -strict-concurrency=complete -warnings-as-errors \
    CC365-Apps/Runtime/DeviceSupportPolicy.swift Tests/DeviceSupportPolicyTests.swift \
    -o "$build_dir/DeviceSupportPolicyTests"
"$build_dir/DeviceSupportPolicyTests"
