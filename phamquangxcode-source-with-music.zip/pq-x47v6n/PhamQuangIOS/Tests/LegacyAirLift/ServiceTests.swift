import Foundation
@_silgen_name("fixture_legacy_active") func fixtureActive() -> Int32
@_silgen_name("fixture_legacy_reject") func fixtureReject(_ code: Int32)
@_silgen_name("fixture_legacy_finish") func fixtureFinish(_ outcome: Int32)
@MainActor final class LegacyInternalVPN {
    static let shared = LegacyInternalVPN()
    var calls = 0
    func ensureConnected() async throws { calls += 1 }
}
@MainActor final class Pause {
    var entered = false
    var continuation: CheckedContinuation<Void, Never>?
    func wait() async { entered = true; await withCheckedContinuation { continuation = $0 } }
    func release() { continuation?.resume(); continuation = nil }
}
@main struct Tests {
    @MainActor static func main() async throws {
        var checks = 0
        func check(_ value: Bool) { precondition(value); checks += 1 }
        func until(_ predicate: () -> Bool) async throws {
            for _ in 0..<1000 { if predicate() { return }; try await Task.sleep(nanoseconds: 1_000_000) }
            throw LegacyAirLiftError(message: "Fixture timed out")
        }
        let pause = Pause()
        let first = Task { try await LegacyAirLiftService.perform(["action":"apply"], patch: true, onCompletion: { await pause.wait() }) }
        try await until { fixtureActive() != 0 }
        check(LegacyInternalVPN.shared.calls == 1)
        do { _ = try await LegacyAirLiftService.perform(["action":"probe"], patch: false); preconditionFailure() } catch { check(error is LegacyAirLiftError) }
        check(LegacyInternalVPN.shared.calls == 1)
        fixtureFinish(0)
        try await until { pause.entered }
        do { _ = try await LegacyAirLiftService.perform(["action":"probe"], patch: false); preconditionFailure() } catch { check(error is LegacyAirLiftError) }
        check(LegacyInternalVPN.shared.calls == 1)
        pause.release(); let data = try await first.value
        check((try JSONSerialization.jsonObject(with: data) as? [String: Bool])?["ok"] == true)

        var completed = 0
        fixtureReject(2)
        do { _ = try await LegacyAirLiftService.perform(["action":"restore"], patch: true, onCompletion: { completed += 1 }); preconditionFailure() } catch { check(error is LegacyAirLiftError) }
        check(completed == 0)
        let next = Task { try await LegacyAirLiftService.perform(["action":"restore"], patch: true, onCompletion: { completed += 1 }) }
        try await until { fixtureActive() != 0 }; fixtureFinish(1)
        do { _ = try await next.value; preconditionFailure() } catch { check(error is LegacyAirLiftError) }
        check(completed == 1)

        let count = LegacyInternalVPN.shared.calls
        let history = Task { try await LegacyAirLiftService.perform(["action":"history"], patch: true) }
        try await until { fixtureActive() != 0 }; check(LegacyInternalVPN.shared.calls == count)
        fixtureFinish(0); _ = try await history.value
        let cancelled = Task { try await LegacyAirLiftService.perform(["action":"probe"], patch: false, onCompletion: { completed += 1 }) }
        try await until { fixtureActive() != 0 }; cancelled.cancel(); fixtureFinish(2)
        do { _ = try await cancelled.value; preconditionFailure() } catch { check(error is CancellationError) }
        check(completed == 2)
        let before = LegacyInternalVPN.shared.calls
        let preCancelled = Task { try await Task.sleep(nanoseconds: 10_000_000); return try await LegacyAirLiftService.perform(["action":"probe"], patch: false) }
        preCancelled.cancel()
        do { _ = try await preCancelled.value; preconditionFailure() } catch { check(error is CancellationError) }
        check(LegacyInternalVPN.shared.calls == before)
        print("Legacy AirLift service: \(checks) lifecycle checks passed")
    }
}
