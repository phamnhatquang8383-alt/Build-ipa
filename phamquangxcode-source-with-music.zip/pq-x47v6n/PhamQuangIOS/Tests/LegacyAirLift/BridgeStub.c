#include "viet99_airlift.h"
#include <stdlib.h>
#include <string.h>
struct LegacyJob { int cancelled; };
static LegacyJob *active;
static Viet99AirLiftCallback callback;
static void *context;
static int reject;
int fixture_legacy_active(void) { return active != NULL; }
void fixture_legacy_reject(int code) { reject = code; }
void fixture_legacy_finish(int outcome) {
    Viet99AirLiftCallback call = callback; void *ctx = context;
    active = NULL; callback = NULL; context = NULL;
    const char *json = outcome == 0 ? "{\"kind\":\"complete\",\"result\":{\"ok\":true}}" :
       outcome == 1 ? "{\"kind\":\"error\",\"message\":\"fixture\"}" :
       "{\"kind\":\"error\",\"message\":\"cancelled\",\"cancelled\":true}";
    if (call) call(ctx, (const uint8_t *)json, strlen(json));
}
int32_t viet99_airlift_job_start(const uint8_t *json,size_t length,Viet99AirLiftCallback call,void *ctx,LegacyJob **out) {
    (void)json; (void)length; *out = NULL;
    if (reject) { int code=reject;reject=0;return code; }
    if (active) return 2;
    active=calloc(1,sizeof(*active));callback=call;context=ctx;*out=active;return 0;
}
void viet99_airlift_job_cancel(LegacyJob *job) { if (job) job->cancelled=1; }
void viet99_airlift_job_release(LegacyJob *job) { free(job); }
LegacyBuffer viet99_airlift_storage(const uint8_t *json,size_t length) {
    (void)json;(void)length;char *text=strdup("{\"exists\":false}");return (LegacyBuffer){(uint8_t *)text,strlen(text)};
}
void viet99_airlift_buffer_free(LegacyBuffer b) { free(b.data); }
