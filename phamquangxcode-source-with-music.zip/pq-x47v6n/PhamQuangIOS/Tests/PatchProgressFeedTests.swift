import Foundation

@main struct PatchProgressFeedTests {
    static func main() async {
        var checks = 0
        func check(_ value: Bool, _ name: String) {
            precondition(value, name)
            checks += 1
            print("PASS " + name)
        }
        let a = "Documents/a", b = "Documents/b", c = "Documents/c"
        let feed = PatchProgressFeed(plan: [a, b, c])
        var iterator = feed.frames.makeAsyncIterator()
        let events = [
            RustPatchProgress(phase: "checking", done: 0, total: 3, path: a),
            RustPatchProgress(phase: "checking", done: 1, total: 3, path: b),
            RustPatchProgress(phase: "skipped", done: 2, total: 3, path: b),
            RustPatchProgress(phase: "checking", done: 2, total: 3, path: c),
            RustPatchProgress(phase: "applying", done: 0, total: 2, path: a),
            RustPatchProgress(phase: "applied", done: 1, total: 2, path: a),
            RustPatchProgress(phase: "applying", done: 1, total: 2, path: c),
            RustPatchProgress(phase: "applied", done: 2, total: 2, path: c),
            RustPatchProgress(phase: "complete", done: 2, total: 2, path: "")
        ]
        for (index, event) in events.enumerated() {
            feed.receive(event)
            guard let frame = await iterator.next() else { preconditionFailure("missing real frame") }
            check(frame.event == event, "raw-event-counters-preserved-\(index)")
            if index == 0 { check(frame.previous.isEmpty && frame.active == a && frame.upcoming == b, "first-file-context-matches-plan") }
            if index == 2 { check(frame.previous == a && frame.active == b && frame.upcoming == c, "same-file-phase-does-not-shift-neighbors") }
            if index == 4 { check(frame.previous == c && frame.active == a && frame.upcoming == b, "apply-phase-resets-count-without-inventing-global-progress") }
            if index == 8 { check(frame.active == c && frame.previous == a && frame.upcoming.isEmpty, "pathless-completion-keeps-last-file-context") }
        }
        let history = feed.fileDetails()
        check(history.map(\.path) == [a, b, c], "history-retains-first-seen-order")
        check(history.map(\.phase) == ["applied", "skipped", "applied"], "history-records-latest-real-outcome-only")
        check(history[1].label == "Đã khớp từ trước", "native-skipped-phase-has-accurate-label")
        feed.finish()
        check(await iterator.next() == nil, "finish-does-not-add-a-completion-event")

        let buffered = PatchProgressFeed(plan: [a, b, c])
        buffered.receive(.init(phase: "checking", done: 0, total: 3, path: a))
        buffered.receive(.init(phase: "skipped", done: 1, total: 3, path: a))
        buffered.receive(.init(phase: "checking", done: 1, total: 3, path: b))
        buffered.receive(.init(phase: "skipped", done: 2, total: 3, path: b))
        let finalReal = RustPatchProgress(phase: "checking", done: 2, total: 3, path: c)
        buffered.receive(finalReal)
        buffered.finish()
        var displayed = [PatchProgressFrame]()
        for await frame in buffered.frames { displayed.append(frame) }
        check(displayed.count == 1 && displayed.first?.event == finalReal, "coalescing-displays-newest-real-frame")
        check(displayed.first?.previous == b && displayed.first?.active == c, "coalescing-keeps-real-previous-distinct-file")
        check(buffered.fileDetails().map(\.phase) == ["skipped", "skipped", "checking"], "dropped-ui-frames-do-not-drop-file-history")
        check(buffered.fileDetails().last?.label == "Đã bắt đầu kiểm tra", "interrupted-last-file-is-not-marked-complete")

        let zero = PatchProgressFeed(plan: [a])
        zero.receive(.init(phase: "skipped", done: 1, total: 1, path: a))
        zero.receive(.init(phase: "complete", done: 0, total: 0, path: ""))
        zero.finish()
        for await frame in zero.frames {
            check(frame.event.done == 0 && frame.event.total == 0, "all-skipped-native-zero-total-is-not-fabricated")
            check(frame.active == a && zero.fileDetails().first?.phase == "skipped", "completion-does-not-overwrite-file-result")
        }

        let concurrent = PatchProgressFeed(plan: [])
        DispatchQueue.concurrentPerform(iterations: 256) { index in
            let path = "Documents/\(index)"
            concurrent.receive(.init(phase: "checking", done: index, total: 256, path: path))
            concurrent.receive(.init(phase: "applied", done: index + 1, total: 256, path: path))
            _ = concurrent.fileDetails()
        }
        concurrent.finish()
        let concurrentHistory = concurrent.fileDetails()
        check(concurrentHistory.count == 256 && Set(concurrentHistory.map(\.path)).count == 256, "concurrent-receive-and-history-keep-every-file-once")
        check(concurrentHistory.allSatisfy { $0.phase == "applied" }, "concurrent-history-retains-each-last-real-file-result")
        var concurrentFrames = 0
        for await _ in concurrent.frames { concurrentFrames += 1 }
        check(concurrentFrames == 1, "concurrent-producer-buffer-remains-bounded-to-newest-frame")
        print("\(checks) patch progress feed checks passed.")
    }
}
