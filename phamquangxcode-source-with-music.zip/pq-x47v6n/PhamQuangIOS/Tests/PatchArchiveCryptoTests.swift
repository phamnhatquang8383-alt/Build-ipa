import Foundation

@main
struct PatchArchiveCryptoTests {
    static func main() throws {
        let root = FileManager.default.temporaryDirectory.appendingPathComponent("PatchArchiveCryptoTests-" + UUID().uuidString)
        try FileManager.default.createDirectory(at: root, withIntermediateDirectories: true)
        defer { try? FileManager.default.removeItem(at: root) }

        let original = root.appendingPathComponent("original.zip")
        let encrypted = root.appendingPathComponent("sample.vpatch")
        let restored = root.appendingPathComponent("restored.zip")
        let payload = Data((0..<(2 * 1_048_576 + 173)).map { UInt8(($0 * 31 + 7) & 0xff) })
        try payload.write(to: original)

        try PatchArchiveCrypto.encrypt(original, to: encrypted, password: "Viet99-Strong-Passphrase-2026")
        precondition(PatchArchiveCrypto.isEncryptedFile(encrypted), "encrypted magic must be recognized")
        try PatchArchiveCrypto.decrypt(encrypted, to: restored, password: "Viet99-Strong-Passphrase-2026")
        let restoredBytes = try Data(contentsOf: restored)
        precondition(restoredBytes == payload, "round-trip must preserve exact bytes")

        let wrongPasswordOutput = root.appendingPathComponent("wrong.zip")
        do {
            try PatchArchiveCrypto.decrypt(encrypted, to: wrongPasswordOutput, password: "Wrong-Password-For-Test")
            fatalError("wrong password must fail authentication")
        } catch { }
        precondition(!FileManager.default.fileExists(atPath: wrongPasswordOutput.path), "failed decrypt must not publish plaintext")

        var tampered = try Data(contentsOf: encrypted)
        let headerSize = 8 + 1 + 16 + 8 + 4 + 8
        tampered[headerSize + 4 + 20] ^= 0x40
        let tamperedURL = root.appendingPathComponent("tampered.vpatch")
        try tampered.write(to: tamperedURL)
        do {
            try PatchArchiveCrypto.decrypt(tamperedURL, to: root.appendingPathComponent("tampered.zip"),
                                           password: "Viet99-Strong-Passphrase-2026")
            fatalError("tampered ciphertext must fail authentication")
        } catch { }

        var truncated = try Data(contentsOf: encrypted)
        truncated.removeLast(7)
        let truncatedURL = root.appendingPathComponent("truncated.vpatch")
        try truncated.write(to: truncatedURL)
        do {
            try PatchArchiveCrypto.decrypt(truncatedURL, to: root.appendingPathComponent("truncated.zip"),
                                           password: "Viet99-Strong-Passphrase-2026")
            fatalError("truncated ciphertext must fail")
        } catch { }

        print("PatchArchiveCryptoTests: 5 checks passed")
    }
}
