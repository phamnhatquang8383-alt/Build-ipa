#!/usr/bin/env python3






from pathlib import Path
import os
import re
import subprocess

root = Path(__file__).resolve().parents[1]
source = (root / 'CC365-Apps/Files/BQCore/BQCore.m').read_text()

def function(marker):
    start = source.index(marker)
    brace = source.index('{', start)
    depth = 1
    end = brace + 1
    while depth:
        if source[end] == '{':
            depth += 1
        elif source[end] == '}':
            depth -= 1
        end += 1
    return source[start:end]

constants = '\n'.join(re.findall(r'^static NSString \* const k(?:MGGroup|MGCaches) = .*;$', source, re.M))
cache = re.search(r'^static NSMutableOrderedSet<NSString \*> \*gTraversalFailedTargets;$', source, re.M).group(0)
release_type = re.search(r'^typedef \w+ \(\*fn_release\)\(int64_t\);$', source, re.M).group(0)
actual = '\n\n'.join(function(marker) for marker in [
    'static NSString *bq_dots(',
    'static NSString *bq_traversal_cache_key(',
    'static BOOL bq_should_try_traversal(',
    'static void bq_remember_traversal_failure(',
    'int64_t BQEscape(',
])
fixture = r'''
#import <Foundation/Foundation.h>
static BOOL gClass2ParentEnabled;
static BOOL ready;
static NSString *activeTarget;
static NSString *groupID;
static NSMutableDictionary<NSString *, NSNumber *> *traversalResults;
static NSMutableDictionary<NSString *, NSNumber *> *traversalCalls;
static NSMutableArray<NSString *> *domains;
static NSUInteger symlinks, class2Calls, directCalls, geodCalls, checks;
static int64_t symlinkResult, geodResult, directResult;
static BOOL BQCoreInit(void) { return ready; }
static NSString *BQGroupID(void) { return groupID; }
static void BQLog(NSString *format, ...) {}
static int64_t bq_query_escape(uint64_t cls, NSString *ident, BOOL group, uint64_t part,
                               NSString *domain, uint64_t flags, NSString *label, NSString **outPath) {
    int64_t result = -5;
    if ([label isEqual:@"class13-traversal"]) {
        traversalCalls[activeTarget] = @([traversalCalls[activeTarget] unsignedIntegerValue] + 1);
        [domains addObject:domain];
        result = traversalResults[activeTarget] ? [traversalResults[activeTarget] longLongValue] : -5;
    } else if ([label isEqual:@"class13-direct"]) { directCalls++; result = directResult; }
    else if ([label isEqual:@"class12-geod-traversal"]) { geodCalls++; result = geodResult; }
    if (result >= 0 && outPath) *outPath = activeTarget;
    return result;
}
static int64_t bq_escape_symlink(NSString *target, NSString **outPath) {
    symlinks++; if (symlinkResult >= 0 && outPath) *outPath = target; return symlinkResult;
}
static int64_t bq_escape_class2_parent(NSString *target, NSString **outPath) { class2Calls++; return -5; }
'''
tests = r'''
_Static_assert(__builtin_types_compatible_p(fn_release, int (*)(int64_t)),
               "sandbox_extension_release must return int, not int64_t");
static int FixtureRelease(int64_t handle) { return handle == 42 ? -1 : 0; }
static void Reset(void) {
    gTraversalFailedTargets = nil; gClass2ParentEnabled = NO; ready = YES; groupID = nil;
    traversalResults = [NSMutableDictionary dictionary]; traversalCalls = [NSMutableDictionary dictionary];
    domains = [NSMutableArray array]; symlinks = class2Calls = directCalls = geodCalls = 0;
    symlinkResult = geodResult = directResult = -5;
}
static int64_t Run(NSString *target) { activeTarget = target; NSString *returned = nil; return BQEscape(target, &returned); }
static NSUInteger Calls(NSString *target) { return [traversalCalls[target] unsignedIntegerValue]; }
static void Check(BOOL condition, NSString *label) {
    if (!condition) { fprintf(stderr, "FAIL %s\n", label.UTF8String); exit(1); }
    checks++; printf("PASS %s\n", label.UTF8String);
}
int main(void) { @autoreleasepool {
    fn_release release = FixtureRelease;
    Check(release(42) < 0 && release(43) == 0, @"actual-release-ABI-preserves-negative-int-result");
    NSString *root = @"/var/mobile/Containers/Data/Application";
    NSString *child = [root stringByAppendingPathComponent:@"FIRST-UUID"];
    NSString *other = [root stringByAppendingPathComponent:@"SECOND-UUID"];
    Reset(); traversalResults[child] = @41;
    Check(Run(root) < 0 && Run(child) == 41 && Calls(root) == 1 && Calls(child) == 1,
          @"failed-parent-still-allows-child-class13-success");
    Run(root); Check(Calls(root) == 1, @"same-failed-target-skips-redundant-class13");
    Check(Run(child) == 41 && Calls(child) == 2, @"successful-target-remains-attemptable");
    traversalResults[other] = @42;
    Check(Run(other) == 42 && Calls(other) == 1, @"different-container-keeps-independent-capability");
    Check(class2Calls == 0 && !gClass2ParentEnabled, @"class2-remains-disabled");

    Reset(); NSString *privateRoot = [@"/private" stringByAppendingString:root];
    Run(privateRoot); Run(root);
    Check(Calls(privateRoot) == 1 && Calls(root) == 0 && gTraversalFailedTargets.count == 1,
          @"private-var-alias-shares-only-the-same-target-cache");
    Check([domains.firstObject hasSuffix:privateRoot], @"cache-normalization-does-not-change-query-path");

    Reset();
    for (NSUInteger i = 0; i < 129; i++) Run([root stringByAppendingPathComponent:[NSString stringWithFormat:@"UUID-%lu", (unsigned long)i]]);
    NSString *oldest = [root stringByAppendingPathComponent:@"UUID-0"];
    NSString *newest = [root stringByAppendingPathComponent:@"UUID-128"];
    Check(gTraversalFailedTargets.count == 128, @"negative-cache-is-bounded-to-128-targets");
    traversalResults[oldest] = @77;
    Check(Run(oldest) == 77 && Calls(oldest) == 2, @"evicted-target-can-be-retried");
    Run(newest); Check(Calls(newest) == 1, @"recent-failed-target-remains-cached");

    Reset(); groupID = @"group.fixture"; symlinkResult = 88;
    Check(Run(root) == 88 && Run(root) == 88 && symlinks == 2 && Calls(root) == 1,
          @"app-group-fallback-remains-available-on-cache-hit");
    Reset(); geodResult = 99;
    Check(Run(root) == 99 && Run(root) == 99 && geodCalls == 2 && Calls(root) == 1,
          @"geod-fallback-remains-available-on-cache-hit");
    Reset(); directResult = 66;
    Check(Run(kMGCaches) == 66 && Run(kMGCaches) == 66 && directCalls == 2 && Calls(kMGCaches) == 1,
          @"direct-mobilegestalt-fallback-remains-available");

    Reset(); ready = NO;
    Check(Run(child) == -7 && Calls(child) == 0 && gTraversalFailedTargets.count == 0,
          @"runtime-init-failure-does-not-poison-target-cache");
    ready = YES; traversalResults[child] = @12;
    Check(Run(child) == 12 && Calls(child) == 1, @"target-retries-after-initialization-becomes-available");
    Reset();
    Check(Run(@"relative") == -1 && domains.count == 0 && gTraversalFailedTargets.count == 0,
          @"relative-path-does-not-enter-absolute-traversal-cache");
    printf("%lu dispatcher checks passed; all native queries are inert fixtures.\n", (unsigned long)checks);
    return 0;
}}
'''
build = Path(os.environ.get('CC365_TEST_BUILD_DIR', root / 'build/Tests'))
build.mkdir(parents=True, exist_ok=True)
generated = build / 'BQTraversalCacheTests.generated.m'
generated.write_text(fixture + '\n' + release_type + '\n' + constants + '\n' + cache + '\n' + actual + '\n' + tests)
executable = build / 'BQTraversalCacheTests'
subprocess.run(['xcrun', '--sdk', 'macosx', 'clang', '-fobjc-arc', '-fblocks', '-Wall', '-Wextra',
                '-Wno-unused-parameter', str(generated), '-framework', 'Foundation', '-o', str(executable)], check=True)
subprocess.run([str(executable)], check=True)
