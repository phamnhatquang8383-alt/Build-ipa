#!/bin/bash
set -euo pipefail
root="$(cd "$(dirname "$0")/.." && pwd)"
scratch="$(mktemp -d "${TMPDIR:-/tmp}/viet99-direct-provider.XXXXXX")"
trap 'rm -rf "$scratch"' EXIT
clang -fobjc-arc -fblocks -O2 -Wno-deprecated-declarations -framework Foundation \
    "$root/Tests/DirectFileProviderTests.m" -o "$scratch/direct-files"
"$scratch/direct-files"
python3 - "$root" "$scratch/direct-patches.m" <<'PY'
from pathlib import Path
import sys
root=Path(sys.argv[1])
text=(root/'Tests/BQPatchEngineTests.m').read_text()
for old,new in [('CCBQ','VVDirect'),('BQContainerEntry','VVDirectContainerEntry'),
                ('BQDiscoverContainers','VVDirectDiscoverContainers'),('BQDiscoverPatchTargets','VVDirectDiscoverPatchTargets'),
                ('BQResolveApplicationTarget','VVDirectResolveApplicationTarget')]:
    text=text.replace(old,new)
text=text.replace('../CC365-Apps/Files/BQCore/VVDirectPatchEngine.m',str(root/'CC365-Apps/Files/LegacyDirect/VVDirectPatchEngine.m'))
text+='\n#pragma clang diagnostic push\n#pragma clang diagnostic ignored "-Wincomplete-implementation"\n@implementation VVLegacyDirectAccess\n+ (BOOL)isReady { return YES; }\n@end\n#pragma clang diagnostic pop\n'
Path(sys.argv[2]).write_text(text)
PY
clang -fobjc-arc -fblocks -O2 -Wno-deprecated-declarations -framework Foundation \
    "$scratch/direct-patches.m" -o "$scratch/direct-patches"
"$scratch/direct-patches"
