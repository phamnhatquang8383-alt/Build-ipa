#import <Foundation/Foundation.h>
#import "BQLSStoreParser.h"
#import <string.h>

static NSUInteger checks;
static void Check(BOOL value, const char *label) {
    if (!value) { fprintf(stderr, "FAIL %s\n", label); exit(1); }
    checks++; printf("PASS %s\n", label);
}
static NSString *const App = @"/var/mobile/Containers/Data/Application/11111111-2222-4333-8444-555555555555";
static NSString *const Second = @"/var/mobile/Containers/Data/Application/AAAAAAAA-BBBB-4CCC-8DDD-EEEEEEEEEEEE";
static NSString *const Plugin = @"/var/mobile/Containers/Data/PluginKitPlugin/11111111-2222-4333-8444-555555555555";
static void Word(NSMutableData *data, NSUInteger offset, uint32_t value) {
    uint8_t bytes[4] = {value & 255, (value >> 8) & 255, (value >> 16) & 255, (value >> 24) & 255};
    [data replaceBytesInRange:NSMakeRange(offset, 4) withBytes:bytes];
}
static void Text(NSMutableData *data, NSUInteger offset, uint32_t identifier, NSString *value) {
    NSData *utf8 = [value dataUsingEncoding:NSUTF8StringEncoding];
    Word(data, offset, identifier); Word(data, offset + 4, (uint32_t)utf8.length);
    [data replaceBytesInRange:NSMakeRange(offset + 8, utf8.length) withBytes:utf8.bytes];
    NSUInteger padding = (4 - utf8.length % 4) % 4;
    if (padding) memset((uint8_t *)data.mutableBytes + offset + 8 + utf8.length, 0, padding);

    if (offset + 8 + utf8.length + padding < data.length) ((uint8_t *)data.mutableBytes)[offset + 8 + utf8.length + padding] = 0xfe;
}
static void Record(NSMutableData *data, NSUInteger offset, int version, BOOL plugin, uint32_t owner, uint32_t path) {
    uint32_t size = plugin ? (version == 26 ? 0x104 : version == 272 ? 0x120 : 0x118)
        : (version == 26 ? 0x23c : version == 272 ? 0x25c : 0x250);
    Word(data, offset + 4, size);
    NSUInteger body = offset + 8;
    Word(data, body + (plugin ? 0 : 0x0c), owner << 2);
    NSUInteger base = plugin ? (version == 26 ? 0x50 : version == 272 ? 0x58 : 0x54)
        : (version == 26 ? 0x64 : version == 272 ? 0x6c : 0x68);
    Word(data, body + base, path << 2);
    if (!plugin) { Word(data, body + base + 4, 3 << 2); Word(data, body + base + 12, 4 << 2); }
}
static NSMutableData *Fixture(int version, BOOL plugin) {
    NSMutableData *data = [NSMutableData dataWithLength:0x5000];
    memcpy(data.mutableBytes, "bdsl", 4);
    memcpy((uint8_t *)data.mutableBytes + 0x2000, "<string>", 8);
    Record(data, 0x180, version, plugin, 1, 2);
    Text(data, 0x2100, 1, plugin ? @"com.example.game.widget" : @"com.example.game");
    Text(data, 0x2200, 2, plugin ? Plugin : App);
    Text(data, 0x2300, 3, @"Bundle title");
    Text(data, 0x2400, 4, @"GameName");
    return data;
}
static NSArray *Parse(NSData *data) { return BQParseLSStore(data, nil, nil); }
static NSDictionary *Only(NSData *data) { NSArray *rows = Parse(data); return rows.count == 1 ? rows[0] : nil; }

int main(void) {
    @autoreleasepool {
        for (NSNumber *version in @[@26, @270, @272]) {
            NSDictionary *app = Only(Fixture(version.intValue, NO));
            Check([app[@"path"] isEqual:App] && [app[@"identifier"] isEqual:@"com.example.game"] &&
                [app[@"name"] isEqual:@"GameName"] && [app[@"kind"] isEqual:@"app"] && [app[@"source"] isEqual:@"csstore"],
                "known-app-layout-and-word-aligned-name");
            NSDictionary *plugin = Only(Fixture(version.intValue, YES));
            Check([plugin[@"path"] isEqual:Plugin] && [plugin[@"kind"] isEqual:@"plugin"] &&
                [plugin[@"name"] isEqual:@"com.example.game.widget"], "known-plugin-layout-falls-back-to-true-id");
            Check(!app[@"bundlePath"] && !app[@"bundle_path"], "parser-does-not-grant-bundle-path");
        }
        NSMutableData *data = Fixture(26, NO);
        Text(data, 0x2200, 2, [[@"/private" stringByAppendingString:App.lowercaseString] stringByAppendingString:@"/"]);

        Text(data, 0x2200, 2, [[@"/private" stringByAppendingString:App] stringByAppendingString:@"/"]);
        Check([Only(data)[@"path"] isEqual:App], "private-var-and-ios26-trailing-slash-canonicalize");
        data = Fixture(270, NO);
        Text(data, 0x2200, 2, Second.lowercaseString);
        Check(Parse(data).count == 0, "root-directory-case-is-not-guessed");
        Text(data, 0x2200, 2, [@"/var/mobile/Containers/Data/Application/" stringByAppendingString:Second.lastPathComponent.lowercaseString]);
        Check([Only(data)[@"path"] isEqual:Second], "uuid-case-canonicalizes");

        data = Fixture(272, NO);
        Word(data, 0x188 + 0x0c, 0); Word(data, 0x188 + 0x10, 1 << 2);
        Check([Only(data)[@"identifier"] isEqual:@"com.example.game"], "272-alternate-app-id-offset");
        data = Fixture(272, YES);
        Word(data, 0x188, 0); Word(data, 0x188 + 4, 1 << 2);
        Check([Only(data)[@"identifier"] isEqual:@"com.example.game.widget"], "272-alternate-plugin-id-offset");
        data = Fixture(272, NO);
        Word(data, 0x188 + 0x10, 5 << 2); Text(data, 0x2500, 5, @"com.different.owner");
        NSString *notice = nil;
        Check(BQParseLSStore(data, nil, &notice).count == 0 && notice.length, "272-conflicting-alternatives-fail-closed");
        Text(data, 0x2500, 5, @"com.example.game");
        Check(Only(data) != nil, "272-identical-alternatives-agree");

        data = Fixture(270, NO);
        Record(data, 0x700, 270, NO, 1, 2);
        Check(Parse(data).count == 1, "identical-records-deduplicate");
        Record(data, 0x700, 270, NO, 5, 2); Text(data, 0x2500, 5, @"com.other.owner");
        Check(Parse(data).count == 0, "two-owners-for-one-root-are-omitted");
        Record(data, 0xb00, 270, NO, 1, 6); Text(data, 0x2600, 6, Second);
        Check([Only(data)[@"path"] isEqual:Second], "ambiguous-root-does-not-remove-independent-safe-row");

        data = Fixture(270, NO);
        Text(data, 0x1000, 2, [@"/private" stringByAppendingString:App]);
        Check(Parse(data).count == 1, "same-path-string-ref-with-var-alias-is-not-conflict");
        Text(data, 0x1000, 2, Second);
        Check(Parse(data).count == 0, "one-path-ref-with-two-roots-is-ambiguous");
        Text(data, 0x1000, 2, @"/var/mobile/Containers/Data/Application/not-a-uuid");
        Check(Parse(data).count == 0, "conflicting-invalid-path-ref-cannot-be-ignored");
        Text(data, 0x1000, 2, @"/var/mobile/Containers/Data/InternalDaemon/11111111-2222-4333-8444-555555555555");
        Check(Parse(data).count == 0, "wrong-data-container-root-in-same-namespace-vetoes-mapping");
        data = Fixture(26, NO);
        Text(data, 0x1000, 2, @"/private/var/containers/Bundle/Application/AAAAAAAA-BBBB-4CCC-8DDD-EEEEEEEEEEEE/Game.app/");
        Check([Only(data)[@"path"] isEqual:App], "bundle-path-table-sid-before-data-path-does-not-poison-identity");
        Text(data, 0x2600, 2, @"/private/var/containers/Bundle/Application/AAAAAAAA-BBBB-4CCC-8DDD-EEEEEEEEEEEE/Game.app/");
        Check([Only(data)[@"path"] isEqual:App] && !Only(data)[@"bundle_path"], "bundle-path-table-sid-after-data-path-is-ignored-not-granted");
        data = Fixture(270, NO);
        Text(data, 0x2500, 1, @"com.other.owner");
        Check(Parse(data).count == 0, "conflicting-owner-string-reference-is-omitted");
        data = Fixture(272, NO);
        Word(data, 0x188 + 0x10, 5 << 2);
        Text(data, 0x2500, 5, @"com.owner.one"); Text(data, 0x2600, 5, @"com.owner.two");
        Check(Parse(data).count == 0, "ambiguous-alternate-owner-ref-vetoes-other-layout-position");

        data = Fixture(26, NO);
        Word(data, 0x188 + 0x64, 1 << 2);
        Text(data, 0x1000, 1, App);  
        Check([Only(data)[@"identifier"] isEqual:@"com.example.game"] && [Only(data)[@"path"] isEqual:App],
              "ios26-path-and-general-string-namespaces-overlap-safely");
        data = Fixture(270, NO);
        Text(data, 0x1000, 1, @"com.old.text");
        Check([Only(data)[@"identifier"] isEqual:@"com.example.game"], "general-string-heap-preferred-over-preheap-copy");

        data = Fixture(270, NO);
        Text(data, 0x2400, 4, @"Cafe\u0301 日本\u202Eevil\n");
        Check([Only(data)[@"name"] isEqual:@"Café 日本�evil�"], "names-normalize-and-visibly-replace-control-bidi");
        Text(data, 0x2400, 4, @"/misread/path");
        Check([Only(data)[@"name"] isEqual:@"Bundle title"], "invalid-display-name-falls-back-to-bundle-name");
        Word(data, 0x188 + 0x6c, 0); Word(data, 0x188 + 0x74, 0);
        Check([Only(data)[@"name"] isEqual:@"com.example.game"], "missing-names-fall-back-to-actual-identifier");

        for (NSString *invalid in @[@"/var/mobile/Containers/Shared/AppGroup/11111111-2222-4333-8444-555555555555", @"/var/mobile/Containers/Data/Application/not-a-uuid", [App stringByAppendingString:@"/Documents"], [App stringByAppendingString:@"//"], @"/var/mobile/Containers/Data/Application/../Library"]) {
            data = Fixture(270, NO); Text(data, 0x2200, 2, invalid);
            Check(Parse(data).count == 0, "noncanonical-or-nonapp-path-rejected");
        }
        data = Fixture(270, NO); Text(data, 0x2200, 2, Plugin);
        Check(Parse(data).count == 0, "app-record-cannot-authorize-extension-container");
        data = Fixture(270, YES); Text(data, 0x2200, 2, App);
        Check(Parse(data).count == 0, "extension-record-cannot-authorize-app-container");
        data = Fixture(270, NO); Text(data, 0x2100, 1, @"com..invalid");
        Check(Parse(data).count == 0, "invalid-bundle-components-rejected");

        data = Fixture(270, NO); Word(data, 0x184, 0x258);
        Check(Parse(data) == nil, "unsupported-layout-not-inferred");
        Check(Parse([NSMutableData dataWithLength:4095]) == nil, "minimum-store-size-enforced");
        data = Fixture(270, NO); memcpy(data.mutableBytes, "nope", 4);
        Check(Parse(data) == nil, "wrong-magic-rejected");
        data = [NSMutableData dataWithLength:4096]; memcpy(data.mutableBytes, "bdsl", 4);
        Word(data, 0xf80 + 4, 0x250); Word(data, 0xf88 + 0x0c, 4);
        Check(Parse(data) == nil, "truncated-record-not-read-outside-buffer");
        data = Fixture(270, NO); Word(data, 0x2204, 0xfffffff0);
        Check(Parse(data).count == 0, "oversized-string-length-is-not-followed");
        data = Fixture(270, NO); Word(data, 0x188 + 0x68, 0x7fffffff);
        Check(Parse(data) == nil, "unaligned-or-out-of-range-reference-rejected");
        Check(BQParseLSStore(Fixture(270, NO), ^BOOL { return YES; }, &notice) == nil && notice.length,
              "cancellation-before-parser-work");
        __block NSUInteger polls = 0;
        Check(BQParseLSStore(Fixture(270, NO), ^BOOL { return ++polls > 4; }, &notice) == nil && polls > 4,
              "cancellation-during-parser-passes");
        NSMutableData *tooLarge = [NSMutableData dataWithLength:64 * 1024 * 1024 + 1];
        memcpy(tooLarge.mutableBytes, "bdsl", 4);
        Check(Parse(tooLarge) == nil, "maximum-64mib-store-bound");

        data = [NSMutableData dataWithLength:100001u * (0x258u) + 0x1000u];
        memcpy(data.mutableBytes, "bdsl", 4);
        for (NSUInteger i = 0; i < 100001; i++) Record(data, 0x1000 + i * 0x258, 270, NO, 1, 2);
        Check(Parse(data) == nil, "record-count-bound");
        data = Fixture(270, NO);
        [data setLength:0x5000 + 200001u * 12];
        for (NSUInteger i = 0; i < 200001; i++) Text(data, 0x5000 + i * 12, 4, @"X");
        Check(Parse(data) == nil, "decoded-string-count-bound");
        data = Fixture(270, NO);
        [data setLength:0x5000 + 4300u * 2012];
        NSString *longName = [@"x" stringByPaddingToLength:2000 withString:@"x" startingAtIndex:0];
        for (NSUInteger i = 0; i < 4300; i++) Text(data, 0x5000 + i * 2012, 4, longName);
        Check(Parse(data) == nil, "decoded-string-bytes-bound");
        printf("%lu pure LS store parser checks passed; no device access.\n", (unsigned long)checks);
    }
    return 0;
}
