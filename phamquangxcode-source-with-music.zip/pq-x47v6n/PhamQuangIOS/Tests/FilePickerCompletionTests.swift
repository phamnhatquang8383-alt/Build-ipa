import Foundation

@main struct FilePickerCompletionTests {
    static func main() {
        let url = URL(fileURLWithPath: "/fixture.txt")
        var calls: [URL?] = []
        let delivery: (URL?) -> Void = { calls.append($0) }
        let state = FilePickerCompletion()
        var session = state.begin()
        state.dismiss(session: session, finish: delivery)
        precondition(calls.isEmpty, "Dismissal before delegate must wait")
        state.select(url, session: session, finish: delivery)
        precondition(calls.count == 1 && calls[0] == url, "Late delegate delivers selected file")
        state.dismiss(session: session, finish: delivery)
        state.select(nil, session: session, finish: delivery)
        precondition(calls.count == 1, "Duplicate events cannot clear or redeliver selection")
        session = state.begin()
        state.select(url, session: session, finish: delivery)
        precondition(calls.count == 1, "Selection before dismissal must wait")
        state.dismiss(session: session, finish: delivery)
        precondition(calls.count == 2 && calls[1] == url, "Selection-first order works")
        session = state.begin()
        state.select(nil, session: session, finish: delivery)
        state.dismiss(session: session, finish: delivery)
        precondition(calls.count == 3 && calls[2] == nil, "Cancel delivers nil once")
        session = state.begin()
        state.dismiss(session: session, finish: delivery)
        state.select(nil, session: session, finish: delivery)
        precondition(calls.count == 4 && calls[3] == nil, "Dismiss-before-cancel works")
        session = state.begin()
        state.dismiss(session: session, finish: delivery)
        precondition(calls.count == 4, "Interactive dismissal without delegate must not invent a selection")
        let previous = session
        session = state.begin()
        state.select(url, session: previous, finish: delivery)
        state.dismiss(session: previous, finish: delivery)
        precondition(calls.count == 4, "Late callbacks from old presentation are ignored")
        state.select(url, session: session, finish: delivery)
        state.dismiss(session: session, finish: delivery)
        precondition(calls.count == 5 && calls[4] == url, "Retry after interactive dismiss works")
        session = state.begin()
        state.select(url, session: session) { _ in preconditionFailure("Must wait for dismissal") }
        state.dismiss(session: session) { value in
            precondition(value == url)
            state.select(nil, session: session, finish: delivery)
            state.dismiss(session: session, finish: delivery)
        }
        precondition(calls.count == 5, "Reentrant callbacks cannot redeliver")
        print("File picker completion: 11 checks passed")
    }
}
