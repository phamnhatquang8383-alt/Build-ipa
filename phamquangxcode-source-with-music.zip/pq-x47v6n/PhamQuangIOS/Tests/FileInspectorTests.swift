import Foundation
import SQLite3

@MainActor @main struct FileInspectorTests {
    static var count = 0
    static func check(_ value: @autoclosure () throws -> Bool, _ label: String) rethrows {
        let passed = try value()
        precondition(passed, label); count += 1; print("PASS " + label)
    }
    static func rejects(_ label: String, _ action: () throws -> Void) {
        do { try action(); preconditionFailure(label) } catch { count += 1; print("PASS " + label) }
    }
    static func main() throws {
        let fm = FileManager.default
        let root = fm.temporaryDirectory.appendingPathComponent("inspector-" + UUID().uuidString)
        try fm.createDirectory(at: root, withIntermediateDirectories: true)
        defer { try? fm.removeItem(at: root) }
        let file = root.appendingPathComponent("test.txt")
        try Data("Xin chào\nSATO".utf8).write(to: file)
        let text = try FileTextDocument.load(file, asPlist: false)
        try check(text.text == "Xin chào\nSATO" && text.data(for: text.text) == Data("Xin chào\nSATO".utf8), "utf8-roundtrip")
        try "Một\nhai".data(using: .utf16)!.write(to: file)
        let utf16 = try FileTextDocument.load(file, asPlist: false)
        try check(String(data: utf16.data(for: "Ba"), encoding: .utf16) == "Ba", "utf16-retains-encoding")
        let bigEndian = Data([0xfe, 0xff]) + "Chào".data(using: .utf16BigEndian)!
        try bigEndian.write(to: file)
        let bigText = try FileTextDocument.load(file, asPlist: false)
        try check(bigText.text == "Chào" && bigText.data(for: "Chào") == bigEndian, "utf16-big-endian-bom-retained")
        try Data([0, 1, 2, 3]).write(to: file)
        rejects("binary-not-editable-as-text") { _ = try FileTextDocument.load(file, asPlist: false) }
        try Data(repeating: 65, count: FileTextDocument.maximumBytes + 1).write(to: file)
        rejects("oversize-text-rejected") { _ = try FileTextDocument.load(file, asPlist: false) }
        rejects("oversize-edit-rejected") { _ = try text.data(for: String(repeating: "A", count: FileTextDocument.maximumBytes + 1)) }
        let linked = root.appendingPathComponent("link")
        try fm.createSymbolicLink(at: linked, withDestinationURL: file)
        rejects("editor-rejects-symlink") { _ = try FileTextDocument.load(linked, asPlist: false) }

        for format in [PropertyListSerialization.PropertyListFormat.binary, .xml] {
            let original: [String: Any] = ["name": "SATO", "count": 5, "enabled": true, "array": ["a", "b"]]
            try PropertyListSerialization.data(fromPropertyList: original, format: format, options: 0).write(to: file)
            let loaded = try FileTextDocument.load(file, asPlist: true)
            let edited = try loaded.data(for: loaded.text.replacingOccurrences(of: "SATO", with: "CC365"))
            var resulting = PropertyListSerialization.PropertyListFormat.openStep
            let value = try PropertyListSerialization.propertyList(from: edited, options: [], format: &resulting) as! [String: Any]
            check(resulting == format && value["name"] as? String == "CC365" && value["count"] as? Int == 5, "plist-preserves-format-and-types-\(format.rawValue)")
            rejects("invalid-plist-edit-rejected-\(format.rawValue)") { _ = try loaded.data(for: "not a plist <") }
        }
        let expanding: [String: Any] = ["bytes": Data(repeating: 0, count: 1700 * 1024)]
        try PropertyListSerialization.data(fromPropertyList: expanding, format: .binary, options: 0).write(to: file)
        rejects("binary-plist-expanded-xml-budget") { _ = try FileTextDocument.load(file, asPlist: true) }
        try Data((0..<4100).map { UInt8($0 % 256) }).write(to: file)
        let first = try FileHexPage.load(file, offset: 0), second = try FileHexPage.load(file, offset: 4096)
        check(first.total == 4100 && first.hasNext && first.text.contains("00000000  00 01 02"), "hex-first-page-bounded-addresses")
        check(!second.hasNext && second.text.contains("00001000  00 01 02 03"), "hex-final-page-offset")
        try Data().write(to: file)
        try check(FileHexPage.load(file, offset: 0).text.isEmpty, "hex-empty-file")

        let dbFile = root.appendingPathComponent("database.sqlite")
        var db: OpaquePointer?
        precondition(sqlite3_open(dbFile.path, &db) == SQLITE_OK)
        defer { sqlite3_close(db) }
        precondition(sqlite3_exec(db, "PRAGMA journal_mode=WAL; CREATE TABLE \"odd\"\"name\" (id INTEGER, value TEXT, bytes BLOB);", nil, nil, nil) == SQLITE_OK)
        for i in 0..<52 {
            precondition(sqlite3_exec(db, "INSERT INTO \"odd\"\"name\" VALUES(\(i), 'n\(i)', X'0102');", nil, nil, nil) == SQLITE_OK)
        }
        try check(FileSQLiteReader.tables(dbFile) == ["odd\"name"], "sqlite-wal-includes-live-table")
        let page = try FileSQLiteReader.rows(dbFile, table: "odd\"name", offset: 0)
        check(page.columns == ["id", "value", "bytes"] && page.rows.count == 50 && page.hasNext && page.rows[0][2] == "BLOB · 2 byte", "sqlite-bounded-page-and-blob-label")
        let last = try FileSQLiteReader.rows(dbFile, table: "odd\"name", offset: 50)
        check(last.rows.count == 2 && !last.hasNext, "sqlite-pagination-final")
        rejects("sqlite-injection-rejected") { _ = try FileSQLiteReader.rows(dbFile, table: "odd\"name; DROP TABLE foo; --", offset: 0) }
        rejects("sqlite-negative-offset") { _ = try FileSQLiteReader.rows(dbFile, table: "odd\"name", offset: -1) }
        rejects("sqlite-page-budget") { _ = try FileSQLiteReader.rows(dbFile, table: "odd\"name", offset: 100_001) }
        try Data("not a database".utf8).write(to: file)
        rejects("non-database-rejected") { _ = try FileSQLiteReader.tables(file) }
        let before = try Data(contentsOf: dbFile), wal = dbFile.path + "-wal"
        let walBefore = try Data(contentsOf: URL(fileURLWithPath: wal))
        _ = try FileSQLiteReader.rows(dbFile, table: "odd\"name", offset: 0)
        try check(Data(contentsOf: dbFile) == before && Data(contentsOf: URL(fileURLWithPath: wal)) == walBefore, "sqlite-view-does-not-write-database-or-wal")
        let longName = String(repeating: "x", count: 1100)
        precondition(sqlite3_exec(db, "CREATE TABLE \"\(longName)\" (id INTEGER);", nil, nil, nil) == SQLITE_OK)
        rejects("sqlite-long-name-rejected-instead-of-truncated-id") { _ = try FileSQLiteReader.tables(dbFile) }

        let suite = "cc365-settings-tests-" + UUID().uuidString
        let defaults = UserDefaults(suiteName: suite)!
        defer { defaults.removePersistentDomain(forName: suite) }
        check(FileWorkPreset.automatic.resolved(reducedLoad: false) == AppFileSettings(compressionLevel: 6, workMode: .balanced), "automatic-normal-device-balances-compression")
        check(FileWorkPreset.automatic.resolved(reducedLoad: true) == AppFileSettings(compressionLevel: 1, workMode: .eco), "automatic-reduces-load-on-hot-or-low-power-device")
        let initial = AppFileSettings.load(defaults: defaults)
        check(initial.workMode == .eco || initial.workMode == .balanced, "settings-first-run-automatic-policy")
        defaults.set("eco", forKey: AppFileSettings.workModeKey)
        let snapshot = AppFileSettings.load(defaults: defaults)
        check(snapshot.compressionLevel == 1 && snapshot.workMode.nativeValue == 0, "eco-preset-configures-compression-and-processing-together")
        defaults.set("fast", forKey: AppFileSettings.workModeKey)
        check(AppFileSettings.load(defaults: defaults) == AppFileSettings(compressionLevel: 1, workMode: .fast), "fast-preset-configures-compression-and-processing-together")
        defaults.set("unknown", forKey: AppFileSettings.workModeKey)
        check(AppFileSettings.load(defaults: defaults) == initial && snapshot.workMode == .eco, "settings-invalid-fallback-and-snapshot-stability")
        print("FileInspectorTests: \(count) checks passed")
    }
}
