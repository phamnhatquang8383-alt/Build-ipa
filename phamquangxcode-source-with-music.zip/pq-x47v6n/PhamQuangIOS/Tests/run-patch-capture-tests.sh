#!/bin/bash
set -euo pipefail
cd "$(dirname "$0")/.."
build="${BUILD_DIR:-$PWD/build}"
xcrun --sdk macosx swiftc -swift-version 5 -strict-concurrency=complete -warnings-as-errors -I Vendor/cc365 \
  CC365-Apps/Files/AppFileSettings.swift CC365-Apps/Files/FileTransferSupport.swift CC365-Apps/Files/PatchArchiveCrypto.swift CC365-Apps/Files/AppPatchSource.swift \
  CC365-Apps/Files/PatchCaptureService.swift Tests/PatchCaptureTests.swift \
  "$build/rust/host/debug/libcc365_core.a" -o "$build/Tests/PatchCaptureTests"
"$build/Tests/PatchCaptureTests"
