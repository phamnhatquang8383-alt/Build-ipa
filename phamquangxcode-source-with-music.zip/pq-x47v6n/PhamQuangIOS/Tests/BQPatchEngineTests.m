#define CCBQ_PATCH_TESTING 1
#import <Foundation/Foundation.h>
#import <stdio.h>
static int TestRename(int from, const char *source, int to, const char *destination, unsigned int flags);
#define renameatx_np TestRename
#import "../CC365-Apps/Files/BQCore/CCBQPatchEngine.m"
#undef renameatx_np
static BOOL raceNextSwap;
static BOOL raceNewFileRestore;
static BOOL denyNewFileMoveBack;
static int TestRename(int from, const char *source, int to, const char *destination, unsigned int flags) {
    if (denyNewFileMoveBack && flags == RENAME_EXCL && strncmp(source, ".cc365-", 7) == 0) { errno = EACCES; return -1; }
    if (raceNewFileRestore && flags == RENAME_EXCL && strncmp(destination, ".cc365-", 7) == 0) {
        raceNewFileRestore = NO;
        int fd = openat(from, source, O_WRONLY | O_TRUNC | O_NOFOLLOW);
        if (fd >= 0) { write(fd, "raced-app-data", 14); fsync(fd); close(fd); }
        denyNewFileMoveBack = YES;
    }
    if (raceNextSwap && flags == RENAME_SWAP) {
        raceNextSwap = NO;
        int fd = openat(to, destination, O_WRONLY | O_TRUNC | O_NOFOLLOW);
        if (fd >= 0) { write(fd, "raced-app-data", 14); fsync(fd); close(fd); }
    }
    return renameatx_np(from, source, to, destination, flags);
}
static NSString *supportDirectory;
static NSString *targetDirectory;
static NSString *targetBundle;
static NSString *catalogBundlePath;
static NSString *catalogIdentifier;
static NSString *catalogNotice;
static NSString *catalogDataPath;
static NSArray<BQContainerEntry *> *catalogExtraEntries;
static BOOL catalogOmitTarget;
static NSUInteger directoryOperations;
static NSUInteger catalogCalls;
static NSString *lastCatalogLog;
static NSDictionary *resolvedTarget;
static NSUInteger resolveCalls;
static NSMutableArray<NSString *> *stagedDirectories;
static NSUInteger passed;
void BQLog(NSString *format, ...) {
    va_list arguments; va_start(arguments, format);
    lastCatalogLog = [[NSString alloc] initWithFormat:format arguments:arguments];
    va_end(arguments);
}
NSString *CCBQTestSupportDirectory(void) { return supportDirectory; }
dispatch_queue_t BQWorkQueue(void) { static dispatch_queue_t queue; static dispatch_once_t once; dispatch_once(&once, ^{ queue = dispatch_queue_create("CC365.patch.tests", 0); }); return queue; }
NSString *const CCBQRetrySafeKey = @"CCBQRetrySafe";
@interface BQContainerEntry ()
@property(nonatomic, copy, readwrite) NSString *name;
@property(nonatomic, copy, readwrite) NSString *identifier;
@property(nonatomic, copy, readwrite) NSString *path;
@property(nonatomic, copy, readwrite) NSString *kind;
@property(nonatomic, copy, readwrite, nullable) NSString *bundlePath;
@property(nonatomic, readwrite) BOOL accessRestricted;
@end
@implementation BQContainerEntry
@end
NSArray<BQContainerEntry *> *BQDiscoverContainers(BOOL (^cancelled)(void), NSString **notice) {
    catalogCalls++;
    if (catalogOmitTarget) return catalogExtraEntries ?: @[];
    BQContainerEntry *entry = [BQContainerEntry new]; entry.name = @"Test app"; entry.identifier = catalogIdentifier; entry.path = catalogDataPath ?: targetDirectory; entry.kind = @"app"; entry.bundlePath = catalogBundlePath; return [@[entry] arrayByAddingObjectsFromArray:catalogExtraEntries ?: @[]];
}
NSArray<BQContainerEntry *> *BQDiscoverPatchTargets(BOOL (^cancelled)(void), NSString **notice) {
    if (notice) *notice = catalogNotice;
    return BQDiscoverContainers(cancelled, notice);
}
NSDictionary *BQResolveApplicationTarget(NSString *bundle, BOOL (^cancelled)(void), NSError **error) {
    resolveCalls++;
    if (cancelled && cancelled()) { if (error) *error = [NSError errorWithDomain:NSCocoaErrorDomain code:NSUserCancelledError userInfo:nil]; return nil; }
    if (!resolvedTarget && error) *error = [NSError errorWithDomain:@"CC365.BQResolve" code:1 userInfo:@{NSLocalizedDescriptionKey:@"Fixture lookup unavailable"}];
    return resolvedTarget;
}
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Wincomplete-implementation"
@implementation CCBQFileSystem
+ (BOOL)withDirectory:(NSString *)path progress:(NSProgress *)progress operation:(BOOL (^)(NSString *, NSError **))operation error:(NSError **)error {


    directoryOperations++;
    if ([path isEqual:catalogDataPath]) return operation(targetDirectory, error);
    if ([path hasPrefix:@"/var/mobile/Containers/Data/Application/"]) {
        if (error) *error = [NSError errorWithDomain:NSPOSIXErrorDomain code:ENOENT userInfo:nil];
        return NO;  
    }
    return operation(path, error);
}
@end
#pragma clang diagnostic pop
static void Check(BOOL value, NSString *label) { if (!value) { fprintf(stderr, "FAIL %s\n", label.UTF8String); exit(1); } passed++; fprintf(stdout, "PASS %s\n", label.UTF8String); }
static void Write(NSString *path, NSString *text) { NSError *error; BOOL ok = [text writeToFile:path atomically:YES encoding:NSUTF8StringEncoding error:&error]; if (!ok) { NSLog(@"%@", error); exit(2); } }
static NSString *Read(NSString *relative) { return [NSString stringWithContentsOfFile:[targetDirectory stringByAppendingPathComponent:relative] encoding:NSUTF8StringEncoding error:nil]; }
static NSString *Source(NSString *text) {
    NSString *directory = [[NSTemporaryDirectory() stringByAppendingPathComponent:@"CC365-Files"] stringByAppendingPathComponent:NSUUID.UUID.UUIDString];
    [NSFileManager.defaultManager createDirectoryAtPath:directory withIntermediateDirectories:YES attributes:@{NSFilePosixPermissions:@0700} error:nil];
    [stagedDirectories addObject:directory];
    NSString *path = [directory stringByAppendingPathComponent:@"source.bin"]; Write(path, text); return path;
}
static NSDictionary *Request(NSString *action, NSArray *items) { NSMutableDictionary *r = [@{@"action":action, @"bundle_id":targetBundle, @"patch_scope":@"data", @"expected_root":targetDirectory} mutableCopy]; if (items) r[@"patch_items"] = items; return r; }
static NSDictionary *Item(NSString *relative, NSString *text) { return @{@"relative_path":relative, @"local_path":Source(text)}; }
static NSDictionary *Run(NSString *action, NSArray *items, NSError **error) { return CCPerform(Request(action, items), NSProgress.new, nil, error); }
static void Fresh(NSString *name) {
    catalogBundlePath = nil; catalogNotice = nil;
    catalogDataPath = nil; catalogExtraEntries = nil;
    catalogOmitTarget = NO; directoryOperations = 0; catalogCalls = 0;
    resolvedTarget = nil; resolveCalls = 0;
    targetBundle = [@"com.cc365.test." stringByAppendingString:name];
    catalogIdentifier = targetBundle;
    targetDirectory = [supportDirectory stringByAppendingPathComponent:name];
    for (NSString *relative in @[@"Documents", @"Library/Caches"]) [NSFileManager.defaultManager createDirectoryAtPath:[targetDirectory stringByAppendingPathComponent:relative] withIntermediateDirectories:YES attributes:@{NSFilePosixPermissions:@0700} error:nil];
}
static NSString *Slot(void) { NSError *error; return CCSlotPath(targetBundle, @"data", &error); }
static NSString *HistoryFixture(NSString *identity, NSDictionary *journal) {
    NSError *error = nil;
    NSString *slot = CCSlotPath(identity, journal[@"scope"], &error);
    NSData *data = [NSJSONSerialization dataWithJSONObject:journal options:0 error:&error];
    BOOL ok = slot && data && [data writeToFile:[slot stringByAppendingPathComponent:@"journal.json"] options:0 error:&error];
    if (!ok) { NSLog(@"History fixture: %@", error); exit(2); }
    return slot;
}
static NSDictionary *HistoryRow(NSDictionary *response, NSString *slot) {
    for (NSDictionary *row in response[@"patches"]) if ([row[@"id"] isEqual:slot.lastPathComponent]) return row;
    return nil;
}
int main(void) { @autoreleasepool {
    supportDirectory = [NSTemporaryDirectory() stringByAppendingPathComponent:[@"cc365-patch-tests-" stringByAppendingString:NSUUID.UUID.UUIDString]];
    [NSFileManager.defaultManager createDirectoryAtPath:supportDirectory withIntermediateDirectories:YES attributes:nil error:nil];
    stagedDirectories = [NSMutableArray array];
    NSError *error = nil; NSDictionary *result;
    Fresh(@"roundtrip"); Write([targetDirectory stringByAppendingPathComponent:@"Documents/original.bin"], @"original");
    result = Run(@"apply", @[Item(@"Documents/original.bin", @"replacement"), Item(@"Documents/new.bin", @"new")], &error);
    Check([result[@"state"] isEqual:@"applied"] && !error && [Read(@"Documents/original.bin") isEqual:@"replacement"] && [Read(@"Documents/new.bin") isEqual:@"new"], @"apply-existing-and-new");
    Check([result[@"created"] isEqual:@1] && [result[@"changed"] isEqual:@2], @"receipt-counts");
    result = Run(@"restore", nil, &error);
    Check([result[@"state"] isEqual:@"restored"] && [Read(@"Documents/original.bin") isEqual:@"original"] && !Read(@"Documents/new.bin"), @"restore-original-and-remove-new");
    result = Run(@"restore", nil, &error); Check([result[@"state"] isEqual:@"restored"], @"repeat-restore-idempotent");
    result = Run(@"apply", @[Item(@"Documents/original.bin", @"original")], &error); Check([result[@"state"] isEqual:@"unchanged"] && [result[@"skipped"] isEqual:@1], @"skip-identical-hash");

    Fresh(@"mixedcreator");
    Write([targetDirectory stringByAppendingPathComponent:@"Documents/a"], @"original-doc");
    Write([targetDirectory stringByAppendingPathComponent:@"Library/Caches/b"], @"original-cache");
    error = nil; result = Run(@"apply", @[Item(@"Documents/a", @"new-doc"), Item(@"Library/Caches/b", @"new-cache")], &error);
    Check(!error && [result[@"state"] isEqual:@"applied"] && [Read(@"Documents/a") isEqual:@"new-doc"] && [Read(@"Library/Caches/b") isEqual:@"new-cache"], @"creator-mixed-documents-cache-share-one-transaction");
    error = nil; result = Run(@"restore", nil, &error);
    Check(!error && [result[@"state"] isEqual:@"restored"] && [Read(@"Documents/a") isEqual:@"original-doc"] && [Read(@"Library/Caches/b") isEqual:@"original-cache"], @"creator-mixed-documents-cache-restore-both-originals");
    error = nil; result = Run(@"apply", @[Item(@"Documents/a", @"must-not-write"), Item(@"Library/Caches/missing", @"missing-cache")], &error);
    Check(!result && error && [Read(@"Documents/a") isEqual:@"original-doc"] && !Read(@"Library/Caches/missing"), @"creator-missing-cache-preparation-preserves-documents");

    Fresh(@"reinstall"); Write([targetDirectory stringByAppendingPathComponent:@"Documents/a"], @"first-original");
    error = nil; Run(@"apply", @[Item(@"Documents/a", @"first-patch")], &error); Run(@"restore", nil, &error);
    targetDirectory = [supportDirectory stringByAppendingPathComponent:@"reinstall-new-container"];
    [NSFileManager.defaultManager createDirectoryAtPath:[targetDirectory stringByAppendingPathComponent:@"Documents"] withIntermediateDirectories:YES attributes:nil error:nil];
    Write([targetDirectory stringByAppendingPathComponent:@"Documents/a"], @"new-original");
    error = nil; result = Run(@"apply", @[Item(@"Documents/a", @"new-patch")], &error);
    Check([result[@"state"] isEqual:@"applied"] && !error && [Read(@"Documents/a") isEqual:@"new-patch"], @"fresh-apply-after-restored-app-reinstall");
    error = nil; result = Run(@"restore", nil, &error);
    Check([result[@"state"] isEqual:@"restored"] && [Read(@"Documents/a") isEqual:@"new-original"], @"reinstalled-app-restore-uses-new-backup");

    Fresh(@"conflict"); Write([targetDirectory stringByAppendingPathComponent:@"Documents/a"], @"old");
    Run(@"apply", @[Item(@"Documents/a", @"patch")], &error); Write([targetDirectory stringByAppendingPathComponent:@"Documents/a"], @"app-changed");
    error = nil; result = Run(@"restore", nil, &error); Check(!result && error && [Read(@"Documents/a") isEqual:@"app-changed"], @"restore-preserves-app-changes");
    error = nil; result = Run(@"status", nil, &error); Check([result[@"state"] isEqual:@"applied"], @"conflict-retains-backup-status");
    Write([targetDirectory stringByAppendingPathComponent:@"Documents/a"], @"patch"); error = nil; result = Run(@"restore", nil, &error);
    Check([result[@"state"] isEqual:@"restored"] && [Read(@"Documents/a") isEqual:@"old"], @"restore-after-conflict-can-resume");

    Fresh(@"cancel"); Write([targetDirectory stringByAppendingPathComponent:@"Documents/a"], @"old-a"); Write([targetDirectory stringByAppendingPathComponent:@"Documents/b"], @"old-b");
    NSProgress *progress = NSProgress.new; error = nil;
    result = CCPerform(Request(@"apply", @[Item(@"Documents/a", @"new-a"), Item(@"Documents/b", @"new-b")]), progress, ^(NSDictionary *event) { if ([event[@"phase"] isEqual:@"applied"] && [event[@"done"] isEqual:@1]) [progress cancel]; }, &error);
    Check(!result && error.code == NSUserCancelledError && [Read(@"Documents/a") isEqual:@"new-a"] && [Read(@"Documents/b") isEqual:@"old-b"], @"cancel-after-first-commit-keeps-receipt");
    error = nil; result = Run(@"restore", nil, &error); Check([result[@"state"] isEqual:@"restored"] && [Read(@"Documents/a") isEqual:@"old-a"] && [Read(@"Documents/b") isEqual:@"old-b"], @"restore-partial-apply");

    Fresh(@"partialrestore"); Write([targetDirectory stringByAppendingPathComponent:@"Documents/a"], @"old-a"); Write([targetDirectory stringByAppendingPathComponent:@"Documents/b"], @"old-b");
    error = nil; Run(@"apply", @[Item(@"Documents/a", @"new-a"), Item(@"Documents/b", @"new-b")], &error);
    progress = NSProgress.new; result = CCPerform(Request(@"restore", nil), progress, ^(NSDictionary *event) { if ([event[@"phase"] isEqual:@"restored"] && [event[@"done"] isEqual:@1]) [progress cancel]; }, &error);
    Check(!result && [Read(@"Documents/a") isEqual:@"old-a"] && [Read(@"Documents/b") isEqual:@"new-b"], @"cancel-partial-restore");
    error = nil; result = Run(@"restore", nil, &error); Check([result[@"state"] isEqual:@"restored"] && [Read(@"Documents/b") isEqual:@"old-b"], @"repeat-restore-after-interruption");

    Fresh(@"tamper"); Write([targetDirectory stringByAppendingPathComponent:@"Documents/a"], @"old-a"); Write([targetDirectory stringByAppendingPathComponent:@"Documents/b"], @"old-b");
    error = nil; Run(@"apply", @[Item(@"Documents/a", @"new-a"), Item(@"Documents/b", @"new-b")], &error);
    Write([Slot() stringByAppendingPathComponent:@"original-1"], @"broken"); error = nil; result = Run(@"restore", nil, &error);
    Check(!result && [Read(@"Documents/a") isEqual:@"new-a"] && [Read(@"Documents/b") isEqual:@"new-b"], @"all-backups-validated-before-restore-writes");

    for (NSString *bad in @[@"Documents/../bad", @"/Documents/bad", @"Library/Preferences/bad", @"Documents/.hidden", @"Documents//bad"]) {
        Fresh(NSUUID.UUID.UUIDString); error = nil; result = Run(@"apply", @[Item(bad, @"x")], &error); Check(!result && error, [@"reject-path-" stringByAppendingString:bad]);
    }
    Fresh(@"duplicates"); error = nil; result = Run(@"apply", @[Item(@"Documents/A", @"x"), Item(@"Documents/a", @"y")], &error); Check(!result && error, @"reject-case-folded-duplicate");
    Fresh(@"symlink"); NSString *outside = [supportDirectory stringByAppendingPathComponent:@"outside"]; Write(outside, @"untouched");
    symlink(outside.fileSystemRepresentation, [targetDirectory stringByAppendingPathComponent:@"Documents/link"].fileSystemRepresentation);
    error = nil; result = Run(@"apply", @[Item(@"Documents/link", @"x")], &error); Check(!result && error && [[NSString stringWithContentsOfFile:outside encoding:NSUTF8StringEncoding error:nil] isEqual:@"untouched"], @"reject-symlink-target");
    Fresh(@"symlinkparent"); symlink(supportDirectory.fileSystemRepresentation, [targetDirectory stringByAppendingPathComponent:@"Documents/link"].fileSystemRepresentation);
    error = nil; result = Run(@"apply", @[Item(@"Documents/link/outside", @"x")], &error); Check(!result && error, @"reject-symlink-parent");
    Fresh(@"missingcache"); error = nil; result = Run(@"apply", @[Item(@"Library/Caches/new", @"x")], &error); Check(!result && error, @"reject-new-cache-file");
    Fresh(@"missingsource"); error = nil; result = Run(@"apply", @[@{@"relative_path":@"Documents/a", @"local_path":outside}], &error); Check(!result && error, @"reject-source-outside-private-staging");
    Fresh(@"largesource"); NSString *large = Source(@""); truncate(large.fileSystemRepresentation, CCMaxFile + 1);
    error = nil; result = Run(@"apply", @[@{@"relative_path":@"Documents/a", @"local_path":large}], &error); Check(!result && error && !Read(@"Documents/a"), @"reject-over-limit-before-target-write");
    Fresh(@"staleroot"); NSMutableDictionary *request = [Request(@"apply", @[Item(@"Documents/a", @"x")]) mutableCopy]; request[@"expected_root"] = @"/somewhere-else";
    error = nil; result = CCPerform(request, NSProgress.new, nil, &error); Check(!result && error, @"reject-stale-selected-container");

    Fresh(@"malformed"); Write([Slot() stringByAppendingPathComponent:@"journal.json"], @"{}"); error = nil; result = Run(@"status", nil, &error); Check(!result && error, @"reject-malformed-local-receipt");
    [NSFileManager.defaultManager removeItemAtPath:[Slot() stringByAppendingPathComponent:@"journal.json"] error:nil];
    Fresh(@"applyrace"); Write([targetDirectory stringByAppendingPathComponent:@"Documents/a"], @"original");
    raceNextSwap = YES; error = nil; result = Run(@"apply", @[Item(@"Documents/a", @"patch")], &error);
    Check(!result && error && [Read(@"Documents/a") isEqual:@"raced-app-data"], @"apply-race-returns-displaced-app-data");
    Fresh(@"restorerace"); Write([targetDirectory stringByAppendingPathComponent:@"Documents/a"], @"original");
    error = nil; Run(@"apply", @[Item(@"Documents/a", @"patch")], &error);
    raceNextSwap = YES; error = nil; result = Run(@"restore", nil, &error);
    Check(!result && error && [Read(@"Documents/a") isEqual:@"raced-app-data"], @"restore-race-preserves-new-app-data");

    Fresh(@"interruptedstage"); Write([targetDirectory stringByAppendingPathComponent:@"Documents/a"], @"original");
    error = nil; Run(@"apply", @[Item(@"Documents/a", @"replacement")], &error);
    NSString *slotPath = Slot(); int slotFD = open(slotPath.fileSystemRepresentation, O_RDONLY | O_DIRECTORY);
    NSMutableDictionary *journal = CCLoad(slotFD, targetBundle, @"data", &error);
    NSMutableDictionary *entry = journal[@"entries"][0]; entry[@"state"] = @"armed"; journal[@"state"] = @"pending";
    Write([targetDirectory stringByAppendingPathComponent:@"Documents/a"], @"original");
    NSString *temporaryPath = [[targetDirectory stringByAppendingPathComponent:@"Documents"] stringByAppendingPathComponent:CCTemporary(journal, 0)];
    Write(temporaryPath, @"half"); struct stat staged; lstat(temporaryPath.fileSystemRepresentation, &staged);
    entry[@"temp_device"] = @((unsigned long long)staged.st_dev); entry[@"temp_inode"] = @((unsigned long long)staged.st_ino); entry[@"temp_partial"] = @YES;
    CCSave(slotFD, journal, &error); close(slotFD);
    error = nil; result = Run(@"restore", nil, &error);
    Check([result[@"state"] isEqual:@"restored"] && [Read(@"Documents/a") isEqual:@"original"] && ![NSFileManager.defaultManager fileExistsAtPath:temporaryPath], @"recover-partial-staging-inode-after-crash");

    Fresh(@"publishedinode"); error = nil; Run(@"apply", @[Item(@"Documents/a", @"patch")], &error);
    slotPath = Slot(); slotFD = open(slotPath.fileSystemRepresentation, O_RDONLY | O_DIRECTORY);
    journal = CCLoad(slotFD, targetBundle, @"data", &error); close(slotFD);
    temporaryPath = [[targetDirectory stringByAppendingPathComponent:@"Documents"] stringByAppendingPathComponent:CCTemporary(journal, 0)];
    Check([journal[@"entries"][0][@"temp_partial"] isEqual:@NO], @"partial-stage-ownership-revoked-before-publication");
    raceNewFileRestore = YES; error = nil; result = Run(@"restore", nil, &error); denyNewFileMoveBack = NO;
    Check(!result && !Read(@"Documents/a") && [[NSString stringWithContentsOfFile:temporaryPath encoding:NSUTF8StringEncoding error:nil] isEqual:@"raced-app-data"], @"failed-new-file-moveback-preserves-displaced-data");
    error = nil; result = Run(@"restore", nil, &error);
    Check(!result && error && [[NSString stringWithContentsOfFile:temporaryPath encoding:NSUTF8StringEncoding error:nil] isEqual:@"raced-app-data"], @"restore-retry-never-deletes-modified-published-inode");

    Fresh(@"preparedchanged"); Write([targetDirectory stringByAppendingPathComponent:@"Documents/a"], @"old-a"); Write([targetDirectory stringByAppendingPathComponent:@"Documents/b"], @"old-b");
    progress = NSProgress.new; error = nil;
    CCPerform(Request(@"apply", @[Item(@"Documents/a", @"new-a"), Item(@"Documents/b", @"new-b")]), progress, ^(NSDictionary *event) { if ([event[@"phase"] isEqual:@"applied"]) [progress cancel]; }, &error);
    Write([targetDirectory stringByAppendingPathComponent:@"Documents/b"], @"app-update"); error = nil; result = Run(@"restore", nil, &error);
    Check([result[@"state"] isEqual:@"restored"] && [Read(@"Documents/a") isEqual:@"old-a"] && [Read(@"Documents/b") isEqual:@"app-update"], @"unarmed-entry-never-overwrites-app-update");

    Fresh(@"deniedpreflight"); NSString *documents = [targetDirectory stringByAppendingPathComponent:@"Documents"];
    int rootFD = open(targetDirectory.fileSystemRepresentation, O_RDONLY | O_DIRECTORY);
    chmod(documents.fileSystemRepresentation, 0000); error = nil;
    BOOL ready = CCPreflight(rootFD, @[@{@"relative_path":@"Documents/a"}], &error); chmod(documents.fileSystemRepresentation, 0700);
    Check(!ready && [error.domain isEqual:NSPOSIXErrorDomain] && [error.userInfo[CCBQRetrySafeKey] boolValue], @"child-access-denial-is-safe-for-bq-retry");
    Write([documents stringByAppendingPathComponent:@"a"], @"old"); chmod([documents stringByAppendingPathComponent:@"a"].fileSystemRepresentation, 0000); error = nil;
    ready = CCPreflight(rootFD, @[@{@"relative_path":@"Documents/a"}], &error); chmod([documents stringByAppendingPathComponent:@"a"].fileSystemRepresentation, 0600); close(rootFD);
    Check(!ready && [error.domain isEqual:NSPOSIXErrorDomain] && [error.userInfo[CCBQRetrySafeKey] boolValue], @"target-read-denial-is-safe-for-bq-retry");
    Fresh(@"bundleresource"); catalogBundlePath = targetDirectory;
    Check([CCApps(NSProgress.new, nil).firstObject[@"bundle_path"] isEqual:catalogBundlePath], @"observed-bundle-path-exposed-to-picker");
    Write([targetDirectory stringByAppendingPathComponent:@"resource.dat"], @"old-resource");
    request = [Request(@"apply", @[Item(@"resource.dat", @"new-resource")]) mutableCopy]; request[@"patch_scope"] = @"bundle";
    error = nil; result = CCPerform(request, NSProgress.new, nil, &error);
    Check([result[@"state"] isEqual:@"applied"] && [Read(@"resource.dat") isEqual:@"new-resource"], @"existing-bundle-resource-patch");
    request = [Request(@"restore", nil) mutableCopy]; request[@"patch_scope"] = @"bundle";
    error = nil; result = CCPerform(request, NSProgress.new, nil, &error);
    Check([result[@"state"] isEqual:@"restored"] && [Read(@"resource.dat") isEqual:@"old-resource"], @"bundle-resource-restore");
    Check(!CCDestination(@"Info.plist", @"bundle") && !CCDestination(@"Frameworks/Test", @"bundle") && !CCDestination(@"_CodeSignature/CodeResources", @"bundle"), @"bundle-code-and-signature-paths-protected");
    Fresh(@"unknowncontainer"); catalogIdentifier = @"";
    NSDictionary *unknownApp = CCApps(NSProgress.new, nil).firstObject;
    Check(unknownApp && !unknownApp[@"bundle_id"] && [unknownApp[@"target_id"] isEqual:CCTargetID(targetDirectory)] && [unknownApp[@"name"] hasPrefix:@"Container "], @"picker-includes-unnamed-container-with-honest-path-identity");
    Write([targetDirectory stringByAppendingPathComponent:@"Documents/a"], @"unknown-original");
    request = [Request(@"apply", @[Item(@"Documents/a", @"unknown-patch")]) mutableCopy];
    request[@"target_id"] = unknownApp[@"target_id"]; [request removeObjectForKey:@"bundle_id"];
    error = nil; result = CCPerform(request, NSProgress.new, nil, &error);
    Check([result[@"state"] isEqual:@"applied"] && !error && [Read(@"Documents/a") isEqual:@"unknown-patch"], @"unknown-observed-container-can-apply-patch");
    catalogIdentifier = targetBundle;
    Check([CCApps(NSProgress.new, nil).firstObject[@"target_id"] isEqual:unknownApp[@"target_id"]], @"path-identity-stays-stable-after-bundle-resolution");
    request[@"bundle_id"] = targetBundle; error = nil; result = CCPerform(request, NSProgress.new, nil, &error);
    Check(!result && error && [Read(@"Documents/a") isEqual:@"unknown-patch"], @"resolved-bundle-cannot-overlap-active-path-patch");
    request = [Request(@"status", nil) mutableCopy]; request[@"target_id"] = [@"id:" stringByAppendingString:targetBundle]; [request removeObjectForKey:@"bundle_id"];
    error = nil; result = CCPerform(request, NSProgress.new, nil, &error);
    Check([result[@"state"] isEqual:@"applied"] && !error, @"bundle-id-alias-finds-active-path-receipt");
    error = nil; result = Run(@"restore", nil, &error);
    Check([result[@"state"] isEqual:@"restored"] && [Read(@"Documents/a") isEqual:@"unknown-original"], @"legacy-bundle-request-restores-path-created-backup");

    Fresh(@"legacyreceiptpath"); Write([targetDirectory stringByAppendingPathComponent:@"Documents/a"], @"legacy-original");
    error = nil; Run(@"apply", @[Item(@"Documents/a", @"legacy-patch")], &error);
    slotPath = Slot(); slotFD = open(slotPath.fileSystemRepresentation, O_RDONLY | O_DIRECTORY);
    journal = CCLoad(slotFD, targetBundle, @"data", &error); [journal removeObjectForKey:@"target_id"]; CCSave(slotFD, journal, &error); close(slotFD);
    catalogIdentifier = @"";
    request = [Request(@"status", nil) mutableCopy]; request[@"target_id"] = CCTargetID(targetDirectory); [request removeObjectForKey:@"bundle_id"];
    error = nil; result = CCPerform(request, NSProgress.new, nil, &error);
    Check([result[@"state"] isEqual:@"applied"] && !error, @"path-selector-finds-version1-bundle-keyed-receipt");
    request[@"action"] = @"apply"; request[@"patch_items"] = @[Item(@"Documents/a", @"overlap")];
    error = nil; result = CCPerform(request, NSProgress.new, nil, &error);
    Check(!result && error && [Read(@"Documents/a") isEqual:@"legacy-patch"], @"path-selector-cannot-overlap-legacy-active-backup");
    request[@"action"] = @"restore"; [request removeObjectForKey:@"patch_items"];
    error = nil; result = CCPerform(request, NSProgress.new, nil, &error);
    Check([result[@"state"] isEqual:@"restored"] && [Read(@"Documents/a") isEqual:@"legacy-original"], @"unknown-path-selector-restores-version1-backup");

    Fresh(@"hiddenagain"); Write([targetDirectory stringByAppendingPathComponent:@"Documents/a"], @"original");
    request = [Request(@"apply", @[Item(@"Documents/a", @"patch")]) mutableCopy]; request[@"target_id"] = CCTargetID(targetDirectory);
    error = nil; CCPerform(request, NSProgress.new, nil, &error);
    catalogIdentifier = @""; error = nil; result = Run(@"restore", nil, &error);
    Check([result[@"state"] isEqual:@"restored"] && [Read(@"Documents/a") isEqual:@"original"], @"legacy-id-recovers-path-receipt-when-metadata-becomes-hidden");

    Fresh(@"unobserved"); request = [Request(@"apply", @[Item(@"Documents/a", @"x")]) mutableCopy];
    request[@"target_id"] = CCTargetID([targetDirectory stringByAppendingPathComponent:@"not-observed"]); [request removeObjectForKey:@"bundle_id"];
    error = nil; result = CCPerform(request, NSProgress.new, nil, &error);
    Check(!result && error && !Read(@"Documents/a"), @"reject-path-target-not-in-observed-catalog");
    request[@"target_id"] = CCTargetID(targetDirectory); request[@"bundle_id"] = @"com.some.other.app";
    error = nil; result = CCPerform(request, NSProgress.new, nil, &error);
    Check(!result && error, @"reject-conflicting-observed-bundle-metadata");

    Fresh(@"duplicatealiases"); Write([targetDirectory stringByAppendingPathComponent:@"Documents/a"], @"original");
    error = nil; Run(@"apply", @[Item(@"Documents/a", @"patch")], &error);
    NSString *duplicateSlot = CCSlotPath([@"target:" stringByAppendingString:CCTargetID(targetDirectory)], @"data", &error);
    [NSFileManager.defaultManager removeItemAtPath:duplicateSlot error:nil];
    [NSFileManager.defaultManager copyItemAtPath:Slot() toPath:duplicateSlot error:&error];
    error = nil; result = Run(@"status", nil, &error);
    Check(!result && error && [Read(@"Documents/a") isEqual:@"patch"], @"duplicate-active-alias-receipts-block-unsafe-selection");
    [NSFileManager.defaultManager removeItemAtPath:duplicateSlot error:nil];
    error = nil; result = Run(@"restore", nil, &error); Check([result[@"state"] isEqual:@"restored"], @"remaining-legacy-receipt-still-restorable");

    Fresh(@"pickernotice"); catalogIdentifier = @"";
    catalogNotice = @"The container scan stopped at its time or result limit.\n\nBQCore chưa đọc được metadata của một số container trên thiết bị này.";
    error = nil; result = CCPerform(@{@"action":@"apps"}, NSProgress.new, nil, &error);
    Check([result[@"notice"] containsString:@"giới hạn thời gian"] && [result[@"notice"] containsString:@"BQCore chưa đọc được metadata"] && [result[@"notice"] containsString:@"chưa xác định được bundle ID"], @"picker-response-preserves-localized-partial-and-metadata-notice");
    Check([lastCatalogLog containsString:@"rows=1 identified=0 named=0 unknown=1"] && ![lastCatalogLog containsString:targetDirectory], @"picker-diagnostics-report-displayed-unknown-count-without-paths");
    Fresh(@"pickernonotice"); error = nil; result = CCPerform(@{@"action":@"apps"}, NSProgress.new, nil, &error);
    Check(result && !result[@"notice"], @"picker-notice-omitted-when-no-limit-or-unknown-metadata");
    Check([lastCatalogLog containsString:@"rows=1 identified=1 named=1 unknown=0"] && ![lastCatalogLog containsString:targetBundle] && ![lastCatalogLog containsString:@"Test app"], @"picker-diagnostics-report-name-join-without-identities");
    BQContainerEntry *namedTarget = [BQDiscoverContainers(nil, nil) firstObject];
    namedTarget.name = targetDirectory.lastPathComponent;
    NSDictionary *namedRow = CCAppRows(@[namedTarget]).firstObject;
    Check([namedRow[@"name"] isEqual:targetBundle] && [namedRow[@"target_id"] isEqual:CCTargetID(targetDirectory)], @"known-bundle-does-not-keep-container-uuid-as-title");
    namedTarget.name = @"Ứng dụng đã ghép tên";
    namedRow = CCAppRows(@[namedTarget]).firstObject;
    Check([namedRow[@"name"] isEqual:namedTarget.name] && [namedRow[@"bundle_id"] isEqual:targetBundle] && [namedRow[@"target_id"] isEqual:CCTargetID(targetDirectory)], @"resolved-friendly-name-preserves-bundle-and-path-identity");
    progress = NSProgress.new; [progress cancel]; error = nil;
    result = CCPerform(@{@"action":@"apps"}, progress, nil, &error);
    Check(!result && error.code == NSUserCancelledError, @"cancelled-picker-does-not-publish-stale-results");

    Fresh(@"targetedresolve");
    error = nil; result = CCPerform(@{@"action":@"resolve", @"bundle_id":targetBundle}, NSProgress.new, nil, &error);
    Check([result[@"app"][@"data_path"] isEqual:targetDirectory] && resolveCalls == 0, @"source-bundle-resolves-from-proved-catalog-without-private-query");
    catalogIdentifier = @"";
    resolvedTarget = @{@"target_id":CCTargetID(targetDirectory), @"data_path":targetDirectory, @"bundle_id":targetBundle, @"name":targetBundle};
    error = nil; result = CCPerform(@{@"action":@"resolve", @"bundle_id":targetBundle}, NSProgress.new, nil, &error);
    Check([result[@"app"] isEqual:resolvedTarget] && resolveCalls == 1, @"source-bundle-targeted-lookup-resolves-hidden-metadata");
    NSMutableDictionary *targeted = [Request(@"apply", @[Item(@"Documents/a", @"patch")]) mutableCopy];
    targeted[@"target_id"] = CCTargetID(targetDirectory);
    Write([targetDirectory stringByAppendingPathComponent:@"Documents/a"], @"original");
    error = nil; result = CCPerform(targeted, NSProgress.new, nil, &error);
    Check([result[@"state"] isEqual:@"applied"] && resolveCalls == 2, @"source-target-is-revalidated-before-apply");
    error = nil; result = Run(@"status", nil, &error);
    Check([result[@"state"] isEqual:@"applied"], @"bundle-source-finds-existing-path-receipt");
    resolvedTarget = nil;
    error = nil; result = Run(@"restore", nil, &error);
    Check([result[@"state"] isEqual:@"restored"] && [Read(@"Documents/a") isEqual:@"original"], @"unavailable-lookup-still-restores-exact-observed-receipt-root");
    error = nil; result = CCPerform(targeted, NSProgress.new, nil, &error);
    Check(!result && error && [Read(@"Documents/a") isEqual:@"original"], @"unavailable-bundle-mapping-cannot-authorize-new-apply");
    error = nil; result = CCPerform(@{@"action":@"resolve", @"bundle_id":targetBundle, @"target_id":CCTargetID(targetDirectory)}, NSProgress.new, nil, &error);
    Check(!result && error, @"resolve-cannot-accept-caller-supplied-root");
    resolvedTarget = @{@"target_id":CCTargetID(targetDirectory), @"data_path":targetDirectory, @"bundle_id":@"com.another.app", @"name":@"wrong"};
    error = nil; result = CCPerform(@{@"action":@"resolve", @"bundle_id":targetBundle}, NSProgress.new, nil, &error);
    Check(!result && error, @"resolve-rejects-mismatching-native-identity");
    NSString *changedRoot = [supportDirectory stringByAppendingPathComponent:@"reinstalled-target"];
    resolvedTarget = @{@"target_id":CCTargetID(changedRoot), @"data_path":changedRoot, @"bundle_id":targetBundle, @"name":targetBundle};
    error = nil; result = CCPerform(targeted, NSProgress.new, nil, &error);
    Check(!result && error && [Read(@"Documents/a") isEqual:@"original"], @"targeted-reinstall-mismatch-blocks-stale-path-apply");
    catalogIdentifier = @"com.another.app";
    resolvedTarget = @{@"target_id":CCTargetID(targetDirectory), @"data_path":targetDirectory, @"bundle_id":targetBundle, @"name":targetBundle};
    error = nil; result = CCPerform(@{@"action":@"resolve", @"bundle_id":targetBundle}, NSProgress.new, nil, &error);
    Check(!result && error, @"resolve-rejects-conflicting-observed-root-owner");

    Fresh(@"manualbqonly"); catalogIdentifier = @"";
    Write([targetDirectory stringByAppendingPathComponent:@"Documents/manual.bin"], @"original-manual");
    NSMutableDictionary *manual = [@{@"action":@"apply", @"patch_scope":@"data", @"target_id":CCTargetID(targetDirectory),
        @"expected_root":targetDirectory, @"declared_bundle_id":@"com.observed.owner.a", @"patch_items":@[Item(@"Documents/manual.bin", @"selected-manual")]} mutableCopy];
    error = nil; result = CCPerform(manual, NSProgress.new, nil, &error);
    Check([result[@"state"] isEqual:@"applied"] && !error && resolveCalls == 0 && [Read(@"Documents/manual.bin") isEqual:@"selected-manual"],
        @"BQ-only-explicit-observed-path-applies-without-known-bundle-owner");
    NSString *manualSlot = CCSlotPath([@"target:" stringByAppendingString:manual[@"target_id"]], @"data", &error);
    error = nil; result = CCPerform(@{@"action":@"history"}, NSProgress.new, nil, &error);
    NSDictionary *manualRow = HistoryRow(result, manualSlot);
    Check([manualRow[@"app"][@"target_id"] isEqual:manual[@"target_id"]] && !manualRow[@"app"][@"bundle_id"] &&
        [manualRow[@"app"][@"name"] hasPrefix:@"Container "] && [manualRow[@"status"][@"state"] isEqual:@"applied"] && resolveCalls == 0,
        @"BQ-only-history-retains-observed-root-without-fabricating-archive-owner");
    catalogOmitTarget = YES; manual[@"action"] = @"restore";
    NSUInteger beforeMissingManualRoot = directoryOperations;
    error = nil; result = CCPerform(manual, NSProgress.new, nil, &error);
    Check(!result && error && directoryOperations == beforeMissingManualRoot && [Read(@"Documents/manual.bin") isEqual:@"selected-manual"],
        @"BQ-only-restore-refuses-unobserved-root-before-target-access-and-keeps-backup");
    manual[@"action"] = @"status"; error = nil; result = CCPerform(manual, NSProgress.new, nil, &error);
    Check([result[@"state"] isEqual:@"applied"] && resolveCalls == 0, @"BQ-only-status-remains-readable-when-target-observation-disappears");
    catalogOmitTarget = NO;
    NSMutableDictionary *manualRestore = [manualRow[@"app"] mutableCopy]; manualRestore[@"action"] = @"restore"; manualRestore[@"patch_scope"] = @"data";
    error = nil; result = CCPerform(manualRestore, NSProgress.new, nil, &error);
    Check([result[@"state"] isEqual:@"restored"] && [Read(@"Documents/manual.bin") isEqual:@"original-manual"] && resolveCalls == 0,
        @"BQ-only-saved-path-restores-without-original-source-or-bundle-lookup");
    manual[@"action"] = @"apply"; manual[@"expected_root"] = [targetDirectory stringByAppendingString:@"-other"];
    error = nil; result = CCPerform(manual, NSProgress.new, nil, &error);
    Check(!result && error && [Read(@"Documents/manual.bin") isEqual:@"original-manual"], @"BQ-only-manual-selection-cannot-bypass-expected-root");
    manual[@"expected_root"] = targetDirectory;
    BQContainerEntry *ownerOne = [BQContainerEntry new]; ownerOne.kind = @"app"; ownerOne.path = targetDirectory; ownerOne.name = @"Owner A"; ownerOne.identifier = @"com.observed.owner.a";
    BQContainerEntry *ownerTwo = [BQContainerEntry new]; ownerTwo.kind = @"app"; ownerTwo.path = targetDirectory; ownerTwo.name = @"Owner B"; ownerTwo.identifier = @"com.observed.owner.b";
    catalogExtraEntries = @[ownerOne, ownerTwo];
    error = nil; result = CCPerform(manual, NSProgress.new, nil, &error);
    Check(!result && [error.domain isEqual:@"CC365.BQResolve"] && error.code == 2 && [Read(@"Documents/manual.bin") isEqual:@"original-manual"],
        @"BQ-only-path-selection-rejects-conflicting-known-owners-hidden-after-unknown-row");
    catalogExtraEntries = nil;
    manual[@"declared_bundle_id"] = @"com..invalid";
    NSUInteger beforeDeclaredAccess = directoryOperations, beforeDeclaredCatalog = catalogCalls;
    error = nil; result = CCPerform(manual, NSProgress.new, nil, &error);
    Check(!result && error.code == 2 && directoryOperations == beforeDeclaredAccess && catalogCalls == beforeDeclaredCatalog,
        @"invalid-declared-owner-rejected-before-discovery-or-target-access");
    manual[@"declared_bundle_id"] = @"com.observed.owner.a";
    catalogIdentifier = @"com.observed.owner.b";
    error = nil; result = CCPerform(manual, NSProgress.new, nil, &error);
    Check(!result && [error.domain isEqual:@"CC365.BQResolve"] && error.code == 2 && directoryOperations == beforeDeclaredAccess && resolveCalls == 0 &&
        [Read(@"Documents/manual.bin") isEqual:@"original-manual"], @"previously-unknown-target-becoming-conflicting-owner-blocks-before-target-IO");
    catalogIdentifier = @""; catalogExtraEntries = @[ownerTwo];
    error = nil; result = CCPerform(manual, NSProgress.new, nil, &error);
    Check(!result && error.code == 2 && directoryOperations == beforeDeclaredAccess,
        @"declared-owner-veto-checks-known-duplicate-after-an-unknown-row");
    catalogExtraEntries = nil; catalogIdentifier = @"com.observed.owner.a";
    error = nil; result = CCPerform(manual, NSProgress.new, nil, &error);
    Check([result[@"state"] isEqual:@"applied"] && !error && resolveCalls == 0, @"matching-positive-owner-still-allows-declared-source-apply");
    slotFD = open(manualSlot.fileSystemRepresentation, O_RDONLY | O_DIRECTORY); error = nil;
    NSDictionary *actualOwnerReceipt = CCLoad(slotFD, nil, nil, &error); close(slotFD);
    Check([actualOwnerReceipt[@"bundle"] isEqual:catalogIdentifier] && !actualOwnerReceipt[@"declared_bundle_id"],
        @"receipt-persists-only-native-observed-owner-never-source-claim");
    manual[@"action"] = @"restore"; manual[@"declared_bundle_id"] = @"malformed/ignored-on-restore";
    error = nil; result = CCPerform(manual, NSProgress.new, nil, &error);
    Check([result[@"state"] isEqual:@"restored"] && [Read(@"Documents/manual.bin") isEqual:@"original-manual"],
        @"declared-owner-field-never-alters-existing-restore-semantics");



    NSString *allFixtures = supportDirectory;
    supportDirectory = [allFixtures stringByAppendingPathComponent:@"history-fixtures"];
    [NSFileManager.defaultManager createDirectoryAtPath:supportDirectory withIntermediateDirectories:YES attributes:nil error:nil];
    Fresh(@"history");
    NSString *historyBase = [supportDirectory stringByAppendingPathComponent:@"CC365-BQPatch-v1"];
    error = nil; result = CCPerform(@{@"action":@"history"}, NSProgress.new, nil, &error);
    Check(result && !error && [result[@"patches"] count] == 0 && ![NSFileManager.defaultManager fileExistsAtPath:historyBase] && catalogCalls == 0 && directoryOperations == 0,
        @"empty-history-does-not-create-storage-or-discover-apps");
    Write([targetDirectory stringByAppendingPathComponent:@"Documents/saved.bin"], @"original");
    NSMutableDictionary *historyApply = [Request(@"apply", @[Item(@"Documents/saved.bin", @"patched")]) mutableCopy];
    historyApply[@"app_name"] = @"  Liên Quân Mobile  ";
    error = nil; result = CCPerform(historyApply, NSProgress.new, nil, &error);
    Check([result[@"state"] isEqual:@"applied"] && !error, @"history-fixture-applies-real-transaction");
    NSString *historySlot = Slot();
    slotFD = open(historySlot.fileSystemRepresentation, O_RDONLY | O_DIRECTORY); error = nil;
    NSMutableDictionary *historyJournal = CCLoad(slotFD, nil, nil, &error); close(slotFD);
    Check([historyJournal[@"app_name"] isEqual:@"Liên Quân Mobile"] && [historyJournal[@"updated_at"] doubleValue] > 0,
        @"apply-persists-friendly-name-and-update-time-without-extra-authorization");
    NSData *unchangedReceipt = [NSData dataWithContentsOfFile:[historySlot stringByAppendingPathComponent:@"journal.json"]];
    NSUInteger catalogsBeforeHistory = catalogCalls, directoriesBeforeHistory = directoryOperations, resolvesBeforeHistory = resolveCalls;
    catalogOmitTarget = YES;
    error = nil; result = CCPerform(@{@"action":@"history"}, NSProgress.new, nil, &error);
    NSDictionary *savedRow = HistoryRow(result, historySlot);
    Check([result[@"patches"] count] == 1 && [savedRow[@"app"][@"name"] isEqual:@"Liên Quân Mobile"] && !savedRow[@"app"][@"identity_source"] &&
        [savedRow[@"app"][@"target_id"] isEqual:CCTargetID(targetDirectory)] && [savedRow[@"status"][@"restore_paths"] isEqual:@[@"Documents/saved.bin"]] && [savedRow[@"can_restore"] boolValue],
        @"history-lists-saved-exact-target-without-current-app-catalog");
    Check(catalogCalls == catalogsBeforeHistory && directoryOperations == directoriesBeforeHistory && resolveCalls == resolvesBeforeHistory &&
        [unchangedReceipt isEqual:[NSData dataWithContentsOfFile:[historySlot stringByAppendingPathComponent:@"journal.json"]]],
        @"history-never-calls-catalog-resolver-lease-or-rewrites-receipts");
    catalogOmitTarget = NO;
    NSMutableDictionary *directRestore = [savedRow[@"app"] mutableCopy]; directRestore[@"action"] = @"restore"; directRestore[@"patch_scope"] = savedRow[@"patch_scope"];
    error = nil; result = CCPerform(directRestore, NSProgress.new, nil, &error);
    Check([result[@"state"] isEqual:@"restored"] && [Read(@"Documents/saved.bin") isEqual:@"original"], @"saved-history-target-restores-without-archive-or-picker");
    error = nil; result = CCPerform(@{@"action":@"history"}, NSProgress.new, nil, &error);
    Check([result[@"patches"] count] == 0, @"successfully-restored-receipts-are-omitted-from-active-history");

    Fresh(@"historypending"); Write([targetDirectory stringByAppendingPathComponent:@"Documents/a"], @"old-a"); Write([targetDirectory stringByAppendingPathComponent:@"Documents/b"], @"old-b");
    historyApply = [Request(@"apply", @[Item(@"Documents/a", @"new-a"), Item(@"Documents/b", @"new-b")]) mutableCopy]; historyApply[@"app_name"] = @"Cancelled app";
    progress = NSProgress.new; error = nil;
    CCPerform(historyApply, progress, ^(NSDictionary *event) { if ([event[@"phase"] isEqual:@"applied"]) [progress cancel]; }, &error);
    NSString *pendingSlot = Slot();
    error = nil; result = CCPerform(@{@"action":@"history"}, NSProgress.new, nil, &error);
    Check([HistoryRow(result, pendingSlot)[@"status"][@"state"] isEqual:@"pending"] && [HistoryRow(result, pendingSlot)[@"app"][@"name"] isEqual:@"Cancelled app"],
        @"interrupted-apply-retains-friendly-pending-history-for-direct-restore");

    NSMutableDictionary *legacyHistory = [historyJournal mutableCopy];
    [legacyHistory removeObjectsForKeys:@[@"app_name", @"updated_at", @"target_id"]];
    legacyHistory[@"bundle"] = @"com.cc365.legacy.history"; legacyHistory[@"root"] = @"/var/mobile/Containers/Data/Application/AAAAAAAA-1111-4111-8111-111111111111";
    NSString *oldHistorySlot = HistoryFixture(legacyHistory[@"bundle"], legacyHistory);
    NSMutableDictionary *unknownHistory = [historyJournal mutableCopy]; unknownHistory[@"bundle"] = @"";
    unknownHistory[@"root"] = @"/var/mobile/Containers/Data/Application/BBBBBBBB-1111-4111-8111-111111111111";
    unknownHistory[@"target_id"] = CCTargetID(unknownHistory[@"root"]); unknownHistory[@"app_name"] = @[@"malformed name"];
    unknownHistory[@"skipped"] = @{@"invalid":@YES};
    NSString *unknownSlot = HistoryFixture(@"target:unknown-history", unknownHistory);
    NSMutableDictionary *bundleHistory = [legacyHistory mutableCopy]; bundleHistory[@"scope"] = @"bundle";
    bundleHistory[@"root"] = @"/var/containers/Bundle/Application/CCCCCCCC-1111-4111-8111-111111111111/Example.app";
    NSMutableDictionary *bundleEntry = [bundleHistory[@"entries"][0] mutableCopy]; bundleEntry[@"rel"] = @"assets/saved.bin"; bundleHistory[@"entries"] = @[bundleEntry];
    NSString *bundleHistorySlot = HistoryFixture(bundleHistory[@"bundle"], bundleHistory);
    error = nil; result = CCPerform(@{@"action":@"history"}, NSProgress.new, nil, &error);
    NSDictionary *oldRow = HistoryRow(result, oldHistorySlot), *unknownRow = HistoryRow(result, unknownSlot), *bundleRow = HistoryRow(result, bundleHistorySlot);
    Check([oldRow[@"app"][@"name"] isEqual:legacyHistory[@"bundle"]] && [oldRow[@"app"][@"target_id"] isEqual:CCTargetID(legacyHistory[@"root"])] &&
        !oldRow[@"app"][@"identity_source"] && [oldRow[@"updated_at"] doubleValue] > 0, @"old-bundle-keyed-receipt-has-honest-fallback-and-exact-data-root");
    Check(!unknownRow[@"app"][@"bundle_id"] && !unknownRow[@"app"][@"identity_source"] &&
        [unknownRow[@"app"][@"name"] isEqual:@"Container BBBBBBBB-1111-4111-8111-111111111111"] && [unknownRow[@"status"][@"skipped"] isEqual:@0],
        @"unknown-target-history-never-fabricates-bundle-and-ignores-malformed-display-fields");
    Check([bundleRow[@"patch_scope"] isEqual:@"bundle"] && [bundleRow[@"app"][@"bundle_path"] isEqual:bundleHistory[@"root"]] &&
        !bundleRow[@"app"][@"data_path"] && !bundleRow[@"app"][@"identity_source"] && [bundleRow[@"can_restore"] boolValue] && [oldRow[@"can_restore"] boolValue],
        @"old-bundle-scope-history-keeps-scope-without-fabricating-data-container-or-conflicting-with-data-receipt");

    NSMutableDictionary *duplicateHistory = [unknownHistory mutableCopy]; duplicateHistory[@"bundle"] = @"com.cc365.now.identified";
    NSString *duplicateHistorySlot = HistoryFixture(@"duplicate-history", duplicateHistory);
    error = nil; result = CCPerform(@{@"action":@"history"}, NSProgress.new, nil, &error);
    Check(![HistoryRow(result, duplicateHistorySlot)[@"can_restore"] boolValue] && ![HistoryRow(result, unknownSlot)[@"can_restore"] boolValue] &&
        [HistoryRow(result, unknownSlot)[@"notice"] length] && [HistoryRow(result, oldHistorySlot)[@"can_restore"] boolValue],
        @"same-root-alias-receipts-remain-visible-disabled-without-hiding-unrelated-valid-backups");
    [NSFileManager.defaultManager removeItemAtPath:duplicateHistorySlot error:nil];
    duplicateHistory = [legacyHistory mutableCopy]; duplicateHistory[@"root"] = @"/var/mobile/Containers/Data/Application/DDDDDDDD-1111-4111-8111-111111111111";
    duplicateHistorySlot = HistoryFixture(@"duplicate-owner-history", duplicateHistory);
    error = nil; result = CCPerform(@{@"action":@"history"}, NSProgress.new, nil, &error);
    Check(![HistoryRow(result, duplicateHistorySlot)[@"can_restore"] boolValue] && ![HistoryRow(result, oldHistorySlot)[@"can_restore"] boolValue],
        @"same-bundle-at-different-roots-remains-conflicted-in-history");
    [NSFileManager.defaultManager removeItemAtPath:duplicateHistorySlot error:nil];

    NSString *badHistorySlot = CCSlotPath(@"bad-history", @"data", &error);
    Write([badHistorySlot stringByAppendingPathComponent:@"journal.json"], @"{}");
    error = nil; result = CCPerform(@{@"action":@"history"}, NSProgress.new, nil, &error);
    Check(!error && [result[@"patches"] count] == 4 && [result[@"notice"] length] && ![HistoryRow(result, oldHistorySlot)[@"can_restore"] boolValue] &&
        [[NSString stringWithContentsOfFile:[badHistorySlot stringByAppendingPathComponent:@"journal.json"] encoding:NSUTF8StringEncoding error:nil] isEqual:@"{}"],
        @"malformed-journal-keeps-other-history-visible-and-preserves-all-backups");
    [NSFileManager.defaultManager removeItemAtPath:badHistorySlot error:nil];
    NSString *linkedSlot = CCSlotPath(@"linked-history", @"data", &error);
    symlink([[oldHistorySlot stringByAppendingPathComponent:@"journal.json"] fileSystemRepresentation], [[linkedSlot stringByAppendingPathComponent:@"journal.json"] fileSystemRepresentation]);
    error = nil; result = CCPerform(@{@"action":@"history"}, NSProgress.new, nil, &error);
    Check(!error && [result[@"patches"] count] == 4 && [result[@"notice"] length] && !HistoryRow(result, linkedSlot), @"history-never-follows-journal-symlinks");
    [NSFileManager.defaultManager removeItemAtPath:linkedSlot error:nil];
    linkedSlot = CCSlotPath(@"linked-slot-history", @"data", &error);
    [NSFileManager.defaultManager removeItemAtPath:linkedSlot error:nil]; symlink(oldHistorySlot.fileSystemRepresentation, linkedSlot.fileSystemRepresentation);
    error = nil; result = CCPerform(@{@"action":@"history"}, NSProgress.new, nil, &error);
    Check(!error && [result[@"patches"] count] == 4 && [result[@"notice"] length] && !HistoryRow(result, linkedSlot), @"history-never-follows-slot-symlinks");
    [NSFileManager.defaultManager removeItemAtPath:linkedSlot error:nil];
    badHistorySlot = CCSlotPath(@"oversized-history", @"data", &error);
    int oversizedHistoryFD = open([[badHistorySlot stringByAppendingPathComponent:@"journal.json"] fileSystemRepresentation], O_CREAT | O_WRONLY, 0600);
    ftruncate(oversizedHistoryFD, 4 * 1024 * 1024 + 1); close(oversizedHistoryFD);
    error = nil; result = CCPerform(@{@"action":@"history"}, NSProgress.new, nil, &error);
    Check(!error && [result[@"patches"] count] == 4 && [result[@"notice"] length], @"history-skips-oversized-journal-with-visible-notice");
    [NSFileManager.defaultManager removeItemAtPath:badHistorySlot error:nil];
    progress = NSProgress.new; [progress cancel]; error = nil;
    result = CCPerform(@{@"action":@"history"}, progress, nil, &error);
    Check(!result && error.code == NSUserCancelledError, @"cancelled-history-returns-no-misleading-partial-list");
    error = nil; result = CCPerform(@{@"action":@"history"}, NSProgress.new, nil, &error);
    Check(!error && !result[@"notice"] && [HistoryRow(result, oldHistorySlot)[@"can_restore"] boolValue], @"clean-history-reload-recovers-after-invalid-fixtures-are-removed");
    NSMutableArray *largeHistorySlots = [NSMutableArray array];
    NSString *padding = [@"x" stringByPaddingToLength:4 * 1024 * 1024 - 16384 withString:@"x" startingAtIndex:0];
    for (NSUInteger index = 0; index < 9; index++) {
        NSMutableDictionary *largeHistory = [legacyHistory mutableCopy]; largeHistory[@"padding"] = padding;
        [largeHistorySlots addObject:HistoryFixture([NSString stringWithFormat:@"history-budget-%lu", (unsigned long)index], largeHistory)];
    }
    error = nil; result = CCPerform(@{@"action":@"history"}, NSProgress.new, nil, &error);
    BOOL partialHistoryDisabled = YES;
    for (NSDictionary *row in result[@"patches"]) if ([row[@"can_restore"] boolValue]) partialHistoryDisabled = NO;
    Check(result && !error && [result[@"notice"] containsString:@"Chưa đọc hết"] && partialHistoryDisabled,
        @"history-caps-aggregate-journal-read-and-never-authorizes-partial-conflict-scan");
    for (NSString *largeSlot in largeHistorySlots) [NSFileManager.defaultManager removeItemAtPath:largeSlot error:nil];
    supportDirectory = allFixtures;

    for (NSString *directory in stagedDirectories) [NSFileManager.defaultManager removeItemAtPath:directory error:nil];
    [NSFileManager.defaultManager removeItemAtPath:supportDirectory error:nil];
    printf("%lu patch checks passed.\n", (unsigned long)passed); return 0;
}}
