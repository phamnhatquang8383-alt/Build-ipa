import Foundation
import Darwin

@MainActor @main struct PatchCreationTests {
    static func check(_ condition: Bool, _ label: String) {
        precondition(condition, label)
        print("PASS " + label)
    }
    static func rejected(_ label: String, _ operation: () async throws -> Void) async {
        do { try await operation(); preconditionFailure("Expected rejection: " + label) }
        catch { print("PASS " + label) }
    }
    static func write(_ root: URL, _ name: String, _ bytes: Data = Data("payload".utf8)) throws -> URL {
        let url = root.appendingPathComponent(name)
        try FileManager.default.createDirectory(at: url.deletingLastPathComponent(), withIntermediateDirectories: true)
        try bytes.write(to: url)
        return url
    }
    static func main() async throws {
        let fm = FileManager.default
        let sandbox = fm.temporaryDirectory.appendingPathComponent("creator-" + UUID().uuidString)
        defer { try? fm.removeItem(at: sandbox) }
        try fm.createDirectory(at: sandbox, withIntermediateDirectories: true)
        let library = sandbox.appendingPathComponent("Library")
        let store = PatchCreationStore(root: library)
        var project = try await store.create(name: "  Bộ patch  ", author: "  Người tạo  ")
        check(project.name == "Bộ patch" && project.author == "Người tạo" && project.mappings.isEmpty, "create-trims-metadata-and-persists-empty-draft")
        let initial = try await PatchCreationStore(root: library).project(id: project.id)
        check(initial == project, "reopen-preserves-id-dates-and-metadata")
        await rejected("empty-draft-cannot-export") { _ = try await store.export(projectID: project.id) }

        let source = try write(sandbox, "source.bin", Data([1, 2, 3]))
        project = try await store.importMapping(projectID: project.id, bundleID: "com.example.game",
            destination: "Documents/data.bin", source: source)
        let single = project.mappings[0]
        check(single.fileCount == 1 && single.totalBytes == 3 && !single.isDirectory && single.files[0].relativePath.isEmpty,
              "single-file-uses-exact-destination-not-source-name")
        try Data([9]).write(to: source)
        let metadata = library.appendingPathComponent(project.id.uuidString).appendingPathComponent("project.json")
        let encoded = try String(contentsOf: metadata, encoding: .utf8)
        check(!encoded.contains(source.path) && !encoded.contains("replacementData"), "metadata-stores-private-payload-references-not-source-paths-or-base64")

        let folder = sandbox.appendingPathComponent("folder")
        _ = try write(folder, "en/words.json", Data("hello".utf8))
        _ = try write(folder, "vi/words.json", Data("xin chao".utf8))
        _ = try write(folder, "empty.bin", Data())
        try fm.createDirectory(at: folder.appendingPathComponent("empty-dir"), withIntermediateDirectories: true)
        project = try await store.importMapping(projectID: project.id, bundleID: "com.example.game", destination: "Library/Caches/Locale", source: folder)
        check(project.mappings[1].files.map(\.relativePath) == ["empty.bin", "en/words.json", "vi/words.json"], "folder-preserves-subtree-and-zero-byte-files")
        check(project.fileCount == 4 && project.totalBytes == 16, "combined-file-count-and-bytes")

        let other = try write(sandbox, "other.bin", Data("other".utf8))
        project = try await store.importMapping(projectID: project.id, bundleID: "com.example.other", destination: "Documents/other.bin", source: other)
        let batch = try await store.export(projectID: project.id)
        check(batch.urls.count == 2 && batch.urls.allSatisfy { $0.pathExtension == "zip" }, "multi-owner-project-exports-one-archive-per-owner")
        var exportedOwnerIDs = Set<String>()
        for archive in batch.urls {
            let imported = try await AppPatchSource.stage(archive)
            guard let owner = imported.embeddedBundleID else { preconditionFailure("Missing owner") }
            exportedOwnerIDs.insert(owner)
            if owner == "com.example.game" {
                check(imported.files.count == 4, "export-reimports-documents-and-caches-together")
                let saved = imported.files.first { $0.path == "Documents/data.bin" }!
                check(try Data(contentsOf: saved.local) == Data([1, 2, 3]), "export-uses-immutable-snapshot-after-original-source-changes")
                check(imported.files.first { $0.path.hasSuffix("empty.bin") }?.size == 0, "zero-byte-export-roundtrips")
            }
        }
        check(exportedOwnerIDs == ["com.example.game", "com.example.other"], "all-export-groups-retain-declared-bundle-not-container-uuid")
        let renamedBatch = try await store.export(projectID: project.id, fileExtension: "vailon")
        let header = try Data(contentsOf: renamedBatch.urls[0]).prefix(4)
        check(header == Data([0x50, 0x4b, 0x03, 0x04]), "vailon-is-real-zip-bytes")
        check(try await AppPatchSource.stage(renamedBatch.urls[0]).embeddedBundleID != nil, "vailon-extension-imports-directly-through-current-zip-codec")

        let lastGood = project
        await rejected("duplicate-target-across-mappings") {
            _ = try await store.importMapping(projectID: project.id, bundleID: "com.example.game", destination: "Documents/data.bin", source: source)
        }
        await rejected("case-equivalent-target-collision") {
            _ = try await store.importMapping(projectID: project.id, bundleID: "COM.EXAMPLE.GAME", destination: "Documents/DATA.bin", source: source)
        }
        await rejected("file-parent-target-collision") {
            _ = try await store.importMapping(projectID: project.id, bundleID: "com.example.game", destination: "Documents/data.bin/child", source: source)
        }
        check(try await store.project(id: project.id) == lastGood, "failed-imports-preserve-previous-project-and-snapshots")

        for destination in ["Library/Preferences/a", "Documents", "Documents/../outside", "/Documents/a", "Documents/.hidden", "Documents//file", "Documents/a\\b", "Documents/a\n"] {
            await rejected("reject-invalid-destination-" + destination.debugDescription) {
                _ = try await store.editMapping(projectID: project.id, mappingID: single.id, bundleID: "com.example.game", destination: destination)
            }
        }
        for bundle in ["", "com..example", "../outside", UUID().uuidString] {
            await rejected("reject-invalid-owner-" + bundle) {
                _ = try await store.editMapping(projectID: project.id, mappingID: single.id, bundleID: bundle, destination: "Documents/new.bin")
            }
        }
        project = try await store.editMapping(projectID: project.id, mappingID: single.id, bundleID: "com.example.game", destination: "Documents/renamed.bin")
        check(project.mappings[0].snapshotID == single.snapshotID, "editing-destination-retains-snapshot")
        project = try await store.update(projectID: project.id, name: "Renamed", author: "")
        check(project.id == initial.id && project.createdAt == initial.createdAt && project.author.isEmpty, "editing-project-retains-creation-identity")

        let hidden = try write(sandbox, ".hidden")
        await rejected("hidden-source-file-rejected") { _ = try await store.importMapping(projectID: project.id, bundleID: "com.example.game", destination: "Documents/x", source: hidden) }
        let hiddenFolder = sandbox.appendingPathComponent("hidden-folder")
        _ = try write(hiddenFolder, ".secret")
        await rejected("hidden-child-rejected-not-silently-exported") { _ = try await store.importMapping(projectID: project.id, bundleID: "com.example.game", destination: "Documents/x", source: hiddenFolder) }
        let symlink = sandbox.appendingPathComponent("link")
        try fm.createSymbolicLink(at: symlink, withDestinationURL: source)
        await rejected("source-symlink-rejected") { _ = try await store.importMapping(projectID: project.id, bundleID: "com.example.game", destination: "Documents/x", source: symlink) }
        let ancestorLink = sandbox.appendingPathComponent("folder-link")
        try fm.createSymbolicLink(at: ancestorLink, withDestinationURL: folder)
        await rejected("source-ancestor-symlink-rejected") { _ = try await store.importMapping(projectID: project.id, bundleID: "com.example.game", destination: "Documents/x", source: ancestorLink.appendingPathComponent("empty.bin")) }
        let empty = sandbox.appendingPathComponent("empty-folder")
        try fm.createDirectory(at: empty, withIntermediateDirectories: true)
        await rejected("empty-directory-only-source-rejected") { _ = try await store.importMapping(projectID: project.id, bundleID: "com.example.game", destination: "Documents/x", source: empty) }
        let large = sandbox.appendingPathComponent("large.bin")
        let fd = open(large.path, O_WRONLY | O_CREAT | O_EXCL, 0o600)
        precondition(fd >= 0 && ftruncate(fd, off_t(PatchCreationValidation.maximumFileBytes + 1)) == 0)
        close(fd)
        await rejected("oversized-file-fails-before-copy") { _ = try await store.importMapping(projectID: project.id, bundleID: "com.example.game", destination: "Documents/x", source: large) }
        let beforeReplacement = try await store.project(id: project.id)
        await rejected("failed-replacement-retains-last-good-snapshot") {
            _ = try await store.importMapping(projectID: project.id, bundleID: "com.example.game", destination: "Documents/renamed.bin", source: large, replacing: single.id)
        }
        check(try await store.project(id: project.id) == beforeReplacement, "failed-replacement-does-not-commit-metadata")

        let cancelledProjectID = project.id
        let cancelled = Task {
            withUnsafeCurrentTask { $0?.cancel() }
            return try await store.importMapping(projectID: cancelledProjectID, bundleID: "com.example.game", destination: "Documents/cancelled", source: source)
        }
        await rejected("cancelled-import-does-not-commit") { _ = try await cancelled.value }
        check(try await store.project(id: project.id) == beforeReplacement, "cancelled-import-preserves-last-good-project")
        let cancelledExport = Task {
            withUnsafeCurrentTask { $0?.cancel() }
            return try await store.export(projectID: cancelledProjectID)
        }
        await rejected("cancelled-export-returns-no-partial-batch") { _ = try await cancelledExport.value }

        project = try await store.importMapping(projectID: project.id, bundleID: "com.example.game", destination: "Documents/renamed.bin", source: source, replacing: single.id)
        check(project.mappings[0].id == single.id && project.mappings[0].snapshotID != single.snapshotID && project.mappings[0].totalBytes == 1,
              "successful-replacement-keeps-mapping-id-with-new-snapshot")
        let priorSnapshot = library.appendingPathComponent(project.id.uuidString).appendingPathComponent("snapshots").appendingPathComponent(single.snapshotID.uuidString)
        check(!fm.fileExists(atPath: priorSnapshot.path), "old-snapshot-cleaned-only-after-replacement-commit")
        let removal = project.mappings[1]
        project = try await store.removeMapping(projectID: project.id, mappingID: removal.id)
        check(project.fileCount == 2 && !project.mappings.contains { $0.id == removal.id }, "remove-mapping-updates-durable-project")
        check(try await PatchCreationStore(root: library).project(id: project.id) == project, "edited-project-reopens-with-current-snapshots")
        try await validationCases(project)

        let missing = project.mappings[0]
        let missingPayload = library.appendingPathComponent(project.id.uuidString).appendingPathComponent("snapshots")
            .appendingPathComponent(missing.snapshotID.uuidString).appendingPathComponent(missing.files[0].payloadName)
        try fm.removeItem(at: missingPayload)
        await rejected("missing-snapshot-blocks-export-without-deleting-project") { _ = try await store.export(projectID: project.id) }
        check(try await store.project(id: project.id) == project, "missing-payload-does-not-mutate-metadata")
        try await store.delete(projectID: project.id)
        check(try await store.projects().isEmpty, "delete-removes-own-project")
        check(fm.fileExists(atPath: source.path), "creator-never-modifies-original-source")
        print("PatchCreationTests: persistent snapshots, mappings, limits, cancellation and ZIP roundtrip passed")
    }

    static func validationCases(_ template: PatchCreationProject) async throws {
        var project = template
        let emptyFile = PatchCreationFile(relativePath: "", size: 0, payloadName: UUID().uuidString)
        func mapping(_ path: String, files: [PatchCreationFile] = []) -> PatchCreationMapping {
            PatchCreationMapping(id: UUID(), bundleID: "com.example.game", destination: path, isDirectory: false,
                sourceName: "file", snapshotID: UUID(), files: files.isEmpty ? [emptyFile] : files)
        }
        project.mappings = [mapping("Documents/café"), mapping("Documents/cafe\u{301}")]
        await rejected("unicode-equivalent-target-collision") { try PatchCreationValidation.project(project) }
        project.mappings = [mapping("Documents/a"), mapping("Documents/a/b")]
        await rejected("ancestor-collision-independent-of-order") { try PatchCreationValidation.project(project) }
        project.mappings = (0..<1_025).map { mapping("Documents/\($0)") }
        await rejected("effective-file-count-bounded") { try PatchCreationValidation.project(project) }
        project.mappings = (0..<3).map { index in
            mapping("Documents/\(index)", files: [PatchCreationFile(relativePath: "", size: 100 * 1_024 * 1_024, payloadName: UUID().uuidString)])
        }
        await rejected("aggregate-byte-budget-spans-mappings") { try PatchCreationValidation.project(project) }
        project.mappings = [mapping("Documents/" + String(repeating: "a", count: 1_025))]
        await rejected("destination-path-byte-limit") { try PatchCreationValidation.project(project) }
        project.mappings = [mapping("Documents/" + Array(repeating: "a", count: 32).joined(separator: "/"))]
        await rejected("destination-depth-limit") { try PatchCreationValidation.project(project) }
    }
}
