#!/bin/bash
set -euo pipefail
cd "$(dirname "$0")/.."
diagnostics_build="${BUILD_DIR:-$PWD/build}"
mkdir -p "$diagnostics_build/Tests"
xcrun --sdk macosx swiftc -O -swift-version 5 -strict-concurrency=complete -warnings-as-errors \
  CC365-Apps/Runtime/DiagnosticsReport.swift Tests/DiagnosticsReportTests.swift \
  -o "$diagnostics_build/Tests/DiagnosticsReportTests"
"$diagnostics_build/Tests/DiagnosticsReportTests"
