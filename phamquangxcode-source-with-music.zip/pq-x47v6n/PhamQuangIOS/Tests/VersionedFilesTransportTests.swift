import Foundation

struct PatchInputError: LocalizedError {
    let errorDescription: String?
    init(_ text: String) { errorDescription = text }
}
@MainActor final class DeviceAccessModel {
    static let shared = DeviceAccessModel()
    var mode: DeviceAccessMode = .unsupported
    var allowed = false
    var gateCalls = 0
    func pauseAfterPatch(message: String = "") { }
    func requireDirectAccess() throws {
        gateCalls += 1
        guard mode == .directLegacy && allowed else { throw PatchInputError("Not ready") }
    }
}
@MainActor enum Providers {
    static var calls: [String] = []
    static var failure: String?
    static var events: [String] = []
    static var rejectAirLiftStart = false
    static var cancelAirLift = false
    static var nativeCleanedUp = false
    static func result(_ provider: String, _ request: [String: Any]) throws -> [String: Any] {
        let action = request["action"] as? String ?? ""
        calls.append(provider + ":" + action)
        if failure == provider { throw PatchInputError("Fixture provider failure") }
        switch action {
        case "list": return ["entries": [], "total": 0]
        case "details": return ["name": "fixture", "path": request["path"] ?? "", "kind": "file", "size": 0,
                                "modified": 0, "created": 0, "permissions": "600", "owner": 501, "group": 501, "inode": 1]
        case "check": return ["exactBytesRecovered": true, "cleanupComplete": true, "recoveryOnly": false, "message": "checked"]
        default: return ["bytes": 0, "provider": provider]
        }
    }
    static func native(_ provider: String, _ request: [String: Any], _ completion: @Sendable ([AnyHashable: Any]?, Error?) -> Void) {
        do { completion(try result(provider, request), nil) } catch { completion(nil, error) }
    }
}
@MainActor enum CCBQFileSystem {
    static func perform(request: [String: Any], progress: Progress, completion: @escaping @Sendable ([AnyHashable: Any]?, Error?) -> Void) {
        Providers.native("bq-file", request, completion)
    }
}
@MainActor enum CCBQPatchEngine {
    static func perform(request: [String: Any], progress: Progress, onProgress: @escaping @Sendable ([String: Any]) -> Void,
                        completion: @escaping @Sendable ([AnyHashable: Any]?, Error?) -> Void) {
        Providers.native("bq-patch", request, completion)
    }
}
@MainActor enum VVDirectFileSystem {
    static func perform(request: [String: Any], progress: Progress, completion: @escaping @Sendable ([AnyHashable: Any]?, Error?) -> Void) {
        Providers.native("direct-file", request, completion)
    }
}
@MainActor enum VVDirectPatchEngine {
    static func perform(request: [String: Any], progress: Progress, onProgress: @escaping @Sendable ([String: Any]) -> Void,
                        completion: @escaping @Sendable ([AnyHashable: Any]?, Error?) -> Void) {
        Providers.native("direct-patch", request, completion)
    }
}
@MainActor enum LegacyAirLiftService {
    static func perform(_ request: [String: Any], patch: Bool,
                        onProgress: @escaping @Sendable (RustPatchProgress) -> Void,
                        onCompletion: @MainActor () async -> Void = {}) async throws -> Data {
        if Providers.rejectAirLiftStart { throw PatchInputError("Another job is still cleaning up") }
        Providers.nativeCleanedUp = false
        do {
            if Providers.cancelAirLift { throw CancellationError() }
            let result = try JSONSerialization.data(withJSONObject: Providers.result(patch ? "airlift-patch" : "airlift-file", request))
            Providers.nativeCleanedUp = true
            Providers.events.append("cleaned")
            await onCompletion()
            return result
        } catch {
            Providers.nativeCleanedUp = true
            Providers.events.append("cleaned")
            await onCompletion()
            throw error
        }
    }
}
@MainActor final class LegacyInternalVPN {
    static let shared = LegacyInternalVPN()
    static var calls = 0
    var error: String?
    func disconnectAfterPatch() async {
        precondition(DeviceAccessModel.shared.mode == .airLift && Providers.nativeCleanedUp,
                     "Internal VPN shutdown must only follow AirLift terminal cleanup")
        Self.calls += 1
        Providers.events.append("disable")
    }
}
struct PatchReply: Decodable, Sendable { let provider: String }

@MainActor @main struct VersionedFilesTransportTests {
    static var count = 0
    static let file = URL(fileURLWithPath: "/tmp/fixture.txt")
    static let protected = "/private/var/mobile/Containers/Data/Application/fixture/Documents/file"
    static let workspace = "/CC365/fixture"
    static func expect(_ expected: [String], _ label: String, _ operation: () async throws -> Void) async throws {
        Providers.calls = []
        try await operation()
        precondition(Providers.calls == expected, "\(label): \(Providers.calls), expected \(expected)")
        count += 1
    }
    static func rejectsWithoutProvider(_ label: String, _ operation: () async throws -> Void) async {
        Providers.calls = []
        do { try await operation(); preconditionFailure("Expected refusal: " + label) }
        catch { precondition(Providers.calls.isEmpty, "Refused path must not reach a provider: " + label); count += 1 }
    }
    static func writes(_ root: String) -> [(String, () async throws -> Void)] {
        [("mkdir", { try await VersionedFilesTransport.makeFolder(parent: root, name: "child") }),
         ("import", { _ = try await VersionedFilesTransport.upload(local: file, parent: root, name: "child") }),
         ("delete", { try await VersionedFilesTransport.delete(path: root) }),
         ("move", { try await VersionedFilesTransport.move(path: root, to: root + "-new") }),
         ("importTree", { try await VersionedFilesTransport.uploadTree(local: file, to: root) }),
         ("replace", { try await VersionedFilesTransport.replace(local: file, path: root, expected: file) })]
    }
    static func readAndPatch(_ fileProvider: String, _ patchProvider: String, _ root: String) async throws {
        try await expect([fileProvider + ":list"], "list") { _ = try await VersionedFilesTransport.list(path: root, offset: 0) }
        try await expect([fileProvider + ":details"], "details") { _ = try await VersionedFilesTransport.details(path: root) }
        try await expect([fileProvider + ":download"], "download") { try await VersionedFilesTransport.download(path: root, to: file) }
        try await expect([patchProvider + ":apply"], "patch") {
            let result = try await VersionedFilesTransport.patch("apply", fields: ["path": root], as: PatchReply.self)
            precondition(result.provider == patchProvider)
        }
    }
    static func main() async throws {
        let access = DeviceAccessModel.shared
        access.mode = .bqCore
        access.allowed = false
        try await readAndPatch("bq-file", "bq-patch", protected)
        for (action, operation) in writes(protected) { try await expect(["bq-file:" + action], "modern " + action, operation) }
        try await expect(["bq-file:ensureWorkspace"], "modern workspace") { try await VersionedFilesTransport.ensureWorkspace() }
        try await expect(["bq-file:check"], "modern access check") { _ = try await VersionedFilesTransport.checkAccess() }
        precondition(access.gateCalls == 0, "Modern calls must not consult the legacy readiness gate")
        precondition(LegacyInternalVPN.calls == 0, "Modern calls must never change the internal VPN")
        count += 1

        access.mode = .directLegacy
        access.allowed = true
        try await readAndPatch("direct-file", "direct-patch", protected)
        access.mode = .airLift
        try await readAndPatch("airlift-file", "airlift-patch", protected)

        for mode in [DeviceAccessMode.directLegacy, .airLift, .unsupported] {
            access.mode = mode
            for (action, operation) in writes(protected) {
                await rejectsWithoutProvider("\(mode) protected " + action, operation)
            }
            await rejectsWithoutProvider("\(mode) move local to protected") {
                try await VersionedFilesTransport.move(path: workspace, to: protected)
            }
            await rejectsWithoutProvider("\(mode) move protected to local") {
                try await VersionedFilesTransport.move(path: protected, to: workspace)
            }
            await rejectsWithoutProvider("\(mode) workspace prefix lookalike") {
                try await VersionedFilesTransport.delete(path: "/CC365-other/file")
            }
            for (action, operation) in writes(workspace) { try await expect(["bq-file:" + action], "local " + action, operation) }
            try await expect(["bq-file:list"], "local list") { _ = try await VersionedFilesTransport.list(path: workspace, offset: 0) }
            try await expect(["bq-file:details"], "local details") { _ = try await VersionedFilesTransport.details(path: workspace) }
            try await expect(["bq-file:download"], "local download") { try await VersionedFilesTransport.download(path: workspace, to: file) }
            try await expect(["bq-file:ensureWorkspace"], "local workspace") { try await VersionedFilesTransport.ensureWorkspace() }
            try await expect(["direct-file:check"], "local access check never enters BQ catalog") { _ = try await VersionedFilesTransport.checkAccess() }
        }
        for mode in [DeviceAccessMode.directLegacy, .unsupported] {
            access.mode = mode; access.allowed = false
            await rejectsWithoutProvider("\(mode) denied list") { _ = try await VersionedFilesTransport.list(path: protected, offset: 0) }
            await rejectsWithoutProvider("\(mode) denied details") { _ = try await VersionedFilesTransport.details(path: protected) }
            await rejectsWithoutProvider("\(mode) denied download") { try await VersionedFilesTransport.download(path: protected, to: file) }
            await rejectsWithoutProvider("\(mode) denied patch") { _ = try await VersionedFilesTransport.patch("apply", as: PatchReply.self) }
            try await expect(["direct-file:list"], "root metadata avoids BQ") { _ = try await VersionedFilesTransport.list(path: "/", offset: 0) }
            try await expect(["direct-patch:history"], "history metadata avoids BQ") { _ = try await VersionedFilesTransport.patch("history", as: PatchReply.self) }
        }
        for (mode, provider) in [(DeviceAccessMode.bqCore, "bq-file"), (.directLegacy, "direct-file"), (.airLift, "airlift-file")] {
            access.mode = mode; access.allowed = true; Providers.failure = provider; Providers.calls = []
            do { _ = try await VersionedFilesTransport.list(path: protected, offset: 0); preconditionFailure("Expected provider failure") }
            catch { precondition(Providers.calls == [provider + ":list"], "Provider failure must never fall back to a different backend"); count += 1 }
        }
        access.mode = .airLift
        for action in ["apply", "restore"] {
            for outcome in ["success", "failure", "cancel"] {
                Providers.events = []
                Providers.failure = outcome == "failure" ? "airlift-patch" : nil
                Providers.cancelAirLift = outcome == "cancel"
                do { _ = try await VersionedFilesTransport.patch(action, as: PatchReply.self) }
                catch { precondition(outcome != "success") }
                precondition(Providers.events == ["cleaned", "disable"], "\(action) \(outcome): disable only after cleanup")
                count += 1
            }
        }
        Providers.failure = nil; Providers.cancelAirLift = false
        for action in ["status", "history", "apps", "resolve"] {
            Providers.events = []
            _ = try await VersionedFilesTransport.patch(action, as: PatchReply.self)
            precondition(Providers.events == ["cleaned"], "Read-only actions must not turn off the internal VPN")
            count += 1
        }
        Providers.rejectAirLiftStart = true; Providers.events = []
        do { _ = try await VersionedFilesTransport.patch("apply", as: PatchReply.self); preconditionFailure("Expected start rejection") }
        catch { precondition(Providers.events.isEmpty, "Rejected starts must not disable another job's VPN"); count += 1 }
        print("Versioned transport isolation: \(count) checks passed")
    }
}
