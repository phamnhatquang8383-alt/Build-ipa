#!/bin/bash
set -euo pipefail
root="$(cd "$(dirname "$0")/.." && pwd)"
output="$root/build/Tests/LegacyAirLiftService"
mkdir -p "$output"
xcrun --sdk macosx clang -I "$root/Vendor/legacy-airlift" -c "$root/Tests/LegacyAirLift/BridgeStub.c" -o "$output/bridge.o"
xcrun --sdk macosx swiftc -O -swift-version 5 -strict-concurrency=complete -warnings-as-errors \
 -I "$root/Vendor/legacy-airlift" "$root/CC365-Apps/Platform/RustCore.swift" \
 "$root/CC365-Apps/Runtime/LegacyAirLiftService.swift" "$root/Tests/LegacyAirLift/ServiceTests.swift" \
 "$output/bridge.o" -o "$output/checks"
"$output/checks"
