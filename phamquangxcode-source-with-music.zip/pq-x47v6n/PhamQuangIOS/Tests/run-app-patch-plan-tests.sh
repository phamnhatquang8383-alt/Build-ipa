#!/bin/bash
set -euo pipefail
cd "$(dirname "$0")/.."
plan_build="${BUILD_DIR:-$PWD/build}"
mkdir -p "$plan_build/Tests"
xcrun --sdk macosx swiftc -swift-version 5 -strict-concurrency=complete -warnings-as-errors \
  -I Vendor/cc365 CC365-Apps/Files/FileTransferSupport.swift \
  CC365-Apps/Files/AppFileSettings.swift CC365-Apps/Files/PatchArchiveCrypto.swift CC365-Apps/Files/AppPatchSource.swift CC365-Apps/Files/AppPatchPlan.swift \
  Tests/AppPatchPlanTests.swift "$plan_build/rust/host/debug/libcc365_core.a" \
  -o "$plan_build/Tests/AppPatchPlanTests"
"$plan_build/Tests/AppPatchPlanTests"
