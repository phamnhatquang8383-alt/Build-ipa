#import <Foundation/Foundation.h>
#import <dirent.h>
#import <errno.h>
#import <fcntl.h>
#import <sys/stat.h>
#import <unistd.h>
#import "BQCore.h"
#import "BQLSStoreParser.h"

static NSString *fixture, *physicalRoot, *physicalStore, *logicalStore;
static NSArray *discovered;
static NSMutableArray<NSString *> *logs;
static BOOL denyDirect, listDirect, denyLeasedRead, leaseFail, badLeasePath, cancelledFlag, cancelOnLease;
static BOOL growOnRead, changeDuringParse, replaceDuringParse, throwDuringParse, denyRealpath, emptyParse, firstParseEmpty;
static int scans, acquires, releases, active, parses, sourceFD = -1, checks;
static NSString *const logicalRoot = @"/private/var/mobile/Containers/Data/InternalDaemon";
static void Check(BOOL passed, NSString *name) { checks++; if (!passed) { NSLog(@"FAIL %@ logs=%@", name, logs); exit(1); } }

static NSString *Map(NSString *path) {
    return [path hasPrefix:logicalRoot] ? [physicalRoot stringByAppendingString:[path substringFromIndex:logicalRoot.length]] : path;
}
static int fixture_open(const char *bytes, int flags, ...) {
    NSString *path = [NSString stringWithUTF8String:bytes];
    if ([path hasPrefix:logicalRoot] && (denyDirect || ([path isEqual:logicalRoot] && !listDirect))) { errno = EPERM; return -1; }
    return open(Map(path).fileSystemRepresentation, flags);
}
static int fixture_openat(int dir, const char *name, int flags, ...) {
    if (active && denyLeasedRead) { errno = EPERM; return -1; }
    int fd = openat(dir, name, flags);
    if (fd >= 0 && strstr(name, ".csstore")) sourceFD = fd;
    return fd;
}
static char *fixture_realpath(const char *bytes, char *resolved) {
    if (denyRealpath) { errno = EPERM; return NULL; }
    char *actual = realpath(bytes, NULL);
    if (!actual) return NULL;
    NSString *path = [NSString stringWithUTF8String:actual]; free(actual);
    if ([path hasPrefix:physicalRoot]) path = [logicalRoot stringByAppendingString:[path substringFromIndex:physicalRoot.length]];
    if (resolved) { strcpy(resolved, path.fileSystemRepresentation); return resolved; }
    return strdup(path.fileSystemRepresentation);
}
static ssize_t fixture_readlinkat(int directory, const char *name, char *buffer, size_t size) {
    char bytes[PATH_MAX];
    ssize_t count = readlinkat(directory, name, bytes, sizeof(bytes));
    if (count <= 0) return count;
    NSString *path = [[NSString alloc] initWithBytes:bytes length:(NSUInteger)count encoding:NSUTF8StringEncoding];
    if ([path hasPrefix:physicalRoot]) path = [logicalRoot stringByAppendingString:[path substringFromIndex:physicalRoot.length]];
    NSData *data = [path dataUsingEncoding:NSUTF8StringEncoding];
    count = (ssize_t)MIN(data.length, size); memcpy(buffer, data.bytes, (size_t)count); return count;
}
static ssize_t fixture_read(int fd, void *buffer, size_t count) {
    ssize_t got = read(fd, buffer, count);
    if (fd == sourceFD && growOnRead && got > 0) {
        growOnRead = NO;
        int writer = open(physicalStore.fileSystemRepresentation, O_WRONLY | O_APPEND);
        write(writer, "changed", 7); close(writer);
    }
    return got;
}

void BQLog(NSString *format, ...) {
    va_list args; va_start(args, format);
    [logs addObject:[[NSString alloc] initWithFormat:format arguments:args]];
    va_end(args);
}
NSArray<NSString *> *BQDiscoverLSStorePaths(NSTimeInterval time, NSUInteger limit, BOOL (^cancelled)(void), BOOL *stopped, NSString **error) {
    scans++; (void)stopped; (void)error;
    Check(time > 0 && time <= 8 && limit <= 4, @"discovery bounded");
    return cancelled && cancelled() ? @[] : discovered;
}
int64_t BQEscape(NSString *target, NSString **accessible) {
    acquires++;
    Check(active == 0, @"no nested lease");
    Check([target isEqual:logicalStore.stringByDeletingLastPathComponent], @"lease exact observed cache folder");
    if (leaseFail) return -5;
    active++; if (cancelOnLease) cancelledFlag = YES;
    NSString *link = [fixture stringByAppendingPathComponent:@"lease"];
    unlink(link.fileSystemRepresentation);
    NSString *destination = badLeasePath ? fixture : physicalStore.stringByDeletingLastPathComponent;
    Check(symlink(destination.fileSystemRepresentation, link.fileSystemRepresentation) == 0, @"fixture lease link created");
    *accessible = link; return 12;
}
void BQEndEscape(int64_t handle) {
    Check(handle == 12 && active == 1, @"releases exact owned lease");
    releases++; active--;
    unlink([fixture stringByAppendingPathComponent:@"lease"].fileSystemRepresentation);
}
NSArray<NSDictionary *> *BQParseLSStore(NSData *data, BOOL (^cancelled)(void), NSString **notice) {
    parses++; if (notice) *notice = nil;
    if (throwDuringParse) [NSException raise:@"Fixture" format:@"parse exception"];
    if (cancelled && cancelled()) return nil;
    if (data.length < 4096 || memcmp(data.bytes, "bdsl", 4)) return nil;
    if (emptyParse || (firstParseEmpty && parses == 1)) return @[];
    if (changeDuringParse) {
        int fd = open(physicalStore.fileSystemRepresentation, O_WRONLY); pwrite(fd, "changed", 7, 100); close(fd);
    }
    if (replaceDuringParse) {
        NSString *other = [fixture stringByAppendingPathComponent:@"replacement"];
        [data writeToFile:other atomically:NO];
        rename(other.fileSystemRepresentation, physicalStore.fileSystemRepresentation);
    }
    return @[@{@"path":@"/var/mobile/Containers/Data/Application/11111111-2222-3333-4444-555555555555", @"identifier":@"com.example.private", @"name":@"Sensitive app name", @"kind":@"app", @"source":@"csstore"}];
}

#define open fixture_open
#define openat fixture_openat
#define realpath fixture_realpath
#define readlinkat fixture_readlinkat
#define read fixture_read
#include "../CC365-Apps/Files/BQCore/BQLSApplicationCatalog.m"
#undef open
#undef openat
#undef realpath
#undef readlinkat
#undef read

static void Reset(void) {
    BQLSRetryAfter = 0; BQLSLastNotice = nil;
    [NSUserDefaults.standardUserDefaults removeObjectForKey:BQLSPathKey];
    denyDirect = listDirect = denyLeasedRead = leaseFail = badLeasePath = cancelledFlag = cancelOnLease = NO;
    growOnRead = changeDuringParse = replaceDuringParse = throwDuringParse = denyRealpath = emptyParse = firstParseEmpty = NO;
    scans = acquires = releases = parses = 0; sourceFD = -1;
    discovered = @[]; logs = [NSMutableArray new];
    NSMutableData *data = [NSMutableData dataWithLength:8192]; memcpy(data.mutableBytes, "bdsl", 4);
    [NSFileManager.defaultManager removeItemAtPath:physicalStore error:nil];
    Check([data writeToFile:physicalStore atomically:NO], @"fixture store created");
}
static NSArray *Read(NSString **notice) { return BQReadLSApplicationRecords(^BOOL { return cancelledFlag; }, notice); }
static void Remember(void) { [NSUserDefaults.standardUserDefaults setObject:logicalStore forKey:BQLSPathKey]; }

int main(void) {
    @autoreleasepool {
        id old = [NSUserDefaults.standardUserDefaults objectForKey:BQLSPathKey];
        char *temporary = realpath(NSTemporaryDirectory().fileSystemRepresentation, NULL);
        fixture = [[NSString stringWithUTF8String:temporary] stringByAppendingPathComponent:[@"BQLSProvider-" stringByAppendingString:NSUUID.UUID.UUIDString]];
        free(temporary);
        physicalRoot = [fixture stringByAppendingPathComponent:@"daemons"];
        NSString *relative = @"AAAAAAAA-BBBB-CCCC-DDDD-EEEEEEEEEEEE/Library/Caches/com.apple.LaunchServices-test.csstore";
        logicalStore = [logicalRoot stringByAppendingPathComponent:relative];
        physicalStore = [physicalRoot stringByAppendingPathComponent:relative];
        [NSFileManager.defaultManager createDirectoryAtPath:physicalStore.stringByDeletingLastPathComponent withIntermediateDirectories:YES attributes:nil error:nil];
        @try {
            NSString *notice = nil;
            Reset(); Remember();
            Check(Read(&notice).count == 1 && !notice, @"cached exact path direct read");
            Check(acquires == 0 && scans == 0 && parses == 1, @"direct read does not lease or scan");
            Check([[NSUserDefaults.standardUserDefaults stringForKey:BQLSPathKey] isEqual:logicalStore], @"persists validated successful path");

            Reset(); listDirect = YES;
            Check(Read(&notice).count == 1 && scans == 0, @"direct daemon listing discovers exact cache file");
            Reset(); discovered = @[logicalStore];
            Check(Read(&notice).count == 1 && scans == 1, @"bounded observed path fallback");
            Reset(); Remember(); emptyParse = YES;
            Check(Read(&notice).count == 0 && scans == 1, @"empty parser result continues bounded discovery");
            Check([NSUserDefaults.standardUserDefaults objectForKey:BQLSPathKey] == nil && [notice containsString:@"xác nhận"], @"empty parser result is not cached as successful catalog");
            Reset(); Remember(); firstParseEmpty = YES;
            NSString *otherLogical = [logicalStore stringByReplacingOccurrencesOfString:@"-test.csstore" withString:@"-other.csstore"];
            NSString *otherPhysical = Map(otherLogical);
            [NSFileManager.defaultManager copyItemAtPath:physicalStore toPath:otherPhysical error:nil];
            discovered = @[otherLogical];
            Check(Read(&notice).count == 1 && parses == 2, @"empty cached store does not hide later usable candidate");
            Check([[NSUserDefaults.standardUserDefaults stringForKey:BQLSPathKey] isEqual:otherLogical], @"only useful fallback candidate cached");
            [NSFileManager.defaultManager removeItemAtPath:otherPhysical error:nil];

            Reset(); Remember(); denyDirect = YES;
            Check(Read(&notice).count == 1, @"permission failure retries existing lease");
            Check(acquires == 1 && releases == 1 && active == 0, @"successful lease always released");
            NSString *joined = [logs componentsJoinedByString:@"\n"];
            Check(![joined containsString:@"com.example"] && ![joined containsString:@"Sensitive"] && ![joined containsString:@"AAAAAAAA"] && ![joined containsString:@"/var/"], @"logs contain counters only");
            Reset(); Remember(); denyDirect = YES; denyRealpath = YES;
            Check(Read(&notice).count == 1 && releases == 1, @"exact BQ alias works when original realpath denied");
            Reset(); Remember(); denyDirect = YES; denyRealpath = YES; badLeasePath = YES;
            Check(Read(&notice).count == 0 && releases == 1, @"readlink fallback rejects a different target");

            Reset(); Remember(); denyDirect = YES; denyLeasedRead = YES;
            Check(Read(&notice).count == 0 && [notice containsString:@"iOS"], @"grant without read permission is honest failure");
            Check(releases == 1 && active == 0, @"denied read releases lease");
            int previousScans = scans, previousLeases = acquires;
            Check(Read(&notice).count == 0 && scans == previousScans && acquires == previousLeases, @"failure backoff avoids repeat scan");
            BQLSRetryAfter = 0; denyDirect = NO; denyLeasedRead = NO; Remember();
            Check(Read(&notice).count == 1, @"later retry can succeed");

            Reset(); Remember(); Check(Read(&notice).count == 1, @"first snapshot available");
            denyDirect = YES; leaseFail = YES;
            Check(Read(&notice).count == 0, @"unreadable refresh never reuses old identities");
            Check([NSUserDefaults.standardUserDefaults objectForKey:BQLSPathKey] == nil, @"unreadable cached path removed");

            for (NSString *bad in @[@"/tmp/com.apple.LaunchServices-a.csstore", [logicalStore stringByReplacingOccurrencesOfString:@"Library/Caches" withString:@"Library/../Caches"], [logicalStore stringByReplacingOccurrencesOfString:@"AAAAAAAA-BBBB-CCCC-DDDD-EEEEEEEEEEEE" withString:@"not-a-uuid"]]) {
                Reset(); [NSUserDefaults.standardUserDefaults setObject:bad forKey:BQLSPathKey];
                Check(Read(&notice).count == 0 && acquires == 0 && parses == 0, @"malformed cached path never read or leased");
                Check([NSUserDefaults.standardUserDefaults objectForKey:BQLSPathKey] == nil, @"malformed cache removed");
            }
            Reset(); Remember(); growOnRead = YES;
            Check(Read(&notice).count == 0, @"growth during read discarded");
            Reset(); Remember(); changeDuringParse = YES;
            Check(Read(&notice).count == 0, @"same-inode modification during parse discarded");
            Reset(); Remember(); replaceDuringParse = YES;
            Check(Read(&notice).count == 0, @"namespace replacement during parse discarded");

            Reset(); Remember(); denyDirect = YES; badLeasePath = YES;
            Check(Read(&notice).count == 0 && releases == 1, @"wrong leased ancestor rejected and released");
            Reset(); Remember(); denyDirect = YES; throwDuringParse = YES;
            Check(Read(&notice).count == 0 && releases == 1 && active == 0, @"exception closes file and releases lease");
            Reset(); Remember(); denyDirect = YES; cancelOnLease = YES;
            Check(Read(&notice).count == 0 && releases == 1 && parses == 0 && active == 0, @"cancel after acquisition releases without reading");
            Reset(); Remember(); cancelledFlag = YES;
            Check(Read(&notice).count == 0 && parses == 0 && acquires == 0 && scans == 0, @"pre-cancelled request does no work");

            Reset(); Remember();
            [NSFileManager.defaultManager removeItemAtPath:physicalStore error:nil];
            NSString *outside = [fixture stringByAppendingPathComponent:@"outside"];
            [[NSMutableData dataWithLength:8192] writeToFile:outside atomically:NO];
            symlink(outside.fileSystemRepresentation, physicalStore.fileSystemRepresentation);
            Check(Read(&notice).count == 0 && parses == 0 && acquires == 0, @"database symlink never followed");
            Reset(); Remember();
            int oversized = open(physicalStore.fileSystemRepresentation, O_WRONLY); ftruncate(oversized, (off_t)BQLSMaxBytes + 1); close(oversized);
            Check(Read(&notice).count == 0 && parses == 0, @"oversized database never parsed");
            printf("BQLSApplicationCatalogTests: %d checks passed\n", checks);
        } @finally {
            [NSFileManager.defaultManager removeItemAtPath:fixture error:nil];
            if (old) [NSUserDefaults.standardUserDefaults setObject:old forKey:BQLSPathKey];
            else [NSUserDefaults.standardUserDefaults removeObjectForKey:BQLSPathKey];
        }
    }
    return 0;
}
