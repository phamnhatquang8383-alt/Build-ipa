import Foundation

struct DeviceFileEntry: Sendable {
    let name: String
    let kind: String
    let size: UInt64?
    var path: String? = nil
}
struct DeviceFilesPage: Sendable {
    let entries: [DeviceFileEntry]
    let nextOffset: Int?
    var notice: String? = nil
}
@MainActor enum VersionedFilesTransport {
    static var pages: [String: DeviceFilesPage] = [:]
    static var payloads: [String: Data] = [:]
    static var downloads = 0
    static var apps = Data("{\"apps\":[]}".utf8)
    static func list(path: String, offset: Int) async throws -> DeviceFilesPage {
        guard let page = pages[path + ":" + String(offset)] else { throw PatchInputError("Missing fixture page") }
        return page
    }
    static func download(path: String, to local: URL) async throws {
        downloads += 1
        guard let data = payloads[path] else { throw PatchInputError("Missing fixture data") }
        try data.write(to: local)
    }
    static func patch<T: Decodable & Sendable>(_ action: String, as: T.Type) async throws -> T {
        precondition(action == "apps")
        return try JSONDecoder().decode(T.self, from: apps)
    }
}

@main struct PatchCaptureTests {
    @MainActor static func main() async throws {
        let root = "/var/mobile/Containers/Data/Application/11111111-2222-4333-8444-555555555555"
        let docs = root + "/Documents"
        VersionedFilesTransport.pages[docs + ":0"] = .init(entries: [.init(name: "a", kind: "file", size: 3), .init(name: "zero", kind: "file", size: 0)], nextOffset: nil)
        VersionedFilesTransport.payloads[docs + "/a"] = Data([1, 2, 3])
        VersionedFilesTransport.payloads[docs + "/zero"] = Data()
        var seed: PatchCaptureSource? = try await PatchCaptureService.capture(path: docs, isDirectory: true)
        precondition(seed?.bundleID == nil && seed?.destination == "Documents")
        let folder = seed!.sourceURL
        let captured = try Data(contentsOf: folder.appendingPathComponent("a"))
        let empty = try Data(contentsOf: folder.appendingPathComponent("zero"))
        precondition(captured == Data([1, 2, 3]))
        precondition(empty.isEmpty)
        let scratch = seed!.staging.directory
        seed = nil
        precondition(!FileManager.default.fileExists(atPath: scratch.path))
        VersionedFilesTransport.apps = try JSONSerialization.data(withJSONObject: ["apps": [["name":"Example", "bundle_id":"com.example.app", "data_path":root, "target_id":"path:" + root]]])
        seed = try await PatchCaptureService.capture(path: "/private" + docs + "/zero", isDirectory: false)
        precondition(seed?.bundleID == "com.example.app" && seed?.destination == "Documents/zero")
        seed = nil
        var rejected = 0
        func reject(_ path: String = docs, isDirectory: Bool = true) async {
            do { _ = try await PatchCaptureService.capture(path: path, isDirectory: isDirectory); preconditionFailure("Unexpected capture success") }
            catch { rejected += 1 }
        }
        VersionedFilesTransport.pages[docs + ":0"] = .init(entries: [.init(name: ".Trash", kind: "directory", size: nil), .init(name: "unrelated-link", kind: "symlink", size: 3), .init(name: "zero", kind: "file", size: 0)], nextOffset: nil)
        seed = try await PatchCaptureService.capture(path: docs + "/zero", isDirectory: false)
        precondition(seed?.destination == "Documents/zero")
        seed = nil
        await reject()  
        VersionedFilesTransport.pages[docs + ":0"] = .init(entries: [.init(name: "zero", kind: "file", size: 0), .init(name: "zero", kind: "file", size: 0)], nextOffset: nil)
        await reject(docs + "/zero", isDirectory: false)
        VersionedFilesTransport.pages[docs + ":0"] = .init(entries: [], nextOffset: nil, notice: "Partial scan")
        await reject()
        VersionedFilesTransport.pages[docs + ":0"] = .init(entries: [.init(name: "link", kind: "symlink", size: 3)], nextOffset: nil)
        await reject()
        VersionedFilesTransport.pages[docs + ":0"] = .init(entries: [.init(name: "a", kind: "file", size: 3, path: "/elsewhere/a")], nextOffset: nil)
        await reject()
        let before = VersionedFilesTransport.downloads
        VersionedFilesTransport.pages[docs + ":0"] = .init(entries: [.init(name: "a", kind: "file", size: AppPatchSource.perFile + 1)], nextOffset: nil)
        await reject()
        precondition(VersionedFilesTransport.downloads == before)
        VersionedFilesTransport.pages[docs + ":0"] = .init(entries: [], nextOffset: 0)
        await reject()
        VersionedFilesTransport.pages[docs + ":0"] = .init(entries: [.init(name: "a", kind: "file", size: 4)], nextOffset: nil)
        await reject()
        await reject(docs + "/../Library")
        VersionedFilesTransport.pages[docs + ":0"] = .init(entries: [], nextOffset: nil)
        await reject()
        let task = Task { try await Task.sleep(nanoseconds: 10_000_000); return try await PatchCaptureService.capture(path: docs, isDirectory: true) }
        task.cancel()
        do { _ = try await task.value; preconditionFailure("Cancellation lost") } catch { precondition(FileTransferSupport.cancelled(error)) }
        precondition(rejected == 10)
        print("BQ capture: files/folders/zero bytes, exact observed identity, scratch lifetime, partial scans, symlinks, path escape, limits, pagination, changed size and cancellation passed")
    }
}
