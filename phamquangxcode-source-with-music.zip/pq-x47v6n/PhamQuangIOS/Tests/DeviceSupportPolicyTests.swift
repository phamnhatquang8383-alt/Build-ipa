import Foundation

@main struct DeviceSupportPolicyTests {
    static func main() {
        let cases: [(Int, Int, Int, DeviceAccessMode)] = [
            (0, 0, 0, .unsupported),
            (15, 9, 99, .unsupported),
            (16, 0, 0, .directLegacy),
            (16, 7, 0, .directLegacy),
            (16, 7, 99, .directLegacy),
            (16, 8, 0, .unsupported),
            (17, 0, 0, .directLegacy),
            (17, 7, 99, .directLegacy),
            (17, 8, 0, .unsupported),
            (18, 0, 0, .directLegacy),
            (18, 6, 99, .directLegacy),
            (18, 7, 0, .directLegacy),
            (18, 7, 1, .directLegacy),
            (18, 7, 2, .airLift),
            (18, 7, 99, .airLift),
            (18, 8, 0, .airLift),
            (18, 8, 99, .airLift),
            (18, 9, 0, .unsupported),
            (19, 0, 0, .unsupported),
            (25, 9, 99, .unsupported),
            (26, 0, 0, .bqCore),
            (26, 6, 99, .bqCore),
            (26, 7, 0, .bqCore),
            (26, 7, 1, .bqCore),
            (26, 7, 2, .bqCore),
            (26, 7, 3, .unsupported),
            (26, 8, 0, .unsupported),
            (27, 0, 0, .bqCore),
            (27, 3, 0, .bqCore),
            (27, 3, 99, .bqCore),
            (27, 4, 0, .unsupported),
            (28, 0, 0, .unsupported),
            (-1, 0, 0, .unsupported),
            (18, -1, 0, .unsupported),
            (18, 7, -1, .unsupported),
            (16, 0, -1, .unsupported),
            (26, 0, -1, .unsupported),
            (27, 0, -1, .unsupported),
            (Int.max, 0, 0, .unsupported),
            (18, Int.max, 0, .unsupported),
            (26, 7, Int.max, .unsupported),
            (27, 3, Int.max, .bqCore)
        ]
        for (major, minor, patch, expected) in cases {
            let version = OperatingSystemVersion(majorVersion: major, minorVersion: minor, patchVersion: patch)
            let actual = DeviceSupportPolicy.mode(for: version)
            precondition(actual == expected,
                         "\(major).\(minor).\(patch): expected \(expected), got \(actual)")
            let reason = DeviceSupportPolicy.unsupportedReason(for: version)
            precondition((reason != nil) == (expected == .unsupported),
                         "\(major).\(minor).\(patch): reason presence must match unsupported mode")
            precondition(reason?.isEmpty != true, "\(major).\(minor).\(patch): empty reason")
        }
        print("Device support policy: \(cases.count) version boundary checks passed")
    }
}
