#!/bin/bash
set -euo pipefail
root="$(cd "$(dirname "$0")/.." && pwd)"
build="${CC365_TEST_BUILD_DIR:-$root/build/Tests}"
mkdir -p "$build"
xcrun --sdk macosx clang -fobjc-arc -fblocks -Wno-deprecated-declarations -Wall -Wextra -Wno-unused-parameter \
    "$root/Tests/BQPatchEngineTests.m" -framework Foundation -o "$build/BQPatchEngineTests"
"$build/BQPatchEngineTests"
