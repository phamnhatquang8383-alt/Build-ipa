#import <Foundation/Foundation.h>
#import <dirent.h>
#import <fcntl.h>
#import <stdarg.h>
#import <sys/stat.h>
#import <unistd.h>
#import "CCBQFileSystem.h"
#import "BQContainerCatalog.h"

static NSString *fixture;
static NSUInteger checks, scans, catalogs, escapes, openDirectories;
static NSString *deniedRoot, *missingRoot, *lastScan;
static NSArray<NSString *> *observed;
static BOOL scanStopped, scanFailed;
static NSProgress *cancelDuringScan;
static NSProgress *cancelDuringCatalog;
static NSArray<BQContainerEntry *> *catalogEntries;
static NSString *catalogNotice;
@interface BQContainerEntry ()
@property (nonatomic, copy, readwrite) NSString *name;
@property (nonatomic, copy, readwrite) NSString *identifier;
@property (nonatomic, copy, readwrite) NSString *path;
@property (nonatomic, copy, readwrite) NSString *kind;
@property (nonatomic, copy, readwrite) NSString *bundlePath;
@property (nonatomic, readwrite) BOOL accessRestricted;
@end
@implementation BQContainerEntry
@end
static NSArray<NSString *> *Roots(void) {
    return @[@"/var/containers/Data/System", @"/var/containers/Shared/SystemGroup",
        @"/var/mobile/Containers/Data/Application", @"/var/mobile/Containers/Data/InternalDaemon",
        @"/var/mobile/Containers/Data/PluginKitPlugin", @"/var/mobile/Containers/Shared/AppGroup"];
}
static NSString *Normal(const char *raw) {
    NSString *path = [NSString stringWithUTF8String:raw];
    return [path hasPrefix:@"/private/var/"] ? [path substringFromIndex:8] : path;
}
static NSString *Mapped(const char *raw) {
    NSString *path = Normal(raw);
    for (NSUInteger i = 0; i < Roots().count; i++) {
        NSString *root = Roots()[i];
        if ([path isEqual:root] || [path hasPrefix:[root stringByAppendingString:@"/"]])
            return [[fixture stringByAppendingPathComponent:[NSString stringWithFormat:@"root-%lu", (unsigned long)i]]
                stringByAppendingString:[path substringFromIndex:root.length]];
    }
    return path;
}
static DIR *FixtureOpenDir(const char *raw) {
    NSString *path = Normal(raw);
    if ([path isEqual:deniedRoot]) { errno = EACCES; return NULL; }
    if ([path isEqual:missingRoot]) { errno = ENOENT; return NULL; }
    DIR *result = opendir(Mapped(raw).fileSystemRepresentation);
    if (result) openDirectories++;
    return result;
}
static int FixtureCloseDir(DIR *dir) { openDirectories--; return closedir(dir); }
static int FixtureOpen(const char *raw, int flags, ...) {
    mode_t mode = 0;
    if (flags & O_CREAT) { va_list args; va_start(args, flags); mode = (mode_t)va_arg(args, int); va_end(args); }
    return open(Mapped(raw).fileSystemRepresentation, flags, mode);
}
static int FixtureLstat(const char *raw, struct stat *st) {
    if ([Normal(raw).lastPathComponent isEqual:@"DeniedUUID"]) { errno = EPERM; return -1; }
    return lstat(Mapped(raw).fileSystemRepresentation, st);
}
NSString *BQDocuments(void) { return [fixture stringByAppendingPathComponent:@"Documents"]; }
dispatch_queue_t BQWorkQueue(void) { return dispatch_get_main_queue(); }
int64_t BQEscape(__unused NSString *path, __unused NSString **accessible) { escapes++; return -7; }
void BQEndEscape(__unused int64_t handle) {}
NSArray<BQContainerEntry *> *BQDiscoverContainers(BOOL (^cancelled)(void), NSString **notice) {
    catalogs++;
    NSCAssert(openDirectories == 0, @"catalog runs only after directory closes");
    if (cancelDuringCatalog) [cancelDuringCatalog cancel];
    if (notice) *notice = catalogNotice;
    return cancelled && cancelled() ? @[] : (catalogEntries ?: @[]);
}
NSArray<NSString *> *BQDiscoverContainerPaths(NSString *root, NSTimeInterval seconds, NSUInteger limit,
    BOOL (^cancelled)(void), BOOL *stopped, NSString **error) {
    scans++; lastScan = root;
    NSCAssert(seconds > 0 && seconds <= 1.5 && limit > 0 && limit <= 1024, @"bounded root scan");
    if (cancelDuringScan) [cancelDuringScan cancel];
    if (stopped) *stopped = scanStopped;
    if (error) *error = scanFailed ? @"Fixture denied volume" : nil;
    return cancelled && cancelled() ? @[] : (observed ?: @[]);
}
#define opendir FixtureOpenDir
#define closedir FixtureCloseDir
#define open FixtureOpen
#define lstat FixtureLstat
#import "../CC365-Apps/Files/BQCore/CCBQFileSystem.m"
#undef opendir
#undef closedir
#undef open
#undef lstat

static void Check(BOOL pass, NSString *name) {
    if (!pass) { NSLog(@"FAIL: %@", name); exit(1); }
    checks++;
}
static NSDictionary *List(NSString *path, NSError **error) {
    if (error) *error = nil;
    return [CCBQFileSystem request:@{@"action":@"list", @"path":path} progress:[NSProgress progressWithTotalUnitCount:1] error:error];
}
static void Directory(NSString *path) {
    [NSFileManager.defaultManager createDirectoryAtPath:Mapped(path.fileSystemRepresentation) withIntermediateDirectories:YES attributes:nil error:nil];
}
static BQContainerEntry *Entry(NSString *path, NSString *identifier, NSString *name) {
    BQContainerEntry *entry = [BQContainerEntry new];
    entry.path = path; entry.identifier = identifier; entry.name = name; entry.kind = @"app";
    return entry;
}
int main(void) { @autoreleasepool {
    NSFileManager *fm = NSFileManager.defaultManager;
    fixture = [NSTemporaryDirectory() stringByAppendingPathComponent:NSUUID.UUID.UUIDString];
    @try {
        Check(scans == 0 && catalogs == 0 && escapes == 0, @"service initialization performs no discovery");
        for (NSString *root in Roots()) Directory(root);
        NSString *apps = Roots()[2], *groups = Roots()[5];
        Directory([apps stringByAppendingPathComponent:@"AppUUID"]);
        Directory([groups stringByAppendingPathComponent:@"GroupUUID"]);
        NSError *error = nil;
        NSDictionary *page = List(@"/", &error);
        Check(page && !error && [page[@"total"] isEqual:@6], @"six root locations exactly once");
        Check([[page[@"entries"] valueForKey:@"path"] isEqual:Roots()], @"fixed user-requested root order");
        Check([[page[@"entries"] valueForKey:@"subtitle"] isEqual:Roots()], @"full root paths are visible");
        List(@"/", &error);
        Check(scans == 0 && catalogs == 0 && escapes == 0, @"opening and refreshing Files root performs no discovery");
        for (NSString *root in Roots()) {
            NSUInteger beforeCatalog = catalogs;
            page = List(root, &error);
            Check(page && !error && scans == 0, @"each fixed root opens directly without a scan");
            Check(catalogs == beforeCatalog + (([root isEqual:Roots()[2]] || [root isEqual:Roots()[4]]) ? 1 : 0), @"only explicit Application and PluginKitPlugin roots enrich names");
        }
        page = List(apps, &error);
        Check([page[@"entries"] count] == 1 && [page[@"entries"][0][@"path"] isEqual:[apps stringByAppendingPathComponent:@"AppUUID"]], @"application children stay under selected root");
        page = List(groups, &error);
        Check([page[@"entries"] count] == 1 && [page[@"entries"][0][@"name"] isEqual:@"GroupUUID"], @"app groups are not merged into application root");
        deniedRoot = apps; scanStopped = YES;
        Directory([apps stringByAppendingPathComponent:@"DeniedUUID"]);
        [@"bytes" writeToFile:Mapped([[apps stringByAppendingPathComponent:@"FileUUID"] fileSystemRepresentation]) atomically:NO encoding:NSUTF8StringEncoding error:nil];
        [fm createSymbolicLinkAtPath:Mapped([[apps stringByAppendingPathComponent:@"LinkUUID"] fileSystemRepresentation])
            withDestinationPath:Mapped([[apps stringByAppendingPathComponent:@"AppUUID"] fileSystemRepresentation]) error:nil];
        observed = @[[apps stringByAppendingPathComponent:@"AppUUID"], [@"/private" stringByAppendingString:[apps stringByAppendingPathComponent:@"AppUUID"]],
            [apps stringByAppendingPathComponent:@"DeniedUUID"], [groups stringByAppendingPathComponent:@"GroupUUID"],
            [apps stringByAppendingPathComponent:@"AppUUID/Nested"], [apps stringByAppendingPathComponent:@"MissingUUID"],
            [apps stringByAppendingPathComponent:@"FileUUID"], [apps stringByAppendingPathComponent:@"LinkUUID"]];
        NSUInteger beforeCatalog = catalogs;
        page = List(apps, &error);
        Check(page && !error && scans == 1 && [lastScan isEqual:apps] && catalogs == beforeCatalog + 1 && escapes == 0, @"denied app root scans itself then enriches names without escape");
        Check([page[@"entries"] count] == 2, @"scan rejects unrelated nested missing file and symlink paths; aliases deduplicate");
        NSDictionary *denied = page[@"entries"][1];
        Check([denied[@"name"] isEqual:@"DeniedUUID"] && [denied[@"kind"] isEqual:@"directory"], @"inode-observed permission-denied child remains browseable");
        Check([page[@"notice"] containsString:@"có thể còn thiếu"] && [page[@"notice"] containsString:@"giới hạn"], @"partial result is explicitly described");
        page = List(denied[@"path"], &error);
        Check(page && !error && scans == 1 && catalogs == beforeCatalog + 1, @"observed child selection opens exact child without discovery");
        observed = @[]; scanStopped = NO; scanFailed = YES;
        page = List(apps, &error);
        Check(page && !error && [page[@"entries"] count] == 0 && [page[@"notice"] containsString:@"không có nghĩa là thư mục trống"], @"empty denied scan is not reported as an empty directory");
        NSUInteger before = scans; beforeCatalog = catalogs; deniedRoot = nil; missingRoot = apps;
        page = List(apps, &error);
        Check(!page && error.code == ENOENT && scans == before && catalogs == beforeCatalog, @"missing root does not trigger inode or catalog discovery");
        missingRoot = nil; deniedRoot = groups; scanFailed = NO;
        observed = @[[groups stringByAppendingPathComponent:@"GroupUUID"]];
        error = nil; page = List(groups, &error);
        Check(page && !error && [lastScan isEqual:groups] && [page[@"entries"][0][@"name"] isEqual:@"GroupUUID"], @"group denial fallback remains isolated to group root");
        cancelDuringScan = [NSProgress progressWithTotalUnitCount:1];
        error = nil;
        page = [CCBQFileSystem request:@{@"action":@"list", @"path":groups} progress:cancelDuringScan error:&error];
        Check(!page && error.code == NSUserCancelledError, @"canceled scan cannot commit partial results");
        Check(catalogs == beforeCatalog && escapes == 0, @"group root and cancellation do not invoke catalog or protected access");
        cancelDuringScan = nil; deniedRoot = nil; observed = @[];


        NSString *uuid = @"11111111-2222-3333-4444-555555555555";
        NSString *namedPath = [apps stringByAppendingPathComponent:uuid];
        Directory(namedPath);
        catalogEntries = @[Entry(namedPath, @"com.example.game", @"Friendly Game"),
            Entry([@"/private" stringByAppendingString:namedPath], @"com.example.game", @"Friendly Game"),
            Entry([apps stringByAppendingPathComponent:@"MissingUUID"], @"invalid.missing", @"Missing"),
            Entry([apps stringByAppendingPathComponent:@"LinkUUID"], @"invalid.link", @"Link"),
            Entry([apps stringByAppendingPathComponent:@"FileUUID"], @"invalid.file", @"File"),
            Entry([apps stringByAppendingPathComponent:@"AppUUID/Nested"], @"invalid.nested", @"Nested"),
            Entry([groups stringByAppendingPathComponent:@"GroupUUID"], @"invalid.group", @"Group")];
        page = List(apps, &error);
        NSArray *named = [page[@"entries"] filteredArrayUsingPredicate:[NSPredicate predicateWithFormat:@"display_name == %@", @"Friendly Game"]];
        Check(named.count == 1 && [named[0][@"name"] isEqual:uuid] && [named[0][@"path"] isEqual:namedPath], @"friendly title keeps raw UUID/path and aliases deduplicate");
        Check([named[0][@"subtitle"] isEqual:@"com.example.game"], @"bundle ID is the friendly row subtitle");
        Check([[page[@"entries"] filteredArrayUsingPredicate:[NSPredicate predicateWithFormat:@"display_name != nil"]] count] == 1, @"missing file symlink nested and other-root catalog labels are rejected");
        beforeCatalog = catalogs;
        page = List(namedPath, &error);
        Check(page && !error && catalogs == beforeCatalog, @"named row opens exact UUID without catalog lookup");
        NSString *rawFile = [namedPath stringByAppendingPathComponent:@"original.txt"];
        [@"unchanged bytes" writeToFile:Mapped(rawFile.fileSystemRepresentation) atomically:NO encoding:NSUTF8StringEncoding error:nil];
        NSString *download = [fixture stringByAppendingPathComponent:@"download.txt"];
        NSDictionary *receipt = [CCBQFileSystem request:@{@"action":@"download", @"path":rawFile, @"local_path":download}
            progress:[NSProgress progressWithTotalUnitCount:1] error:&error];
        Check(receipt && !error && [[NSString stringWithContentsOfFile:download encoding:NSUTF8StringEncoding error:nil] isEqual:@"unchanged bytes"] && catalogs == beforeCatalog, @"friendly display does not change raw UUID file download path");

        deniedRoot = apps; observed = @[];
        catalogEntries = @[Entry(namedPath, @"com.example.game", @"Friendly Game"),
            Entry([apps stringByAppendingPathComponent:@"DeniedUUID"], @"com.example.denied", @"Denied Game")];
        page = List(apps, &error);
        Check([page[@"entries"] count] == 2 && [page[@"notice"] containsString:@"có thể còn thiếu"] && ![page[@"notice"] containsString:@"Chưa tìm thấy"], @"catalog adds current and permission-denied folders missed by limited scan, retaining partial notice");
        Check([page[@"entries"][0][@"display_name"] isEqual:@"Denied Game"], @"friendly name controls sorting");
        catalogEntries = @[Entry(namedPath, @"com.example.one", @"First"), Entry(namedPath, @"com.example.two", @"Second")];
        catalogNotice = @"Fixture names may be incomplete.";
        page = List(apps, &error);
        Check([page[@"entries"] count] == 1 && !page[@"entries"][0][@"display_name"] && !page[@"entries"][0][@"subtitle"], @"conflicting owners retain only raw observed folder");
        Check([page[@"notice"] containsString:catalogNotice] && [page[@"notice"] containsString:@"có thể còn thiếu"], @"lookup notice appended when unresolved names remain");
        catalogEntries = @[Entry(namedPath, @"com.example.one", @"Named")];
        page = List(apps, &error);
        Check(![page[@"notice"] containsString:catalogNotice], @"irrelevant catalog warning omitted when all visible names resolve");
        cancelDuringCatalog = [NSProgress progressWithTotalUnitCount:1]; error = nil;
        page = [CCBQFileSystem request:@{@"action":@"list", @"path":apps} progress:cancelDuringCatalog error:&error];
        Check(!page && error.code == NSUserCancelledError, @"canceled name lookup never commits partial listing");
        cancelDuringCatalog = nil;
        NSString *pluginPath = [Roots()[4] stringByAppendingPathComponent:@"PluginUUID"];
        Directory(pluginPath);
        catalogEntries = @[Entry(pluginPath, @"com.example.plugin", @"Named Extension"), Entry(namedPath, @"com.example.game", @"Named Game")];
        page = List(Roots()[4], &error);
        Check([page[@"entries"] count] == 1 && [page[@"entries"][0][@"display_name"] isEqual:@"Named Extension"], @"PluginKitPlugin gets only names for its own direct children");
        NSMutableArray *many = [NSMutableArray array];
        for (NSUInteger i = 0; i < 1025; i++) {
            NSString *path = [apps stringByAppendingPathComponent:[NSString stringWithFormat:@"Bound-%04lu", (unsigned long)i]];
            Directory(path);
            [many addObject:Entry(path, @"com.example.same", @"Same Name")];
        }
        catalogEntries = many;
        page = List(apps, &error);
        Check([page[@"total"] isEqual:@1024] && [page[@"notice"] containsString:@"1.024"], @"enriched roots retain explicit 1024-result bound");
        Check([page[@"entries"][0][@"name"] isEqual:@"Bound-0000"] && [page[@"entries"][99][@"name"] isEqual:@"Bound-0099"], @"equal display names have stable raw-path order for pagination");
        Check(openDirectories == 0 && escapes == 0, @"all directory handles close and no root lease is acquired");
        printf("BQFileRoots: %lu assertions passed (observed-path fixtures).\n", (unsigned long)checks);
    } @finally { [fm removeItemAtPath:fixture error:nil]; }
} return 0; }
