#import <Foundation/Foundation.h>
#import <fcntl.h>
#import <unistd.h>
#import <errno.h>
#import <sys/stat.h>
#define VV_LEGACY_DIRECT_TESTING 1
#import "../CC365-Apps/Files/LegacyDirect/VVLegacyDirectAccess.m"

static NSUInteger checks;
static void Check(BOOL ok, NSString *message) {
    if (!ok) { fprintf(stderr, "FAIL: %s\n", message.UTF8String); exit(1); }
    checks++;
}
dispatch_queue_t BQWorkQueue(void) {
    static dispatch_queue_t queue;
    static dispatch_once_t once;
    dispatch_once(&once, ^{ queue = dispatch_queue_create("viet99.legacy.tests", DISPATCH_QUEUE_SERIAL); });
    return queue;
}
void BQLog(NSString *format, ...) {}
static NSUInteger probeCalls, kernelCalls, procCalls, escapeCalls;
static BOOL initialAccess, finalAccess;
static NSInteger initialProbeError, finalProbeError;
static int kernelResult, escapeResult;
static uint64_t selfProc;
static BOOL VVLegacyTestProbe(NSError **error) {
    BOOL first = probeCalls++ == 0;
    NSInteger code = first ? initialProbeError : finalProbeError;
    if (error) *error = code ? [NSError errorWithDomain:VVLegacyDirectProbeErrorDomain
        code:code userInfo:@{NSLocalizedDescriptionKey:@"probe failure"}] : nil;
    return first ? initialAccess : finalAccess;
}
static int VVLegacyTestKernel(void) { kernelCalls++; return kernelResult; }
static uint64_t VVLegacyTestProc(void) { procCalls++; return selfProc; }
static int VVLegacyTestEscape(uint64_t proc) { escapeCalls++; return escapeResult; }
static void Reset(void) {
    dispatch_sync(BQWorkQueue(), ^{
        VVLegacyAttempted = NO;
        @synchronized(VVLegacyDirectAccess.class) { VVLegacyResult = nil; }
    });
    VVLegacyTestVersion = (NSOperatingSystemVersion){18,7,1};
    VVLegacyTestDevice = YES; VVLegacyTestHardware = YES;
    probeCalls = kernelCalls = procCalls = escapeCalls = 0;
    initialAccess = NO; finalAccess = YES;
    initialProbeError = 1; finalProbeError = 0;
    kernelResult = 0; escapeResult = 0; selfProc = 1;
}
static NSDictionary *Prepare(void) {
    __block NSDictionary *result;
    [VVLegacyDirectAccess prepareWithCompletion:^(NSDictionary *value) {
        Check(NSThread.isMainThread, @"completion runs on main queue");
        result = value;
    }];
    NSDate *deadline = [NSDate dateWithTimeIntervalSinceNow:3];
    while (!result && deadline.timeIntervalSinceNow > 0)
        [NSRunLoop.currentRunLoop runUntilDate:[NSDate dateWithTimeIntervalSinceNow:0.001]];
    Check(result != nil, @"prepare finishes");
    return result;
}


static BOOL denyProbeWrite, denyProbeCleanup;
static ssize_t TestWrite(int fd, const void *data, size_t size) {
    if (denyProbeWrite) { errno = EIO; return -1; }
    return write(fd, data, size);
}
static int TestUnlinkat(int fd, const char *name, int flags) {
    if (denyProbeCleanup) { errno = EPERM; return -1; }
    return unlinkat(fd, name, flags);
}
#define write TestWrite
#define unlinkat TestUnlinkat
#import "../CC365-Apps/Files/LegacyDirect/VVLegacyDirectProbe.m"
#undef write
#undef unlinkat

#import "../CC365-Apps/Files/LegacyDirect/VVLegacyDirectOffsets.m"
uint32_t off_inpcb_inp_list_le_next, off_inpcb_inp_pcbinfo, off_inpcb_inp_socket;
uint32_t off_inpcbinfo_ipi_zone, off_inpcb_inp_depend6_inp6_icmp6filt;
uint32_t off_inpcb_inp_depend6_inp6_chksum, off_socket_so_usecount;
uint32_t off_socket_so_background_thread, off_kalloc_type_view_kt_zv_zv_name;
uint32_t off_thread_t_tro, off_thread_ro_tro_proc;
uint64_t t1sz_boot, smr_base, pac_mask, VM_MIN_KERNEL_ADDRESS, VM_MAX_KERNEL_ADDRESS;

int main(void) { @autoreleasepool {
    const NSOperatingSystemVersion supported[] = {{16,0,0},{16,7,13},{17,0,0},{17,7,10},{18,0,0},{18,6,9},{18,7,1}};
    for (NSUInteger i=0;i<sizeof(supported)/sizeof(supported[0]);i++)
        Check(VVLegacyVersionEligible(supported[i]), @"supported candidate version");
    const NSOperatingSystemVersion unsupported[] = {{15,9,0},{16,8,0},{17,8,0},{18,7,2},{18,8,0},{26,0,0},{27,0,0},{18,-1,0},{18,0,-1}};
    for (NSUInteger i=0;i<sizeof(unsupported)/sizeof(unsupported[0]);i++) {
        Reset(); VVLegacyTestVersion = unsupported[i];
        NSDictionary *r = Prepare();
        Check(![r[@"ready"] boolValue] && [r[@"state"] isEqual:@"unsupported"] && !kernelCalls && !probeCalls,
            @"unsupported version never touches access or kernel");
    }
    Reset(); VVLegacyTestDevice = NO;
    Check([Prepare()[@"state"] isEqual:@"simulator"] && !probeCalls && !kernelCalls, @"simulator does no access work");
    Reset(); VVLegacyTestHardware = NO;
    Check([Prepare()[@"state"] isEqual:@"unsupported_hardware"] && !kernelCalls, @"unknown hardware does not start kernel");
    Reset(); kernelResult = -60;
    Check(![Prepare()[@"ready"] boolValue] && !procCalls && !escapeCalls, @"missing offsets do not advance preparation");
    Reset(); kernelResult = -7;
    Check([Prepare()[@"state"] isEqual:@"failed"] && !procCalls, @"kernel failure stops chain");
    Reset(); selfProc = 0;
    Check([Prepare()[@"state"] isEqual:@"kernel_only"] && !escapeCalls, @"kernel-only missing self process is not ready");
    Reset(); escapeResult = -1;
    Check(![Prepare()[@"ready"] boolValue] && probeCalls == 2, @"escape failure stays not ready even if later probe succeeds");
    Reset(); finalAccess = NO; finalProbeError = 1;
    Check([Prepare()[@"state"] isEqual:@"kernel_only"] && !VVLegacyDirectAccess.isReady, @"kernel success cannot replace actual FD access");
    Reset(); initialProbeError = 2;
    Check([Prepare()[@"state"] isEqual:@"cleanup_failed"] && !kernelCalls, @"initial cleanup failure never starts kernel");
    Reset(); finalAccess = NO; finalProbeError = 2;
    Check([Prepare()[@"state"] isEqual:@"cleanup_failed"] && !VVLegacyDirectAccess.isReady, @"final cleanup failure cannot report ready");
    Reset();
    Check(!VVLegacyDirectAccess.isReady, @"initial state is not ready");
    NSDictionary *ready = Prepare();
    Check([ready[@"ready"] boolValue] && [ready[@"kernel_ready"] boolValue] && VVLegacyDirectAccess.isReady,
        @"full setup plus FD verification becomes ready");
    NSDictionary *again = Prepare();
    Check([again isEqual:ready] && kernelCalls == 1 && probeCalls == 2, @"repeat returns result without repeating native operations");
    Reset(); initialAccess = YES; initialProbeError = 0;
    Check([Prepare()[@"ready"] boolValue] && !kernelCalls && !escapeCalls, @"verified existing ordinary access needs no exploit");
    Reset(); kernelResult = -1;
    Prepare(); Prepare();
    Check(kernelCalls == 1, @"failed preparation also remains one attempt per process");
    Reset();
    __block NSUInteger callbacks = 0;
    for (NSUInteger i=0;i<4;i++) [VVLegacyDirectAccess prepareWithCompletion:^(NSDictionary *result) {
        Check([result[@"ready"] boolValue], @"concurrent waiter receives same successful result"); callbacks++;
    }];
    NSDate *deadline = [NSDate dateWithTimeIntervalSinceNow:3];
    while (callbacks < 4 && deadline.timeIntervalSinceNow > 0)
        [NSRunLoop.currentRunLoop runUntilDate:[NSDate dateWithTimeIntervalSinceNow:0.001]];
    Check(callbacks == 4 && kernelCalls == 1 && escapeCalls == 1, @"concurrent prepare calls serialize one native attempt");

    NSFileManager *fm = NSFileManager.defaultManager;
    NSString *base = [[NSTemporaryDirectory() stringByResolvingSymlinksInPath]
        stringByAppendingPathComponent:[@"viet99-legacy-test-" stringByAppendingString:NSUUID.UUID.UUIDString]];
    Check([fm createDirectoryAtPath:base withIntermediateDirectories:NO attributes:@{NSFilePosixPermissions:@0700} error:NULL], @"create owned fixture");
    char *physicalPath = realpath(base.fileSystemRepresentation, NULL);
    Check(physicalPath != NULL, @"resolve owned fixture path");
    base = [NSString stringWithUTF8String:physicalPath];
    free(physicalPath);
    NSError *error;
    BOOL fixtureProbeOK = VVLegacyDirectProbeDirectory(base, &error);
    if (!fixtureProbeOK) fprintf(stderr, "fixture probe error: %s (%s)\n", error.description.UTF8String, base.UTF8String);
    Check(fixtureProbeOK && !error, @"actual FD probe verifies a temporary fixture");
    Check([fm contentsOfDirectoryAtPath:base error:NULL].count == 0, @"successful canary leaves no files");
    denyProbeWrite = YES;
    Check(!VVLegacyDirectProbeDirectory(base, &error) && error.code == 1, @"failed write is not access readiness");
    denyProbeWrite = NO;
    Check([fm contentsOfDirectoryAtPath:base error:NULL].count == 0, @"failed IO still cleans owned canary");
    denyProbeCleanup = YES;
    Check(!VVLegacyDirectProbeDirectory(base, &error) && error.code == 2, @"cleanup denial is explicit failure");
    denyProbeCleanup = NO;
    NSArray *leftovers = [fm contentsOfDirectoryAtPath:base error:NULL];
    Check(leftovers.count == 1, @"failed cleanup retains the canary rather than claiming success");
    Check(!VVLegacyDirectProbeDirectory(base, &error) && error.code == 2 &&
        [fm contentsOfDirectoryAtPath:base error:NULL].count == 1,
        @"later probe cannot hide an earlier cleanup failure or create another canary");
    [fm removeItemAtPath:[base stringByAppendingPathComponent:leftovers.firstObject] error:NULL];
    atomic_store(&VVProbeCleanupUnconfirmed, false);  
    NSString *link = [base stringByAppendingString:@"-link"];
    Check([fm createSymbolicLinkAtPath:link withDestinationPath:base error:NULL], @"create fixture symlink");
    Check(!VVLegacyDirectProbeDirectory(link, &error) && [fm contentsOfDirectoryAtPath:base error:NULL].count == 0,
        @"symlink directory is rejected before creating canary");
    Check(!VVLegacyDirectProbeDirectory([link stringByAppendingPathComponent:@"child"], &error), @"parent symlink is rejected");
    Check(!VVLegacyDirectProbeDirectory([base stringByAppendingString:@"/../"], &error), @"traversal rejected");
    Check(!VVLegacyDirectProbeApplicationRoot(&error), @"host cannot probe real Application root");
    [fm removeItemAtPath:link error:NULL]; [fm removeItemAtPath:base error:NULL];

    uint32_t *fields[] = {&off_inpcb_inp_list_le_next,&off_inpcb_inp_pcbinfo,&off_inpcb_inp_socket,
        &off_inpcbinfo_ipi_zone,&off_inpcb_inp_depend6_inp6_icmp6filt,&off_inpcb_inp_depend6_inp6_chksum,
        &off_socket_so_usecount,&off_socket_so_background_thread,&off_kalloc_type_view_kt_zv_zv_name,
        &off_thread_t_tro,&off_thread_ro_tro_proc};
    for (NSUInteger i=0;i<sizeof(fields)/sizeof(fields[0]);i++) *fields[i]=8;
    t1sz_boot=25; smr_base=2; pac_mask=UINT64_MAX; VM_MIN_KERNEL_ADDRESS=0xffffff0000000000; VM_MAX_KERNEL_ADDRESS=UINT64_MAX;
    Check(VVLegacyDirectOffsetsAreValid(), @"complete bounded offset fixture passes");
    for (NSUInteger i=0;i<sizeof(fields)/sizeof(fields[0]);i++) {
        *fields[i]=0; Check(!VVLegacyDirectOffsetsAreValid(), @"each required missing field fails closed"); *fields[i]=8;
    }
    t1sz_boot=64; Check(!VVLegacyDirectOffsetsAreValid(), @"invalid shift parameter rejected");
    t1sz_boot=25; VM_MAX_KERNEL_ADDRESS=VM_MIN_KERNEL_ADDRESS;
    Check(!VVLegacyDirectOffsetsAreValid(), @"invalid pointer bounds rejected");
    printf("%lu legacy direct checks passed (mocked setup; temporary own-file probes only)\n", (unsigned long)checks);
    return 0;
} }
