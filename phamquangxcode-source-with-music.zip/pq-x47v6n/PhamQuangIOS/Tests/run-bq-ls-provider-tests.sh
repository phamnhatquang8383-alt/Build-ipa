#!/bin/bash
set -euo pipefail
cd "$(dirname "$0")/.."
build="${BUILD_DIR:-$PWD/build}/Tests"
mkdir -p "$build"
xcrun --sdk macosx clang -fobjc-arc -fblocks -Wall -Wextra -Werror \
  -I CC365-Apps/Files/BQCore Tests/BQLSApplicationCatalogTests.m \
  -framework Foundation -o "$build/BQLSApplicationCatalogTests"
"$build/BQLSApplicationCatalogTests"
python3 Tests/BQLSStoreDiscoveryTests.py
