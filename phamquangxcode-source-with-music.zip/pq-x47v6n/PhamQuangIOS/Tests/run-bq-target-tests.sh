#!/bin/bash
set -euo pipefail
root="$(cd "$(dirname "$0")/.." && pwd)"
build="${CC365_TEST_BUILD_DIR:-$root/build/Tests}"
mkdir -p "$build"
python3 - "$root" "$build" <<'PY'
from pathlib import Path
import sys
root, build = map(Path, sys.argv[1:])
source = (root / 'CC365-Apps/Files/BQCore/BQCore.m').read_text()
start = source.index('NSString *BQLookupApplicationDataPath(')
brace = source.index('{', start)
end, depth = brace + 1, 1
while depth:
    depth += (source[end] == '{') - (source[end] == '}')
    end += 1
(build / 'BQAppTargetMCM.inc').write_text(source[start:end])
PY
xcrun --sdk macosx clang -fobjc-arc -fblocks -Wno-deprecated-declarations -Wall -Wextra -Wno-unused-parameter \
    -I "$build" "$root/Tests/BQAppTargetResolverTests.m" -framework Foundation -o "$build/BQAppTargetResolverTests"
"$build/BQAppTargetResolverTests"
