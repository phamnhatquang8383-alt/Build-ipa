import Darwin
import Foundation

@main
enum LoopbackPacketTests {
    private static let local: [UInt8] = [10, 7, 1, 1]
    private static let peer: [UInt8] = [10, 7, 0, 1]

    static func main() {
        tcpAndUDPChecksums()
        fragmentsPreserveReassembledTCP()
        unalignedStorageAndDataSlice()
        malformedAndUnrelatedPackets()
        maximumIPv4Length()
        print("PASS: IPv4/TCP/UDP checksums, reverse reflection, fragments, options, unaligned/sliced Data and malformed/unrelated packets")
    }

    private static func maximumIPv4Length() {
        let original = ipv4(payload: [UInt8](repeating: 0xA5, count: Int(UInt16.max) - 20), protocolNumber: 1)
        let reflected = reflect(original)
        verifyReflection(original, reflected)
        require(LoopbackPacket.reflect(reflected, addressFamily: AF_INET) == original, "maximum IPv4 length round-trips")
        var oversized = original
        oversized.append(0)
        require(LoopbackPacket.reflect(oversized, addressFamily: AF_INET) == nil, "oversized IPv4 buffer is rejected")
    }

    private static func tcpAndUDPChecksums() {
        let tcp = tcpSegment(payload: [1, 2, 3, 4, 5])
        for options in [[], [UInt8](repeating: 1, count: 4), [UInt8](repeating: 1, count: 40)] {
            let packet = ipv4(payload: tcp, protocolNumber: 6, options: options)
            let reflected = reflect(packet)
            verifyReflection(packet, reflected)
            require(checksum(pseudoHeader(source: peer, destination: local, protocolNumber: 6, count: tcp.count) + Array(reflected.suffix(tcp.count))) == 0, "TCP checksum survives address exchange")
            require(LoopbackPacket.reflect(reflected, addressFamily: AF_INET) == packet, "reverse endpoint direction round-trips")
        }

        for checksumEnabled in [true, false] {
            let udp = udpDatagram(payload: [9, 8, 7, 6, 5, 4, 3], checksumEnabled: checksumEnabled)
            let packet = ipv4(payload: udp, protocolNumber: 17)
            let reflected = reflect(packet)
            verifyReflection(packet, reflected)
            if checksumEnabled {
                require(checksum(pseudoHeader(source: peer, destination: local, protocolNumber: 17, count: udp.count) + Array(reflected.suffix(udp.count))) == 0, "UDP checksum survives address exchange")
            } else {
                require(reflected[26] == 0 && reflected[27] == 0, "optional zero UDP checksum stays zero")
            }
        }
    }

    private static func fragmentsPreserveReassembledTCP() {
        let tcp = tcpSegment(payload: Array(0..<31))


        let pieces = [Array(tcp[0..<16]), Array(tcp[16..<32]), Array(tcp[32...])]
        let flagsAndOffsets: [UInt16] = [0x2000, 0x2002, 0x0004]
        var reassembled: [UInt8] = []
        for (piece, flags) in zip(pieces, flagsAndOffsets) {
            let packet = ipv4(payload: piece, protocolNumber: 6, fragmentField: flags)
            let reflected = reflect(packet)
            verifyReflection(packet, reflected)
            require(Array(reflected[6..<8]) == Array(packet[6..<8]), "fragment flags and offset stay unchanged")
            reassembled += Array(reflected.dropFirst(20))
        }
        require(reassembled == tcp, "reassembled transport bytes are unchanged")
        require(checksum(pseudoHeader(source: peer, destination: local, protocolNumber: 6, count: tcp.count) + reassembled) == 0, "fragmented TCP checksum remains valid")
    }

    private static func unalignedStorageAndDataSlice() {
        let packet = ipv4(payload: tcpSegment(payload: [42]), protocolNumber: 6)
        let storage = UnsafeMutableRawPointer.allocate(byteCount: packet.count + 1, alignment: 8)
        defer { storage.deallocate() }
        let unaligned = storage.advanced(by: 1)
        packet.copyBytes(to: unaligned.assumingMemoryBound(to: UInt8.self), count: packet.count)
        let noCopy = Data(bytesNoCopy: unaligned, count: packet.count, deallocator: .none)
        verifyReflection(packet, reflect(noCopy))
        require(noCopy == packet, "reflection must not mutate its input storage")

        var prefixed = Data([0xAB])
        prefixed.append(packet)
        let slice = prefixed.dropFirst()
        require(slice.startIndex != 0, "fixture has a non-zero Data startIndex")
        verifyReflection(packet, reflect(slice))
    }

    private static func malformedAndUnrelatedPackets() {
        let valid = ipv4(payload: tcpSegment(payload: []), protocolNumber: 6)
        for length in 0..<valid.count {
            require(LoopbackPacket.reflect(Data(valid.prefix(length)), addressFamily: AF_INET) == nil, "reject every truncated packet")
        }
        var cases: [Data] = []
        var changed = valid
        changed[0] = 0x65  
        cases.append(changed)
        changed = valid
        changed[0] = 0x44  
        cases.append(changed)
        changed = valid
        changed[0] = 0x4F  
        cases.append(changed)
        changed = valid
        changed[2] = 0; changed[3] = 19  
        cases.append(changed)
        changed = valid
        changed[2] = 0xFF; changed[3] = 0xFF  
        cases.append(changed)
        changed = valid
        changed.append(0)  
        cases.append(changed)
        cases.append(ipv4(payload: [], protocolNumber: 1, source: [192, 0, 2, 1], destination: peer))
        cases.append(ipv4(payload: [], protocolNumber: 1, source: local, destination: [8, 8, 8, 8]))
        cases.append(ipv4(payload: [], protocolNumber: 1, source: local, destination: local))
        cases.append(ipv4(payload: [], protocolNumber: 1, source: peer, destination: peer))
        for packet in cases {
            require(LoopbackPacket.reflect(packet, addressFamily: AF_INET) == nil, "reject malformed or unrelated IPv4 packet")
        }
        require(LoopbackPacket.reflect(valid, addressFamily: AF_INET6) == nil, "reject IPv6 address family")
        require(LoopbackPacket.reflect(Data(repeating: 0x60, count: 40), addressFamily: AF_INET6) == nil, "reject IPv6 packet")
        require(LoopbackPacket.reflect(valid, addressFamily: AF_UNIX) == nil, "reject unknown address family")
    }

    private static func reflect(_ packet: Data) -> Data {
        guard let reflected = LoopbackPacket.reflect(packet, addressFamily: AF_INET) else { fatalError("valid fixture rejected") }
        return reflected
    }

    private static func verifyReflection(_ original: Data, _ reflected: Data) {


        let originalBytes = [UInt8](original)
        let reflectedBytes = [UInt8](reflected)
        let headerLength = Int(originalBytes[0] & 0x0F) * 4
        require(checksum(Array(originalBytes.prefix(headerLength))) == 0, "input IPv4 checksum is valid")
        require(checksum(Array(reflectedBytes.prefix(headerLength))) == 0, "reflected IPv4 checksum is valid")
        require(Array(reflectedBytes[12..<16]) == Array(originalBytes[16..<20]), "source becomes destination")
        require(Array(reflectedBytes[16..<20]) == Array(originalBytes[12..<16]), "destination becomes source")
        require(reflected.count == original.count, "packet length stays unchanged")
        for index in originalBytes.indices where !(12..<20).contains(index) {
            require(originalBytes[index] == reflectedBytes[index], "only address bytes may change")
        }
    }

    private static func ipv4(payload: [UInt8], protocolNumber: UInt8, options: [UInt8] = [], fragmentField: UInt16 = 0x4000, source: [UInt8] = local, destination: [UInt8] = peer) -> Data {
        require(options.count % 4 == 0 && options.count <= 40, "valid option fixture")
        var header = [UInt8](repeating: 0, count: 20 + options.count)
        header[0] = 0x40 | UInt8(header.count / 4)
        put(UInt16(header.count + payload.count), in: &header, at: 2)
        put(0x1234, in: &header, at: 4)
        put(fragmentField, in: &header, at: 6)
        header[8] = 64
        header[9] = protocolNumber
        header.replaceSubrange(12..<16, with: source)
        header.replaceSubrange(16..<20, with: destination)
        header.replaceSubrange(20..<header.count, with: options)
        put(checksum(header), in: &header, at: 10)
        return Data(header + payload)
    }

    private static func tcpSegment(payload: [UInt8]) -> [UInt8] {
        var tcp = [UInt8](repeating: 0, count: 20)
        put(62000, in: &tcp, at: 0)
        put(62078, in: &tcp, at: 2)
        tcp[7] = 1
        tcp[12] = 0x50
        tcp[13] = 0x02
        put(65535, in: &tcp, at: 14)
        tcp += payload
        put(checksum(pseudoHeader(source: local, destination: peer, protocolNumber: 6, count: tcp.count) + tcp), in: &tcp, at: 16)
        return tcp
    }

    private static func udpDatagram(payload: [UInt8], checksumEnabled: Bool) -> [UInt8] {
        var udp = [UInt8](repeating: 0, count: 8)
        put(49152, in: &udp, at: 0)
        put(12345, in: &udp, at: 2)
        put(UInt16(8 + payload.count), in: &udp, at: 4)
        udp += payload
        if checksumEnabled {
            let sum = checksum(pseudoHeader(source: local, destination: peer, protocolNumber: 17, count: udp.count) + udp)
            put(sum == 0 ? 0xFFFF : sum, in: &udp, at: 6)
        }
        return udp
    }

    private static func pseudoHeader(source: [UInt8], destination: [UInt8], protocolNumber: UInt8, count: Int) -> [UInt8] {
        source + destination + [0, protocolNumber, UInt8(count >> 8), UInt8(count & 0xFF)]
    }

    private static func checksum(_ bytes: [UInt8]) -> UInt16 {
        var sum: UInt32 = 0
        var index = 0
        while index < bytes.count {
            sum += UInt32(bytes[index]) << 8
            if index + 1 < bytes.count { sum += UInt32(bytes[index + 1]) }
            index += 2
        }
        while sum >> 16 != 0 { sum = (sum & 0xFFFF) + (sum >> 16) }
        return ~UInt16(sum)
    }

    private static func put(_ value: UInt16, in bytes: inout [UInt8], at offset: Int) {
        bytes[offset] = UInt8(value >> 8)
        bytes[offset + 1] = UInt8(value & 0xFF)
    }

    private static func require(_ condition: @autoclosure () -> Bool, _ message: String) {
        if !condition() { fatalError(message) }
    }
}
