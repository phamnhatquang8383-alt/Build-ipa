#!/bin/bash
set -euo pipefail
root="$(cd "$(dirname "$0")/.." && pwd)"
scratch="$(mktemp -d "${TMPDIR:-/tmp}/viet99-tunnel-tests.XXXXXX")"
trap 'rm -rf "$scratch"' EXIT
swiftc -swift-version 5 -O "$root/Viet99Tunnel/LoopbackPacket.swift" \
    "$root/Tests/LoopbackPacketTests.swift" -o "$scratch/packets"
"$scratch/packets"
sed '/^import NetworkExtension$/d' "$root/Viet99Tunnel/PacketTunnelProvider.swift" > "$scratch/PacketTunnelProvider.swift"
swiftc -swift-version 5 -O "$root/Viet99Tunnel/LoopbackPacket.swift" \
    "$scratch/PacketTunnelProvider.swift" "$root/Tests/PacketTunnelLifecycleTests.swift" -o "$scratch/lifecycle"
"$scratch/lifecycle"
