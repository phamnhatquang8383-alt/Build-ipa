import Darwin
import Foundation

final class Locked<Value>: @unchecked Sendable {
    private let lock = NSLock()
    private var stored: Value
    init(_ value: Value) { stored = value }
    func withValue<Result>(_ action: (inout Value) -> Result) -> Result {
        lock.lock(); defer { lock.unlock() }; return action(&stored)
    }
    var value: Value { withValue { $0 } }
}
enum NEProviderStopReason { case userInitiated }
final class NEIPv4Route {
    let destinationAddress: String
    let subnetMask: String
    init(destinationAddress: String, subnetMask: String) { self.destinationAddress = destinationAddress; self.subnetMask = subnetMask }
    static func `default`() -> NEIPv4Route { NEIPv4Route(destinationAddress: "0.0.0.0", subnetMask: "0.0.0.0") }
}
final class NEIPv4Settings {
    let addresses: [String]
    let subnetMasks: [String]
    var includedRoutes: [NEIPv4Route]?
    var excludedRoutes: [NEIPv4Route]?
    init(addresses: [String], subnetMasks: [String]) { self.addresses = addresses; self.subnetMasks = subnetMasks }
}
final class NEPacketTunnelNetworkSettings {
    let tunnelRemoteAddress: String
    var ipv4Settings: NEIPv4Settings?
    var ipv6Settings: Any?
    var dnsSettings: Any?
    var proxySettings: Any?
    init(tunnelRemoteAddress: String) { self.tunnelRemoteAddress = tunnelRemoteAddress }
}
final class NEPacketTunnelFlow: @unchecked Sendable {
    typealias Read = ([Data], [NSNumber]) -> Void
    let reads = Locked<[Read]>([])
    let writes = Locked<[[Data]]>([])
    let writeFamilies = Locked<[[NSNumber]]>([])
    let writesSucceed = Locked(true)
    func readPackets(completionHandler: @escaping Read) { reads.withValue { $0.append(completionHandler) } }
    func writePackets(_ packets: [Data], withProtocols protocols: [NSNumber]) -> Bool {
        writes.withValue { $0.append(packets) }; writeFamilies.withValue { $0.append(protocols) }
        return writesSucceed.value
    }
    func takeRead() -> Read { reads.withValue { $0.removeFirst() } }
}
class NEPacketTunnelProvider: @unchecked Sendable {
    struct Request { let settings: NEPacketTunnelNetworkSettings?; let completion: (Error?) -> Void }
    let packetFlow = NEPacketTunnelFlow()
    let settingsRequests = Locked<[Request]>([])
    let cancellations = Locked<[Error?]>([])
    func startTunnel(options: [String: NSObject]?, completionHandler: @escaping (Error?) -> Void) {}
    func stopTunnel(with reason: NEProviderStopReason, completionHandler: @escaping () -> Void) {}
    func handleAppMessage(_ messageData: Data, completionHandler: ((Data?) -> Void)?) {}
    func setTunnelNetworkSettings(_ settings: NEPacketTunnelNetworkSettings?, completionHandler: @escaping (Error?) -> Void) {
        settingsRequests.withValue { $0.append(Request(settings: settings, completion: completionHandler)) }
    }
    func cancelTunnelWithError(_ error: Error?) { cancellations.withValue { $0.append(error) } }
}

@main enum PacketTunnelLifecycleTests {
    private static var count = 0
    private static func require(_ value: @autoclosure () -> Bool, _ message: String) {
        if !value() { fatalError(message) }; count += 1
    }
    private static func wait(_ condition: () -> Bool) {
        let deadline = Date(timeIntervalSinceNow: 2)
        while !condition() && deadline.timeIntervalSinceNow > 0 { Thread.sleep(forTimeInterval: 0.001) }
        require(condition(), "asynchronous fixture timed out")
    }
    private static func status(_ provider: PacketTunnelProvider) -> [String: Any] {
        let result = Locked<Data?>(nil)
        provider.handleAppMessage(Data("status".utf8)) { data in result.withValue { $0 = data } }
        wait { result.value != nil }
        return try! JSONSerialization.jsonObject(with: result.value!) as! [String: Any]
    }
    private static func packet() -> Data {
        var bytes = [UInt8](repeating: 0, count: 20)
        bytes[0] = 0x45; bytes[3] = 20; bytes[8] = 64; bytes[9] = 17
        bytes.replaceSubrange(12..<16, with: [10,7,1,1])
        bytes.replaceSubrange(16..<20, with: [10,7,0,1])
        return Data(bytes)
    }
    private static func start(_ provider: PacketTunnelProvider) -> Locked<[Error?]> {
        let replies = Locked<[Error?]>([])
        provider.startTunnel(options: ["peer": "8.8.8.8" as NSString]) { error in replies.withValue { $0.append(error) } }
        return replies
    }
    private static func stop(_ provider: PacketTunnelProvider) {
        let calls = Locked(0)
        provider.stopTunnel(with: .userInitiated) { calls.withValue { $0 += 1 } }
        wait { calls.value == 1 }
        require(status(provider)["state"] as? String == "stopped", "stop is serialized before completing")
    }
    static func main() {
        let provider = PacketTunnelProvider()
        let first = start(provider)
        wait { provider.settingsRequests.value.count == 1 }
        require(status(provider)["state"] as? String == "starting", "initial start waits for settings")
        let duplicate = start(provider)
        wait { duplicate.value.count == 1 }
        require((duplicate.value[0] as NSError?)?.code == 1 && provider.settingsRequests.value.count == 1, "duplicate startup does not install another configuration")
        stop(provider)
        require(first.value.count == 1 && (first.value[0] as NSError?)?.code == 2, "stop cancels pending start exactly once")
        provider.settingsRequests.value[0].completion(nil)
        require(status(provider)["state"] as? String == "stopped" && provider.packetFlow.reads.value.isEmpty, "late settings callback cannot revive stopped generation")
        require(first.value.count == 1, "late settings callback cannot complete start again")

        let second = start(provider)
        wait { provider.settingsRequests.value.count == 2 }
        let settings = provider.settingsRequests.value[1].settings!
        require(settings.tunnelRemoteAddress == "10.7.0.1", "caller options cannot replace local peer")
        require(settings.ipv4Settings?.addresses == ["10.7.1.1"] && settings.ipv4Settings?.subnetMasks == ["255.255.255.255"], "fixed /32 interface")
        let included = settings.ipv4Settings!.includedRoutes!
        require(included.count == 1 && included[0].destinationAddress == "10.7.0.1" && included[0].subnetMask == "255.255.255.255", "only peer /32 route is captured")
        let excluded = settings.ipv4Settings!.excludedRoutes!
        require(excluded.count == 1 && excluded[0].destinationAddress == "0.0.0.0" && excluded[0].subnetMask == "0.0.0.0", "default traffic remains excluded")
        require(settings.ipv6Settings == nil && settings.dnsSettings == nil && settings.proxySettings == nil, "no IPv6, DNS or proxy settings")
        provider.settingsRequests.value[1].completion(nil)
        wait { second.value.count == 1 && provider.packetFlow.reads.value.count == 1 }
        require(second.value[0] == nil && status(provider)["state"] as? String == "running", "configuration success starts one reader")
        provider.settingsRequests.value[1].completion(nil)
        require(status(provider)["state"] as? String == "running" && second.value.count == 1 && provider.packetFlow.reads.value.count == 1, "duplicate settings completion cannot start extra readers")
        let runningDuplicate = start(provider)
        wait { runningDuplicate.value.count == 1 }
        require((runningDuplicate.value[0] as NSError?)?.code == 1, "duplicate running start fails once")

        provider.packetFlow.takeRead()([packet(), packet()], [NSNumber(value: AF_INET)])
        wait { provider.packetFlow.writes.value.count == 1 && provider.packetFlow.reads.value.count == 1 }
        let counters = status(provider)
        require(counters["receivedPackets"] as? Int == 2 && counters["reflectedPackets"] as? Int == 1 && counters["droppedPackets"] as? Int == 1, "mismatched protocol counts drop only unmatched packet")
        require(provider.packetFlow.writes.value[0] == [LoopbackPacket.reflect(packet(), addressFamily: AF_INET)!], "provider writes validated reflected bytes")
        require(provider.packetFlow.writeFamilies.value[0].map(\.int32Value) == [AF_INET], "reflected family is IPv4")

        let staleRead = provider.packetFlow.takeRead()
        stop(provider)
        let third = start(provider)
        wait { provider.settingsRequests.value.count == 3 }
        provider.settingsRequests.value[2].completion(nil)
        wait { third.value.count == 1 && provider.packetFlow.reads.value.count == 1 }
        staleRead([packet()], [NSNumber(value: AF_INET)])
        let reset = status(provider)
        require(reset["receivedPackets"] as? Int == 0 && provider.packetFlow.writes.value.count == 1 && provider.packetFlow.reads.value.count == 1, "old read callback cannot process or rearm new generation")

        provider.packetFlow.writesSucceed.withValue { $0 = false }
        provider.packetFlow.takeRead()([packet()], [NSNumber(value: AF_INET)])
        wait { provider.cancellations.value.count == 1 }
        let failed = status(provider)
        require(failed["state"] as? String == "stopped" && failed["writeFailures"] as? Int == 1 && failed["reflectedPackets"] as? Int == 0 && failed["droppedPackets"] as? Int == 1, "write failure stops route and accounts unreturned packet")
        require((provider.cancellations.value[0] as NSError?)?.code == 3 && provider.packetFlow.reads.value.isEmpty, "write failure cancels tunnel without rearming reader")
        stop(provider)

        let configurationFailure = start(provider)
        wait { provider.settingsRequests.value.count == 4 }
        provider.settingsRequests.value[3].completion(NSError(domain: "fixture", code: 9))
        wait { configurationFailure.value.count == 1 }
        require((configurationFailure.value[0] as NSError?)?.code == 9 && status(provider)["state"] as? String == "stopped", "configuration failure is propagated and stops startup")

        provider.packetFlow.writesSucceed.withValue { $0 = true }
        let empty = start(provider)
        wait { provider.settingsRequests.value.count == 5 }
        provider.settingsRequests.value[4].completion(nil)
        wait { empty.value.count == 1 && provider.packetFlow.reads.value.count == 1 }
        provider.packetFlow.takeRead()([], [])
        stop(provider)
        Thread.sleep(forTimeInterval: 0.03)
        require(provider.packetFlow.reads.value.isEmpty, "delayed empty-batch retry cannot rearm after stop")
        let unknownReply = Locked(false)
        provider.handleAppMessage(Data("other".utf8)) { data in unknownReply.withValue { $0 = data == nil } }
        require(unknownReply.value, "unknown app message returns nil without changing state")
        print("\(count) packet-tunnel lifecycle checks passed (mock NetworkExtension only)")
    }
}
