#import <Foundation/Foundation.h>
#import <stdio.h>
#define VVDIRECT_CATALOG_TESTING 1
#define VVDIRECT_PROVIDER_TESTING 1
#import "../CC365-Apps/Files/LegacyDirect/VVDirectFileSystem.m"
#import "../CC365-Apps/Files/LegacyDirect/VVDirectContainerCatalog.m"
static BOOL ready;
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Wincomplete-implementation"
@implementation VVLegacyDirectAccess
+ (BOOL)isReady { return ready; }
@end
#pragma clang diagnostic pop
dispatch_queue_t BQWorkQueue(void) { static dispatch_queue_t q; static dispatch_once_t once; dispatch_once(&once, ^{ q=dispatch_queue_create("direct.file.fixtures", 0); }); return q; }
void BQLog(NSString *format, ...) {}
static NSString *fixture;
static NSUInteger catalogRootRequests;
NSString *VVDirectTestDocuments(void) { return [fixture stringByAppendingPathComponent:@"Workspace"]; }
NSDictionary *VVDirectTestRoots(void) {
    catalogRootRequests++;
    return @{@"app":[fixture stringByAppendingPathComponent:@"Application"],
        @"plugin":[fixture stringByAppendingPathComponent:@"Plugin"],
        @"group":[fixture stringByAppendingPathComponent:@"Group"],
        @"system":[fixture stringByAppendingPathComponent:@"System"]};
}
NSString *VVDirectTestBundleRoot(void) { return [fixture stringByAppendingPathComponent:@"Bundle"]; }
static NSUInteger checks;
static void Check(BOOL ok, NSString *message) { if (!ok) { fprintf(stderr,"FAIL %s\n",message.UTF8String); exit(1); } checks++; }
static void Directory(NSString *path) { Check([NSFileManager.defaultManager createDirectoryAtPath:path withIntermediateDirectories:YES attributes:@{NSFilePosixPermissions:@0700} error:NULL], @"create own fixture"); }
static void Plist(NSString *directory, NSString *name, NSDictionary *value) {
    NSData *data=[NSPropertyListSerialization dataWithPropertyList:value format:NSPropertyListBinaryFormat_v1_0 options:0 error:NULL];
    Check([data writeToFile:[directory stringByAppendingPathComponent:name] options:NSDataWritingAtomic error:NULL], @"write fixture metadata");
}
int main(void) { @autoreleasepool {
    NSString *initial=[NSTemporaryDirectory() stringByAppendingPathComponent:[@"vv-direct-provider-" stringByAppendingString:NSUUID.UUID.UUIDString]];
    Directory(initial); char *physical=realpath(initial.fileSystemRepresentation,NULL); fixture=[NSString stringWithUTF8String:physical]; free(physical);
    for (NSString *path in VVDirectTestRoots().allValues) Directory(path);
    Directory(VVDirectTestDocuments());
    Directory(VVDirectTestBundleRoot());
    NSString *one=[VVDirectTestRoots()[@"app"] stringByAppendingPathComponent:NSUUID.UUID.UUIDString]; Directory(one);
    Plist(one,@".com.apple.mobile_container_manager.metadata.plist",@{@"MCMMetadataIdentifier":@"com.example.one"});
    NSString *bundle=[[[VVDirectTestBundleRoot() stringByAppendingPathComponent:NSUUID.UUID.UUIDString] stringByAppendingPathComponent:@"One.app"] copy]; Directory(bundle);
    Plist(bundle,@"Info.plist",@{@"CFBundleIdentifier":@"com.example.one",@"CFBundleDisplayName":@"App One"});
    NSError *error=nil; NSProgress *progress=[NSProgress progressWithTotalUnitCount:1]; __block NSUInteger calls=0;
    ready=NO;
    Check(![VVDirectFileSystem withDirectory:one progress:progress operation:^BOOL(NSString *path,NSError **e){ calls++; return YES; } error:&error] && calls==0,
        @"not-ready protected request never invokes operation");
    NSString *notice=nil;
    Check(VVDirectDiscoverContainers(nil,&notice).count==0 && notice.length, @"not-ready catalog performs no discovery");
    Check([VVDirectFileSystem request:@{@"action":@"list",@"path":@"/"} progress:progress error:&error]!=nil,
        @"location landing remains available before setup");
    ready=YES;
    catalogRootRequests=0;
    NSDictionary *localCheck=[VVDirectFileSystem request:@{@"action":@"check"} progress:progress error:&error];
    Check([localCheck[@"exactBytesRecovered"] boolValue] && [localCheck[@"cleanupComplete"] boolValue] && catalogRootRequests==0,
        @"workspace check verifies and cleans its own bytes without any catalog discovery");
    Check([NSFileManager.defaultManager contentsOfDirectoryAtPath:VVDirectTestDocuments() error:NULL].count==0,
        @"local check leaves the workspace empty");
    Check([VVDirectFileSystem withDirectory:one progress:progress operation:^BOOL(NSString *path,NSError **e){ calls++; return [path isEqual:VVCanonical(one)]; } error:&error] && calls==1,
        @"ready operation uses exact direct root once");
    calls=0;
    Check(![VVDirectFileSystem withDirectory:one progress:progress operation:^BOOL(NSString *path,NSError **e){
        calls++; *e=[NSError errorWithDomain:NSPOSIXErrorDomain code:EPERM userInfo:@{VVDirectRetrySafeKey:@YES}]; return NO;
    } error:&error] && calls==1 && error.code==EPERM, @"permission failure never retries or invokes another provider");
    Check(![VVDirectFileSystem withDirectory:[one stringByAppendingPathComponent:@"missing"] progress:progress operation:^BOOL(NSString *p,NSError **e){ calls++;return YES; } error:&error] && calls==1,
        @"missing root fails before callback");
    [progress cancel];
    Check(![VVDirectFileSystem withDirectory:one progress:progress operation:^BOOL(NSString *p,NSError **e){ calls++;return YES; } error:&error] && calls==1,
        @"canceled request never enters direct operation");
    progress=[NSProgress progressWithTotalUnitCount:1];
    NSArray<VVDirectContainerEntry *> *rows=VVDirectDiscoverContainers(nil,&notice);
    Check(rows.count==1 && [rows.firstObject.identifier isEqual:@"com.example.one"] && [rows.firstObject.path isEqual:one], @"catalog binds identity only from observed container metadata");
    Check([rows.firstObject.name isEqual:@"App One"] && [rows.firstObject.bundlePath isEqual:bundle], @"friendly name joins exact observed bundle identifier");
    NSDictionary *resolved=VVDirectResolveApplicationTarget(@"com.example.one",nil,&error);
    Check([resolved[@"data_path"] isEqual:one] && [resolved[@"target_id"] isEqual:[@"path:" stringByAppendingString:one]], @"resolver returns exact observed root");
    NSString *unknown=[VVDirectTestRoots()[@"app"] stringByAppendingPathComponent:NSUUID.UUID.UUIDString]; Directory(unknown);
    rows=VVDirectDiscoverContainers(nil,NULL);
    NSPredicate *unknownPredicate=[NSPredicate predicateWithBlock:^BOOL(VVDirectContainerEntry *entry,NSDictionary *bindings){ return [entry.path isEqual:unknown]; }];
    VVDirectContainerEntry *unknownEntry=[[rows filteredArrayUsingPredicate:unknownPredicate] firstObject];
    Check(unknownEntry && !unknownEntry.identifier.length && [unknownEntry.name hasPrefix:@"Container "], @"unknown container never invents an owner");
    Plist(unknown,@".com.apple.mobile_container_manager.metadata.plist",@{@"MCMMetadataIdentifier":@"com.example.one"});
    Check(!VVDirectResolveApplicationTarget(@"com.example.one",nil,&error) && error.code==2, @"duplicate owner in distinct roots is a conflict");
    Plist(unknown,@".com.apple.mobile_container_manager.metadata.plist",@{@"MCMMetadataIdentifier":@"com.example.two"});
    resolved=VVDirectResolveApplicationTarget(@"com.example.two",nil,&error);
    Check([resolved[@"data_path"] isEqual:unknown], @"fresh scan observes changed metadata rather than caching target root");
    NSString *link=[VVDirectTestRoots()[@"app"] stringByAppendingPathComponent:NSUUID.UUID.UUIDString];
    Check([NSFileManager.defaultManager createSymbolicLinkAtPath:link withDestinationPath:one error:NULL], @"create fixture alias");
    Check(VVDirectDiscoverContainers(nil,NULL).count==2, @"symlink container is excluded from identity mapping");
    Check(!VVDirectResolveApplicationTarget(@"com.example.one",^BOOL{return YES;},&error) && error.code==NSUserCancelledError, @"cancellation cannot return an identity");
    NSUInteger budget=4;
    int fd=VVOpenRoot(one);
    Check(!VVReadPlist(fd,".com.apple.mobile_container_manager.metadata.plist",&budget,nil,NSProcessInfo.processInfo.systemUptime+1) && budget==4,
        @"metadata budget enforced before allocating or reading bytes");
    close(fd);
    NSString *info=[bundle stringByAppendingPathComponent:@"Info.plist"];
    [NSFileManager.defaultManager removeItemAtPath:info error:NULL];
    Check([NSFileManager.defaultManager createSymbolicLinkAtPath:info withDestinationPath:[one stringByAppendingPathComponent:@".com.apple.mobile_container_manager.metadata.plist"] error:NULL], @"create metadata symlink fixture");
    rows=VVDirectDiscoverContainers(nil,NULL);
    VVDirectContainerEntry *first=[[rows filteredArrayUsingPredicate:[NSPredicate predicateWithBlock:^BOOL(VVDirectContainerEntry *entry,NSDictionary *bindings){return [entry.path isEqual:one];}]] firstObject];
    Check([first.name isEqual:@"com.example.one"] && !first.bundlePath, @"symlink bundle metadata cannot grant bundle path or name");
    [NSFileManager.defaultManager removeItemAtPath:fixture error:NULL];
    printf("%lu direct provider checks passed (own temporary fixtures only)\n",(unsigned long)checks);
    return 0;
} }
