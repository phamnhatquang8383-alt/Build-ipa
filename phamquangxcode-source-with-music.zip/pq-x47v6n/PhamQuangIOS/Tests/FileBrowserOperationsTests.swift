import Foundation

struct PatchInputError: LocalizedError { let errorDescription: String?; init(_ text: String) { errorDescription = text } }
struct DeviceFileEntry { let name: String; let kind: String; let path: String? }
struct DeviceFilesPage { let entries: [DeviceFileEntry]; let nextOffset: Int?; let notice: String? }
struct DeviceFileDetails { let inode: UInt64; let modified: Int64; let kind: String; let size: UInt64 }
@MainActor enum VersionedFilesTransport {
    static var workspace = URL(fileURLWithPath: "/unused")
    static var incomplete = false
    static func url(_ path: String) -> URL {
        path.hasPrefix("/CC365/") ? workspace.appendingPathComponent(String(path.dropFirst(7))) : URL(fileURLWithPath: path)
    }
    static func details(path: String) async throws -> DeviceFileDetails {
        let value = try FileManager.default.attributesOfItem(atPath: url(path).path)
        let type = value[.type] as? FileAttributeType
        return DeviceFileDetails(inode: (value[.systemFileNumber] as? NSNumber)?.uint64Value ?? 0,
            modified: Int64((value[.modificationDate] as? Date)?.timeIntervalSince1970 ?? 0),
            kind: type == .typeDirectory ? "directory" : type == .typeRegular ? "file" : "symlink",
            size: (value[.size] as? NSNumber)?.uint64Value ?? 0)
    }
    static func list(path: String, offset: Int) async throws -> DeviceFilesPage {
        let children = try FileManager.default.contentsOfDirectory(at: url(path), includingPropertiesForKeys: nil).sorted { $0.path < $1.path }
        let end = min(offset + 2, children.count)
        var entries: [DeviceFileEntry] = []
        for child in children.dropFirst(offset).prefix(end - offset) {
            let childPath = path + "/" + child.lastPathComponent
            entries.append(DeviceFileEntry(name: child.lastPathComponent, kind: try await details(path: childPath).kind, path: childPath))
        }
        return DeviceFilesPage(entries: entries, nextOffset: end < children.count ? end : nil, notice: incomplete ? "partial fixture" : nil)
    }
    static func download(path: String, to local: URL) async throws { _ = try FileTransferSupport.copyRegularFile(from: url(path), to: local, limit: FileTransferSupport.maxSize) }
    static func uploadTree(local: URL, to path: String) async throws {


        try await Task.sleep(for: .milliseconds(1))
        try FileManager.default.copyItem(at: local, to: url(path))
    }
    static func upload(local: URL, parent: String, name: String) async throws -> String? {
        try await Task.sleep(for: .milliseconds(1))
        try FileManager.default.copyItem(at: local, to: url(parent + "/" + name)); return nil
    }
}

@MainActor @main struct FileBrowserOperationsTests {
    static var count = 0
    static func check(_ value: Bool, _ label: String) { precondition(value, label); count += 1; print("PASS " + label) }
    static func rejects(_ label: String, _ body: () async throws -> Void) async {
        do { try await body(); preconditionFailure(label) } catch { count += 1; print("PASS " + label) }
    }
    static func main() async throws {
        let fm = FileManager.default
        let root = fm.temporaryDirectory.appendingPathComponent("browser-tests-" + UUID().uuidString)
        defer { try? fm.removeItem(at: root) }
        let folder = root.appendingPathComponent("Source")
        try fm.createDirectory(at: folder.appendingPathComponent("empty"), withIntermediateDirectories: true)
        try Data([1, 2, 3]).write(to: folder.appendingPathComponent(".hidden"))
        try Data().write(to: folder.appendingPathComponent("zero"))
        try Data("café".utf8).write(to: folder.appendingPathComponent("café.txt"))
        VersionedFilesTransport.workspace = root.appendingPathComponent("Workspace")
        try fm.createDirectory(at: VersionedFilesTransport.workspace, withIntermediateDirectories: false)
        let settings = AppFileSettings(compressionLevel: 6, workMode: .balanced)
        let captured = try await FileBrowserOperations.snapshot(path: folder.path, isDirectory: true)
        check(captured.fileCount == 3 && captured.bytes == 8, "snapshot-spans-all-pages-and-counts-real-bytes")
        check(fm.fileExists(atPath: captured.item.file.appendingPathComponent("empty").path), "snapshot-preserves-empty-directory")
        check(try Data(contentsOf: captured.item.file.appendingPathComponent(".hidden")) == Data([1, 2, 3]), "snapshot-preserves-hidden-file")
        let archive = try await FileBrowserOperations.buildArchive(snapshot: captured, name: "Archive.zip", settings: settings)
        let unpacked = try await FileBrowserOperations.extractArchive(archive.file, settings: settings)
        let result = unpacked.file.appendingPathComponent("Source")
        check(try Data(contentsOf: result.appendingPathComponent(".hidden")) == Data([1, 2, 3]), "actual-zip-roundtrip-hidden-bytes")
        check(fm.fileExists(atPath: result.appendingPathComponent("empty").path), "actual-zip-roundtrip-empty-directory")
        check(try Data(contentsOf: result.appendingPathComponent("zero")).isEmpty, "actual-zip-roundtrip-zero-file")
        check(try String(contentsOf: result.appendingPathComponent("café.txt"), encoding: .utf8) == "café", "actual-zip-roundtrip-unicode-name-and-text")
        try await FileBrowserOperations.copy(path: folder.path, isDirectory: true, to: "/CC365", name: "Copied")
        check(fm.fileExists(atPath: VersionedFilesTransport.workspace.appendingPathComponent("Copied/empty").path), "copy-service-retains-snapshot-through-suspended-url-only-publish")
        await rejects("copy-does-not-overwrite-existing-destination") { try await FileBrowserOperations.copy(path: folder.path, isDirectory: true, to: "/CC365", name: "Copied") }
        await rejects("copy-refuses-external-destination") { try await FileBrowserOperations.copy(path: folder.path, isDirectory: true, to: root.path, name: "Outside") }
        try await FileBrowserOperations.compress(path: folder.path, isDirectory: true, to: "/CC365", name: "Packed.zip", settings: settings)
        try await FileBrowserOperations.extract(path: "/CC365/Packed.zip", to: "/CC365", name: "Unpacked", settings: settings)
        check(try Data(contentsOf: VersionedFilesTransport.workspace.appendingPathComponent("Unpacked/Source/.hidden")) == Data([1, 2, 3]), "zip-services-retain-scratch-through-suspended-url-only-publication")
        VersionedFilesTransport.incomplete = true
        await rejects("partial-directory-is-never-silently-copied") { _ = try await FileBrowserOperations.snapshot(path: folder.path, isDirectory: true) }
        VersionedFilesTransport.incomplete = false
        try fm.createSymbolicLink(at: folder.appendingPathComponent("link"), withDestinationURL: root)
        await rejects("snapshot-rejects-symlink-entry") { _ = try await FileBrowserOperations.snapshot(path: folder.path, isDirectory: true) }
        try fm.removeItem(at: folder.appendingPathComponent("link"))
        try fm.createDirectory(at: root.appendingPathComponent("Empty"), withIntermediateDirectories: false)
        let empty = try await FileBrowserOperations.snapshot(path: root.appendingPathComponent("Empty").path, isDirectory: true)
        let emptyZip = try await FileBrowserOperations.buildArchive(snapshot: empty, name: "Empty.zip", settings: .init(compressionLevel: 0, workMode: .eco))
        let emptyOutput = try await FileBrowserOperations.extractArchive(emptyZip.file, settings: .init(compressionLevel: 9, workMode: .fast))
        check(empty.fileCount == 0 && fm.fileExists(atPath: emptyOutput.file.appendingPathComponent("Empty").path), "empty-folder-archive-is-valid")
        let cancelled = Task { try await Task.sleep(for: .seconds(1)); return try await FileBrowserOperations.buildArchive(snapshot: captured, name: "Cancelled.zip", settings: settings) }
        cancelled.cancel()
        await rejects("cancelled-archive-operation-returns-no-output") { _ = try await cancelled.value }
        check(fm.fileExists(atPath: folder.appendingPathComponent("café.txt").path), "operations-preserve-original-source")
        print("\(count) browser operation checks passed; native I/O is mocked, ZIP writer/extractor are real.")
    }
}
