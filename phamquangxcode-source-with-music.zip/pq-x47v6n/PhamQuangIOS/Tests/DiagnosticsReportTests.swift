import Foundation

@main struct DiagnosticsReportTests {
    static func main() {
        let generatedAt = Date(timeIntervalSince1970: 0)
        let input = DiagnosticsReportInput(
            generatedAt: generatedAt,
            appVersion: "1.4.1 (8)",
            osVersion: "iOS 18.0.0",
            modeTitle: "AirLift",
            supportedVersions: "fixture versions",
            status: "Sẵn sàng",
            pairing: "Đã nhập",
            freeSpace: "10 GB",
            totalSpace: "64 GB"
        )
        let text = DiagnosticsReport.text(input)
        let lines = text.components(separatedBy: "\n")

        precondition(!text.contains("\\n"), "Report must not contain a literal backslash-n")
        precondition(!text.contains("\r"), "Report must use LF line endings only")
        precondition(lines.count == 12, "Report has 12 lines including the blank separator")
        precondition(lines[0] == "PhamQuang IOS — Báo cáo chẩn đoán", "Title line")
        precondition(lines[1] == "Thời gian: " + ISO8601DateFormatter().string(from: generatedAt), "Timestamp line")
        precondition(lines[2] == "Phiên bản ứng dụng: 1.4.1 (8)", "App version line")
        precondition(lines[3] == "Hệ điều hành: iOS 18.0.0", "OS line")
        precondition(lines[4] == "Chế độ truy cập: AirLift", "Mode line")
        precondition(lines[5] == "Dải phiên bản: fixture versions", "Supported versions line")
        precondition(lines[6] == "Trạng thái: Sẵn sàng", "Status line")
        precondition(lines[7] == "Pairing AirLift: Đã nhập", "Pairing line")
        precondition(lines[8] == "Dung lượng trống: 10 GB", "Free space line")
        precondition(lines[9] == "Tổng dung lượng: 64 GB", "Total space line")
        precondition(lines[10].isEmpty, "Blank separator line")
        precondition(lines[11] == DiagnosticsReport.privacyFooter, "Privacy footer is the last line")
        precondition(!text.hasSuffix("\n"), "Report must not end with a newline")
        print("DiagnosticsReportTests: all checks passed")
    }
}
