#!/bin/bash
set -euo pipefail
cd "$(dirname "$0")/.."
test_build="${BUILD_DIR:-$PWD/build}/Tests"
mkdir -p "$test_build"
xcrun --sdk macosx clang -fobjc-arc -fblocks -Wall -Wextra -Werror \
  -I CC365-Apps/Files/BQCore Tests/BQLSStoreParserTests.m \
  CC365-Apps/Files/BQCore/BQLSStoreParser.m -framework Foundation \
  -o "$test_build/BQLSStoreParserTests"
"$test_build/BQLSStoreParserTests"
