import Foundation

@MainActor @main struct AppPatchPlanTests {
    static var checks = 0
    static func check(_ value: Bool, _ label: String) {
        precondition(value, label); checks += 1; print("PASS " + label)
    }
    static func reject(_ label: String, _ operation: () throws -> Void) {
        do { try operation(); preconditionFailure("Expected rejection: " + label) }
        catch { checks += 1; print("PASS " + label) }
    }
    static func rejectAsync(_ label: String, _ operation: () async throws -> Void) async {
        do { try await operation(); preconditionFailure("Expected rejection: " + label) }
        catch { checks += 1; print("PASS " + label) }
    }
    static func write(_ root: URL, _ relative: String, _ bytes: Data = Data([1, 2, 3])) throws -> URL {
        let file = root.appendingPathComponent(relative)
        try FileManager.default.createDirectory(at: file.deletingLastPathComponent(), withIntermediateDirectories: true)
        try bytes.write(to: file)
        return file
    }
    static func main() async throws {
        let fm = FileManager.default
        let scratch = fm.temporaryDirectory.appendingPathComponent("plan-tests-" + UUID().uuidString)
        defer { try? fm.removeItem(at: scratch) }
        let targetRoot = "/var/mobile/Containers/Data/Application/11111111-2222-4333-8444-555555555555"
        let app = PatchTargetApp(bundleID: "com.example.game", name: "Game", bundlePath: "/fixture/Game.app",
            dataPath: targetRoot, targetID: "path:" + targetRoot)
        let fileURL = try write(scratch, "one.bin")
        let emptyURL = try write(scratch, "empty.bin", Data())
        let file = try await AppPatchSource.stage(fileURL)
        let zero = try await AppPatchSource.stage(emptyURL)
        let folderURL = scratch.appendingPathComponent("folder")
        _ = try write(folderURL, "nested/a", Data([4]))
        _ = try write(folderURL, "b", Data([5, 6]))
        let folder = try await AppPatchSource.stage(folderURL)
        var plan = AppPatchPlan(app: app, scope: .data, entries: [
            .init(source: file, destination: "Documents/one.bin"),
            .init(source: folder, destination: "Documents/Assets"),
            .init(source: zero, destination: "Library/Caches/empty.bin")
        ])
        try plan.validateSources()
        let combined = try plan.mappings(app: app, scope: .data)
        check(combined.map(\.destination) == ["Documents/one.bin", "Documents/Assets/b", "Documents/Assets/nested/a", "Library/Caches/empty.bin"],
              "file-folder-and-zero-byte-cache-source-combine-for-one-target")
        check(plan.fileCount == 4 && plan.size == 6 && combined.reduce(0, { $0 + $1.size }) == plan.size, "aggregate-count-and-size-cover-all-sources")
        check(try plan.declaredBundleID() == nil, "manual-sources-do-not-fabricate-bundle-owner")
        check(try Data(contentsOf: combined[1].local) == Data([5, 6]), "folder-files-retain-staged-byte-content")

        let originalEntries = plan.entries.map(\.id)
        var candidate = plan
        candidate.entries[0].destination = ""
        try candidate.validateSources()
        reject("unfinished-manual-destination-blocks-mappings-not-source-addition") { _ = try candidate.mappings(app: app, scope: .data) }
        check(plan.entries.map(\.id) == originalEntries && plan.entries[0].destination == "Documents/one.bin", "candidate-edit-does-not-mutate-current-plan")
        candidate = plan
        candidate.entries.append(.init(source: file, destination: "Documents/ONE.bin"))
        reject("case-equivalent-destinations-across-entries-rejected") { _ = try candidate.mappings(app: app, scope: .data) }
        candidate = AppPatchPlan(app: app, scope: .data, entries: [
            .init(source: file, destination: "Documents/café"), .init(source: zero, destination: "Documents/cafe\u{301}")])
        reject("unicode-equivalent-destinations-across-entries-rejected") { _ = try candidate.mappings(app: app, scope: .data) }
        candidate = AppPatchPlan(app: app, scope: .data, entries: [
            .init(source: folder, destination: "Documents/Assets"), .init(source: file, destination: "Documents/Assets")])
        reject("folder-child-and-file-parent-collision-rejected") { _ = try candidate.mappings(app: app, scope: .data) }
        candidate = AppPatchPlan(app: app, scope: .data, entries: [
            .init(source: folder, destination: "Documents/Assets"), .init(source: folder, destination: "Documents/Assets")])
        reject("overlapping-folder-mappings-rejected") { _ = try candidate.mappings(app: app, scope: .data) }
        candidate = plan
        candidate.entries.append(candidate.entries[0])
        reject("duplicate-entry-identity-rejected") { try candidate.validateSources() }

        let changedRoot = PatchTargetApp(bundleID: app.bundleID, name: app.name, bundlePath: app.bundlePath,
            dataPath: targetRoot + "-reinstalled", targetID: app.targetID)
        reject("same-target-id-with-reinstalled-root-rejected") { _ = try plan.mappings(app: changedRoot, scope: .data) }
        let changedID = PatchTargetApp(bundleID: app.bundleID, name: app.name, bundlePath: app.bundlePath,
            dataPath: app.dataPath, targetID: "path:other")
        reject("same-root-with-different-target-id-rejected") { _ = try plan.mappings(app: changedID, scope: .data) }
        let changedOwner = PatchTargetApp(bundleID: "com.other.owner", name: app.name, bundlePath: app.bundlePath,
            dataPath: app.dataPath, targetID: app.targetID)
        reject("known-owner-change-rejected") { _ = try plan.mappings(app: changedOwner, scope: .data) }
        reject("scope-change-rejected") { _ = try plan.mappings(app: app, scope: .bundle) }
        let renamed = PatchTargetApp(bundleID: app.bundleID, name: "New friendly name", bundlePath: app.bundlePath,
            dataPath: app.dataPath, targetID: app.targetID)
        check(try plan.mappings(app: renamed, scope: .data).count == 4, "display-name-change-does-not-change-target-binding")

        let ownedRoot = scratch.appendingPathComponent("owned")
        _ = try write(ownedRoot, "Application/com.example.game/Documents/owned.bin", Data([7]))
        let owned = try await AppPatchSource.stage(ownedRoot)
        let otherRoot = scratch.appendingPathComponent("foreign")
        _ = try write(otherRoot, "Application/com.other.app/Documents/foreign.bin")
        let foreign = try await AppPatchSource.stage(otherRoot)
        candidate = AppPatchPlan(app: app, scope: .data, entries: [.init(source: owned, destination: ""), .init(source: file, destination: "Documents/manual.bin")])
        check(try candidate.declaredBundleID() == app.bundleID && candidate.mappings(app: app, scope: .data).count == 2,
              "owned-and-manual-sources-combine-with-one-declared-owner")
        candidate.entries.append(.init(source: foreign, destination: ""))
        reject("conflicting-declared-owners-rejected") { _ = try candidate.declaredBundleID() }
        reject("foreign-source-rejected-before-candidate-commit") { try candidate.validateSources() }
        candidate = AppPatchPlan(app: app, scope: .data, entries: [.init(source: foreign, destination: "")])
        reject("single-foreign-owner-cannot-enter-bound-plan") { try candidate.validateSources() }

        let archive = scratch.appendingPathComponent("same-owner.vailon")
        let zip = Process()
        zip.executableURL = URL(fileURLWithPath: "/usr/bin/zip")
        zip.currentDirectoryURL = ownedRoot
        zip.arguments = ["-qr", archive.path, "Application"]
        try zip.run(); zip.waitUntilExit(); precondition(zip.terminationStatus == 0)
        let zipped = try await AppPatchSource.stage(archive)
        candidate = AppPatchPlan(app: app, scope: .data, entries: [.init(source: zipped, destination: ""), .init(source: folder, destination: "Library/Caches/assets")])
        check(try candidate.mappings(app: app, scope: .data).count == 3, "actual-vailon-and-folder-combine-without-changing-archive-format")

        let unknown = PatchTargetApp(bundleID: nil, name: "Container", bundlePath: nil, dataPath: app.dataPath, targetID: app.targetID)
        let explicit = try owned.binding(toObservedContainer: unknown)
        var explicitPlan = AppPatchPlan(app: unknown, scope: .data, entries: [.init(source: explicit, destination: "")])
        check(try explicitPlan.mappings(app: unknown, scope: .data).count == 1 && explicitPlan.declaredBundleID() == app.bundleID,
              "explicit-unknown-container-binding-retained-with-declaration-only")
        let secondOwnedRoot = scratch.appendingPathComponent("second-owned")
        _ = try write(secondOwnedRoot, "Application/com.example.game/Library/Caches/second.bin")
        let secondArchive = scratch.appendingPathComponent("second-owned.vailon")
        let secondZip = Process()
        secondZip.executableURL = URL(fileURLWithPath: "/usr/bin/zip")
        secondZip.currentDirectoryURL = secondOwnedRoot
        secondZip.arguments = ["-qr", secondArchive.path, "Application"]
        try secondZip.run(); secondZip.waitUntilExit(); precondition(secondZip.terminationStatus == 0)
        let secondConfirmed = try await explicitPlan.stageSource(secondArchive, expectDirectory: false)
        check(secondConfirmed.usesExplicitContainerSelection && secondConfirmed.embeddedBundleID == app.bundleID,
              "same-owner-second-vailon-inherits-existing-explicit-confirmation")
        var confirmedCandidate = explicitPlan
        confirmedCandidate.entries.append(.init(source: secondConfirmed, destination: ""))
        try confirmedCandidate.validateSources()
        check(try confirmedCandidate.mappings(app: unknown, scope: .data).map(\.destination) == ["Documents/owned.bin", "Library/Caches/second.bin"],
              "same-owner-confirmed-container-combines-second-archive")
        await rejectAsync("foreign-owner-replacement-cannot-change-sole-confirmed-owner") {
            _ = try await explicitPlan.stageSource(otherRoot, expectDirectory: true)
        }
        check(try explicitPlan.declaredBundleID() == app.bundleID && explicitPlan.entries.count == 1,
              "rejected-source-preserves-current-confirmed-plan")
        let unconfirmedPlan = AppPatchPlan(app: unknown, scope: .data)
        await rejectAsync("unknown-container-without-explicit-confirmation-rejects-owned-archive") {
            _ = try await unconfirmedPlan.stageSource(secondArchive, expectDirectory: false)
        }
        let manualStaged = try await explicitPlan.stageSource(fileURL, expectDirectory: false)
        check(!manualStaged.hasEmbeddedDestinations && manualStaged.embeddedBundleID == nil,
              "plain-file-added-to-confirmed-plan-keeps-manual-destination")
        let automaticRoot = scratch.appendingPathComponent("unowned-layout")
        _ = try write(automaticRoot, "Documents/unowned.bin")
        let automatic = try await explicitPlan.stageSource(automaticRoot, expectDirectory: true)
        check(automatic.hasEmbeddedDestinations && automatic.embeddedBundleID == nil,
              "unowned-documents-layout-keeps-automatic-selected-target-mapping")
        check(try automatic.mappings(destination: "", app: unknown, scope: .data).map(\.destination) == ["Documents/unowned.bin"],
              "unowned-layout-path-is-not-prefixed-or-remapped")
        let secondRoot = "/var/mobile/Containers/Data/Application/AAAAAAAA-BBBB-4CCC-8DDD-EEEEEEEEEEEE"
        let secondUnknown = PatchTargetApp(bundleID: nil, name: "Other", bundlePath: nil, dataPath: secondRoot, targetID: "path:" + secondRoot)
        let separatelyBound = try owned.binding(toObservedContainer: secondUnknown)
        explicitPlan.entries.append(.init(source: separatelyBound, destination: ""))
        reject("sources-bound-to-different-observed-roots-cannot-combine") { try explicitPlan.validateSources() }

        let emptyPlan = AppPatchPlan(app: app, scope: .data)
        try emptyPlan.validateSources()
        check(emptyPlan.fileCount == 0 && emptyPlan.size == 0, "empty-draft-can-be-edited")
        reject("empty-draft-cannot-apply") { _ = try emptyPlan.mappings(app: app, scope: .data) }
        let zeroPlan = AppPatchPlan(app: app, scope: .data, entries: [.init(source: zero, destination: "Documents/zero")])
        check(try zeroPlan.mappings(app: app, scope: .data).first?.size == 0, "zero-byte-file-is-valid-not-empty-plan")
        candidate = AppPatchPlan(app: app, scope: .data, entries: (0..<513).map { .init(source: folder, destination: "Documents/\($0)") })
        reject("effective-file-budget-spans-all-entries") { try candidate.validateSources() }
        let medium = try write(scratch, "eight-mib.bin", Data(repeating: 1, count: 8 * 1024 * 1024))
        let mediumSource = try await AppPatchSource.stage(medium)
        candidate = AppPatchPlan(app: app, scope: .data, entries: (0..<33).map { .init(source: mediumSource, destination: "Documents/\($0)") })
        reject("global-byte-budget-cannot-reset-for-each-source") { try candidate.validateSources() }
        candidate.entries.removeLast()
        try candidate.validateSources()
        check(candidate.size == AppPatchSource.total, "global-byte-boundary-accepted")


        do {
            let absent = try await AppPatchSource.stage(scratch.appendingPathComponent("missing.bin"))
            plan.entries.append(.init(source: absent, destination: "Documents/missing"))
            preconditionFailure("Missing source unexpectedly imported")
        } catch { check(plan.entries.map(\.id) == originalEntries, "failed-stage-preserves-existing-source-list") }
        try await lifetime(app: app, file: fileURL)
        print("\(checks) same-app patch plan checks passed; all imports are local fixtures.")
    }

    static func lifetime(app: PatchTargetApp, file: URL) async throws {
        var editing = AppPatchPlan(app: app, scope: .data, entries: [
            .init(source: try await AppPatchSource.stage(file), destination: "Documents/snapshot")])
        let payload = editing.entries[0].source.files[0].local
        let snapshotDirectory = payload.deletingLastPathComponent()
        var applying: AppPatchPlan? = editing
        editing.entries.removeAll()
        check(FileManager.default.fileExists(atPath: payload.path), "active-plan-retains-source-after-editor-removes-row")
        let mappings = try applying!.mappings(app: app, scope: .data)
        check(try Data(contentsOf: mappings[0].local) == Data([1, 2, 3]), "retained-apply-plan-still-reads-original-payload")
        applying = nil
        check(!FileManager.default.fileExists(atPath: snapshotDirectory.path), "last-plan-release-cleans-only-owned-scratch")
        check(FileManager.default.fileExists(atPath: file.path), "source-removal-never-deletes-user-original")
    }
}
