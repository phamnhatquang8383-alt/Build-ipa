#!/bin/bash
set -euo pipefail
cd "$(dirname "$0")/.."
progress_build="${BUILD_DIR:-$PWD/build}"
mkdir -p "$progress_build/Tests"
xcrun --sdk macosx swiftc -O -swift-version 5 -strict-concurrency=complete -warnings-as-errors \
  CC365-Apps/Platform/RustCore.swift CC365-Apps/Files/PatchProgressFeed.swift \
  Tests/PatchProgressFeedTests.swift -o "$progress_build/Tests/PatchProgressFeedTests"
"$progress_build/Tests/PatchProgressFeedTests"
