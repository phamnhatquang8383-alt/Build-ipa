# PhamQuang IOS Pro — ghi chú nâng cấp

## Nguyên tắc tương thích

- Giữ nguyên Bundle ID `sato.cc365.file` và Bundle ID extension `.tunnel`.
- Không thay đổi schema patch, API C/Rust, khóa `AppStorage`, định dạng pairing hoặc luồng truy cập thiết bị.
- Không sửa hoặc xóa các module BQCore, LegacyDirect, AirLift, VPN, patch, file browser và Rust core.
- Tính năng mới được thêm theo kiểu additive; báo cáo chẩn đoán chỉ đọc trạng thái.

## Nâng cấp mới

### Trung tâm chẩn đoán

- Hiển thị phiên bản ứng dụng, build, iOS, chế độ truy cập và dải phiên bản hỗ trợ.
- Hiển thị trạng thái truy cập, trạng thái pairing AirLift và dung lượng lưu trữ.
- Xuất báo cáo văn bản để gửi hỗ trợ kỹ thuật.
- Báo cáo không chứa pairing file, khóa, đường dẫn riêng tư hoặc nội dung tệp.
- Không tự chạy lại exploit, không bật VPN, không sửa dữ liệu hoặc thay đổi trạng thái thiết bị.

## Kiểm thử

- `python3 -m unittest discover -s Tests -p 'test_package_ipa.py' -v`
- `make test` trên macOS có Xcode, iOS SDK và Rust toolchain.
- `make ipa` để chạy toàn bộ test, build iOS và đóng gói IPA unsigned.

Bản build IPA chưa được xác nhận trong môi trường không có Xcode/iOS SDK.


## Bảo vệ gói patch `.vpatch`

- Bổ sung định dạng `.vpatch` mã hóa; ZIP và `.vailon` cũ vẫn xuất/nhập theo luồng cũ.
- Mã hóa AES-256-GCM theo từng khối 1 MiB; mỗi khối có nonce riêng và xác thực AAD, thứ tự, kích thước.
- Dẫn xuất khóa từ mật khẩu bằng PBKDF2-HMAC-SHA256 với 600.000 vòng và salt ngẫu nhiên 128-bit. Mật khẩu tối thiểu 12 ký tự, không lưu vào cấu hình hoặc Keychain.
- Nhập `.vpatch` yêu cầu mật khẩu trong ứng dụng. Nội dung giải mã chỉ nằm trong thư mục tạm riêng của PhamQuang IOS, được bảo vệ bằng Data Protection trên iOS và xóa sau khi ZIP validator nhận dữ liệu.
- Không sửa BQCore, Rust patch engine, LegacyDirect, API áp dụng patch hoặc logic ghi/khôi phục container đích. Không có thao tác mới nào ghi vào sandbox của ứng dụng đích trong lúc tạo, mã hóa hoặc giải mã gói.
- AES-GCM xác thực dữ liệu và PBKDF2 làm tăng chi phí dò mật khẩu ngoại tuyến; không có cơ chế nào bảo đảm chống reverse-engineering tuyệt đối nếu kẻ tấn công kiểm soát thiết bị hoặc có thể phân tích binary.
- Đây là triển khai mật mã trong ứng dụng, không phải chứng nhận phù hợp TCVN/QCVN hay chứng thư đánh giá quốc gia. Không tuyên bố đạt chứng nhận trước khi có đánh giá độc lập và hồ sơ chứng nhận hợp lệ.

### Kiểm thử bổ sung

- `PatchArchiveCryptoTests`: round-trip, nhận diện định dạng, sai mật khẩu, sửa ciphertext và cắt cụt gói.
- Bổ sung file crypto vào các lệnh Swift test macOS có biên dịch `AppPatchSource` và `PatchCreationStore`.
