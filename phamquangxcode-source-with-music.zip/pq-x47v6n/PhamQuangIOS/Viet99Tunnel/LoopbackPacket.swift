import Darwin
import Foundation

enum LoopbackPacket {
    static let interfaceAddress = "10.7.1.1"
    static let peerAddress = "10.7.0.1"
    static let subnetMask = "255.255.255.255"
    private static let local: [UInt8] = [10, 7, 1, 1]
    private static let peer: [UInt8] = [10, 7, 0, 1]



    static func reflect(_ packet: Data, addressFamily: Int32) -> Data? {
        guard addressFamily == AF_INET, packet.count >= 20,
              packet.count <= Int(UInt16.max) else { return nil }
        var output = packet
        let accepted = output.withUnsafeMutableBytes { (bytes: UnsafeMutableRawBufferPointer) -> Bool in
            guard bytes[0] >> 4 == 4 else { return false }
            let headerLength = Int(bytes[0] & 15) * 4
            let totalLength = Int(bytes[2]) << 8 | Int(bytes[3])
            guard headerLength >= 20, headerLength <= bytes.count,
                  totalLength >= headerLength, totalLength == bytes.count else { return false }
            let forward = (0..<4).allSatisfy { bytes[12 + $0] == local[$0] && bytes[16 + $0] == peer[$0] }
            let reverse = (0..<4).allSatisfy { bytes[12 + $0] == peer[$0] && bytes[16 + $0] == local[$0] }
            guard forward || reverse else { return false }


            for offset in 0..<4 {
                let previous = bytes[12 + offset]
                bytes[12 + offset] = bytes[16 + offset]
                bytes[16 + offset] = previous
            }
            return true
        }
        return accepted ? output : nil
    }
}
