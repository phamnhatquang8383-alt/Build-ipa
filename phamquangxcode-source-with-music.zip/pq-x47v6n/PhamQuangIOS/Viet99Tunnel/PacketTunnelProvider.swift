import Darwin
import Foundation
import NetworkExtension



final class PacketTunnelProvider: NEPacketTunnelProvider, @unchecked Sendable {

    private let queue = DispatchQueue(label: "viet99.loopback.packet-flow", autoreleaseFrequency: .workItem)
    private var generation = UUID()
    private var state: State = .stopped
    private var pendingStart: TunnelCompletion<Error?>?
    private var receivedPackets: UInt64 = 0
    private var reflectedPackets: UInt64 = 0
    private var droppedPackets: UInt64 = 0
    private var writeFailures: UInt64 = 0

    private enum State: String { case stopped, starting, running }

    override func startTunnel(options: [String: NSObject]?, completionHandler: @escaping (Error?) -> Void) {
        let completion = TunnelCompletion(completionHandler)
        queue.async { self.start(completion) }
    }

    override func stopTunnel(with reason: NEProviderStopReason, completionHandler: @escaping () -> Void) {
        let completion = TunnelCompletion<Void> { _ in completionHandler() }
        queue.async {
            self.generation = UUID()
            self.state = .stopped
            let pendingStart = self.pendingStart
            self.pendingStart = nil
            pendingStart?.complete(Self.failure(2, "Local tunnel startup was cancelled."))



            completion.complete(())
        }
    }



    override func handleAppMessage(_ messageData: Data, completionHandler: ((Data?) -> Void)?) {
        guard let completionHandler else { return }
        let completion = TunnelCompletion(completionHandler)
        guard messageData == Data("status".utf8) else {
            completion.complete(nil)
            return
        }
        queue.async {
            let status: [String: Any] = [
                "version": 1,
                "state": self.state.rawValue,
                "receivedPackets": self.receivedPackets,
                "reflectedPackets": self.reflectedPackets,
                "droppedPackets": self.droppedPackets,
                "writeFailures": self.writeFailures
            ]
            completion.complete(try? JSONSerialization.data(withJSONObject: status, options: [.sortedKeys]))
        }
    }

    private func start(_ completion: TunnelCompletion<Error?>) {
        dispatchPrecondition(condition: .onQueue(queue))
        guard state == .stopped else {
            completion.complete(Self.failure(1, "The local tunnel is already starting or running."))
            return
        }
        let id = UUID()
        generation = id
        state = .starting
        pendingStart = completion
        receivedPackets = 0
        reflectedPackets = 0
        droppedPackets = 0
        writeFailures = 0

        let ipv4 = NEIPv4Settings(addresses: [LoopbackPacket.interfaceAddress], subnetMasks: [LoopbackPacket.subnetMask])
        ipv4.includedRoutes = [NEIPv4Route(destinationAddress: LoopbackPacket.peerAddress, subnetMask: LoopbackPacket.subnetMask)]
        ipv4.excludedRoutes = [.default()]

        let settings = NEPacketTunnelNetworkSettings(tunnelRemoteAddress: LoopbackPacket.peerAddress)
        settings.ipv4Settings = ipv4


        setTunnelNetworkSettings(settings) { [weak self] error in
            guard let self else {
                completion.complete(Self.failure(2, "The local tunnel provider was released."))
                return
            }
            self.queue.async {
                guard self.generation == id, self.state == .starting else { return }
                self.pendingStart = nil
                if let error {
                    self.state = .stopped
                    completion.complete(error)
                    return
                }
                self.state = .running
                self.readNext(generation: id)
                completion.complete(nil)
            }
        }
    }

    private func readNext(generation id: UUID) {
        dispatchPrecondition(condition: .onQueue(queue))
        guard generation == id, state == .running else { return }
        packetFlow.readPackets { [weak self] packets, protocols in


            let families = protocols.map(\.int32Value)
            self?.queue.async { [weak self] in
                guard let self, self.generation == id, self.state == .running else { return }
                self.process(packets, families: families, generation: id)
            }
        }
    }

    private func process(_ packets: [Data], families: [Int32], generation id: UUID) {
        dispatchPrecondition(condition: .onQueue(queue))
        receivedPackets &+= UInt64(packets.count)
        var output: [Data] = []
        output.reserveCapacity(min(packets.count, families.count))
        for (packet, family) in zip(packets, families) {
            if let reflected = LoopbackPacket.reflect(packet, addressFamily: family) { output.append(reflected) }
        }
        droppedPackets &+= UInt64(packets.count - output.count)
        if !output.isEmpty {
            let families = Array(repeating: NSNumber(value: AF_INET), count: output.count)
            guard packetFlow.writePackets(output, withProtocols: families) else {
                writeFailures &+= 1
                droppedPackets &+= UInt64(output.count)
                generation = UUID()
                state = .stopped
                cancelTunnelWithError(Self.failure(3, "The local tunnel could not return packets to the device."))
                return
            }
            reflectedPackets &+= UInt64(output.count)
        }



        if packets.isEmpty {


            queue.asyncAfter(deadline: .now() + .milliseconds(10)) { [weak self] in
                self?.readNext(generation: id)
            }
        } else {
            readNext(generation: id)
        }
    }

    private static func failure(_ code: Int, _ description: String) -> NSError {
        NSError(domain: "Viet99.LocalTunnel", code: code, userInfo: [NSLocalizedDescriptionKey: description])
    }
}




private final class TunnelCompletion<Value: Sendable>: @unchecked Sendable {
    private let lock = NSLock()
    private var callback: ((Value) -> Void)?

    init(_ callback: @escaping (Value) -> Void) { self.callback = callback }

    func complete(_ value: Value) {
        lock.lock()
        let callback = callback
        self.callback = nil
        lock.unlock()
        callback?(value)
    }
}
