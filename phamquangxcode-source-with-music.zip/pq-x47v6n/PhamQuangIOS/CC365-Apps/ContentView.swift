import SwiftUI

struct ContentView: View {
    private enum Page: Hashable { case patch, files, settings }
    @State private var selectedTab: Page = .patch
    @AppStorage(AppFileSettings.showFilesTabKey) private var showFilesTab = false

    var body: some View {
        TabView(selection: $selectedTab) {
            NavigationStack { AppPatchView() }
                .tabItem { Label("Patch", systemImage: "doc.badge.gearshape") }
                .tag(Page.patch)
            if showFilesTab {
                FilesTab()
                    .tabItem { Label("Tệp", image: CC365Glyph.files.assetName) }
                    .tag(Page.files)
            }
            NavigationStack { SettingsView() }
                .tabItem { Label("Cài đặt", systemImage: "gearshape") }
                .tag(Page.settings)
        }
        .onChange(of: showFilesTab) { isVisible in
            if !isVisible && selectedTab == .files { selectedTab = .patch }
        }
    }
}
