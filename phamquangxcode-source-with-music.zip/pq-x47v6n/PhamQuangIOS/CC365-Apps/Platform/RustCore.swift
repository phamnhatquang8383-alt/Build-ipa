import Foundation


struct RustPatchProgress: Decodable, Sendable, Equatable {
    let phase: String
    let done: Int
    let total: Int
    let path: String
}
