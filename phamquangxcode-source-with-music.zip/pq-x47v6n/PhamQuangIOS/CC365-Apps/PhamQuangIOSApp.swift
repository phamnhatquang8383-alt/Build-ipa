import SwiftUI

@main
struct PhamQuangIOSApp: App {
    @StateObject private var access = DeviceAccessModel.shared

    var body: some Scene {
        WindowGroup {
            Group {
                if access.enteredApp {
                    ContentView()
                } else {
                    NavigationStack { DeviceAccessView(access: access, onboarding: true) }
                }
            }
            .task {
                AppMusicPlayer.shared.start()
                await access.start()
            }
        }
    }
}
