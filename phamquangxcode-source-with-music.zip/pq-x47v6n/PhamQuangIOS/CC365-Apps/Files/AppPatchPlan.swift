import Foundation




struct AppPatchPlan: Sendable {
    struct Entry: Identifiable, Sendable {
        let id: UUID
        var source: AppPatchSource
        var destination: String

        init(id: UUID = UUID(), source: AppPatchSource, destination: String) {
            self.id = id
            self.source = source
            self.destination = destination
        }
    }

    var entries: [Entry]
    private let boundApp: PatchTargetApp
    private let boundScope: PatchScope

    init(app: PatchTargetApp, scope: PatchScope, entries: [Entry] = []) {
        boundApp = app
        boundScope = scope
        self.entries = entries
    }

    var fileCount: Int { entries.reduce(0) { $0 + $1.source.files.count } }
    var size: UInt64 { entries.reduce(0) { $0 + $1.source.size } }




    func stageSource(_ selection: URL, expectDirectory: Bool? = nil) async throws -> AppPatchSource {
        guard boundApp.bundleID == nil,
              entries.contains(where: { $0.source.usesExplicitContainerSelection }) else {
            return try await AppPatchSource.stage(selection, app: boundApp, scope: boundScope,
                                                  expectDirectory: expectDirectory)
        }
        try validateSources()
        guard let confirmedOwner = try declaredBundleID() else {
            throw PatchInputError("Không còn khai báo ứng dụng đã xác nhận. Hãy chọn lại nguồn và container.")
        }
        let staged = try await AppPatchSource.stage(selection, scope: boundScope, expectDirectory: expectDirectory)
        try Task.checkCancellation()
        if let owner = staged.embeddedBundleID {
            guard owner == confirmedOwner else {
                throw PatchInputError("Nguồn mới khai báo ứng dụng khác với gói đã xác nhận cho container này.")
            }
            return try staged.binding(toObservedContainer: boundApp)
        }
        return try staged.targetingUnownedSource(app: boundApp, scope: boundScope)
    }



    func validateSources() throws {
        guard entries.count <= AppPatchSource.maxFiles else { throw PatchInputError("Một lượt patch hỗ trợ tối đa 1.024 tệp từ tất cả nguồn.") }
        var ids = Set<UUID>()
        var count = 0
        var bytes: UInt64 = 0
        for entry in entries {
            guard ids.insert(entry.id).inserted, !entry.source.files.isEmpty else {
                throw PatchInputError("Mục nguồn bị trùng hoặc không có tệp. Hãy chọn lại nguồn.")
            }
            for file in entry.source.files {
                count += 1
                guard count <= AppPatchSource.maxFiles, file.size <= AppPatchSource.perFile,
                      file.size <= AppPatchSource.total - bytes else {
                    throw PatchInputError("Tất cả nguồn trong một lượt patch tối đa 1.024 tệp, 128 MiB mỗi tệp và 256 MiB tổng cộng.")
                }
                bytes += file.size
            }


            if entry.source.hasEmbeddedDestinations {
                _ = try entry.source.mappings(destination: "", app: boundApp, scope: boundScope)
            }
        }
        let owner = try declaredBundleID()
        if let owner, let selectedOwner = boundApp.bundleID, owner != selectedOwner {
            throw PatchInputError("Các nguồn khai báo ứng dụng khác với ứng dụng đã chọn.")
        }
    }

    func declaredBundleID() throws -> String? {
        let owners = Set(entries.compactMap { $0.source.embeddedBundleID })
        guard owners.count <= 1 else { throw PatchInputError("Một lượt patch chỉ dành cho một bundle ID. Các nguồn đang khai báo nhiều ứng dụng khác nhau.") }
        return owners.first
    }

    func mappings(app: PatchTargetApp, scope: PatchScope) throws -> [PatchFileMapping] {
        guard scope == boundScope, app.id == boundApp.id,
              let root = boundApp.root(for: boundScope), !root.isEmpty,
              app.root(for: scope) == root,
              boundApp.bundleID == nil || boundApp.bundleID == app.bundleID else {
            throw PatchInputError("Ứng dụng, container hoặc vùng dữ liệu đã thay đổi. Hãy chọn lại các nguồn cho đích hiện tại.")
        }
        try validateSources()
        guard !entries.isEmpty else { throw PatchInputError("Thêm ít nhất một nguồn trước khi áp dụng patch.") }
        let combined = try entries.flatMap { entry in
            try entry.source.mappings(destination: entry.destination, app: app, scope: scope)
        }
        try AppPatchSource.validate(combined, scope: scope)
        return combined
    }
}
