import Foundation
import Darwin
import CC365Core



actor PatchCreationStore {
    static let shared = PatchCreationStore()
    private let root: URL
    private static let metadataLimit = 4 * 1_024 * 1_024
    private static let projectLimit = 256

    init(root: URL? = nil) {
        self.root = root ?? FileManager.default.urls(for: .applicationSupportDirectory, in: .userDomainMask)[0]
            .appendingPathComponent("PatchCreation-v1", isDirectory: true)
    }

    func projects() throws -> [PatchCreationProject] {
        try directory(root)
        let entries = try FileManager.default.contentsOfDirectory(at: root, includingPropertiesForKeys: nil)
        guard entries.count <= 1_024 else { throw PatchCreationError("Thư viện có quá nhiều mục; hãy kiểm tra thư mục dự án.") }
        var result: [PatchCreationProject] = []
        for entry in entries {
            guard let id = UUID(uuidString: entry.lastPathComponent), id.uuidString == entry.lastPathComponent else { continue }
            result.append(try load(id))
        }
        return result.sorted { $0.updatedAt > $1.updatedAt }
    }

    func project(id: UUID) throws -> PatchCreationProject { try load(id) }

    func create(name: String, author: String = "") throws -> PatchCreationProject {
        let now = Date()
        let project = PatchCreationProject(id: UUID(), name: name.trimmingCharacters(in: .whitespacesAndNewlines),
            author: author.trimmingCharacters(in: .whitespacesAndNewlines), createdAt: now, updatedAt: now, mappings: [])
        try PatchCreationValidation.project(project)
        guard try projects().count < Self.projectLimit else { throw PatchCreationError("Tối đa 256 dự án đã lưu.") }
        let home = projectURL(project.id)
        let pending = root.appendingPathComponent(".creating-" + project.id.uuidString, isDirectory: true)
        try directory(pending)
        defer { try? FileManager.default.removeItem(at: pending) }
        let metadata = pending.appendingPathComponent("project.json")
        try JSONEncoder().encode(project).write(to: metadata, options: [.atomic, .completeFileProtection])
        try FileManager.default.setAttributes([.posixPermissions: 0o600], ofItemAtPath: metadata.path)
        try Task.checkCancellation()
        try FileManager.default.moveItem(at: pending, to: home)
        return project
    }

    func update(projectID: UUID, name: String, author: String) throws -> PatchCreationProject {
        var project = try load(projectID)
        project.name = name.trimmingCharacters(in: .whitespacesAndNewlines)
        project.author = author.trimmingCharacters(in: .whitespacesAndNewlines)
        project.updatedAt = Date()
        try save(project)
        return project
    }

    func importMapping(projectID: UUID, bundleID: String, destination: String, source: URL,
                       replacing mappingID: UUID? = nil) async throws -> PatchCreationProject {
        try PatchCreationValidation.bundle(bundleID)

        _ = try load(projectID)
        let staged = try await FileTransferSupport.coordinatedImport(source) { coordinated in
            try Self.stage(coordinated, sourceName: source.lastPathComponent)
        }
        try Task.checkCancellation()


        var project = try load(projectID)
        let old = mappingID.flatMap { id in project.mappings.first { $0.id == id } }
        guard mappingID == nil || old != nil else { throw PatchCreationError("Ánh xạ đã bị xóa. Hãy mở lại dự án.") }
        let mapping = PatchCreationMapping(id: mappingID ?? UUID(), bundleID: bundleID,
            destination: destination, isDirectory: staged.isDirectory, sourceName: staged.sourceName,
            snapshotID: UUID(), files: staged.files)
        if let index = project.mappings.firstIndex(where: { $0.id == mapping.id }) { project.mappings[index] = mapping }
        else { project.mappings.append(mapping) }
        project.updatedAt = Date()
        try PatchCreationValidation.project(project)
        let parent = projectURL(projectID).appendingPathComponent("snapshots", isDirectory: true)
        try directory(parent)
        let snapshot = parent.appendingPathComponent(mapping.snapshotID.uuidString, isDirectory: true)
        try Task.checkCancellation()
        try FileManager.default.moveItem(at: staged.transfer.directory, to: snapshot)
        do {
            try Task.checkCancellation()
            try save(project)
        } catch {
            try? FileManager.default.removeItem(at: snapshot)
            throw error
        }

        if let old { try? FileManager.default.removeItem(at: snapshotURL(projectID, old.snapshotID)) }
        return project
    }

    func editMapping(projectID: UUID, mappingID: UUID, bundleID: String, destination: String) throws -> PatchCreationProject {
        var project = try load(projectID)
        guard let index = project.mappings.firstIndex(where: { $0.id == mappingID }) else {
            throw PatchCreationError("Ánh xạ không còn trong dự án.")
        }
        project.mappings[index].bundleID = bundleID
        project.mappings[index].destination = destination
        project.updatedAt = Date()
        try save(project)
        return project
    }

    func removeMapping(projectID: UUID, mappingID: UUID) throws -> PatchCreationProject {
        var project = try load(projectID)
        guard let mapping = project.mappings.first(where: { $0.id == mappingID }) else {
            throw PatchCreationError("Ánh xạ không còn trong dự án.")
        }
        project.mappings.removeAll { $0.id == mappingID }
        project.updatedAt = Date()
        try save(project)
        try? FileManager.default.removeItem(at: snapshotURL(projectID, mapping.snapshotID))
        return project
    }

    func delete(projectID: UUID) throws {
        _ = try load(projectID)
        try Task.checkCancellation()
        try FileManager.default.removeItem(at: projectURL(projectID))
    }

    func export(projectID: UUID, fileExtension: String = "zip", password: String? = nil) throws -> PatchCreationExport {
        guard ["zip", "vailon", "vpatch"].contains(fileExtension) else { throw PatchCreationError("Chọn định dạng ZIP, .vailon hoặc .vpatch.") }
        if fileExtension == "vpatch" {
            guard let password, password.count >= 12 else {
                throw PatchCreationError("Patch mã hóa cần mật khẩu tối thiểu 12 ký tự.")
            }
        }
        let settings = AppFileSettings.load()
        let project = try load(projectID)
        try PatchCreationValidation.project(project, allowEmpty: false)
        try requireDirectory(projectURL(projectID).appendingPathComponent("snapshots", isDirectory: true))
        let scratch = try FileTransferItem(name: "export")
        var outputs: [URL] = []
        for (index, bundle) in project.bundleIDs.enumerated() {
            try Task.checkCancellation()
            var entries: [[String: String]] = []
            for mapping in project.mappings where mapping.bundleID == bundle {
                let snapshot = snapshotURL(projectID, mapping.snapshotID)
                try requireDirectory(snapshot)
                for file in mapping.files {
                    let payload = snapshot.appendingPathComponent(file.payloadName)
                    try Self.requireRegular(payload, size: file.size)
                    entries.append(["archive_path": "Application/" + bundle + "/" + mapping.target(for: file),
                                    "local_path": payload.path])
                }
            }
            let manifest = scratch.directory.appendingPathComponent("manifest-\(index).json")
            let data = try JSONSerialization.data(withJSONObject: ["name": project.name, "author": project.author, "entries": entries,
                "compression_level": settings.compressionLevel, "work_mode": settings.workMode.rawValue], options: [.sortedKeys])
            try data.write(to: manifest, options: .atomic)
            try FileManager.default.setAttributes([.posixPermissions: 0o600], ofItemAtPath: manifest.path)
            let label = Self.exportName(project.name, bundle: bundle, index: index, multiple: project.bundleIDs.count > 1)
            let archiveExtension = fileExtension == "vpatch" ? "zip" : fileExtension
            let archive = scratch.directory.appendingPathComponent(label + "." + archiveExtension)
            let status = manifest.withUnsafeFileSystemRepresentation { input in
                archive.withUnsafeFileSystemRepresentation { destination in
                    cc365_create_patch_zip(input, destination) { Task.isCancelled }
                }
            }
            switch status {
            case 0: break
            case 2: throw PatchCreationError("Nguồn hoặc đường dẫn xuất không hợp lệ, trùng nhau hay chứa liên kết.")
            case 3: throw PatchCreationError("Gói xuất vượt giới hạn dung lượng hoặc số tệp. Hãy chia thành dự án nhỏ hơn.")
            case 6: throw CancellationError()
            case 7: throw PatchCreationError("Chưa có tệp nào để xuất.")
            default: throw PatchCreationError("Chưa xuất được patch. Hãy kiểm tra bản sao nguồn và dung lượng trống.")
            }
            if fileExtension == "vpatch" {
                guard let password else { throw PatchCreationError("Thiếu mật khẩu mã hóa patch.") }
                let encrypted = scratch.directory.appendingPathComponent(label + ".vpatch")
                try PatchArchiveCrypto.encrypt(archive, to: encrypted, password: password)
                try FileManager.default.removeItem(at: archive)
                outputs.append(encrypted)
            } else {
                outputs.append(archive)
            }
        }
        try Task.checkCancellation()
        return PatchCreationExport(urls: outputs, transfer: scratch)
    }

    private func projectURL(_ id: UUID) -> URL { root.appendingPathComponent(id.uuidString, isDirectory: true) }
    private func snapshotURL(_ project: UUID, _ snapshot: UUID) -> URL {
        projectURL(project).appendingPathComponent("snapshots", isDirectory: true).appendingPathComponent(snapshot.uuidString, isDirectory: true)
    }

    private func directory(_ url: URL) throws {
        try FileManager.default.createDirectory(at: url, withIntermediateDirectories: true, attributes: [.posixPermissions: 0o700])
        try requireDirectory(url)
    }
    private func requireDirectory(_ url: URL) throws {
        let values = try url.resourceValues(forKeys: [.isDirectoryKey, .isSymbolicLinkKey])
        guard values.isDirectory == true, values.isSymbolicLink != true else {
            throw PatchCreationError("Thư mục dự án không hợp lệ hoặc đã bị thay bằng liên kết.")
        }
    }

    private func load(_ id: UUID) throws -> PatchCreationProject {
        try requireDirectory(root)
        let home = projectURL(id)
        try requireDirectory(home)
        let url = home.appendingPathComponent("project.json")
        let values = try url.resourceValues(forKeys: [.isRegularFileKey, .isSymbolicLinkKey, .fileSizeKey])
        guard values.isRegularFile == true, values.isSymbolicLink != true,
              let size = values.fileSize, size <= Self.metadataLimit else {
            throw PatchCreationError("Thông tin dự án không hợp lệ hoặc quá lớn.")
        }
        let data = try Data(contentsOf: url)
        guard data.count <= Self.metadataLimit else { throw PatchCreationError("Thông tin dự án quá lớn.") }
        let project = try JSONDecoder().decode(PatchCreationProject.self, from: data)
        guard project.id == id else { throw PatchCreationError("Mã dự án không khớp với bản đã lưu.") }
        try PatchCreationValidation.project(project)
        return project
    }

    private func save(_ project: PatchCreationProject) throws {
        try PatchCreationValidation.project(project)
        try requireDirectory(root)
        let home = projectURL(project.id)
        try requireDirectory(home)
        let url = home.appendingPathComponent("project.json")
        if FileManager.default.fileExists(atPath: url.path) {
            let values = try url.resourceValues(forKeys: [.isRegularFileKey, .isSymbolicLinkKey])
            guard values.isRegularFile == true, values.isSymbolicLink != true else { throw PatchCreationError("Tệp thông tin dự án không hợp lệ.") }
        }
        let encoder = JSONEncoder()
        encoder.outputFormatting = [.sortedKeys]
        let data = try encoder.encode(project)
        guard data.count <= Self.metadataLimit else { throw PatchCreationError("Thông tin dự án quá lớn.") }
        try Task.checkCancellation()
        try data.write(to: url, options: [.atomic, .completeFileProtection])


        try? FileManager.default.setAttributes([.posixPermissions: 0o600], ofItemAtPath: url.path)
    }

    private static func exportName(_ name: String, bundle: String, index: Int, multiple: Bool) -> String {
        var stem = name.map { "/\\:".contains($0) ? "-" : String($0) }.joined()
        while stem.utf8.count > 100 { stem.removeLast() }
        if stem.hasPrefix(".") { stem = "Patch-" + stem }
        if multiple {
            let owner = String(bundle.prefix(80))
            stem += "-\(index + 1)-" + owner
        }
        return stem
    }

    private struct Staged: Sendable {
        let transfer: FileTransferItem
        let isDirectory: Bool
        let sourceName: String
        let files: [PatchCreationFile]
    }

    private static func stage(_ source: URL, sourceName: String) throws -> Staged {
        guard FileTransferSupport.validName(sourceName), !sourceName.hasPrefix("."), sourceName != "__MACOSX" else {
            throw PatchCreationError("Không thể dùng tệp hoặc thư mục ẩn làm nguồn patch.")
        }
        let scratch = try FileTransferItem(name: sourceName)
        try rejectSourceLinks(source)
        let keys: Set<URLResourceKey> = [.isRegularFileKey, .isDirectoryKey, .isSymbolicLinkKey]
        let top = try source.resourceValues(forKeys: keys)
        guard top.isSymbolicLink != true, top.isDirectory == true || top.isRegularFile == true else {
            throw PatchCreationError("Chọn tệp hoặc thư mục thông thường, không dùng liên kết.")
        }
        let isDirectory = top.isDirectory == true
        var files: [PatchCreationFile] = []
        var bytes: UInt64 = 0
        var visited = 0
        func collect(_ url: URL, relative: String, depth: Int) throws {
            try Task.checkCancellation()
            visited += 1
            guard depth <= 32, visited <= 4_096 else { throw PatchCreationError("Cây nguồn quá lớn; hãy chọn thư mục nhỏ hơn.") }
            if !relative.isEmpty { try PatchCreationValidation.path(relative) }
            try rejectSourceLinks(url)
            let values = try url.resourceValues(forKeys: keys)
            guard values.isSymbolicLink != true else { throw PatchCreationError("Nguồn chứa liên kết tại “\(relative)”.") }
            if values.isDirectory == true {
                let children = try FileManager.default.contentsOfDirectory(at: url, includingPropertiesForKeys: Array(keys))
                guard children.count <= 4_096 else { throw PatchCreationError("Thư mục nguồn có quá nhiều mục.") }
                for child in children.sorted(by: { $0.lastPathComponent < $1.lastPathComponent }) {
                    let name = child.lastPathComponent
                    guard FileTransferSupport.validName(name), !name.hasPrefix("."), name != "__MACOSX" else {
                        throw PatchCreationError("Nguồn chứa mục ẩn hoặc tên không hợp lệ: “\(name)”.")
                    }
                    try collect(child, relative: relative.isEmpty ? name : relative + "/" + name, depth: depth + 1)
                }
            } else {
                guard values.isRegularFile == true else { throw PatchCreationError("Nguồn chứa mục không phải tệp thông thường.") }
                guard files.count < PatchCreationValidation.maximumFiles else { throw PatchCreationError("Một dự án hỗ trợ tối đa 1.024 tệp.") }
                let payload = UUID().uuidString
                let limit = min(PatchCreationValidation.maximumFileBytes, PatchCreationValidation.maximumTotalBytes - bytes)
                let count = try copySnapshot(from: url, to: scratch.directory.appendingPathComponent(payload), limit: limit)
                files.append(PatchCreationFile(relativePath: relative, size: count, payloadName: payload))
                bytes += count
            }
        }
        try collect(source, relative: "", depth: 0)
        guard !files.isEmpty else { throw PatchCreationError("Thư mục chưa có tệp; patch không hỗ trợ nguồn chỉ gồm thư mục rỗng.") }
        return Staged(transfer: scratch, isDirectory: isDirectory, sourceName: sourceName, files: files)
    }

    private static func requireRegular(_ url: URL, size: UInt64) throws {
        var info = stat()
        guard lstat(url.path, &info) == 0, (info.st_mode & S_IFMT) == S_IFREG,
              info.st_size >= 0, UInt64(info.st_size) == size else {
            throw PatchCreationError("Bản sao nguồn bị thiếu hoặc đã thay đổi. Hãy chọn lại nguồn cho ánh xạ.")
        }
    }

    private static func rejectSourceLinks(_ url: URL) throws {


        var path = url.path
        if path.hasPrefix("/var/") { path = "/private" + path }
        if path.hasPrefix("/tmp/") { path = "/private" + path }
        var cursor = ""
        for component in path.split(separator: "/") {
            cursor += "/" + component
            var info = stat()
            guard lstat(cursor, &info) == 0, (info.st_mode & S_IFMT) != S_IFLNK else {
                throw PatchCreationError("Nguồn hoặc thư mục cha của nguồn là liên kết hoặc không còn truy cập được.")
            }
        }
    }

    private static func copySnapshot(from source: URL, to destination: URL, limit: UInt64) throws -> UInt64 {
        try rejectSourceLinks(source)
        let input = open(source.path, O_RDONLY | O_CLOEXEC | O_NOFOLLOW)
        guard input >= 0 else { throw PatchCreationError("Không mở được tệp nguồn hoặc nguồn là liên kết.") }
        defer { close(input) }
        var before = stat()
        guard fstat(input, &before) == 0, (before.st_mode & S_IFMT) == S_IFREG, before.st_size >= 0 else {
            throw FileTransferSupport.Failure.notRegular
        }
        guard UInt64(before.st_size) <= limit else { throw PatchCreationError("Mỗi tệp tối đa 128 MiB; toàn bộ dự án tối đa 256 MiB.") }
        let output = open(destination.path, O_WRONLY | O_CREAT | O_EXCL | O_CLOEXEC | O_NOFOLLOW, 0o600)
        guard output >= 0 else { throw FileTransferSupport.Failure.staging }
        defer { close(output) }
        var buffer = [UInt8](repeating: 0, count: 64 * 1_024)
        var count: UInt64 = 0
        while true {
            try Task.checkCancellation()
            let size = read(input, &buffer, buffer.count)
            if size < 0, errno == EINTR { continue }
            guard size >= 0 else { throw PatchCreationError("Không đọc hết được tệp nguồn.") }
            if size == 0 { break }
            count += UInt64(size)
            guard count <= limit else { throw PatchCreationError("Nguồn vượt giới hạn dung lượng trong lúc sao chép.") }
            try buffer.withUnsafeBytes { raw in
                var offset = 0
                while offset < size {
                    let written = write(output, raw.baseAddress!.advanced(by: offset), size - offset)
                    if written < 0, errno == EINTR { continue }
                    guard written > 0 else { throw FileTransferSupport.Failure.staging }
                    offset += written
                }
            }
        }
        var after = stat()
        guard fstat(input, &after) == 0, before.st_size == after.st_size, UInt64(after.st_size) == count,
              before.st_mtimespec.tv_sec == after.st_mtimespec.tv_sec, before.st_mtimespec.tv_nsec == after.st_mtimespec.tv_nsec,
              fsync(output) == 0 else { throw PatchCreationError("Nguồn đã đổi khi đang đọc hoặc chưa lưu đủ bản sao. Hãy thử lại.") }
        return count
    }
}
