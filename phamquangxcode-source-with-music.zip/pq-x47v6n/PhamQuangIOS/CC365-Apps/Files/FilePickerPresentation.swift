import SwiftUI
import UIKit
import UniformTypeIdentifiers

enum FilePickerKind { case file, folder }




private struct CC365DocumentPicker: UIViewControllerRepresentable {
    let kind: FilePickerKind
    let completion: FilePickerCompletion
    let close: () -> Void
    let finish: (URL?) -> Void

    final class Coordinator: NSObject, UIDocumentPickerDelegate {
        private var finish: ((URL?) -> Void)?
        init(finish: @escaping (URL?) -> Void) { self.finish = finish }
        private func complete(_ url: URL?) {
            let callback = finish
            finish = nil
            callback?(url)
        }
        func documentPicker(_ controller: UIDocumentPickerViewController, didPickDocumentsAt urls: [URL]) {
            complete(urls.first)
        }
        func documentPickerWasCancelled(_ controller: UIDocumentPickerViewController) { complete(nil) }
    }

    func makeCoordinator() -> Coordinator {
        let session = completion.begin()
        return Coordinator { url in
            guard completion.session == session else { return }
            close()
            completion.select(url, session: session, finish: finish)
        }
    }
    func makeUIViewController(context: Context) -> UIDocumentPickerViewController {
        let picker = UIDocumentPickerViewController(forOpeningContentTypes: kind == .folder ? [.folder] : [.data],
                                                   asCopy: kind == .file)
        picker.allowsMultipleSelection = false
        picker.shouldShowFileExtensions = true
        picker.delegate = context.coordinator
        return picker
    }
    func updateUIViewController(_ controller: UIDocumentPickerViewController, context: Context) {}
}

private struct FilePickerPresentation: ViewModifier {
    @Binding var isPresented: Bool
    let kind: FilePickerKind
    let finish: (URL?) -> Void
    @State private var completion = FilePickerCompletion()

    func body(content: Content) -> some View {
        content.sheet(isPresented: $isPresented, onDismiss: {
            completion.dismiss(session: completion.session, finish: finish)
        }) {
            CC365DocumentPicker(kind: kind, completion: completion, close: { isPresented = false }) { url in
                finish(url)
            }
            .ignoresSafeArea()
        }
    }
}

extension View {
    func cc365FilePicker(isPresented: Binding<Bool>, kind: FilePickerKind,
                         finish: @escaping (URL?) -> Void) -> some View {
        modifier(FilePickerPresentation(isPresented: isPresented, kind: kind, finish: finish))
    }
}
