import Foundation
#if os(iOS)
import SwiftUI
import UIKit
import UniformTypeIdentifiers
#endif

struct LocalPatchDirectory: Sendable {
    struct Entry: Identifiable, Sendable {
        let name: String
        let isDirectory: Bool
        let size: Int?
        var id: String { name }
    }

    let root: URL
    private static let keys: Set<URLResourceKey> = [.isDirectoryKey, .isRegularFileKey, .isSymbolicLinkKey, .isHiddenKey, .fileSizeKey]

    private func validComponent(_ name: String) -> Bool {
        !name.hasPrefix(".") && name != "__MACOSX" && FileTransferSupport.validName(name)
    }


    func url(for components: [String], isDirectory: Bool) throws -> URL {
        var current = root.standardizedFileURL
        let rootValues = try current.resourceValues(forKeys: [.isDirectoryKey, .isSymbolicLinkKey])
        guard rootValues.isDirectory == true, rootValues.isSymbolicLink != true else { throw CocoaError(.fileReadNoPermission) }
        guard !components.isEmpty else {
            guard isDirectory else { throw CocoaError(.fileReadInvalidFileName) }
            return current
        }
        for (offset, component) in components.enumerated() {
            guard validComponent(component) else { throw CocoaError(.fileReadInvalidFileName) }
            let folder = offset < components.count - 1 || isDirectory
            current = current.appendingPathComponent(component, isDirectory: folder)
            let metadata = try current.resourceValues(forKeys: Self.keys)
            guard metadata.isSymbolicLink != true, metadata.isHidden != true,
                  folder ? metadata.isDirectory == true : metadata.isRegularFile == true else {
                throw CocoaError(.fileReadNoPermission)
            }
        }
        return current
    }

    func contents(of components: [String]) throws -> [Entry] {
        let folder = try url(for: components, isDirectory: true)
        let children = try FileManager.default.contentsOfDirectory(at: folder, includingPropertiesForKeys: Array(Self.keys),
                                                                  options: [.skipsHiddenFiles])
        let items = try children.compactMap { child -> Entry? in
            try Task.checkCancellation()
            let name = child.lastPathComponent
            guard validComponent(name),
                  let values = try? child.resourceValues(forKeys: Self.keys),
                  values.isSymbolicLink != true, values.isHidden != true else { return nil }
            if values.isDirectory == true { return Entry(name: name, isDirectory: true, size: nil) }
            guard values.isRegularFile == true else { return nil }
            return Entry(name: name, isDirectory: false, size: values.fileSize)
        }
        return items.sorted {
            if $0.isDirectory != $1.isDirectory { return $0.isDirectory }
            return $0.name.localizedStandardCompare($1.name) == .orderedAscending
        }
    }

    func prepareDropFolderIfEmpty() throws {
        let documents = try url(for: [], isDirectory: true)
        let fm = FileManager.default
        let visible = try fm.contentsOfDirectory(at: documents, includingPropertiesForKeys: nil, options: .skipsHiddenFiles)
        guard visible.isEmpty else { return }
        do {
            try fm.createDirectory(at: documents.appendingPathComponent("Patch", isDirectory: true),
                                   withIntermediateDirectories: false)
        } catch let error as CocoaError where error.code == .fileWriteFileExists {

        }
    }
}

#if os(iOS)
enum PatchSourceChoice: Identifiable {
    case file, folder
    var id: Self { self }
}

struct LocalPatchSourcePicker: View {
    let choice: PatchSourceChoice
    let finish: (URL?) -> Void
    @State private var externalFiles = false
    private let directory = LocalPatchDirectory(root: FileManager.default.urls(for: .documentDirectory, in: .userDomainMask)[0])

    var body: some View {
        NavigationStack {
            LocalPatchFolderPage(directory: directory, components: [], choice: choice,
                                 browseExternal: { externalFiles = true }, finish: finish)
        }
        .cc365FilePicker(isPresented: $externalFiles, kind: choice == .folder ? .folder : .file) { url in

            if let url { finish(url) }
        }
    }
}

private struct PatchSourcePickerPresentation: ViewModifier {
    struct Selection { let url: URL?; let choice: PatchSourceChoice }
    final class Completion { var selection: Selection? }
    @Binding var choice: PatchSourceChoice?
    let finish: (URL?, PatchSourceChoice) -> Void
    @State private var completion = Completion()

    func body(content: Content) -> some View {
        content.fullScreenCover(item: $choice, onDismiss: {
            let result = completion.selection
            completion.selection = nil
            if let result { finish(result.url, result.choice) }
        }) { current in
            LocalPatchSourcePicker(choice: current) { url in
                completion.selection = Selection(url: url, choice: current)
                choice = nil
            }
        }
    }
}

extension View {
    func patchSourcePicker(choice: Binding<PatchSourceChoice?>,
                           finish: @escaping (URL?, PatchSourceChoice) -> Void) -> some View {
        modifier(PatchSourcePickerPresentation(choice: choice, finish: finish))
    }
}

private struct LocalPatchFolderPage: View {
    let directory: LocalPatchDirectory
    let components: [String]
    let choice: PatchSourceChoice
    let browseExternal: () -> Void
    let finish: (URL?) -> Void
    @Environment(\.scenePhase) private var scenePhase
    @Environment(\.dynamicTypeSize) private var dynamicTypeSize
    @State private var entries: [LocalPatchDirectory.Entry]?
    @State private var error: String?

    var body: some View {
        List {
            if !components.isEmpty {
                Text(components.joined(separator: " / "))
                    .font(.footnote).foregroundStyle(.secondary)
                    .fixedSize(horizontal: false, vertical: true)
            }
            if let error {
                Section {
                    Text(error)
                    Button("Tải lại") { Task { await load() } }
                }
            }
            if let entries {
                if components.isEmpty, choice == .folder {
                    Text("Chọn thư mục bên dưới hoặc dùng nút Chọn Tệp để mở vị trí khác.")
                        .font(.footnote)
                        .foregroundStyle(.secondary)
                } else if entries.isEmpty {
                    Text("Thư mục này đang trống.").foregroundStyle(.secondary)
                }
                ForEach(entries) { item in
                    if item.isDirectory {
                        NavigationLink {
                            LocalPatchFolderPage(directory: directory, components: components + [item.name], choice: choice,
                                                 browseExternal: browseExternal, finish: finish)
                        } label: {
                            Label(item.name, systemImage: "folder")
                        }
                        .accessibilityIdentifier("patch-local-folder-" + item.name)
                    } else if choice == .file {
                        Button {
                            select(components + [item.name], isDirectory: false)
                        } label: {
                            fileRow(item)
                                .contentShape(Rectangle())
                        }
                        .buttonStyle(.plain)
                        .accessibilityIdentifier("patch-local-file-" + item.name)
                    } else {
                        fileRow(item).foregroundStyle(.secondary)
                    }
                }
            } else if error == nil {
                ProgressView("Đang đọc thư mục…")
            }
        }
        .navigationTitle(choice == .folder ? "Chọn thư mục" : "Chọn tệp")
        .navigationBarTitleDisplayMode(.inline)
        .toolbar {
            ToolbarItem(placement: components.isEmpty ? .cancellationAction : .topBarTrailing) {
                Button("Hủy") { finish(nil) }.accessibilityIdentifier("patch-local-cancel")
            }
        }
        .safeAreaInset(edge: .bottom) {
            Group {
                if dynamicTypeSize.isAccessibilitySize {
                    VStack(spacing: 10) { bottomActions }
                } else {
                    ViewThatFits(in: .horizontal) {
                        HStack(spacing: 12) { bottomActions }.fixedSize(horizontal: true, vertical: false)
                        VStack(spacing: 10) { bottomActions }
                    }
                }
            }
            .frame(maxWidth: .infinity)
            .padding(.horizontal, 16)
            .padding(.vertical, 10)
            .background(Color(uiColor: .systemGroupedBackground))
        }
        .task(id: scenePhase) { if scenePhase == .active { await load() } }
        .refreshable { await load() }
    }

    @ViewBuilder private var bottomActions: some View {
        Button("Chọn Tệp", action: browseExternal)
            .cc365ActionStyle()
            .accessibilityLabel("Chọn Tệp")
            .accessibilityIdentifier("patch-external-files")
        if choice == .folder, let entries, !entries.isEmpty {
            Button(components.isEmpty ? "Chọn tất cả" : "Chọn thư mục") { select(components, isDirectory: true) }
                .cc365ActionStyle(prominent: true)
                .accessibilityLabel(components.isEmpty ? "Chọn toàn bộ thư mục PhamQuang IOS" : "Chọn thư mục này")
                .accessibilityIdentifier("patch-local-use-folder")
        }
    }

    private func fileRow(_ item: LocalPatchDirectory.Entry) -> some View {
        HStack {
            Label(item.name, systemImage: FileTransferSupport.isPatchArchive(URL(fileURLWithPath: item.name)) ? "doc.zipper" : "doc")
            Spacer()
            if let size = item.size {
                Text(ByteCountFormatter.string(fromByteCount: Int64(size), countStyle: .file))
                    .font(.caption).foregroundStyle(.secondary)
            }
        }
    }

    @MainActor private func load() async {
        do {
            let folder = directory
            let path = components
            let worker = Task.detached(priority: .userInitiated) {
                if path.isEmpty { try folder.prepareDropFolderIfEmpty() }
                return try folder.contents(of: path)
            }
            let rows = try await withTaskCancellationHandler(operation: { try await worker.value }, onCancel: { worker.cancel() })
            try Task.checkCancellation()
            entries = rows
            error = nil
        } catch is CancellationError { }
        catch {
            entries = nil
            self.error = "Chưa đọc được thư mục này. Hãy kiểm tra lại trong ứng dụng Tệp."
        }
    }

    private func select(_ location: [String], isDirectory: Bool) {
        do { finish(try directory.url(for: location, isDirectory: isDirectory)) }
        catch { self.error = "Mục này đã thay đổi. Hãy tải lại thư mục rồi chọn lại." }
    }
}
#endif
