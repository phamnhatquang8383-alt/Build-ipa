#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN




@interface VVLegacyDirectAccess : NSObject
+ (NSDictionary<NSString *, id> *)currentStatus NS_SWIFT_NAME(status());
+ (BOOL)isReady NS_SWIFT_NAME(isReady());


+ (void)prepareWithCompletion:(void (^)(NSDictionary<NSString *, id> *result))completion
    NS_SWIFT_NAME(prepare(completion:));
@end

NS_ASSUME_NONNULL_END
