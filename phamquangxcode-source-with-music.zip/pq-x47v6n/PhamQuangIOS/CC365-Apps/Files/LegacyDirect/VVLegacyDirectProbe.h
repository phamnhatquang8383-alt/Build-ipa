#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN
FOUNDATION_EXPORT NSString * const VVLegacyDirectProbeErrorDomain;
typedef NS_ENUM(NSInteger, VVLegacyDirectProbeErrorCode) {
    VVLegacyDirectProbeAccessFailed = 1,
    VVLegacyDirectProbeCleanupFailed = 2,
};

BOOL VVLegacyDirectProbeDirectory(NSString *path, NSError * _Nullable * _Nullable error);
BOOL VVLegacyDirectProbeApplicationRoot(NSError * _Nullable * _Nullable error);
NS_ASSUME_NONNULL_END
