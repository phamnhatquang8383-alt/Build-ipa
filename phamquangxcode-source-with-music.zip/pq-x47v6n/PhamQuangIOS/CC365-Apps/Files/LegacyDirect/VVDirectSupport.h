#pragma once
#import <Foundation/Foundation.h>
#import "VVLegacyDirectAccess.h"

extern dispatch_queue_t BQWorkQueue(void);
extern void BQLog(NSString *format, ...) NS_FORMAT_FUNCTION(1, 2);
static inline NSString *VVDirectDocuments(void) {
#ifdef VVDIRECT_PROVIDER_TESTING
    extern NSString *VVDirectTestDocuments(void);
    return VVDirectTestDocuments();
#else
    return NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES).firstObject;
#endif
}
static inline BOOL VVDirectPathIsOwn(NSString *path) {
    NSString *(^canonical)(NSString *) = ^NSString *(NSString *value) {
        return [value hasPrefix:@"/private/var/"] ? [value substringFromIndex:8] : value;
    };
    NSString *home = canonical(NSHomeDirectory()), *candidate = canonical(path);
    return [candidate isEqual:home] || [candidate hasPrefix:[home stringByAppendingString:@"/"]];
}
