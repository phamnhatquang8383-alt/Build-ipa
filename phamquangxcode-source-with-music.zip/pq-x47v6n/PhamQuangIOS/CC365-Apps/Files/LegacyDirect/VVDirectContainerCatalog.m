#import "VVDirectContainerCatalog.h"
#import "VVDirectSupport.h"
#import <fcntl.h>
#import <dirent.h>
#import <sys/stat.h>
#import <unistd.h>
#import <errno.h>

@interface VVDirectContainerEntry ()
@property(nonatomic, copy, readwrite) NSString *name;
@property(nonatomic, copy, readwrite) NSString *identifier;
@property(nonatomic, copy, readwrite) NSString *path;
@property(nonatomic, copy, readwrite) NSString *kind;
@property(nonatomic, copy, readwrite) NSString *bundlePath;
@property(nonatomic, readwrite) BOOL accessRestricted;
@end
@implementation VVDirectContainerEntry
@end

static NSDictionary *VVRoots(void) {
#ifdef VVDIRECT_CATALOG_TESTING
    extern NSDictionary *VVDirectTestRoots(void);
    return VVDirectTestRoots();
#else
    return @{@"app":@"/var/mobile/Containers/Data/Application",
        @"plugin":@"/var/mobile/Containers/Data/PluginKitPlugin",
        @"group":@"/var/mobile/Containers/Shared/AppGroup",
        @"system":@"/var/containers/Shared/SystemGroup"};
#endif
}
static NSString *VVCanonical(NSString *path) {
    return [path hasPrefix:@"/private/var/"] ? [path substringFromIndex:8] : path;
}
static NSString *VVIdentifier(id value) {
    if (![value isKindOfClass:NSString.class] || ![value length] || [value length] > 255) return nil;
    NSCharacterSet *allowed = [NSCharacterSet characterSetWithCharactersInString:@"ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789.-_"];
    return [value rangeOfCharacterFromSet:allowed.invertedSet].location == NSNotFound ? value : nil;
}
static NSString *VVName(id value) {
    if (![value isKindOfClass:NSString.class] || ![value length] || [value lengthOfBytesUsingEncoding:NSUTF8StringEncoding] > 512) return nil;
    NSMutableCharacterSet *forbidden = [NSCharacterSet.controlCharacterSet mutableCopy];
    [forbidden addCharactersInRange:NSMakeRange(0x202A, 5)];
    [forbidden addCharactersInRange:NSMakeRange(0x2066, 4)];
    return [value rangeOfCharacterFromSet:forbidden].location == NSNotFound ? value : nil;
}
static BOOL VVStopped(BOOL (^cancelled)(void), NSTimeInterval deadline) {
    return (cancelled && cancelled()) || NSProcessInfo.processInfo.systemUptime >= deadline;
}
static int VVOpenRoot(NSString *root) {


    NSString *physical = [root hasPrefix:@"/var/"] ? [@"/private" stringByAppendingString:root] : root;
    if (![physical hasPrefix:@"/"]) { errno = EINVAL; return -1; }
    int fd = open("/", O_RDONLY | O_DIRECTORY | O_CLOEXEC);
    for (NSString *part in [physical componentsSeparatedByString:@"/"]) {
        if (!part.length) continue;
        if ([part isEqual:@"."] || [part isEqual:@".."] || [part containsString:@"\\"]) { if (fd >= 0) close(fd); errno = EINVAL; return -1; }
        if (fd < 0) return -1;
        int next = openat(fd, part.fileSystemRepresentation, O_RDONLY | O_DIRECTORY | O_CLOEXEC | O_NOFOLLOW);
        int code = errno; close(fd); fd = next; errno = code;
    }
    return fd;
}
static NSDictionary *VVReadPlist(int parent, const char *leaf, NSUInteger *budget, BOOL (^cancelled)(void), NSTimeInterval deadline) {
    if (VVStopped(cancelled, deadline)) return nil;
    int fd = openat(parent, leaf, O_RDONLY | O_NOFOLLOW | O_NONBLOCK | O_CLOEXEC);
    if (fd < 0) return nil;
    @try {
        struct stat before, after, named;
        if (fstat(fd, &before) || !S_ISREG(before.st_mode) || before.st_size <= 0 || before.st_size > 1024*1024 ||
            (uint64_t)before.st_size > *budget) return nil;
        *budget -= (NSUInteger)before.st_size;
        NSMutableData *data = [NSMutableData dataWithLength:(NSUInteger)before.st_size];
        NSUInteger offset = 0;
        while (offset < data.length) {
            if (VVStopped(cancelled, deadline)) return nil;
            ssize_t count = read(fd, (uint8_t *)data.mutableBytes + offset, MIN((NSUInteger)65536, data.length-offset));
            if (count < 0 && errno == EINTR) continue;
            if (count <= 0) return nil;
            offset += (NSUInteger)count;
        }
        if (fstat(fd, &after) || fstatat(parent, leaf, &named, AT_SYMLINK_NOFOLLOW) ||
            !S_ISREG(named.st_mode) || before.st_dev != named.st_dev || before.st_ino != named.st_ino ||
            before.st_size != after.st_size || before.st_mtimespec.tv_sec != after.st_mtimespec.tv_sec ||
            before.st_mtimespec.tv_nsec != after.st_mtimespec.tv_nsec ||
            before.st_ctimespec.tv_sec != after.st_ctimespec.tv_sec || before.st_ctimespec.tv_nsec != after.st_ctimespec.tv_nsec) return nil;
        id value = [NSPropertyListSerialization propertyListWithData:data options:NSPropertyListImmutable format:NULL error:NULL];
        return [value isKindOfClass:NSDictionary.class] ? value : nil;
    } @finally { close(fd); }
}
static NSArray<NSString *> *VVChildren(NSString *root, NSTimeInterval deadline, NSUInteger limit, BOOL (^cancelled)(void), BOOL *partial) {
    NSMutableArray *paths = [NSMutableArray array];
    int fd = VVOpenRoot(root);
    if (fd < 0) { if (partial) *partial = YES; return paths; }
    DIR *directory = fdopendir(fd);
    if (!directory) { close(fd); if (partial) *partial = YES; return paths; }
    @try {
        struct dirent *entry; NSUInteger inspected = 0;
        while ((entry = readdir(directory))) {
            if (VVStopped(cancelled, deadline) || paths.count >= limit || ++inspected > 4096) { if (partial) *partial = YES; break; }
            NSString *name = [NSString stringWithUTF8String:entry->d_name];
            if (!name || ![[NSUUID alloc] initWithUUIDString:name]) continue;
            struct stat st;
            if (fstatat(fd, entry->d_name, &st, AT_SYMLINK_NOFOLLOW) || !S_ISDIR(st.st_mode)) continue;
            [paths addObject:[root stringByAppendingPathComponent:name]];
        }
    } @finally { closedir(directory); }
    return paths;
}

static NSDictionary *VVBundleNames(BOOL (^cancelled)(void), NSTimeInterval deadline, NSUInteger *budget, BOOL *partial) {
#ifdef VVDIRECT_CATALOG_TESTING
    extern NSString *VVDirectTestBundleRoot(void);
    NSString *root = VVDirectTestBundleRoot();
#else
    NSString *root = @"/var/containers/Bundle/Application";
#endif
    NSMutableDictionary *names = [NSMutableDictionary dictionary];
    for (NSString *uuidPath in VVChildren(root, deadline, 512, cancelled, partial)) {
        if (VVStopped(cancelled, deadline)) { *partial = YES; break; }
        int fd = VVOpenRoot(uuidPath);
        if (fd < 0) continue;
        DIR *directory = fdopendir(fd);
        if (!directory) { close(fd); continue; }
        @try {
            struct dirent *entry; NSUInteger inspected = 0;
            while ((entry = readdir(directory))) {
                if (VVStopped(cancelled, deadline) || ++inspected > 128) { *partial = YES; break; }
                NSString *leaf = [NSString stringWithUTF8String:entry->d_name];
                if (![leaf.pathExtension.lowercaseString isEqual:@"app"]) continue;
                int app = openat(fd, entry->d_name, O_RDONLY | O_DIRECTORY | O_CLOEXEC | O_NOFOLLOW);
                if (app < 0) continue;
                NSDictionary *info = VVReadPlist(app, "Info.plist", budget, cancelled, deadline);
                close(app);
                NSString *identifier = VVIdentifier(info[@"CFBundleIdentifier"]);
                if (!identifier) continue;
                NSDictionary *record = @{@"name":VVName(info[@"CFBundleDisplayName"]) ?: VVName(info[@"CFBundleName"]) ?: identifier,
                    @"bundle_path":[uuidPath stringByAppendingPathComponent:leaf]};
                id previous = names[identifier];
                names[identifier] = !previous || [previous isEqual:record] ? record : NSNull.null;
            }
        } @finally { closedir(directory); }
    }
    return names;
}

NSArray<VVDirectContainerEntry *> *VVDirectDiscoverContainers(BOOL (^cancelled)(void), NSString **notice) {
    if (notice) *notice = nil;
    if (![VVLegacyDirectAccess isReady]) { if (notice) *notice = @"Chưa chuẩn bị quyền truy cập trực tiếp."; return @[]; }
    NSTimeInterval deadline = NSProcessInfo.processInfo.systemUptime + 4;
    NSUInteger budget = 16*1024*1024;
    BOOL partial = NO;


    NSMutableArray<VVDirectContainerEntry *> *result = [NSMutableArray array];
    for (NSString *kind in @[@"app",@"plugin",@"group",@"system"]) {
        for (NSString *path in VVChildren(VVRoots()[kind], deadline, 1024-result.count, cancelled, &partial)) {
            if (VVStopped(cancelled, deadline) || result.count >= 1024) { partial = YES; break; }
            int fd = VVOpenRoot(path);
            if (fd < 0) { partial = YES; continue; }
            NSDictionary *metadata = VVReadPlist(fd, ".com.apple.mobile_container_manager.metadata.plist", &budget, cancelled, deadline);
            close(fd);
            VVDirectContainerEntry *entry = [VVDirectContainerEntry new];
            entry.path = path; entry.kind = kind; entry.identifier = VVIdentifier(metadata[@"MCMMetadataIdentifier"]) ?: @"";
            entry.name = entry.identifier.length ? entry.identifier : [@"Container " stringByAppendingString:path.lastPathComponent];
            [result addObject:entry];
        }
        if (VVStopped(cancelled, deadline) || result.count >= 1024) { partial = YES; break; }
    }
    NSDictionary *names = VVBundleNames(cancelled, deadline, &budget, &partial);
    for (VVDirectContainerEntry *entry in result) {
        id record = names[entry.identifier];
        if ([entry.kind isEqual:@"app"] && [record isKindOfClass:NSDictionary.class]) {
            entry.name = record[@"name"]; entry.bundlePath = record[@"bundle_path"];
        }
    }
    NSString *own = VVCanonical(NSHomeDirectory()), *ownID = VVIdentifier(NSBundle.mainBundle.bundleIdentifier);
    if (ownID && !VVStopped(cancelled, deadline)) {
        BOOL found = NO;
        for (VVDirectContainerEntry *entry in result) if ([entry.path isEqual:own]) { found = YES; break; }
        if (!found && result.count < 1024) {
            VVDirectContainerEntry *entry = [VVDirectContainerEntry new]; entry.path=own; entry.kind=@"app"; entry.identifier=ownID;
            entry.name=VVName(NSBundle.mainBundle.infoDictionary[@"CFBundleDisplayName"]) ?: ownID;
            entry.bundlePath=VVCanonical(NSBundle.mainBundle.bundlePath); [result addObject:entry];
        }
    }
    if (notice && (partial || budget == 0 || (cancelled && cancelled())))
        *notice = @"Danh sách trực tiếp chưa đầy đủ hoặc đã chạm giới hạn. Các container chưa có định danh vẫn giữ tên thư mục.";
    return result;
}
NSArray<VVDirectContainerEntry *> *VVDirectDiscoverPatchTargets(BOOL (^cancelled)(void), NSString **notice) {
    return VVDirectDiscoverContainers(cancelled, notice);
}
NSArray<NSString *> *VVDirectDiscoverContainerPaths(NSString *root, NSTimeInterval timeLimit, NSUInteger resultLimit,
    BOOL (^cancelled)(void), BOOL *stoppedEarly, NSString **error) {
    if (stoppedEarly) *stoppedEarly = NO;
    if (error) *error = nil;
    if (![VVLegacyDirectAccess isReady] || ![VVRoots().allValues containsObject:root]) {
        if (error) *error = @"Chưa mở được vị trí này bằng truy cập trực tiếp.";
        return @[];
    }
    return VVChildren(root, NSProcessInfo.processInfo.systemUptime + MIN(MAX(timeLimit, 0), 4), MIN(resultLimit, (NSUInteger)1024), cancelled, stoppedEarly);
}
NSDictionary *VVDirectResolveApplicationTarget(NSString *bundleID, BOOL (^cancelled)(void), NSError **error) {
    if (error) *error = nil;
    NSMutableDictionary *matches = [NSMutableDictionary dictionary];
    for (VVDirectContainerEntry *entry in VVDirectDiscoverContainers(cancelled, nil))
        if ([entry.kind isEqual:@"app"] && [entry.identifier isEqual:bundleID]) matches[entry.path] = entry;
    if (cancelled && cancelled()) { if (error) *error = [NSError errorWithDomain:NSCocoaErrorDomain code:NSUserCancelledError userInfo:nil]; return nil; }
    if (!VVIdentifier(bundleID) || matches.count != 1) {
        if (error) *error = [NSError errorWithDomain:@"CC365.BQResolve" code:(!VVIdentifier(bundleID) || matches.count > 1) ? 2 : 1
            userInfo:@{NSLocalizedDescriptionKey:matches.count > 1 ? @"Nhiều container có cùng định danh ứng dụng. Chưa thể chọn đích an toàn." : @"Chưa tìm thấy container có định danh này bằng truy cập trực tiếp."}];
        return nil;
    }
    VVDirectContainerEntry *entry = matches.allValues.firstObject;
    NSMutableDictionary *row = [@{@"bundle_id":bundleID, @"name":entry.name, @"data_path":entry.path,
        @"target_id":[@"path:" stringByAppendingString:entry.path]} mutableCopy];
    if (entry.bundlePath.length) row[@"bundle_path"] = entry.bundlePath;
    return row;
}
