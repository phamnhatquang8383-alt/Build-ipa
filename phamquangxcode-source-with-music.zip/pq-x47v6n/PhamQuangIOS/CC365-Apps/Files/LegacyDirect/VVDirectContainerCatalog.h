#pragma once
#import <Foundation/Foundation.h>
NS_ASSUME_NONNULL_BEGIN
@interface VVDirectContainerEntry : NSObject
@property(nonatomic, copy, readonly) NSString *name;
@property(nonatomic, copy, readonly) NSString *identifier;
@property(nonatomic, copy, readonly) NSString *path;
@property(nonatomic, copy, readonly) NSString *kind;
@property(nonatomic, copy, readonly, nullable) NSString *bundlePath;
@property(nonatomic, readonly) BOOL accessRestricted;
@end

NSArray<VVDirectContainerEntry *> *VVDirectDiscoverContainers(BOOL (^ _Nullable cancelled)(void), NSString * _Nullable * _Nullable notice);
NSArray<VVDirectContainerEntry *> *VVDirectDiscoverPatchTargets(BOOL (^ _Nullable cancelled)(void), NSString * _Nullable * _Nullable notice);
NSArray<NSString *> *VVDirectDiscoverContainerPaths(NSString *root, NSTimeInterval timeLimit, NSUInteger resultLimit,
    BOOL (^ _Nullable cancelled)(void), BOOL * _Nullable stoppedEarly, NSString * _Nullable * _Nullable error);
NSDictionary * _Nullable VVDirectResolveApplicationTarget(NSString *bundleID, BOOL (^ _Nullable cancelled)(void), NSError * _Nullable * _Nullable error);
NS_ASSUME_NONNULL_END
