#import "VVDirectPatchEngine.h"
#import "VVLegacyDirectAccess.h"
#import "VVDirectFileSystem.h"
#import "VVDirectContainerCatalog.h"
#import "VVDirectContainerCatalog.h"
#ifndef VVDirect_PATCH_TESTING
#import "VVDirectSupport.h"
#else
extern dispatch_queue_t BQWorkQueue(void);
extern void BQLog(NSString *format, ...) NS_FORMAT_FUNCTION(1, 2);
extern NSString *VVDirectTestSupportDirectory(void);
#endif
#import <CommonCrypto/CommonDigest.h>
#import <errno.h>
#import <dirent.h>
#import <string.h>
#import <fcntl.h>
#import <sys/stat.h>
#import <unistd.h>
#import <stdio.h>
#import <math.h>

static const unsigned long long CCMaxFile = 128ULL * 1024 * 1024;
static const unsigned long long CCMaxTotal = 256ULL * 1024 * 1024;
static NSString *const CCConflict = @"Tệp đích đã thay đổi. PhamQuang IOS giữ bản sao và dừng để tránh ghi đè dữ liệu mới.";
static NSString *const CCStorageError = @"Không đọc hoặc lưu được bản sao patch. Hãy kiểm tra dung lượng trống.";

static NSError *CCError(NSString *message) {
    return [NSError errorWithDomain:@"CC365.BQPatch" code:1 userInfo:@{NSLocalizedDescriptionKey:message}];
}
static BOOL CCFail(NSError **error, NSString *message) { if (error) *error = CCError(message); return NO; }
static BOOL CCResolveConflict(NSError **error, NSString *message) {
    if (error) *error = [NSError errorWithDomain:@"CC365.BQResolve" code:2 userInfo:@{NSLocalizedDescriptionKey:message}];
    return NO;
}
static BOOL CCIsResolutionFailure(NSError *error) {
    return [error.domain isEqual:@"CC365.BQResolve"] && error.code != 1;
}
static BOOL CCPOSIX(NSError **error, NSString *message, int code, BOOL retrySafe) {
    NSMutableDictionary *info = [@{NSLocalizedDescriptionKey:message} mutableCopy];
    if (retrySafe && (code == EACCES || code == EPERM)) info[VVDirectRetrySafeKey] = @YES;
    if (error) *error = [NSError errorWithDomain:NSPOSIXErrorDomain code:code userInfo:info];
    return NO;
}
static void CCMarkPreflightDenied(NSError **error) {
    NSError *failure = error ? *error : nil;
    if ([failure.domain isEqual:NSPOSIXErrorDomain] && (failure.code == EACCES || failure.code == EPERM)) {
        CCPOSIX(error, failure.localizedDescription, (int)failure.code, YES);
    }
}
static BOOL CCCancel(NSProgress *progress, NSError **error) {
    if (!progress.cancelled) return NO;
    if (error) *error = [NSError errorWithDomain:NSCocoaErrorDomain code:NSUserCancelledError
        userInfo:@{NSLocalizedDescriptionKey:@"Đã dừng. Bản gốc được giữ để khôi phục."}];
    return YES;
}
static NSString *CCString(id object) { return [object isKindOfClass:NSString.class] ? object : nil; }
static NSString *CCDisplayName(id value) {
    NSString *name = [CCString(value) stringByTrimmingCharactersInSet:NSCharacterSet.whitespaceAndNewlineCharacterSet];
    return name.length && name.length <= 256 && [name rangeOfCharacterFromSet:NSCharacterSet.controlCharacterSet].location == NSNotFound ? name : nil;
}
static NSString *CCNormal(NSString *path) {
    if (![path isKindOfClass:NSString.class] || !path.isAbsolutePath ||
        [path rangeOfCharacterFromSet:NSCharacterSet.controlCharacterSet].location != NSNotFound) return nil;
    if ([path.pathComponents containsObject:@".."]) return nil;
    NSString *clean = path.stringByStandardizingPath;
    return [clean hasPrefix:@"/private/var/"] ? [clean substringFromIndex:8] : clean;
}
static NSString *CCTargetID(NSString *path) {
    NSString *normal = CCNormal(path);
    return normal.length ? [@"path:" stringByAppendingString:normal] : nil;
}
static BOOL CCKnownBundle(NSString *bundle) {
    if (!bundle.length || bundle.length > 255) return NO;
    NSCharacterSet *allowed = [NSCharacterSet characterSetWithCharactersInString:@"ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789.-_"];
    return [bundle rangeOfCharacterFromSet:allowed.invertedSet].location == NSNotFound;
}
static BOOL CCRelative(NSString *path) {
    if (![path isKindOfClass:NSString.class] || !path.length || [path lengthOfBytesUsingEncoding:NSUTF8StringEncoding] > 1024) return NO;
    NSArray *parts = [path componentsSeparatedByString:@"/"];
    if (parts.count > 32) return NO;
    for (NSString *part in parts) {
        if (!part.length || [part hasPrefix:@"."] || [part lengthOfBytesUsingEncoding:NSUTF8StringEncoding] > 255 ||
            [part containsString:@"\\"] || [part rangeOfCharacterFromSet:NSCharacterSet.controlCharacterSet].location != NSNotFound) return NO;
    }
    return YES;
}
static BOOL CCBundleResource(NSString *relative) {
    NSArray *reserved = @[@"info.plist", @"_codesignature", @"sc_info", @"frameworks", @"plugins", @"appclips", @"watch", @"coderesources", @"embedded.mobileprovision", @"embedded.provisionprofile", @"pkginfo"];
    NSString *executable = [NSBundle.mainBundle objectForInfoDictionaryKey:@"CFBundleExecutable"];
    if ([relative caseInsensitiveCompare:executable ?: @""] == NSOrderedSame) return NO;
    for (NSString *component in relative.pathComponents) {
        NSString *part = component.lowercaseString;
        if ([reserved containsObject:part]) return NO;
        for (NSString *suffix in @[@".app", @".appex", @".framework", @".dylib", @".metallib", @".xpc"]) if ([part hasSuffix:suffix]) return NO;
    }
    return YES;
}
static BOOL CCDestination(NSString *relative, NSString *scope) {
    if (!CCRelative(relative)) return NO;
    return [scope isEqualToString:@"data"] ? ([relative hasPrefix:@"Documents/"] || [relative hasPrefix:@"Library/Caches/"]) : CCBundleResource(relative);
}
static NSString *CCHex(const unsigned char *bytes, NSUInteger count) {
    NSMutableString *result = [NSMutableString stringWithCapacity:count * 2];
    for (NSUInteger i = 0; i < count; i++) [result appendFormat:@"%02x", bytes[i]];
    return result;
}
static NSString *CCHashData(NSData *data) {
    unsigned char digest[CC_SHA256_DIGEST_LENGTH]; CC_SHA256(data.bytes, (CC_LONG)data.length, digest);
    return CCHex(digest, sizeof(digest));
}
static BOOL CCStampValid(id stamp) {
    if (![stamp isKindOfClass:NSDictionary.class]) return NO;
    NSString *hash = CCString(stamp[@"hash"]);
    return hash.length == 64 && [hash rangeOfCharacterFromSet:[NSCharacterSet characterSetWithCharactersInString:@"0123456789abcdef"].invertedSet].location == NSNotFound &&
        [stamp[@"size"] isKindOfClass:NSNumber.class] && [stamp[@"size"] unsignedLongLongValue] <= CCMaxFile;
}
static BOOL CCStampEqual(NSDictionary *a, NSDictionary *b) {
    return a && b && [a[@"hash"] isEqual:b[@"hash"]] && [a[@"size"] isEqual:b[@"size"]];
}


static int CCParent(int root, NSString *relative, NSError **error) {
    int current = dup(root);
    if (current < 0) { CCFail(error, CCStorageError); return -1; }
    NSArray *parts = relative.pathComponents;
    for (NSUInteger i = 0; i + 1 < parts.count; i++) {
        int next = openat(current, [parts[i] fileSystemRepresentation], O_RDONLY | O_DIRECTORY | O_NOFOLLOW | O_CLOEXEC);
        int code = errno;
        close(current);
        if (next < 0) { CCPOSIX(error, @"Không mở được thư mục cha. Đường dẫn phải có sẵn và không đi qua liên kết.", code, NO); return -1; }
        current = next;
    }
    return current;
}
static BOOL CCWriteAll(int fd, const void *buffer, size_t count) {
    const char *bytes = buffer;
    while (count) { ssize_t n = write(fd, bytes, count); if (n < 0 && errno == EINTR) continue; if (n <= 0) return NO; bytes += n; count -= n; }
    return YES;
}


static NSDictionary *CCReadFD(int input, int output, BOOL bundle, NSProgress *progress, NSError **error) {
    struct stat before, after;
    if (fstat(input, &before) || !S_ISREG(before.st_mode) || before.st_size < 0 || (unsigned long long)before.st_size > CCMaxFile) {
        CCFail(error, @"Chỉ hỗ trợ tệp thường tối đa 128 MiB; không mở liên kết hoặc tệp đặc biệt."); return nil;
    }
    if (bundle && (before.st_mode & 0111)) { CCFail(error, @"Không thay tệp thực thi trong gói ứng dụng."); return nil; }
    CC_SHA256_CTX context; CC_SHA256_Init(&context);
    unsigned long long total = 0; unsigned char buffer[64 * 1024]; BOOL first = YES;
    while (YES) {
        if (CCCancel(progress, error)) return nil;
        ssize_t count = read(input, buffer, sizeof(buffer));
        if (count < 0 && errno == EINTR) continue;
        if (count < 0) { CCFail(error, CCStorageError); return nil; }
        if (!count) break;
        if (first && bundle) {
            uint32_t magic = 0; if (count >= 4) memcpy(&magic, buffer, 4);
            if ((count >= 2 && buffer[0] == '#' && buffer[1] == '!') || magic == 0xfeedface || magic == 0xfeedfacf || magic == 0xcefaedfe || magic == 0xcffaedfe || magic == 0xcafebabe || magic == 0xbebafeca || magic == 0xcafebabf || magic == 0xbfbafeca) {
                CCFail(error, @"Không thay mã thực thi trong gói ứng dụng."); return nil;
            }
        }
        first = NO; total += (unsigned long long)count;
        if (total > CCMaxFile) { CCFail(error, @"Tệp vượt giới hạn 128 MiB."); return nil; }
        CC_SHA256_Update(&context, buffer, (CC_LONG)count);
        if (output >= 0 && !CCWriteAll(output, buffer, (size_t)count)) { CCFail(error, CCStorageError); return nil; }
    }
    if (fstat(input, &after) || before.st_dev != after.st_dev || before.st_ino != after.st_ino || before.st_size != after.st_size ||
        before.st_mtimespec.tv_sec != after.st_mtimespec.tv_sec || before.st_mtimespec.tv_nsec != after.st_mtimespec.tv_nsec ||
        before.st_ctimespec.tv_sec != after.st_ctimespec.tv_sec || before.st_ctimespec.tv_nsec != after.st_ctimespec.tv_nsec || total != (unsigned long long)before.st_size) {
        CCFail(error, CCConflict); return nil;
    }
    if (output >= 0 && fsync(output)) { CCFail(error, CCStorageError); return nil; }
    unsigned char digest[CC_SHA256_DIGEST_LENGTH]; CC_SHA256_Final(digest, &context);
    return @{@"hash":CCHex(digest, sizeof(digest)), @"size":@(total), @"mode":@(before.st_mode & 0777)};
}
static NSDictionary *CCReadAt(int parent, NSString *name, int output, BOOL bundle, BOOL *missing, NSProgress *progress, NSError **error) {
    if (missing) *missing = NO;
    int input = openat(parent, name.fileSystemRepresentation, O_RDONLY | O_NOFOLLOW | O_NONBLOCK | O_CLOEXEC);
    if (input < 0) {
        if (errno == ENOENT && missing) { *missing = YES; return nil; }
        CCFail(error, @"Không đọc được tệp; tệp phải là tệp thường và iOS phải cho phép truy cập."); return nil;
    }
    NSDictionary *stamp = CCReadFD(input, output, bundle, progress, error); close(input); return stamp;
}
static int CCCreateAt(int directory, NSString *name, NSError **error) {
    int fd = openat(directory, name.fileSystemRepresentation, O_WRONLY | O_CREAT | O_EXCL | O_NOFOLLOW | O_CLOEXEC, 0600);
    if (fd < 0) CCFail(error, CCStorageError);
    return fd;
}
static NSString *CCSupport(void) {
#ifdef VVDirect_PATCH_TESTING
    return VVDirectTestSupportDirectory();
#else
    return NSSearchPathForDirectoriesInDomains(NSApplicationSupportDirectory, NSUserDomainMask, YES).firstObject;
#endif
}
static NSString *CCSlotPath(NSString *bundle, NSString *scope, NSError **error) {
    NSString *base = [CCSupport() stringByAppendingPathComponent:@"CC365-BQPatch-v1"];
    NSMutableData *key = [NSMutableData dataWithData:[bundle dataUsingEncoding:NSUTF8StringEncoding]];
    [key appendBytes:"\0" length:1]; [key appendData:[scope dataUsingEncoding:NSUTF8StringEncoding]];
    NSString *slot = [base stringByAppendingPathComponent:CCHashData(key)];
    for (NSString *path in @[CCSupport(), base, slot]) {
        struct stat st;
        if (lstat(path.fileSystemRepresentation, &st) == 0) {
            if (!S_ISDIR(st.st_mode)) { CCFail(error, CCStorageError); return nil; }
        } else if (errno != ENOENT || ![NSFileManager.defaultManager createDirectoryAtPath:path withIntermediateDirectories:YES attributes:@{NSFilePosixPermissions:@0700} error:error]) return nil;
    }
    return slot;
}
static BOOL CCSave(int slot, NSDictionary *journal, NSError **error) {
    NSMutableDictionary *saved = [journal mutableCopy];
    saved[@"updated_at"] = @(NSDate.date.timeIntervalSince1970);
    NSData *data = [NSJSONSerialization dataWithJSONObject:saved options:NSJSONWritingSortedKeys error:error];
    if (!data || data.length > 4 * 1024 * 1024) return CCFail(error, CCStorageError);
    NSString *name = [@"journal-" stringByAppendingString:NSUUID.UUID.UUIDString];
    int fd = CCCreateAt(slot, name, error); if (fd < 0) return NO;
    BOOL success = CCWriteAll(fd, data.bytes, data.length) && fsync(fd) == 0;
    if (close(fd)) success = NO;
    if (success) success = renameat(slot, name.fileSystemRepresentation, slot, "journal.json") == 0 && fsync(slot) == 0;
    if (!success) { unlinkat(slot, name.fileSystemRepresentation, 0); return CCFail(error, CCStorageError); }
    return YES;
}
static NSMutableDictionary *CCLoad(int slot, NSString *bundle, NSString *scope, NSError **error) {
    int fd = openat(slot, "journal.json", O_RDONLY | O_NOFOLLOW | O_NONBLOCK | O_CLOEXEC);
    if (fd < 0) { if (errno != ENOENT) CCFail(error, CCStorageError); return nil; }
    struct stat st;
    if (fstat(fd, &st) || !S_ISREG(st.st_mode) || st.st_size < 0 || st.st_size > 4 * 1024 * 1024) { close(fd); CCFail(error, CCStorageError); return nil; }
    NSMutableData *data = [NSMutableData data]; uint8_t buffer[8192];
    while (YES) { ssize_t n = read(fd, buffer, sizeof(buffer)); if (n < 0 && errno == EINTR) continue; if (n < 0 || data.length + MAX(0, n) > 4 * 1024 * 1024) { close(fd); CCFail(error, CCStorageError); return nil; } if (!n) break; [data appendBytes:buffer length:n]; }
    close(fd);
    id journal = [NSJSONSerialization JSONObjectWithData:data options:NSJSONReadingMutableContainers error:error];
    NSString *storedBundle = [journal isKindOfClass:NSDictionary.class] ? CCString(journal[@"bundle"]) : nil;
    NSString *storedTarget = [journal isKindOfClass:NSDictionary.class] ? CCString(journal[@"target_id"]) : nil;
    NSString *storedScope = [journal isKindOfClass:NSDictionary.class] ? CCString(journal[@"scope"]) : nil;
    BOOL pathIdentity = [storedTarget hasPrefix:@"path:"] && [CCTargetID([storedTarget substringFromIndex:5]) isEqual:storedTarget];
    BOOL valid = [journal isKindOfClass:NSDictionary.class] && [journal[@"version"] isEqual:@1] &&
        (CCKnownBundle(storedBundle) || (pathIdentity && storedBundle != nil && !storedBundle.length)) &&
        (!bundle || [storedBundle isEqual:bundle]) && (!scope || [storedScope isEqual:scope]) &&
        [@[@"data", @"bundle"] containsObject:storedScope] && (!storedTarget || pathIdentity) &&
        (!pathIdentity || ![storedScope isEqual:@"data"] || [CCTargetID(journal[@"root"]) isEqual:storedTarget]) &&
        CCNormal(journal[@"root"]) && [@[@"pending", @"applied", @"restored"] containsObject:journal[@"state"]] &&
        [journal[@"entries"] isKindOfClass:NSArray.class] && [journal[@"entries"] count] <= 1024 && [journal[@"token"] isKindOfClass:NSString.class] && [[NSUUID alloc] initWithUUIDString:journal[@"token"]];
    NSMutableSet *seen = [NSMutableSet set];
    if (valid) for (id entry in journal[@"entries"]) {
        NSString *relative = [entry isKindOfClass:NSDictionary.class] ? CCString(entry[@"rel"]) : nil;
        if (!CCDestination(relative, storedScope) || [seen containsObject:relative.lowercaseString] || !CCStampValid(entry[@"replacement"]) ||
            (entry[@"original"] != NSNull.null && !CCStampValid(entry[@"original"])) ||
            ![@[@"prepared", @"armed", @"applied", @"restored"] containsObject:entry[@"state"]]) { valid = NO; break; }
        [seen addObject:relative.lowercaseString];
    }
    if (!valid) { CCFail(error, @"Biên nhận patch không hợp lệ. PhamQuang IOS giữ nguyên bản sao để kiểm tra."); return nil; }
    return journal;
}
static NSArray<NSDictionary *> *CCAppRows(NSArray<VVDirectContainerEntry *> *entries) {
    NSMutableArray *apps = [NSMutableArray array]; NSMutableSet *paths = [NSMutableSet set];
    for (VVDirectContainerEntry *entry in entries) {
        NSString *path = CCNormal(entry.path);
        if (![entry.kind isEqualToString:@"app"] || !path || [paths containsObject:path]) continue;
        [paths addObject:path];
        NSString *bundle = CCKnownBundle(entry.identifier) ? entry.identifier : nil;
        NSString *displayName = entry.name.length && ![entry.name isEqualToString:path.lastPathComponent] ? entry.name : bundle;
        NSString *name = bundle ? displayName : [@"Container " stringByAppendingString:path.lastPathComponent];
        NSMutableDictionary *app = [@{@"target_id":CCTargetID(path), @"name":name, @"data_path":path} mutableCopy];
        if (bundle) app[@"bundle_id"] = bundle;
        if (entry.bundlePath.length) app[@"bundle_path"] = entry.bundlePath;
        else if (bundle && [bundle isEqualToString:NSBundle.mainBundle.bundleIdentifier]) app[@"bundle_path"] = NSBundle.mainBundle.bundlePath;
        [apps addObject:app];
    }
    return apps;
}

static NSArray<NSDictionary *> *CCApps(NSProgress *progress, NSString **notice) {
    NSString *discovery = nil;
    NSArray *apps = CCAppRows(VVDirectDiscoverPatchTargets(^BOOL { return progress.cancelled; }, &discovery));
    NSUInteger identified = 0, named = 0;
    for (NSDictionary *app in apps) {
        NSString *bundle = CCString(app[@"bundle_id"]);
        if (!bundle) continue;
        identified++;
        if (![app[@"name"] isEqualToString:bundle]) named++;
    }


    BQLog(@"catalog picker_rows rows=%lu identified=%lu named=%lu unknown=%lu cancelled=%d",
        (unsigned long)apps.count, (unsigned long)identified, (unsigned long)named,
        (unsigned long)(apps.count - identified), progress.cancelled);
    if (notice) {


        NSDictionary *translations = @{
            @"iOS did not expose the application catalog; showing filesystem results.": @"iOS chưa cung cấp danh sách ứng dụng; đang hiển thị các container tìm thấy trên hệ thống tệp.",
            @"The application catalog reached its result limit.": @"Danh sách ứng dụng đã đạt giới hạn kết quả.",
            @"Application container paths are hidden on this device; showing filesystem results.": @"iOS đang ẩn đường dẫn container của ứng dụng; đang hiển thị các container tìm thấy trên hệ thống tệp.",
            @"The application catalog is unavailable on this iOS build.": @"Danh sách ứng dụng chưa khả dụng trên bản iOS này.",
            @"An earlier application lookup is still finishing; showing filesystem results.": @"Lượt tìm ứng dụng trước vẫn đang kết thúc; đang hiển thị các container tìm thấy trên hệ thống tệp.",
            @"The application lookup stopped early; showing available filesystem results.": @"Lượt tìm ứng dụng đã dừng sớm; đang hiển thị các container đã tìm thấy.",
            @"Some container directories could not be fully listed.": @"Chưa liệt kê đầy đủ một số thư mục container.",
            @"iOS restricts container listing; bounded discovery may miss some apps or groups.": @"iOS giới hạn việc liệt kê container; danh sách có thể thiếu một số ứng dụng hoặc nhóm.",
            @"The container scan stopped at its time or result limit.": @"Lượt quét container đã đạt giới hạn thời gian hoặc số kết quả.",
            @"Some standard container locations are unavailable on this device.": @"Một số vị trí container thông thường không khả dụng trên thiết bị này.",
            @"Discovery cancelled; showing results found so far.": @"Đã dừng tìm kiếm; đang hiển thị các kết quả đã tìm thấy.",
            @"Discovery reached its time or result limit; showing partial results.": @"Tìm kiếm đã đạt giới hạn thời gian hoặc số kết quả; danh sách hiện chưa đầy đủ.",
            @"Some observed containers cannot be checked directly. Access is checked when you open them.": @"Một số container chưa thể kiểm tra trực tiếp. Quyền truy cập sẽ được kiểm tra khi bạn mở chúng.",
            @"Only container paths exposed by this device are shown; this may not include every installed app.": @"Danh sách chỉ gồm các container thiết bị hiện cung cấp; có thể chưa đủ mọi ứng dụng đã cài.",
            @"The device did not expose paths for this container root.": @"Thiết bị chưa cung cấp đường dẫn trong vùng container này.",
            @"This path is not a supported container discovery root.": @"Vị trí này không thuộc vùng tìm container được hỗ trợ."
        };
        NSString *localized = discovery ?: @"";
        for (NSString *source in translations) localized = [localized stringByReplacingOccurrencesOfString:source withString:translations[source]];
        NSUInteger unknown = 0;
        for (NSDictionary *app in apps) if (!CCString(app[@"bundle_id"]).length) unknown++;
        if (unknown && ![localized containsString:@"chưa xác định được bundle ID"]) {
            NSString *detail = [NSString stringWithFormat:@"%lu container ứng dụng chưa xác định được bundle ID; bạn vẫn có thể chọn bằng đường dẫn.", (unsigned long)unknown];
            localized = localized.length ? [localized stringByAppendingFormat:@"\n\n%@", detail] : detail;
        }
        *notice = localized.length ? localized : nil;
    }
    return apps;
}
static BOOL CCNativeNoConflict(NSArray<VVDirectContainerEntry *> *entries, NSString *bundle, NSString *path, NSError **error) {




    NSMutableSet<NSString *> *owners = [NSMutableSet set];
    for (VVDirectContainerEntry *entry in entries) {
        if (![entry.kind isEqual:@"app"]) continue;
        NSString *root = CCNormal(entry.path), *known = CCKnownBundle(entry.identifier) ? entry.identifier : nil;
        if ([root isEqual:path]) {
            if (known.length) [owners addObject:known];
            if (known.length && bundle.length && ![known isEqual:bundle]) return CCResolveConflict(error, @"Container hiện thuộc ứng dụng khác. Hãy nhận diện lại ứng dụng.");
        } else if (bundle.length && [known isEqual:bundle]) {
            return CCFail(error, @"Vị trí ứng dụng không khớp container đang được iOS cung cấp.");
        }
    }
    if (owners.count > 1) return CCResolveConflict(error, @"Container có nhiều định danh ứng dụng mâu thuẫn. Chưa chọn đích patch.");
    return YES;
}



static NSDictionary *CCActiveReceipt(NSString *base, NSString *preferred, NSString *root, NSString *targetID,
                                     NSString *bundle, NSString *scope, NSProgress *progress, NSError **error) {
    int directory = open(base.fileSystemRepresentation, O_RDONLY | O_DIRECTORY | O_NOFOLLOW | O_CLOEXEC);
    if (directory < 0) { CCFail(error, CCStorageError); return nil; }
    DIR *listing = fdopendir(dup(directory));
    if (!listing) { close(directory); CCFail(error, CCStorageError); return nil; }
    NSMutableArray *matches = [NSMutableArray array]; NSUInteger inspected = 0;
    NSTimeInterval deadline = NSProcessInfo.processInfo.systemUptime + 3.0;
    @try {
        for (;;) {
            if (CCCancel(progress, error)) return nil;
            errno = 0; struct dirent *item = readdir(listing);
            if (!item) { if (errno) CCFail(error, CCStorageError); break; }
            if (!strcmp(item->d_name, ".") || !strcmp(item->d_name, "..")) continue;
            if (++inspected > 4096 || NSProcessInfo.processInfo.systemUptime > deadline) {
                CCFail(error, @"Chưa kiểm tra hết các biên nhận patch đang lưu. PhamQuang IOS giữ dữ liệu và chưa bắt đầu thay tệp."); return nil;
            }
            NSString *name = [NSFileManager.defaultManager stringWithFileSystemRepresentation:item->d_name length:strlen(item->d_name)];
            if (name.length != 64 || [name rangeOfCharacterFromSet:[NSCharacterSet characterSetWithCharactersInString:@"0123456789abcdef"].invertedSet].location != NSNotFound) continue;
            int slot = openat(directory, item->d_name, O_RDONLY | O_DIRECTORY | O_NOFOLLOW | O_CLOEXEC);
            if (slot < 0) { CCFail(error, CCStorageError); return nil; }
            NSError *failure = nil; NSMutableDictionary *journal = CCLoad(slot, nil, nil, &failure); close(slot);
            if (failure) { if (error) *error = failure; return nil; }
            if (!journal || [journal[@"state"] isEqual:@"restored"] || ![journal[@"scope"] isEqual:scope]) continue;
            NSString *path = [base stringByAppendingPathComponent:name];
            BOOL sameRoot = root && [CCNormal(journal[@"root"]) isEqual:root];
            BOOL sameTarget = targetID && [journal[@"target_id"] isEqual:targetID];
            BOOL sameBundle = bundle.length && [journal[@"bundle"] isEqual:bundle];
            if (sameRoot || sameTarget || sameBundle || [path isEqual:preferred]) [matches addObject:@{@"path":path, @"journal":journal}];
        }
        if (*error) return nil;
        if (matches.count > 1) { CCFail(error, @"Có nhiều biên nhận đang mở cho cùng ứng dụng hoặc container. PhamQuang IOS giữ toàn bộ bản sao và chưa thay tệp để tránh chồng patch."); return nil; }
        return matches.firstObject;
    } @finally { closedir(listing); close(directory); }
}
static NSDictionary *CCStatus(NSDictionary *journal, NSString *noneMessage) {
    if (!journal) return @{@"state":@"none", @"changed":@0, @"created":@0, @"skipped":@0, @"bytes":@0, @"restore_paths":@[], @"message":noneMessage ?: @"Chưa có patch cần khôi phục."};
    NSUInteger changed = 0, created = 0; unsigned long long bytes = 0; NSMutableArray *paths = [NSMutableArray array];
    for (NSDictionary *entry in journal[@"entries"]) { changed++; if (entry[@"original"] == NSNull.null) created++; bytes += [entry[@"replacement"][@"size"] unsignedLongLongValue]; if (![entry[@"state"] isEqual:@"restored"]) [paths addObject:entry[@"rel"]]; }
    NSString *state = journal[@"state"];
    NSString *message = [state isEqual:@"applied"] ? @"Đã áp dụng và đối chiếu SHA-256. Bản gốc được giữ để khôi phục." : ([state isEqual:@"restored"] ? @"Đã khôi phục bản gốc và kiểm tra nội dung." : @"Phiên patch chưa hoàn tất. Chọn Khôi phục bản gốc trước khi áp dụng lượt mới.");
    NSNumber *skipped = [journal[@"skipped"] isKindOfClass:NSNumber.class] && [journal[@"skipped"] longLongValue] >= 0 && [journal[@"skipped"] unsignedLongLongValue] <= 1024 ? journal[@"skipped"] : @0;
    return @{@"state":state, @"changed":@(changed), @"created":@(created), @"skipped":skipped, @"bytes":@(bytes), @"restore_paths":paths, @"message":message};
}


static NSDictionary *CCHistory(NSProgress *progress, NSError **error) {
    NSString *base = [CCSupport() stringByAppendingPathComponent:@"CC365-BQPatch-v1"];
    int directory = open(base.fileSystemRepresentation, O_RDONLY | O_DIRECTORY | O_NOFOLLOW | O_CLOEXEC);
    if (directory < 0) {
        if (errno == ENOENT) return @{@"patches":@[]};
        CCFail(error, CCStorageError); return nil;
    }
    DIR *listing = fdopendir(dup(directory));
    if (!listing) { close(directory); CCFail(error, CCStorageError); return nil; }
    NSMutableArray<NSMutableDictionary *> *rows = [NSMutableArray array];
    NSMutableDictionary<NSString *, NSMutableArray *> *aliases = [NSMutableDictionary dictionary];
    NSUInteger inspected = 0, invalid = 0; unsigned long long bytes = 0;
    BOOL incomplete = NO;
    NSTimeInterval deadline = NSProcessInfo.processInfo.systemUptime + 3.0;
    @try {
        for (;;) {
            if (CCCancel(progress, error)) return nil;
            errno = 0; struct dirent *item = readdir(listing);
            if (!item) { if (errno) incomplete = YES; break; }
            if (!strcmp(item->d_name, ".") || !strcmp(item->d_name, "..")) continue;
            if (++inspected > 4096 || NSProcessInfo.processInfo.systemUptime > deadline) { incomplete = YES; break; }
            NSString *name = [NSFileManager.defaultManager stringWithFileSystemRepresentation:item->d_name length:strlen(item->d_name)];
            if (name.length != 64 || [name rangeOfCharacterFromSet:[NSCharacterSet characterSetWithCharactersInString:@"0123456789abcdef"].invertedSet].location != NSNotFound) continue;
            int slot = openat(directory, item->d_name, O_RDONLY | O_DIRECTORY | O_NOFOLLOW | O_CLOEXEC);
            if (slot < 0) { invalid++; continue; }
            struct stat st; NSError *failure = nil; NSMutableDictionary *journal = nil;
            @try {
                if (fstatat(slot, "journal.json", &st, AT_SYMLINK_NOFOLLOW)) { if (errno != ENOENT) invalid++; continue; }
                if (!S_ISREG(st.st_mode) || st.st_size < 0 || st.st_size > 4 * 1024 * 1024) { invalid++; continue; }
                bytes += (unsigned long long)st.st_size;
                if (bytes > 32ULL * 1024 * 1024) { incomplete = YES; break; }
                journal = CCLoad(slot, nil, nil, &failure);
            } @finally { close(slot); }
            if (failure) { invalid++; continue; }
            if (!journal || [journal[@"state"] isEqual:@"restored"]) continue;
            NSString *scope = journal[@"scope"], *root = CCNormal(journal[@"root"]);
            NSString *bundle = CCKnownBundle(CCString(journal[@"bundle"])) ? journal[@"bundle"] : nil;
            NSString *targetID = CCString(journal[@"target_id"]);
            BOOL dataScope = [scope isEqual:@"data"];
            if (dataScope) targetID = CCTargetID(root);  
            NSString *dataRoot = dataScope ? root : ([targetID hasPrefix:@"path:"] ? [targetID substringFromIndex:5] : nil);
            NSString *display = CCDisplayName(journal[@"app_name"]) ?: bundle ?: [@"Container " stringByAppendingString:(dataRoot ?: root).lastPathComponent];
            NSMutableDictionary *app = [@{@"name":display} mutableCopy];
            if (bundle) app[@"bundle_id"] = bundle;
            if (targetID) app[@"target_id"] = targetID;
            if (dataRoot) app[@"data_path"] = dataRoot;
            if (!dataScope) app[@"bundle_path"] = root;
            double updated = [journal[@"updated_at"] isKindOfClass:NSNumber.class] ? [journal[@"updated_at"] doubleValue] : 0;
            if (!isfinite(updated) || updated <= 0 || updated > NSDate.date.timeIntervalSince1970 + 86400) updated = MAX(0, st.st_mtimespec.tv_sec);
            NSMutableDictionary *row = [@{@"id":name, @"app":app, @"patch_scope":scope, @"status":CCStatus(journal, nil),
                @"updated_at":@(updated), @"can_restore":@YES} mutableCopy];
            [rows addObject:row];
            NSMutableArray *keys = [NSMutableArray arrayWithObject:[NSString stringWithFormat:@"%@\nroot:%@", scope, root]];
            if (targetID) [keys addObject:[NSString stringWithFormat:@"%@\ntarget:%@", scope, targetID]];
            if (bundle) [keys addObject:[NSString stringWithFormat:@"%@\nbundle:%@", scope, bundle]];
            for (NSString *key in keys) { if (!aliases[key]) aliases[key] = [NSMutableArray array]; [aliases[key] addObject:row]; }
        }
    } @finally { closedir(listing); close(directory); }
    if (CCCancel(progress, error)) return nil;
    NSString *duplicateNotice = @"Có nhiều biên nhận đang mở cho cùng ứng dụng hoặc container. Toàn bộ bản sao được giữ để kiểm tra trước khi khôi phục.";
    for (NSArray *matches in aliases.allValues) if (matches.count > 1) for (NSMutableDictionary *row in matches) {
        row[@"can_restore"] = @NO; row[@"notice"] = duplicateNotice;
    }
    NSMutableDictionary *result = [NSMutableDictionary dictionary];
    if (invalid || incomplete) {
        NSString *notice = incomplete ? @"Chưa đọc hết danh sách bản sao. PhamQuang IOS giữ nguyên dữ liệu; hãy tải lại trước khi khôi phục." : @"Có biên nhận patch không đọc được. PhamQuang IOS giữ nguyên toàn bộ bản sao để kiểm tra trước khi khôi phục.";
        result[@"notice"] = notice;


        for (NSMutableDictionary *row in rows) { row[@"can_restore"] = @NO; row[@"notice"] = notice; }
    }
    [rows sortUsingComparator:^NSComparisonResult(NSDictionary *left, NSDictionary *right) {
        NSComparisonResult order = [right[@"updated_at"] compare:left[@"updated_at"]];
        return order == NSOrderedSame ? [left[@"id"] compare:right[@"id"]] : order;
    }];
    result[@"patches"] = rows;
    return result;
}
static NSString *CCArtifact(NSUInteger index, BOOL original) { return [NSString stringWithFormat:@"%@-%lu", original ? @"original" : @"replacement", (unsigned long)index]; }
static NSString *CCTemporary(NSDictionary *journal, NSUInteger index) { return [NSString stringWithFormat:@".cc365-%@-%lu", journal[@"token"], (unsigned long)index]; }
static void CCEmit(void (^emit)(NSDictionary *), NSString *phase, NSUInteger done, NSUInteger total, NSString *path) {
    if (emit) emit(@{@"phase":phase, @"done":@(done), @"total":@(total), @"path":path ?: @""});
}

static BOOL CCCleanSlot(int slot, NSError **error) {
    DIR *directory = fdopendir(dup(slot)); if (!directory) return CCFail(error, CCStorageError);
    BOOL ok = YES; struct dirent *item;
    while ((item = readdir(directory))) {
        NSString *name = [NSFileManager.defaultManager stringWithFileSystemRepresentation:item->d_name length:strlen(item->d_name)];
        if ([name isEqual:@"."] || [name isEqual:@".."] || [name isEqual:@"journal.json"]) continue;
        BOOL owned = [name hasPrefix:@"original-"] || [name hasPrefix:@"replacement-"] || [name hasPrefix:@"journal-"];
        struct stat st;
        if (!owned || fstatat(slot, item->d_name, &st, AT_SYMLINK_NOFOLLOW) || !S_ISREG(st.st_mode) || unlinkat(slot, item->d_name, 0)) { ok = NO; break; }
    }
    closedir(directory);
    if (!ok) return CCFail(error, CCStorageError);
    if (unlinkat(slot, "journal.json", 0) && errno != ENOENT) return CCFail(error, CCStorageError);
    return fsync(slot) == 0 || CCFail(error, CCStorageError);
}
static int CCSource(NSString *path, NSError **error) {
    NSString *temp = CCNormal([NSTemporaryDirectory() stringByAppendingPathComponent:@"CC365-Files"]);
    NSString *normal = CCNormal(path);
    if (!normal || ![normal hasPrefix:[temp stringByAppendingString:@"/"]]) { CCFail(error, @"Nguồn patch phải là bản sao riêng do bộ chọn tệp của PhamQuang IOS chuẩn bị."); return -1; }
    NSString *relative = [normal substringFromIndex:temp.length + 1];
    if (!CCRelative(relative)) { CCFail(error, @"Đường dẫn nguồn không hợp lệ."); return -1; }
    int root = open(temp.fileSystemRepresentation, O_RDONLY | O_DIRECTORY | O_NOFOLLOW | O_CLOEXEC);
    if (root < 0) { CCFail(error, CCStorageError); return -1; }
    int parent = CCParent(root, relative, error); close(root); if (parent < 0) return -1;
    int input = openat(parent, relative.lastPathComponent.fileSystemRepresentation, O_RDONLY | O_NOFOLLOW | O_NONBLOCK | O_CLOEXEC); close(parent);
    if (input < 0) CCFail(error, CCStorageError);
    return input;
}
static BOOL CCPreflight(int root, NSArray *items, NSError **error) {
    for (NSDictionary *item in items) {
        int parent = CCParent(root, item[@"relative_path"], error);
        if (parent < 0) { CCMarkPreflightDenied(error); return NO; }
        int check = faccessat(parent, ".", W_OK, 0); int code = errno;
        if (check) { close(parent); return CCPOSIX(error, @"iOS chưa cho phép ghi vào thư mục đích.", code, YES); }
        NSString *leaf = [item[@"relative_path"] lastPathComponent];
        int input = openat(parent, leaf.fileSystemRepresentation, O_RDONLY | O_NOFOLLOW | O_NONBLOCK | O_CLOEXEC);
        code = errno; close(parent);
        if (input < 0 && code != ENOENT) return CCPOSIX(error, @"iOS chưa cho phép đọc tệp đích để sao lưu.", code, YES);
        if (input >= 0) {
            struct stat st; BOOL regular = fstat(input, &st) == 0 && S_ISREG(st.st_mode); close(input);
            if (!regular) return CCFail(error, @"Tệp đích phải là tệp thường; không thay liên kết hoặc tệp đặc biệt.");
        }
    }
    return YES;
}
static BOOL CCPrepare(int root, int slot, NSMutableDictionary *journal, NSArray *items, NSProgress *progress, void (^emit)(NSDictionary *), NSError **error) {
    unsigned long long sourceTotal = 0, originalTotal = 0;
    NSMutableArray *entries = journal[@"entries"];
    BOOL bundle = [journal[@"scope"] isEqual:@"bundle"];
    for (NSUInteger itemIndex = 0; itemIndex < items.count; itemIndex++) {
        if (CCCancel(progress, error)) return NO;
        NSDictionary *item = items[itemIndex]; NSString *relative = item[@"relative_path"];
        CCEmit(emit, @"checking", itemIndex, items.count, relative);
        NSUInteger index = entries.count;
        NSString *replacementName = CCArtifact(index, NO), *originalName = CCArtifact(index, YES);
        int input = CCSource(item[@"local_path"], error); if (input < 0) return NO;
        int output = CCCreateAt(slot, replacementName, error); if (output < 0) { close(input); return NO; }
        NSDictionary *replacement = CCReadFD(input, output, bundle, progress, error); close(input);
        if (close(output) && replacement) return CCFail(error, CCStorageError);
        if (!replacement) return NO;
        NSDictionary *replacementCheck = CCReadAt(slot, replacementName, -1, NO, nil, progress, error);
        if (!CCStampEqual(replacement, replacementCheck)) return CCFail(error, CCStorageError);
        sourceTotal += [replacement[@"size"] unsignedLongLongValue];
        if (sourceTotal > CCMaxTotal) return CCFail(error, @"Tổng patch vượt giới hạn 256 MiB.");
        int parent = CCParent(root, relative, error); if (parent < 0) return NO;
        int backup = CCCreateAt(slot, originalName, error); if (backup < 0) { close(parent); return NO; }
        BOOL missing = NO;
        NSDictionary *original = CCReadAt(parent, relative.lastPathComponent, backup, bundle, &missing, progress, error);
        int closedBackup = close(backup); close(parent);
        if (closedBackup && original) return CCFail(error, CCStorageError);
        if (!original && !missing) return NO;
        if (original) {
            NSDictionary *backupCheck = CCReadAt(slot, originalName, -1, NO, nil, progress, error);
            if (!CCStampEqual(original, backupCheck)) return CCFail(error, CCStorageError);
        }
        if (missing) {
            unlinkat(slot, originalName.fileSystemRepresentation, 0);
            if (bundle || ![relative hasPrefix:@"Documents/"]) return CCFail(error, @"Chỉ thêm tệp mới trong Documents. Tệp cache và tài nguyên .app phải có sẵn.");
        } else {
            originalTotal += [original[@"size"] unsignedLongLongValue];
            if (originalTotal > CCMaxTotal) return CCFail(error, @"Bản sao các tệp gốc vượt giới hạn 256 MiB.");
        }
        if (CCStampEqual(original, replacement)) {
            unlinkat(slot, originalName.fileSystemRepresentation, 0); unlinkat(slot, replacementName.fileSystemRepresentation, 0);
            journal[@"skipped"] = @([journal[@"skipped"] unsignedIntegerValue] + 1);
            CCEmit(emit, @"skipped", itemIndex + 1, items.count, relative);
        } else {
            [entries addObject:[@{@"rel":relative, @"original":original ?: NSNull.null, @"replacement":replacement, @"state":@"prepared"} mutableCopy]];
        }
        if (!CCSave(slot, journal, error)) return NO;
    }
    return fsync(slot) == 0 || CCFail(error, CCStorageError);
}
static BOOL CCVerifyArtifact(int slot, NSString *name, NSDictionary *expected, NSProgress *progress, NSError **error) {
    NSDictionary *stamp = CCReadAt(slot, name, -1, NO, nil, progress, error);
    return stamp && (CCStampEqual(stamp, expected) || CCFail(error, @"Bản sao patch không còn khớp SHA-256. PhamQuang IOS giữ nguyên dữ liệu để kiểm tra."));
}
static BOOL CCRemoveOwnedTemp(int parent, NSString *name, NSDictionary *entry, NSProgress *progress, NSError **error) {
    BOOL missing = NO;
    NSDictionary *stamp = CCReadAt(parent, name, -1, NO, &missing, progress, error);
    if (missing) return YES;
    if (!stamp) return NO;
    NSDictionary *original = entry[@"original"] == NSNull.null ? nil : entry[@"original"];
    if (!CCStampEqual(stamp, original) && !CCStampEqual(stamp, entry[@"replacement"])) {


        struct stat temporaryStat;
        if (fstatat(parent, name.fileSystemRepresentation, &temporaryStat, AT_SYMLINK_NOFOLLOW) || !S_ISREG(temporaryStat.st_mode)) return CCFail(error, CCConflict);


        BOOL incompleteStage = [entry[@"temp_partial"] isEqual:@YES];
        BOOL emptyOrphan = incompleteStage && !entry[@"temp_inode"] && temporaryStat.st_size == 0;
        BOOL ownedInode = incompleteStage && entry[@"temp_device"] && entry[@"temp_inode"] &&
            (unsigned long long)temporaryStat.st_dev == [entry[@"temp_device"] unsignedLongLongValue] &&
            (unsigned long long)temporaryStat.st_ino == [entry[@"temp_inode"] unsignedLongLongValue];
        if (!emptyOrphan && !ownedInode) return CCFail(error, CCConflict);
    }
    if (unlinkat(parent, name.fileSystemRepresentation, 0) || fsync(parent)) return CCFail(error, CCStorageError);
    return YES;
}


static BOOL CCStage(int slot, NSString *artifact, int parent, NSString *temporary, NSDictionary *stamp, NSMutableDictionary *journal, NSMutableDictionary *entry, NSProgress *progress, NSError **error) {


    entry[@"temp_partial"] = @YES;
    [entry removeObjectForKey:@"temp_device"]; [entry removeObjectForKey:@"temp_inode"];
    if (!CCSave(slot, journal, error)) return NO;
    int output = CCCreateAt(parent, temporary, error); if (output < 0) return NO;
    struct stat temporaryStat;
    if (fstat(output, &temporaryStat)) { close(output); return CCFail(error, CCStorageError); }
    entry[@"temp_device"] = @((unsigned long long)temporaryStat.st_dev);
    entry[@"temp_inode"] = @((unsigned long long)temporaryStat.st_ino);
    if (!CCSave(slot, journal, error)) { close(output); return NO; }
    NSDictionary *copied = CCReadAt(slot, artifact, output, NO, nil, progress, error);
    BOOL ok = copied && CCStampEqual(copied, stamp);
    if (ok) ok = fchmod(output, [stamp[@"mode"] unsignedIntValue] & 0777) == 0 && fsync(output) == 0;
    if (close(output)) ok = NO;
    if (!ok) { unlinkat(parent, temporary.fileSystemRepresentation, 0); if (error && !*error) CCFail(error, CCStorageError); return NO; }
    if (fsync(parent)) return CCFail(error, CCStorageError);


    entry[@"temp_partial"] = @NO;
    return CCSave(slot, journal, error);
}



static void CCReturnDisplaced(int parent, NSString *leaf, NSString *temporary, NSDictionary *ours) {
    NSError *ignored = nil;
    NSDictionary *current = CCReadAt(parent, leaf, -1, NO, nil, nil, &ignored);
    if (!CCStampEqual(current, ours)) return;
    if (renameatx_np(parent, temporary.fileSystemRepresentation, parent, leaf.fileSystemRepresentation, RENAME_SWAP) || fsync(parent)) return;
    ignored = nil;
    NSDictionary *returned = CCReadAt(parent, temporary, -1, NO, nil, nil, &ignored);
    if (CCStampEqual(returned, ours)) { unlinkat(parent, temporary.fileSystemRepresentation, 0); fsync(parent); }
}
static BOOL CCApply(int root, int slot, NSMutableDictionary *journal, NSProgress *progress, void (^emit)(NSDictionary *), NSError **error) {
    NSArray *entries = journal[@"entries"];
    for (NSUInteger index = 0; index < entries.count; index++) {
        if (CCCancel(progress, error)) return NO;
        NSMutableDictionary *entry = entries[index]; NSString *relative = entry[@"rel"], *leaf = relative.lastPathComponent;
        CCEmit(emit, @"applying", index, entries.count, relative);
        int parent = CCParent(root, relative, error); if (parent < 0) return NO;
        BOOL success = NO;
        @try {
            BOOL missing = NO; NSDictionary *current = CCReadAt(parent, leaf, -1, NO, &missing, progress, error);
            NSDictionary *original = entry[@"original"] == NSNull.null ? nil : entry[@"original"];
            if ((!current && !missing) || (original ? !CCStampEqual(current, original) : !missing)) { if (!*error) CCFail(error, CCConflict); return NO; }
            entry[@"state"] = @"armed";
            if (!CCSave(slot, journal, error)) return NO;
            NSString *temporary = CCTemporary(journal, index);
            if (!CCStage(slot, CCArtifact(index, NO), parent, temporary, entry[@"replacement"], journal, entry, progress, error)) return NO;
            if (CCCancel(progress, error)) return NO;


            missing = NO; current = CCReadAt(parent, leaf, -1, NO, &missing, progress, error);
            if ((!current && !missing) || (original ? !CCStampEqual(current, original) : !missing)) { if (!*error) CCFail(error, CCConflict); return NO; }
            unsigned int flags = original ? RENAME_SWAP : RENAME_EXCL;
            if (renameatx_np(parent, temporary.fileSystemRepresentation, parent, leaf.fileSystemRepresentation, flags)) return CCFail(error, @"iOS từ chối thay tệp tại đích. Bản gốc và biên nhận được giữ để khôi phục.");
            if (fsync(parent)) return CCFail(error, CCStorageError);
            if (original) {
                NSDictionary *displaced = CCReadAt(parent, temporary, -1, NO, nil, progress, error);
                if (!CCStampEqual(displaced, original)) {
                    CCReturnDisplaced(parent, leaf, temporary, entry[@"replacement"]);
                    return CCFail(error, CCConflict);
                }
            }
            NSDictionary *installed = CCReadAt(parent, leaf, -1, NO, nil, progress, error);
            if (!CCStampEqual(installed, entry[@"replacement"])) return CCFail(error, CCConflict);
            if (original && !CCRemoveOwnedTemp(parent, temporary, entry, progress, error)) return NO;
            entry[@"state"] = @"applied";
            if (!CCSave(slot, journal, error)) return NO;
            success = YES;
        } @finally { close(parent); }
        if (!success) return NO;
        CCEmit(emit, @"applied", index + 1, entries.count, relative);
    }
    journal[@"state"] = @"applied";
    return CCSave(slot, journal, error);
}
static BOOL CCRestore(int root, int slot, NSMutableDictionary *journal, NSProgress *progress, void (^emit)(NSDictionary *), NSError **error) {
    NSArray *entries = journal[@"entries"];

    for (NSUInteger index = 0; index < entries.count; index++) {
        NSDictionary *entry = entries[index];
        if (entry[@"original"] != NSNull.null && !CCVerifyArtifact(slot, CCArtifact(index, YES), entry[@"original"], progress, error)) return NO;
    }
    for (NSUInteger index = 0; index < entries.count; index++) {
        if (CCCancel(progress, error)) return NO;
        NSMutableDictionary *entry = entries[index]; NSString *relative = entry[@"rel"], *leaf = relative.lastPathComponent;
        CCEmit(emit, @"restoring", index, entries.count, relative);
        if ([entry[@"state"] isEqual:@"prepared"]) {
            entry[@"state"] = @"restored";
            if (!CCSave(slot, journal, error)) return NO;
            CCEmit(emit, @"restored", index + 1, entries.count, relative);
            continue;
        }
        int parent = CCParent(root, relative, error); if (parent < 0) return NO;
        @try {
            NSString *temporary = CCTemporary(journal, index);
            NSDictionary *original = entry[@"original"] == NSNull.null ? nil : entry[@"original"];
            BOOL missing = NO; NSDictionary *current = CCReadAt(parent, leaf, -1, NO, &missing, progress, error);
            if (!current && !missing) return NO;
            if (original ? CCStampEqual(current, original) : missing) {

                if (!CCRemoveOwnedTemp(parent, temporary, entry, progress, error)) return NO;
            } else {
                if (!CCStampEqual(current, entry[@"replacement"])) return CCFail(error, CCConflict);
                if (!CCRemoveOwnedTemp(parent, temporary, entry, progress, error)) return NO;
                entry[@"state"] = @"armed"; journal[@"state"] = @"pending";
                if (!CCSave(slot, journal, error)) return NO;
                if (original) {
                    if (!CCStage(slot, CCArtifact(index, YES), parent, temporary, original, journal, entry, progress, error)) return NO;
                    NSDictionary *latest = CCReadAt(parent, leaf, -1, NO, nil, progress, error);
                    if (!CCStampEqual(latest, entry[@"replacement"])) return CCFail(error, CCConflict);
                    if (renameatx_np(parent, temporary.fileSystemRepresentation, parent, leaf.fileSystemRepresentation, RENAME_SWAP) || fsync(parent)) return CCFail(error, CCStorageError);
                    NSDictionary *displaced = CCReadAt(parent, temporary, -1, NO, nil, progress, error);
                    if (!CCStampEqual(displaced, entry[@"replacement"])) {
                        CCReturnDisplaced(parent, leaf, temporary, original);
                        return CCFail(error, CCConflict);
                    }
                    NSDictionary *restored = CCReadAt(parent, leaf, -1, NO, nil, progress, error);
                    if (!CCStampEqual(restored, original)) return CCFail(error, CCConflict);
                    if (!CCRemoveOwnedTemp(parent, temporary, entry, progress, error)) return NO;
                } else {


                    if (renameatx_np(parent, leaf.fileSystemRepresentation, parent, temporary.fileSystemRepresentation, RENAME_EXCL) || fsync(parent)) return CCFail(error, CCStorageError);
                    NSDictionary *moved = CCReadAt(parent, temporary, -1, NO, nil, progress, error);
                    if (!CCStampEqual(moved, entry[@"replacement"])) {
                        renameatx_np(parent, temporary.fileSystemRepresentation, parent, leaf.fileSystemRepresentation, RENAME_EXCL);
                        fsync(parent);
                        return CCFail(error, CCConflict);
                    }
                    if (!CCRemoveOwnedTemp(parent, temporary, entry, progress, error)) return NO;
                }
            }
            entry[@"state"] = @"restored";
            if (!CCSave(slot, journal, error)) return NO;
        } @finally { close(parent); }
        CCEmit(emit, @"restored", index + 1, entries.count, relative);
    }
    journal[@"state"] = @"restored";
    return CCSave(slot, journal, error);
}

static NSDictionary *CCPerform(NSDictionary *request, NSProgress *progress, void (^emit)(NSDictionary *), NSError **error) {
    if (CCCancel(progress, error)) return nil;
    NSString *action = CCString(request[@"action"]);
    if (![action isEqual:@"history"] && ![VVLegacyDirectAccess isReady]) {
        CCFail(error, @"Chưa chuẩn bị quyền truy cập trực tiếp. Hãy mở Thiết lập."); return nil;
    }
    if ([action isEqual:@"history"]) return CCHistory(progress, error);
    if ([action isEqual:@"apps"]) {
        NSString *notice = nil; NSArray *apps = CCApps(progress, &notice);
        if (CCCancel(progress, error)) return nil;
        NSMutableDictionary *response = [@{@"apps":apps} mutableCopy];
        if (notice.length) response[@"notice"] = notice;
        return response;
    }
    if ([action isEqual:@"resolve"]) {
        NSString *bundle = CCString(request[@"bundle_id"]);
        if (!CCKnownBundle(bundle) || request[@"target_id"] || request[@"expected_root"] || request[@"patch_items"]) {
            CCResolveConflict(error, @"Yêu cầu tìm ứng dụng không hợp lệ."); return nil;
        }
        NSArray *observedEntries = VVDirectDiscoverContainers(^BOOL { return progress.cancelled; }, nil);
        NSArray *observed = CCAppRows(observedEntries);
        if (CCCancel(progress, error)) return nil;
        NSDictionary *resolved = nil;
        for (NSDictionary *candidate in observed) if ([candidate[@"bundle_id"] isEqual:bundle]) {
            if (resolved) { CCResolveConflict(error, @"Có nhiều container cùng bundle ID. Không thể tự chọn đích patch."); return nil; }
            resolved = candidate;
        }
        if (!resolved) resolved = VVDirectResolveApplicationTarget(bundle, ^BOOL { return progress.cancelled; }, error);
        if (CCCancel(progress, error) || !resolved) return nil;


        NSString *path = CCNormal(resolved[@"data_path"]);
        if (![resolved[@"bundle_id"] isEqual:bundle] || !path || ![resolved[@"target_id"] isEqual:CCTargetID(path)]) {
            CCResolveConflict(error, @"iOS trả về định danh ứng dụng không khớp."); return nil;
        }
        if (!CCNativeNoConflict(observedEntries, bundle, path, error)) return nil;
        for (NSDictionary *candidate in observed) {
            NSString *known = CCString(candidate[@"bundle_id"]), *root = CCNormal(candidate[@"data_path"]);
            if (([root isEqual:path] && known.length && ![known isEqual:bundle]) || ([known isEqual:bundle] && ![root isEqual:path])) {
                CCResolveConflict(error, @"Vị trí ứng dụng đã thay đổi trong lúc tìm. Hãy thử lại."); return nil;
            }
        }
        return @{@"app":resolved};
    }
    NSString *bundle = CCString(request[@"bundle_id"]), *scope = CCString(request[@"patch_scope"]);
    NSString *selection = CCString(request[@"target_id"]), *selectedPath = nil;
    if ([selection hasPrefix:@"path:"]) {
        selectedPath = CCNormal([selection substringFromIndex:5]);
        if (!selectedPath) { CCFail(error, @"Đường dẫn định danh container không hợp lệ."); return nil; }
        selection = CCTargetID(selectedPath);
    } else if ([selection hasPrefix:@"id:"]) {
        NSString *alias = [selection substringFromIndex:3];
        if (!CCKnownBundle(alias) || (bundle.length && ![bundle isEqual:alias])) { CCFail(error, @"Định danh ứng dụng không khớp."); return nil; }
        bundle = alias; selection = nil;
    } else if (selection != nil) { CCFail(error, @"Định danh container không hợp lệ."); return nil; }
    if ((!selectedPath && !CCKnownBundle(bundle)) || (bundle.length && !CCKnownBundle(bundle)) ||
        ![@[@"data", @"bundle"] containsObject:scope] || ![@[@"status", @"apply", @"restore"] containsObject:action]) {
        CCFail(error, @"Yêu cầu patch không hợp lệ."); return nil;
    }
    NSString *declaredBundle = nil;
    if ([action isEqual:@"apply"] && request[@"declared_bundle_id"]) {
        declaredBundle = CCString(request[@"declared_bundle_id"]);
        BOOL valid = CCKnownBundle(declaredBundle);
        for (NSString *component in [declaredBundle componentsSeparatedByString:@"."]) if (!component.length) valid = NO;
        if (!valid) { CCResolveConflict(error, @"Bundle ID khai báo trong nguồn patch không hợp lệ."); return nil; }
    }
    NSArray *observedEntries = VVDirectDiscoverContainers(^BOOL { return progress.cancelled; }, nil);
    NSArray *apps = CCAppRows(observedEntries);
    if (CCCancel(progress, error)) return nil;
    NSDictionary *app = nil;
    for (NSDictionary *candidate in apps) {
        BOOL match = selectedPath ? [CCNormal(candidate[@"data_path"]) isEqual:selectedPath] : [candidate[@"bundle_id"] isEqual:bundle];
        if (!match) continue;
        if (app) { CCFail(error, @"Có nhiều container cùng định danh. Hãy chọn đúng đường dẫn container trong danh sách."); return nil; }
        app = candidate;
    }
    NSString *observedBundle = CCString(app[@"bundle_id"]);
    if (selectedPath && bundle.length && observedBundle.length && ![bundle isEqual:observedBundle]) { CCFail(error, @"Định danh ứng dụng tại container đã thay đổi. Hãy tải lại danh sách."); return nil; }
    if (app && !CCNativeNoConflict(observedEntries, bundle.length ? bundle : observedBundle, CCNormal(app[@"data_path"]), error)) return nil;



    if (bundle.length && ![observedBundle isEqual:bundle]) {
        NSError *resolutionError = nil;
        NSDictionary *resolved = VVDirectResolveApplicationTarget(bundle, ^BOOL { return progress.cancelled; }, &resolutionError);
        if (CCCancel(progress, error)) return nil;
        if (CCIsResolutionFailure(resolutionError)) { if (error) *error = resolutionError; return nil; }
        if (resolved) {
            NSString *resolvedPath = CCNormal(resolved[@"data_path"]);
            if (![resolved[@"bundle_id"] isEqual:bundle] || !resolvedPath || ![resolved[@"target_id"] isEqual:CCTargetID(resolvedPath)] ||
                (selectedPath && ![selectedPath isEqual:resolvedPath])) {
                CCFail(error, @"Thư mục ứng dụng đã thay đổi. Hãy đọc lại gói patch để xác định đích."); return nil;
            }
            for (NSDictionary *candidate in apps) {
                NSString *known = CCString(candidate[@"bundle_id"]);
                if ([CCNormal(candidate[@"data_path"]) isEqual:resolvedPath] && known.length && ![known isEqual:bundle]) {
                    CCFail(error, @"Định danh ứng dụng tại container không khớp."); return nil;
                }
            }
            if (!CCNativeNoConflict(observedEntries, bundle, resolvedPath, error)) return nil;
            app = resolved; apps = [apps arrayByAddingObject:resolved];
        } else if ([action isEqual:@"apply"] && ![observedBundle isEqual:bundle]) {
            if (error) *error = resolutionError ?: CCError(@"Chưa xác định được container hiện tại của ứng dụng trong gói patch.");
            return nil;
        }


    }


    if (declaredBundle) {
        NSString *currentRoot = CCNormal(app[@"data_path"]), *currentOwner = CCString(app[@"bundle_id"]);
        BOOL conflict = currentOwner.length && ![currentOwner isEqual:declaredBundle];
        for (VVDirectContainerEntry *entry in observedEntries) {
            if ([entry.kind isEqual:@"app"] && [CCNormal(entry.path) isEqual:currentRoot] &&
                CCKnownBundle(entry.identifier) && ![entry.identifier isEqual:declaredBundle]) conflict = YES;
        }
        if (conflict) { CCResolveConflict(error, @"Container đã được nhận diện là của ứng dụng khác với gói patch. Chưa thay đổi tệp nào."); return nil; }
    }
    NSString *identity = selectedPath ? [@"target:" stringByAppendingString:selection] : bundle;
    NSString *slotPath = CCSlotPath(identity, scope, error); if (!slotPath) return nil;
    int slot = open(slotPath.fileSystemRepresentation, O_RDONLY | O_DIRECTORY | O_NOFOLLOW | O_CLOEXEC);
    if (slot < 0) { CCFail(error, CCStorageError); return nil; }
    @try {
        NSMutableDictionary *journal = CCLoad(slot, nil, scope, error); if (*error) return nil;



        if (!app && journal && !selectedPath) {
            for (NSDictionary *candidate in apps) {
                NSString *candidateRoot = CCNormal(candidate[[scope isEqual:@"data"] ? @"data_path" : @"bundle_path"]);
                if ([candidate[@"target_id"] isEqual:journal[@"target_id"]] || [candidateRoot isEqual:CCNormal(journal[@"root"])]) { app = candidate; break; }
            }
        }
        NSString *root = CCNormal(app[[scope isEqual:@"data"] ? @"data_path" : @"bundle_path"]);
        NSString *targetID = CCString(app[@"target_id"]) ?: selection;
        NSString *aliasBundle = CCString(app[@"bundle_id"]) ?: bundle;
        NSDictionary *active = CCActiveReceipt(slotPath.stringByDeletingLastPathComponent, slotPath, root, targetID, aliasBundle, scope, progress, error);
        if (*error || CCCancel(progress, error)) return nil;
        if (active && ![active[@"path"] isEqual:slotPath]) {
            int other = open([active[@"path"] fileSystemRepresentation], O_RDONLY | O_DIRECTORY | O_NOFOLLOW | O_CLOEXEC);
            if (other < 0) { CCFail(error, CCStorageError); return nil; }
            close(slot); slot = other; slotPath = active[@"path"];
            journal = active[@"journal"];
        }



        if (!app && journal && !selectedPath) {
            for (NSDictionary *candidate in apps) {
                NSString *candidateRoot = CCNormal(candidate[[scope isEqual:@"data"] ? @"data_path" : @"bundle_path"]);
                if ([candidate[@"target_id"] isEqual:journal[@"target_id"]] || [candidateRoot isEqual:CCNormal(journal[@"root"])]) { app = candidate; break; }
            }
            root = CCNormal(app[[scope isEqual:@"data"] ? @"data_path" : @"bundle_path"]);
            targetID = CCString(app[@"target_id"]);
        }
        if ([action isEqual:@"status"]) return CCStatus(journal, nil);
        if ([action isEqual:@"restore"] && (!journal || [journal[@"state"] isEqual:@"restored"])) return CCStatus(journal, @"Không có patch cần khôi phục.");
        if ([action isEqual:@"apply"] && journal && ![journal[@"state"] isEqual:@"restored"]) { CCFail(error, @"Còn patch chưa khôi phục. Chọn Khôi phục bản gốc trước khi áp dụng lượt mới."); return nil; }



        BOOL activeReceipt = journal && ![journal[@"state"] isEqual:@"restored"];
        if (!root || !targetID || (activeReceipt && ![CCNormal(journal[@"root"]) isEqual:root])) { CCFail(error, @"Ứng dụng đã đổi bản cài hoặc thư mục dữ liệu không còn được iOS cung cấp. Bản sao được giữ để khôi phục đúng ứng dụng."); return nil; }
        NSArray *items = request[@"patch_items"];
        if ([action isEqual:@"apply"]) {
            NSString *expected = CCNormal(request[@"expected_root"]);
            if (!expected || ![expected isEqual:root]) { CCFail(error, @"Thư mục ứng dụng đã thay đổi. Hãy chọn lại ứng dụng và kiểm tra đích."); return nil; }
            if (![items isKindOfClass:NSArray.class] || items.count == 0 || items.count > 1024) { CCFail(error, @"Mỗi patch cần từ 1 đến 1.024 tệp."); return nil; }
            NSMutableSet *seen = [NSMutableSet set];
            for (id item in items) {
                NSString *relative = [item isKindOfClass:NSDictionary.class] ? CCString(item[@"relative_path"]) : nil;
                if (!CCDestination(relative, scope) || !CCString(item[@"local_path"]) || [seen containsObject:relative.lowercaseString]) { CCFail(error, @"Đường dẫn đích không hợp lệ hoặc bị trùng."); return nil; }
                [seen addObject:relative.lowercaseString];
            }
        }
        __block NSMutableDictionary *working = journal;
        BOOL success = [VVDirectFileSystem withDirectory:root progress:progress operation:^BOOL(NSString *accessible, NSError **failure) {
            int target = open(accessible.fileSystemRepresentation, O_RDONLY | O_DIRECTORY | O_CLOEXEC);
            if (target < 0) return CCPOSIX(failure, @"Không mở được thư mục của ứng dụng.", errno, YES);
            @try {
                if ([action isEqual:@"restore"]) {
                    NSMutableArray *restoreItems = [NSMutableArray array];
                    for (NSDictionary *entry in working[@"entries"]) [restoreItems addObject:@{@"relative_path":entry[@"rel"]}];
                    if (!CCPreflight(target, restoreItems, failure)) return NO;
                    return CCRestore(target, slot, working, progress, emit, failure);
                }
                if (!CCPreflight(target, items, failure)) return NO;
                if (!CCCleanSlot(slot, failure)) return NO;
                working = [@{@"version":@1, @"bundle":CCString(app[@"bundle_id"]) ?: @"", @"target_id":targetID, @"scope":scope, @"root":root, @"token":NSUUID.UUID.UUIDString,
                    @"state":@"pending", @"skipped":@0, @"entries":[NSMutableArray array]} mutableCopy];
                NSString *displayName = CCDisplayName(request[@"app_name"]) ?: CCDisplayName(app[@"name"]);
                if (displayName) working[@"app_name"] = displayName;  
                if (!CCSave(slot, working, failure)) return NO;
                if (!CCPrepare(target, slot, working, items, progress, emit, failure)) return NO;
                if (![working[@"entries"] count]) { working[@"state"] = @"restored"; return CCSave(slot, working, failure); }
                return CCApply(target, slot, working, progress, emit, failure);
            } @finally { close(target); }
        } error:error];
        if (!success) return nil;
        CCEmit(emit, @"complete", [working[@"entries"] count], [working[@"entries"] count], @"");
        NSMutableDictionary *status = [CCStatus(working, nil) mutableCopy];
        if ([action isEqual:@"apply"] && ![working[@"entries"] count]) { status[@"state"] = @"unchanged"; status[@"message"] = @"Các tệp đã khớp SHA-256; không cần thay đổi."; }
        return status;
    } @finally { close(slot); }
}

@implementation VVDirectPatchEngine
+ (void)performRequest:(NSDictionary *)request progress:(NSProgress *)progress onProgress:(void (^)(NSDictionary *))onProgress completion:(void (^)(NSDictionary *, NSError *))completion {
    NSDictionary *snapshot = [request copy];
    dispatch_async(BQWorkQueue(), ^{
        @autoreleasepool {
            NSError *error = nil; NSDictionary *result = nil;
            @try { result = CCPerform(snapshot, progress, onProgress, &error); }
            @catch (__unused NSException *exception) { error = CCError(@"Không xử lý được yêu cầu patch. PhamQuang IOS giữ biên nhận và bản sao để khôi phục."); }
            completion(result, error ?: (result ? nil : CCError(CCStorageError)));
        }
    });
}
@end
