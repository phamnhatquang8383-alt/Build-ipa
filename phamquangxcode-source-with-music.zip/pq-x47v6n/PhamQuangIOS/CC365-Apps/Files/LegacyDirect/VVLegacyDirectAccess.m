#import "VVLegacyDirectAccess.h"
#import "VVLegacyDirectProbe.h"
#import "../BQCore/BQCore.h"
#import <TargetConditionals.h>

#if TARGET_OS_IOS && !TARGET_OS_SIMULATOR && defined(__arm64__)
#import "Vendor/kexploit_opa334.h"
#import "Vendor/kutils.h"
#import "Vendor/sandbox_escape.h"
#import "Vendor/machine_info.h"
#import <sys/sysctl.h>
#import <dlfcn.h>
#endif

static NSDictionary *VVLegacyResult;
static BOOL VVLegacyAttempted;

static BOOL VVLegacyVersionEligible(NSOperatingSystemVersion v) {
    if (v.minorVersion < 0 || v.patchVersion < 0) return NO;
    if (v.majorVersion == 16 || v.majorVersion == 17) return v.minorVersion <= 7;
    return v.majorVersion == 18 &&
        (v.minorVersion < 7 || (v.minorVersion == 7 && v.patchVersion <= 1));
}

#ifdef VV_LEGACY_DIRECT_TESTING

static NSOperatingSystemVersion VVLegacyTestVersion;
static BOOL VVLegacyTestDevice, VVLegacyTestHardware;
static BOOL VVLegacyTestProbe(NSError **error);
static int VVLegacyTestKernel(void);
static uint64_t VVLegacyTestProc(void);
static int VVLegacyTestEscape(uint64_t proc);
#define VVCurrentVersion() VVLegacyTestVersion
#define VVPhysicalDevice() VVLegacyTestDevice
#define VVHardwareSupported() VVLegacyTestHardware
#define VVProbe(error) VVLegacyTestProbe(error)
#define VVKernel() VVLegacyTestKernel()
#define VVProc() VVLegacyTestProc()
#define VVEscape(proc) VVLegacyTestEscape(proc)
#else
static NSOperatingSystemVersion VVCurrentVersion(void) {
    return NSProcessInfo.processInfo.operatingSystemVersion;
}
static BOOL VVPhysicalDevice(void) {
#if TARGET_OS_IOS && !TARGET_OS_SIMULATOR && defined(__arm64__)
    return YES;
#else
    return NO;
#endif
}
static BOOL VVHardwareSupported(void) {
#if TARGET_OS_IOS && !TARGET_OS_SIMULATOR && defined(__arm64__)
    uint32_t family = 0;
    size_t size = sizeof(family);
    if (sysctlbyname("hw.cpufamily", &family, &size, NULL, 0) != 0 || size != sizeof(family)) return NO;
    switch (family) {
        case CPUFAMILY_ARM_TWISTER:  
        case CPUFAMILY_ARM_HURRICANE:
        case CPUFAMILY_ARM_MONSOON_MISTRAL:
        case CPUFAMILY_ARM_VORTEX_TEMPEST:
        case CPUFAMILY_ARM_LIGHTNING_THUNDER:
        case CPUFAMILY_ARM_FIRESTORM_ICESTORM:
        case CPUFAMILY_ARM_BLIZZARD_AVALANCHE:
        case CPUFAMILY_ARM_EVEREST_SAWTOOTH:
        case CPUFAMILY_ARM_COLL:
        case CPUFAMILY_ARM_TUPAI:
        case CPUFAMILY_ARM_TAHITI:
        case CPUFAMILY_ARM_IBIZA:
        case CPUFAMILY_ARM_DONAN:
            return dlsym(RTLD_DEFAULT, "IOSurfacePrefetchPages") != NULL;
        default: return NO;
    }
#else
    return NO;
#endif
}
#define VVProbe(error) VVLegacyDirectProbeApplicationRoot(error)
static int VVKernel(void) {
#if TARGET_OS_IOS && !TARGET_OS_SIMULATOR && defined(__arm64__)
    return kexploit_opa334();
#else
    return -1;
#endif
}
static uint64_t VVProc(void) {
#if TARGET_OS_IOS && !TARGET_OS_SIMULATOR && defined(__arm64__)
    return proc_self();
#else
    return 0;
#endif
}
static int VVEscape(uint64_t proc) {
#if TARGET_OS_IOS && !TARGET_OS_SIMULATOR && defined(__arm64__)
    return sandbox_escape(proc);
#else
    return -1;
#endif
}
#endif

static NSDictionary *VVResult(BOOL ready, NSString *state, NSString *message, BOOL kernel, NSInteger code) {
    return @{ @"ready": @(ready), @"state": state, @"message": message,
        @"kernel_ready": @(kernel), @"diagnostic_code": @(code) };
}

static void VVStoreResult(NSDictionary *result) {
    @synchronized (VVLegacyDirectAccess.class) { VVLegacyResult = result; }
    BQLog(@"[LegacyDirect] state=%@ ready=%@ code=%@", result[@"state"], result[@"ready"], result[@"diagnostic_code"]);
}

static NSDictionary *VVPrepare(void) {
    if (!VVLegacyVersionEligible(VVCurrentVersion()))
        return VVResult(NO, @"unsupported", @"Phiên bản iOS này không dùng chế độ truy cập trực tiếp cũ.", NO, 1);
    if (!VVPhysicalDevice())
        return VVResult(NO, @"simulator", @"Chế độ truy cập trực tiếp cần iPhone hoặc iPad thật.", NO, 2);
    NSError *probeError = nil;
    if (VVProbe(&probeError))
        return VVResult(YES, @"ready", @"Đã kiểm tra quyền đọc và ghi trực tiếp vào thư mục ứng dụng.", NO, 0);
    if (probeError.code == VVLegacyDirectProbeCleanupFailed)
        return VVResult(NO, @"cleanup_failed", probeError.localizedDescription, NO, 3);
    if (!VVHardwareSupported())
        return VVResult(NO, @"unsupported_hardware", @"Chưa có cấu hình truy cập trực tiếp phù hợp cho thiết bị này.", NO, 4);
    int kernelResult = VVKernel();
    if (kernelResult != 0)
        return VVResult(NO, @"failed", kernelResult == -60
            ? @"Bảng cấu hình của phiên bản này chưa đầy đủ. Chưa bật quyền truy cập trực tiếp."
            : @"Không thể chuẩn bị quyền truy cập trực tiếp. Hãy khởi động lại ứng dụng trước khi thử lại.", NO, kernelResult);
    uint64_t proc = VVProc();
    if (!proc)
        return VVResult(NO, @"kernel_only", @"Chưa xác nhận được quyền truy cập tệp. Ghi patch vẫn bị khóa.", YES, 5);
    int escapeResult = VVEscape(proc);

    probeError = nil;
    BOOL access = VVProbe(&probeError);
    if (probeError.code == VVLegacyDirectProbeCleanupFailed)
        return VVResult(NO, @"cleanup_failed", probeError.localizedDescription, YES, 3);
    if (escapeResult != 0 || !access)
        return VVResult(NO, @"kernel_only", @"Đã chuẩn bị bước đầu nhưng chưa có quyền đọc và ghi tệp. Ghi patch vẫn bị khóa.", YES, escapeResult ?: 6);
    return VVResult(YES, @"ready", @"Đã kiểm tra quyền đọc và ghi trực tiếp vào thư mục ứng dụng.", YES, 0);
}

@implementation VVLegacyDirectAccess
+ (NSDictionary<NSString *,id> *)currentStatus {
    @synchronized (self) {
        return VVLegacyResult ?: VVResult(NO, @"not_prepared", @"Chưa chuẩn bị quyền truy cập trực tiếp.", NO, 0);
    }
}
+ (BOOL)isReady { return [[self currentStatus][@"ready"] boolValue]; }
+ (void)prepareWithCompletion:(void (^)(NSDictionary<NSString *,id> *))completion {
    dispatch_async(BQWorkQueue(), ^{
        @autoreleasepool {


            if (!VVLegacyAttempted) {
                VVLegacyAttempted = YES;
                VVStoreResult(VVResult(NO, @"preparing", @"Đang chuẩn bị quyền truy cập trực tiếp…", NO, 0));
                VVStoreResult(VVPrepare());
            }
            NSDictionary *result = [self currentStatus];
            dispatch_async(dispatch_get_main_queue(), ^{ completion(result); });
        }
    });
}
@end
