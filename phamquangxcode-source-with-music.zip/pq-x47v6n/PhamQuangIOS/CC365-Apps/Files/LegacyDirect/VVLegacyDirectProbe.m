#import "VVLegacyDirectProbe.h"
#import <fcntl.h>
#import <unistd.h>
#import <sys/stat.h>
#import <errno.h>
#import <TargetConditionals.h>
#include <stdatomic.h>

NSString * const VVLegacyDirectProbeErrorDomain = @"Viet99.LegacyDirectProbe";
static atomic_bool VVProbeCleanupUnconfirmed;

static BOOL VVProbeError(NSError **error, NSInteger code, int systemError) {
    if (code == VVLegacyDirectProbeCleanupFailed)
        atomic_store(&VVProbeCleanupUnconfirmed, true);
    if (error) *error = [NSError errorWithDomain:VVLegacyDirectProbeErrorDomain code:code
        userInfo:@{NSLocalizedDescriptionKey: code == VVLegacyDirectProbeCleanupFailed
            ? @"Chưa xác nhận được việc dọn tệp kiểm tra quyền truy cập. Hãy khởi động lại ứng dụng."
            : @"Chưa có quyền đọc và ghi trực tiếp vào thư mục ứng dụng.",
            @"posix_code": @(systemError)}];
    return NO;
}


static int VVProbeOpenDirectory(NSString *path) {
    if (![path hasPrefix:@"/"] || [path rangeOfCharacterFromSet:[NSCharacterSet characterSetWithRange:NSMakeRange(0, 1)]].location != NSNotFound) {
        errno = EINVAL;
        return -1;
    }
    int fd = open("/", O_RDONLY | O_DIRECTORY | O_CLOEXEC);
    for (NSString *part in [path componentsSeparatedByString:@"/"]) {
        if (!part.length) continue;
        if ([part isEqualToString:@"."] || [part isEqualToString:@".."]) {
            if (fd >= 0) close(fd);
            errno = EINVAL;
            return -1;
        }
        if (fd < 0) return -1;
        int next = openat(fd, part.fileSystemRepresentation,
            O_RDONLY | O_DIRECTORY | O_NOFOLLOW | O_CLOEXEC);
        int saved = errno;
        close(fd);
        fd = next;
        errno = saved;
    }
    return fd;
}

BOOL VVLegacyDirectProbeDirectory(NSString *path, NSError **error) {
    if (error) *error = nil;


    if (atomic_load(&VVProbeCleanupUnconfirmed))
        return VVProbeError(error, VVLegacyDirectProbeCleanupFailed, ESTALE);
    int parent = VVProbeOpenDirectory(path);
    if (parent < 0) return VVProbeError(error, VVLegacyDirectProbeAccessFailed, errno);
    NSString *leaf = [@".viet99-access-" stringByAppendingString:NSUUID.UUID.UUIDString];
    int fd = openat(parent, leaf.fileSystemRepresentation,
        O_RDWR | O_CREAT | O_EXCL | O_CLOEXEC | O_NOFOLLOW, 0600);
    if (fd < 0) {
        int saved = errno;
        close(parent);
        return VVProbeError(error, VVLegacyDirectProbeAccessFailed, saved);
    }
    struct stat created = {0}, current = {0};
    BOOL identified = fstat(fd, &created) == 0 && S_ISREG(created.st_mode) &&
        created.st_nlink == 1 && created.st_uid == geteuid();
    const unsigned char expected[] = {0x56, 0x39, 0x39, 0x01};
    unsigned char actual[sizeof(expected)] = {0};
    BOOL ioOK = identified && write(fd, expected, sizeof(expected)) == sizeof(expected) &&
        fsync(fd) == 0 && lseek(fd, 0, SEEK_SET) == 0 &&
        read(fd, actual, sizeof(actual)) == sizeof(actual) &&
        memcmp(expected, actual, sizeof(expected)) == 0;
    int saved = ioOK ? 0 : (errno ?: EIO);

    BOOL owned = identified && fstatat(parent, leaf.fileSystemRepresentation,
        &current, AT_SYMLINK_NOFOLLOW) == 0 && S_ISREG(current.st_mode) &&
        current.st_dev == created.st_dev && current.st_ino == created.st_ino &&
        current.st_nlink == 1;
    BOOL removed = owned && unlinkat(parent, leaf.fileSystemRepresentation, 0) == 0;
    int cleanupError = removed ? 0 : (errno ?: ESTALE);
    BOOL closed = close(fd) == 0;
    BOOL parentClosed = close(parent) == 0;
    if (!removed) return VVProbeError(error, VVLegacyDirectProbeCleanupFailed, cleanupError);
    if (!ioOK || !closed || !parentClosed)
        return VVProbeError(error, VVLegacyDirectProbeAccessFailed, saved ?: EIO);
    return YES;
}

BOOL VVLegacyDirectProbeApplicationRoot(NSError **error) {
#if TARGET_OS_IOS && !TARGET_OS_SIMULATOR && defined(__arm64__)
    return VVLegacyDirectProbeDirectory(@"/private/var/mobile/Containers/Data/Application", error);
#else

    return VVProbeError(error, VVLegacyDirectProbeAccessFailed, ENOTSUP);
#endif
}
