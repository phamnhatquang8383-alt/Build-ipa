#pragma once
#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN
FOUNDATION_EXPORT NSString * const VVDirectRetrySafeKey;

@interface VVDirectFileSystem : NSObject
+ (void)performRequest:(NSDictionary *)request
              progress:(NSProgress *)progress
            completion:(void (^)(NSDictionary * _Nullable result, NSError * _Nullable error))completion
    NS_SWIFT_NAME(perform(request:progress:completion:));



+ (BOOL)withDirectory:(NSString *)path
             progress:(NSProgress *)progress
            operation:(BOOL (^)(NSString *accessible, NSError **error))operation
                error:(NSError * _Nullable * _Nullable)error;
@end
NS_ASSUME_NONNULL_END
