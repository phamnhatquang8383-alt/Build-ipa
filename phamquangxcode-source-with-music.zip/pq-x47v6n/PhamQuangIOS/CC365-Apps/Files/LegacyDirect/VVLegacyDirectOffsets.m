#import <TargetConditionals.h>
#if (TARGET_OS_IOS && !TARGET_OS_SIMULATOR && defined(__arm64__)) || defined(VV_LEGACY_DIRECT_TESTING)
#include <stdbool.h>
#include "Vendor/offsets.h"



bool VVLegacyDirectOffsetsAreValid(void) {
    const uint32_t required[] = {
        off_inpcb_inp_list_le_next, off_inpcb_inp_pcbinfo, off_inpcb_inp_socket,
        off_inpcbinfo_ipi_zone, off_inpcb_inp_depend6_inp6_icmp6filt,
        off_inpcb_inp_depend6_inp6_chksum, off_socket_so_usecount,
        off_socket_so_background_thread, off_kalloc_type_view_kt_zv_zv_name,
        off_thread_t_tro, off_thread_ro_tro_proc,
    };
    for (unsigned i = 0; i < sizeof(required) / sizeof(required[0]); ++i)
        if (!required[i] || required[i] > 0x10000) return false;
    return t1sz_boot > 0 && t1sz_boot < 62 && (smr_base == 2 || smr_base == 3) &&
        pac_mask != 0 && VM_MIN_KERNEL_ADDRESS != 0 &&
        VM_MAX_KERNEL_ADDRESS > VM_MIN_KERNEL_ADDRESS;
}
#endif
