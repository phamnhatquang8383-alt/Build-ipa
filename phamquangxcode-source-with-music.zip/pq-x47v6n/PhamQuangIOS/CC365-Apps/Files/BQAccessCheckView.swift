import SwiftUI

struct BQAccessCheckView: View {
    @State private var phase: Phase = .idle
    @State private var worker: Task<Void, Never>?
    @State private var runID = UUID()

    private enum Phase {
        case idle, running, stopping, cancelled
        case finished(FileAccessReceipt)
        case failed(String)
    }

    var body: some View {
        List {
            Section {
                Text("PhamQuang IOS tạo một tệp thử riêng trong Tệp PhamQuang IOS, đọc lại và so sánh từng byte.")
                    .font(.subheadline)
                Text("Phép thử kiểm tra vùng tệp cục bộ. Quyền mở container của ứng dụng khác được kiểm tra khi bạn mở thư mục đó.")
                    .font(.subheadline)
                switch phase {
                case .running, .stopping:
                    HStack(spacing: 10) {
                        ProgressView().controlSize(.small)
                        if case .stopping = phase {
                            Text("Đang dừng kiểm tra…")
                        } else {
                            Text("Đang kiểm tra…")
                            Spacer()
                            Button("Dừng", action: stop).buttonStyle(.borderless)
                                .accessibilityIdentifier("files-access-stop")
                        }
                    }
                default:
                    Button(action: launch) {
                        Label(actionTitle, systemImage: "play.circle")
                    }
                    .accessibilityIdentifier("files-access-start")
                }
            }

            switch phase {
            case .finished(let result):
                Section("Kết quả") {
                    if result.recoveryOnly {
                        Text("Khôi phục lần thử trước").font(.headline)
                    }
                    LabeledContent(result.recoveryOnly ? "Nội dung tệp thử lần trước" : "Nội dung đọc lại",
                                   value: result.exactBytesRecovered ? "Khớp từng byte" : "Chưa xác nhận")
                    LabeledContent("Dọn tệp của phiên thử", value: result.cleanupComplete ? "Hoàn tất" : "Chưa hoàn tất")
                    if !result.message.isEmpty {
                        Text(result.message).font(.footnote).foregroundStyle(.secondary)
                    }
                }
            case .failed(let message):
                Section("Chưa hoàn tất") { Text(message).font(.subheadline) }
            case .cancelled:
                Section {
                    Text("Đã dừng kiểm tra. Bạn có thể bấm Kiểm tra lại để thử một phiên mới.")
                        .font(.subheadline)
                }
            default: EmptyView()
            }
        }
        .listStyle(.insetGrouped)
        .cc365Canvas()
        .navigationTitle("Kiểm tra truy cập")
        .navigationBarTitleDisplayMode(.inline)
        .onDisappear {
            runID = UUID()
            worker?.cancel()
            worker = nil
            switch phase {
            case .running, .stopping: phase = .cancelled
            default: break
            }
        }
    }

    private var actionTitle: String {
        switch phase {
        case .idle: return "Chạy thử"
        case .finished(let result) where !result.cleanupComplete: return "Kiểm tra lại"
        case .finished(let result) where result.recoveryOnly: return "Chạy thử"
        default: return "Kiểm tra lại"
        }
    }

    private func stop() {
        phase = .stopping
        worker?.cancel()
    }

    @MainActor private func launch() {
        guard worker == nil else { return }
        phase = .running
        let ticket = UUID()
        runID = ticket
        worker = Task { @MainActor in
            defer { if runID == ticket { worker = nil } }
            do {
                let receipt = try await VersionedFilesTransport.checkAccess()


                guard runID == ticket else { return }
                phase = .finished(receipt)
            } catch {
                guard runID == ticket else { return }
                if FileTransferSupport.cancelled(error) {
                    phase = .cancelled
                } else {
                    phase = .failed(FileTransferSupport.message(error))
                }
            }
        }
    }
}
