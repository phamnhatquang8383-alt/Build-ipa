import Foundation



final class FilePickerCompletion {
    private(set) var session = UUID()
    private var received = false
    private var closed = false
    private var delivered = false
    private var url: URL?

    @discardableResult func begin() -> UUID {
        session = UUID()
        received = false; closed = false; delivered = false; url = nil
        return session
    }
    func select(_ value: URL?, session: UUID, finish: (URL?) -> Void) {
        guard session == self.session, !received else { return }
        received = true
        url = value
        deliver(finish)
    }
    func dismiss(session: UUID, finish: (URL?) -> Void) {
        guard session == self.session else { return }
        closed = true
        deliver(finish)
    }
    private func deliver(_ finish: (URL?) -> Void) {
        guard received, closed, !delivered else { return }
        delivered = true
        let value = url
        url = nil
        finish(value)
    }
}
