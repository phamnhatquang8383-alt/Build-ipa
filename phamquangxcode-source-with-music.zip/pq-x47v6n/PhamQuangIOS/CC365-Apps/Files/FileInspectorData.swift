import Foundation
import SQLite3

enum FileInspectorMode: String, CaseIterable, Sendable, Identifiable {
    case text, plist, hex, sqlite
    var id: String { rawValue }
    var title: String {
        switch self {
        case .text: return "Văn bản"
        case .plist: return "Plist"
        case .hex: return "Hex"
        case .sqlite: return "SQLite"
        }
    }
    var systemImage: String {
        switch self {
        case .text: return "doc.plaintext"
        case .plist: return "list.bullet.indent"
        case .hex: return "number"
        case .sqlite: return "tablecells"
        }
    }
}

enum FileInspectorError: LocalizedError {
    case message(String)
    var errorDescription: String? { if case let .message(text) = self { return text }; return nil }
}

struct FileTextDocument: Sendable {
    let text: String
    let encoding: UInt
    let plistFormat: UInt?
    var byteOrderMark = Data()
    static let maximumBytes = 2 * 1024 * 1024

    static func load(_ url: URL, asPlist: Bool) throws -> Self {
        let values = try url.resourceValues(forKeys: [.fileSizeKey, .isRegularFileKey, .isSymbolicLinkKey])
        guard values.isRegularFile == true, values.isSymbolicLink != true else {
            throw FileInspectorError.message("Tệp không còn là tệp thông thường.")
        }
        guard let size = values.fileSize, size <= maximumBytes else {
            throw FileInspectorError.message("Trình sửa văn bản/plist hỗ trợ tối đa 2 MiB. Bạn có thể xem bằng Hex hoặc xuất tệp.")
        }
        let file = try FileHandle(forReadingFrom: url)
        defer { try? file.close() }
        let data = try file.read(upToCount: maximumBytes + 1) ?? Data()
        guard data.count <= maximumBytes else { throw FileInspectorError.message("Tệp vượt giới hạn 2 MiB.") }
        if asPlist {
            var format = PropertyListSerialization.PropertyListFormat.xml
            let object = try PropertyListSerialization.propertyList(from: data, options: [], format: &format)
            guard format == .xml || format == .binary else {
                throw FileInspectorError.message("Chỉ hỗ trợ chỉnh sửa plist XML và binary.")
            }
            let xml = try PropertyListSerialization.data(fromPropertyList: object, format: .xml, options: 0)
            guard xml.count <= maximumBytes else {
                throw FileInspectorError.message("Plist này tạo ra hơn 2 MiB XML, vượt giới hạn trình sửa. Hãy xem bằng Hex hoặc xuất tệp.")
            }
            guard let text = String(data: xml, encoding: .utf8) else { throw FileInspectorError.message("Không đọc được plist.") }
            return Self(text: text, encoding: String.Encoding.utf8.rawValue, plistFormat: format.rawValue)
        }
        let encoding: String.Encoding, payload: Data, mark: Data
        if data.starts(with: [0xff, 0xfe]) { encoding = .utf16LittleEndian; payload = data.dropFirst(2); mark = Data([0xff, 0xfe]) }
        else if data.starts(with: [0xfe, 0xff]) { encoding = .utf16BigEndian; payload = data.dropFirst(2); mark = Data([0xfe, 0xff]) }
        else { encoding = .utf8; payload = data; mark = Data() }
        guard let text = String(data: payload, encoding: encoding),
              !text.unicodeScalars.contains(where: { $0.value < 32 && ![9, 10, 13].contains($0.value) }) else {
            throw FileInspectorError.message("Đây không phải văn bản UTF-8/UTF-16. Hãy mở bằng Hex.")
        }
        return Self(text: text, encoding: encoding.rawValue, plistFormat: nil, byteOrderMark: mark)
    }

    func data(for text: String) throws -> Data {
        if let plistFormat, let format = PropertyListSerialization.PropertyListFormat(rawValue: plistFormat) {
            guard text.utf8.count <= Self.maximumBytes else { throw FileInspectorError.message("Nội dung vượt giới hạn 2 MiB.") }
            let object = try PropertyListSerialization.propertyList(from: Data(text.utf8), options: [], format: nil)
            let result = try PropertyListSerialization.data(fromPropertyList: object, format: format, options: 0)
            guard result.count <= Self.maximumBytes else { throw FileInspectorError.message("Nội dung vượt giới hạn 2 MiB.") }
            return result
        }
        guard let result = text.data(using: String.Encoding(rawValue: encoding)), result.count + byteOrderMark.count <= Self.maximumBytes else {
            throw FileInspectorError.message("Không mã hóa được nội dung trong giới hạn 2 MiB.")
        }
        return byteOrderMark + result
    }
}

struct FileHexPage: Sendable {
    let text: String
    let offset: UInt64
    let total: UInt64
    static let pageSize = 4096
    var hasNext: Bool { offset + UInt64(Self.pageSize) < total }

    static func load(_ url: URL, offset: UInt64) throws -> Self {
        let file = try FileHandle(forReadingFrom: url)
        defer { try? file.close() }
        let total = try file.seekToEnd()
        try file.seek(toOffset: min(offset, total))
        let data = try file.read(upToCount: pageSize) ?? Data()
        var lines = [String]()
        for start in stride(from: 0, to: data.count, by: 16) {
            let bytes = Array(data[start..<min(start + 16, data.count)])
            let hex = bytes.map { String(format: "%02X", $0) }.joined(separator: " ")
            let ascii = String(bytes.map { (32...126).contains($0) ? Character(UnicodeScalar($0)) : "." })
            lines.append(String(format: "%08llX  ", offset + UInt64(start)) + hex.padding(toLength: 47, withPad: " ", startingAt: 0) + "  " + ascii)
        }
        return Self(text: lines.joined(separator: "\n"), offset: offset, total: total)
    }
}

struct FileSQLitePage: Sendable {
    let columns: [String]
    let rows: [[String]]
    let hasNext: Bool
    static let pageSize = 50
}



enum FileSQLiteReader {
    private final class Budget {
        let deadline = Date().addingTimeInterval(3)
        var expired: Bool { Task.isCancelled || Date() >= deadline }
    }
    private static func withDatabase<T>(_ url: URL, read: (OpaquePointer) throws -> T) throws -> T {
        var database: OpaquePointer?
        guard sqlite3_open_v2(url.path, &database, SQLITE_OPEN_READONLY | SQLITE_OPEN_NOMUTEX, nil) == SQLITE_OK, let database else {
            if let database { sqlite3_close(database) }
            throw FileInspectorError.message("Không mở được bản sao SQLite. Tệp có thể không phải SQLite hoặc cần mật khẩu.")
        }
        defer { sqlite3_close(database) }
        sqlite3_limit(database, SQLITE_LIMIT_LENGTH, 2 * 1024 * 1024)
        sqlite3_limit(database, SQLITE_LIMIT_SQL_LENGTH, 64 * 1024)
        sqlite3_limit(database, SQLITE_LIMIT_COLUMN, 256)
        sqlite3_busy_timeout(database, 500)
        sqlite3_exec(database, "PRAGMA trusted_schema=OFF; PRAGMA query_only=ON;", nil, nil, nil)
        let budget = Budget()
        let context = Unmanaged.passUnretained(budget).toOpaque()
        sqlite3_progress_handler(database, 1000, { pointer in
            guard let pointer else { return 1 }
            return Unmanaged<Budget>.fromOpaque(pointer).takeUnretainedValue().expired ? 1 : 0
        }, context)
        defer { sqlite3_progress_handler(database, 0, nil, nil); withExtendedLifetime(budget) {} }
        return try read(database)
    }

    private static func query(_ sql: String, database: OpaquePointer, maximumRows: Int, identifiers: Bool = false) throws -> FileSQLitePage {
        var statement: OpaquePointer?
        guard sqlite3_prepare_v2(database, sql, -1, &statement, nil) == SQLITE_OK, let statement else {
            throw FileInspectorError.message("Không đọc được bảng SQLite: " + String(cString: sqlite3_errmsg(database)))
        }
        defer { sqlite3_finalize(statement) }
        guard sqlite3_stmt_readonly(statement) != 0 else { throw FileInspectorError.message("Trình xem chỉ đọc dữ liệu.") }
        let count = sqlite3_column_count(statement)
        let columns = (0..<count).map { String(cString: sqlite3_column_name(statement, $0)) }
        var rows = [[String]]()
        while true {
            try Task.checkCancellation()
            let result = sqlite3_step(statement)
            if result == SQLITE_DONE { break }
            guard result == SQLITE_ROW else {
                throw FileInspectorError.message("SQLite chưa đọc xong. Bảng có thể quá lớn, đang thay đổi hoặc dữ liệu bị lỗi.")
            }
            if rows.count >= maximumRows { return FileSQLitePage(columns: columns, rows: rows, hasNext: true) }
            rows.append(try (0..<count).map { index in
                switch sqlite3_column_type(statement, index) {
                case SQLITE_NULL: return "NULL"
                case SQLITE_BLOB: return "BLOB · \(sqlite3_column_bytes(statement, index)) byte"
                default:
                    guard let text = sqlite3_column_text(statement, index) else { return "" }
                    let length = Int(sqlite3_column_bytes(statement, index))
                    if identifiers && length > 1024 { throw FileInspectorError.message("Tên bảng SQLite dài hơn 1.024 byte, vượt giới hạn trình xem.") }
                    return String(decoding: UnsafeBufferPointer(start: text, count: min(length, 1024)), as: UTF8.self) + (length > 1024 ? "…" : "")
                }
            })
        }
        return FileSQLitePage(columns: columns, rows: rows, hasNext: false)
    }

    static func tables(_ url: URL) throws -> [String] {
        try withDatabase(url) { database in
            let page = try query("SELECT name FROM sqlite_schema WHERE type='table' AND name NOT LIKE 'sqlite_%' ORDER BY name LIMIT 201", database: database, maximumRows: 200, identifiers: true)
            guard !page.hasNext else { throw FileInspectorError.message("Cơ sở dữ liệu có hơn 200 bảng, vượt giới hạn trình xem.") }
            return page.rows.compactMap(\.first)
        }
    }

    static func rows(_ url: URL, table: String, offset: Int) throws -> FileSQLitePage {
        guard offset >= 0, offset <= 100_000, try tables(url).contains(table) else {
            throw FileInspectorError.message("Bảng hoặc vị trí không hợp lệ.")
        }
        let quoted = "\"" + table.replacingOccurrences(of: "\"", with: "\"\"") + "\""
        return try withDatabase(url) { database in
            try query("SELECT * FROM \(quoted) LIMIT 51 OFFSET \(offset)", database: database, maximumRows: FileSQLitePage.pageSize)
        }
    }
}
