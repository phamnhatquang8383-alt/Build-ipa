import Foundation
import SwiftUI

struct FileInspectorRequest: Identifiable {
    let id = UUID()
    let staged: FileTransferItem
    let sourcePath: String
    let mode: FileInspectorMode
    var editable: Bool { sourcePath.hasPrefix("/CC365/") && (mode == .text || mode == .plist) }

    @MainActor static func prepare(path: String, name: String, mode: FileInspectorMode) async throws -> Self {
        let item = try FileTransferItem(name: name)
        defer { withExtendedLifetime(item) {} }
        if mode != .sqlite {
            try await VersionedFilesTransport.download(path: path, to: item.file)
            return Self(staged: item, sourcePath: path, mode: mode)
        }


        let parent = (path as NSString).deletingLastPathComponent
        func walEntry() async throws -> DeviceFileEntry? {
            var offset = 0
            for _ in 0..<100 {
                let page = try await VersionedFilesTransport.list(path: parent, offset: offset)
                if let notice = page.notice, !notice.isEmpty { throw FileInspectorError.message("Chưa kiểm tra đầy đủ WAL. " + notice) }
                if let entry = page.entries.first(where: { $0.name == name + "-wal" }) { return entry }
                guard let next = page.nextOffset else { return nil }
                guard next > offset else { throw FileInspectorError.message("Chưa đọc được danh sách tệp SQLite.") }
                offset = next
            }
            throw FileInspectorError.message("Thư mục có quá nhiều tệp để kiểm tra WAL. Hãy sao chép cơ sở dữ liệu vào vùng tệp riêng trước.")
        }
        let before = try await walEntry()
        if let before, before.kind != "file" { throw FileInspectorError.message("WAL không phải tệp thông thường.") }
        try await VersionedFilesTransport.download(path: path, to: item.file)
        let wal = item.directory.appendingPathComponent(name + "-wal")
        if before != nil { try await VersionedFilesTransport.download(path: path + "-wal", to: wal) }
        let check = try FileTransferItem(name: name)
        defer { withExtendedLifetime(check) {} }
        try await VersionedFilesTransport.download(path: path, to: check.file)
        let sameMain = try await FileInspectorWork.run { try equalFiles(item.file, check.file) }
        guard sameMain else { throw FileInspectorError.message("Cơ sở dữ liệu đang thay đổi. Đóng ứng dụng đang dùng tệp rồi thử lại.") }
        if before != nil {
            let checkWAL = check.directory.appendingPathComponent(name + "-wal")
            try await VersionedFilesTransport.download(path: path + "-wal", to: checkWAL)
            let sameWAL = try await FileInspectorWork.run { try equalFiles(wal, checkWAL) }
            guard sameWAL else { throw FileInspectorError.message("WAL đang thay đổi. Đóng ứng dụng đang dùng cơ sở dữ liệu rồi thử lại.") }
        }
        let after = try await walEntry()
        guard (before == nil) == (after == nil) else { throw FileInspectorError.message("Tệp WAL vừa thay đổi. Hãy thử mở lại.") }
        return Self(staged: item, sourcePath: path, mode: mode)
    }

    private static func equalFiles(_ a: URL, _ b: URL) throws -> Bool {
        let left = try FileHandle(forReadingFrom: a), right = try FileHandle(forReadingFrom: b)
        defer { try? left.close(); try? right.close() }
        while true {
            try Task.checkCancellation()
            let l = try left.read(upToCount: 64 * 1024) ?? Data()
            let r = try right.read(upToCount: 64 * 1024) ?? Data()
            if l != r { return false }
            if l.isEmpty { return true }
        }
    }
}

enum FileInspectorWork {
    static func run<T: Sendable>(_ body: @escaping @Sendable () throws -> T) async throws -> T {
        let worker = Task.detached(priority: .userInitiated) { try Task.checkCancellation(); return try body() }
        return try await withTaskCancellationHandler { try await worker.value } onCancel: { worker.cancel() }
    }
}

struct FileInspectorView: View {
    let request: FileInspectorRequest
    let onSaved: () -> Void
    let finish: () -> Void
    @State private var document: FileTextDocument?
    @State private var text = ""
    @State private var original = ""
    @State private var error: String?
    @State private var busy = false
    @State private var confirmDiscard = false
    @State private var worker: Task<Void, Never>?
    @State private var requiresReopen = false
    private var dirty: Bool { document != nil && text != original }

    var body: some View {
        NavigationStack {
            Group {
                switch request.mode {
                case .hex: FileHexView(file: request.staged.file)
                case .sqlite: FileSQLiteTablesView(file: request.staged.file)
                case .text, .plist: editor
                }
            }
            .cc365Canvas()
            .navigationTitle(request.staged.file.lastPathComponent)
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .cancellationAction) {
                    Button("Đóng") { if dirty { confirmDiscard = true } else { finish() } }.disabled(busy)
                }
                if request.editable {
                    ToolbarItem(placement: .confirmationAction) { Button("Lưu", action: save).disabled(!dirty || busy || requiresReopen) }
                }
            }
            .confirmationDialog("Bỏ thay đổi chưa lưu?", isPresented: $confirmDiscard, titleVisibility: .visible) {
                Button("Bỏ thay đổi", role: .destructive, action: finish)
                Button("Tiếp tục sửa", role: .cancel) {}
            }
            .alert("Chưa hoàn tất", isPresented: Binding(get: { error != nil }, set: { if !$0 { error = nil } })) {
                Button("Đóng", role: .cancel) { error = nil }
            } message: { Text(error ?? "") }
        }
        .interactiveDismissDisabled(dirty || busy)
        .onDisappear { worker?.cancel() }
    }

    private var editor: some View {
        VStack(spacing: 0) {
            if document != nil {
                if request.editable {
                    TextEditor(text: $text).font(.system(.body, design: .monospaced))
                        .autocorrectionDisabled().textInputAutocapitalization(.never).disabled(busy || requiresReopen)
                } else {
                    ScrollView { Text(text).font(.system(.body, design: .monospaced)).frame(maxWidth: .infinity, alignment: .leading).padding().textSelection(.enabled) }
                }
                Text(request.editable ? (request.mode == .plist ? "Chỉnh sửa XML; khi lưu sẽ giữ định dạng plist ban đầu." : "Lưu thay đổi vào tệp trong PhamQuang IOS.") : "Chỉ đọc · Sao chép vào Tệp PhamQuang IOS để chỉnh sửa.")
                    .font(.footnote).foregroundStyle(.secondary).padding()
            } else if busy {
                ProgressView("Đang đọc tệp…").frame(maxWidth: .infinity, maxHeight: .infinity)
            } else {
                CC365UnavailableView(title: "Chưa mở được tệp", systemImage: "doc.questionmark", description: "Đóng trình xem để chọn cách mở khác.")
            }
            if busy && document != nil { ProgressView("Đang lưu…").padding() }
        }
        .task {
            guard document == nil else { return }
            busy = true
            defer { busy = false }
            do {
                let file = request.staged.file, plist = request.mode == .plist
                let loaded = try await FileInspectorWork.run { try FileTextDocument.load(file, asPlist: plist) }
                try Task.checkCancellation()
                document = loaded; text = loaded.text; original = loaded.text
            } catch {
                if !FileTransferSupport.cancelled(error) { self.error = FileTransferSupport.message(error) }
            }
        }
    }

    private func save() {
        guard request.editable, let document, !busy, !requiresReopen else { return }
        busy = true
        let content = text
        worker = Task {
            defer { busy = false; worker = nil }
            do {
                let data = try await FileInspectorWork.run { try document.data(for: content) }
                let replacement = try FileTransferItem(name: request.staged.file.lastPathComponent)
                defer { withExtendedLifetime(replacement) {} }
                try data.write(to: replacement.file, options: .atomic)
                try await VersionedFilesTransport.replace(local: replacement.file, path: request.sourcePath, expected: request.staged.file)
                original = content
                onSaved()


                do { try data.write(to: request.staged.file, options: .atomic) }
                catch {
                    requiresReopen = true
                    self.error = "Tệp đã được lưu, nhưng chưa cập nhật được bản xem tạm. Hãy đóng và mở lại tệp trước khi sửa tiếp."
                }
            } catch {
                if !FileTransferSupport.cancelled(error) { self.error = FileTransferSupport.message(error) }
            }
        }
    }
}

private struct FileHexView: View {
    let file: URL
    @State private var offset: UInt64 = 0
    @State private var page: FileHexPage?
    @State private var error: String?
    @State private var loading = false
    @State private var generation = UUID()
    var body: some View {
        VStack {
            if let page {
                ScrollView([.horizontal, .vertical]) { Text(page.text.isEmpty ? "Tệp rỗng" : page.text).font(.system(.caption, design: .monospaced)).textSelection(.enabled).padding() }
                HStack {
                    Button("Trước") { offset -= UInt64(FileHexPage.pageSize) }.disabled(offset == 0 || loading)
                    Spacer()
                    Text("\(page.offset) / \(page.total) byte").font(.caption).monospacedDigit()
                    Spacer()
                    Button("Tiếp") { offset += UInt64(FileHexPage.pageSize) }.disabled(!page.hasNext || loading)
                }.padding()
            } else if loading { ProgressView("Đang đọc…") }
            if let error { Text(error).foregroundStyle(.secondary).padding() }
        }.task(id: offset) {
            let token = UUID(), requestedOffset = offset
            generation = token; loading = true; error = nil; page = nil
            defer { if generation == token { loading = false } }
            do {
                let loaded = try await FileInspectorWork.run { try FileHexPage.load(file, offset: requestedOffset) }
                try Task.checkCancellation()
                if generation == token { page = loaded }
            } catch { if generation == token && !FileTransferSupport.cancelled(error) { self.error = FileTransferSupport.message(error) } }
        }
    }
}

private struct FileSQLiteTablesView: View {
    let file: URL
    @State private var tables: [String] = []
    @State private var loading = true
    @State private var error: String?
    var body: some View {
        List {
            Section {
                if loading { ProgressView("Đang đọc bảng…") }
                else if let error { Text(error).foregroundStyle(.secondary) }
                else if tables.isEmpty { Text("Cơ sở dữ liệu chưa có bảng.").foregroundStyle(.secondary) }
                ForEach(tables, id: \.self) { table in
                    NavigationLink(table) { FileSQLiteTableView(file: file, table: table) }
                }
            } header: { Text("Bảng") } footer: { Text("Chỉ đọc bản sao SQLite và WAL tại thời điểm mở. Thay đổi trong ứng dụng gốc không tự cập nhật ở đây.") }
        }.task {
            do {
                let loaded = try await FileInspectorWork.run { try FileSQLiteReader.tables(file) }
                try Task.checkCancellation()
                tables = loaded
            }
            catch { if !FileTransferSupport.cancelled(error) { self.error = FileTransferSupport.message(error) } }
            loading = false
        }
    }
}

private struct FileSQLiteTableView: View {
    let file: URL
    let table: String
    @State private var offset = 0
    @State private var page: FileSQLitePage?
    @State private var loading = false
    @State private var error: String?
    @State private var generation = UUID()
    var body: some View {
        List {
            if loading { ProgressView("Đang đọc…") }
            if let error { Text(error).foregroundStyle(.secondary) }
            if let page {
                if page.rows.isEmpty { Text("Không có dữ liệu.").foregroundStyle(.secondary) }
                ForEach(page.rows.indices, id: \.self) { row in
                    DisclosureGroup("Hàng \(offset + row + 1)") {
                        ForEach(page.columns.indices, id: \.self) { column in
                            VStack(alignment: .leading, spacing: 4) {
                                Text(page.columns[column]).font(.caption).foregroundStyle(.secondary)
                                Text(page.rows[row][column]).font(.system(.body, design: .monospaced)).textSelection(.enabled)
                            }
                        }
                    }
                }
                HStack {
                    Button("Trước") { offset -= FileSQLitePage.pageSize }.disabled(offset == 0 || loading)
                    Spacer()
                    Button("Tiếp") { offset += FileSQLitePage.pageSize }.disabled(!page.hasNext || offset >= 100_000 || loading)
                }.buttonStyle(.borderless)
            }
        }.cc365Canvas().navigationTitle(table).navigationBarTitleDisplayMode(.inline)
        .task(id: offset) {
            let token = UUID(), requestedOffset = offset
            generation = token; loading = true; error = nil; page = nil
            defer { if generation == token { loading = false } }
            do {
                let loaded = try await FileInspectorWork.run { try FileSQLiteReader.rows(file, table: table, offset: requestedOffset) }
                try Task.checkCancellation()
                if generation == token { page = loaded }
            } catch { if generation == token && !FileTransferSupport.cancelled(error) { self.error = FileTransferSupport.message(error) } }
        }
    }
}
