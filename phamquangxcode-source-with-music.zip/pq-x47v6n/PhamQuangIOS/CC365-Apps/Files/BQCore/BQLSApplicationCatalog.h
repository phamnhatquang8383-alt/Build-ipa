#pragma once
#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN




NSArray<NSDictionary *> *BQReadLSApplicationRecords(BOOL (^ _Nullable cancelled)(void),
                                                    NSString * _Nullable * _Nullable notice);
NS_ASSUME_NONNULL_END
