#pragma once
#import <Foundation/Foundation.h>
NS_ASSUME_NONNULL_BEGIN
@interface CCBQPatchEngine : NSObject





+ (void)performRequest:(NSDictionary *)request
              progress:(NSProgress *)progress
            onProgress:(void (^)(NSDictionary *event))onProgress
            completion:(void (^)(NSDictionary * _Nullable result, NSError * _Nullable error))completion
    NS_SWIFT_NAME(perform(request:progress:onProgress:completion:));
@end
NS_ASSUME_NONNULL_END
