#import "CCBQFileSystem.h"
#import "BQCore.h"
#import "BQContainerCatalog.h"
#import <dirent.h>
#import <errno.h>
#import <fcntl.h>
#import <stdio.h>
#import <string.h>
#import <sys/stat.h>
#import <unistd.h>

NSString * const CCBQRetrySafeKey = @"CCBQRetrySafe";
static const uint64_t CCBQTransferLimit = 256ULL * 1024 * 1024;
static const NSUInteger CCBQPageSize = 100;
static NSString * const CCBQPartPrefix = @".cc365-bq-part-";



static NSArray<NSString *> *CCBQBrowseRoots(void) {
    return @[@"/var/containers/Data/System", @"/var/containers/Shared/SystemGroup",
        @"/var/mobile/Containers/Data/Application", @"/var/mobile/Containers/Data/InternalDaemon",
        @"/var/mobile/Containers/Data/PluginKitPlugin", @"/var/mobile/Containers/Shared/AppGroup"];
}

static NSError *CCBQError(int code, NSString *message, BOOL retrySafe) {
    NSMutableDictionary *info = [NSMutableDictionary dictionaryWithObject:message forKey:NSLocalizedDescriptionKey];
    if (retrySafe) info[CCBQRetrySafeKey] = @YES;
    return [NSError errorWithDomain:NSPOSIXErrorDomain code:code userInfo:info];
}

static NSError *CCBQPOSIX(int code, BOOL retrySafe) {
    NSString *message;
    switch (code) {
        case EACCES: case EPERM: message = @"iOS chưa cho phép truy cập vị trí này."; break;
        case ENOENT: message = @"Tệp hoặc thư mục không còn ở vị trí này."; break;
        case ELOOP: case ENOTDIR: message = @"Đường dẫn chứa liên kết hoặc không phải thư mục."; break;
        case EEXIST: message = @"Tên này đã tồn tại. Hãy chọn tên khác."; break;
        case ENOTEMPTY: message = @"Chỉ có thể xóa thư mục trống."; break;
        case ENOSPC: message = @"Không đủ dung lượng trống."; break;
        case EFBIG: message = @"Mỗi lần có thể chuyển một tệp tối đa 256 MiB."; break;
        default: message = [NSString stringWithFormat:@"Không hoàn tất được thao tác tệp (mã %d).", code]; break;
    }
    return CCBQError(code, message, retrySafe);
}

static BOOL CCBQCancelled(NSProgress *progress, NSError **error) {
    if (!progress.cancelled) return NO;
    if (error) *error = [NSError errorWithDomain:NSCocoaErrorDomain code:NSUserCancelledError
        userInfo:@{NSLocalizedDescriptionKey: @"Đã dừng thao tác tệp."}];
    return YES;
}

static BOOL CCBQPermissionError(NSError *error) {
    if ([error.domain isEqualToString:NSPOSIXErrorDomain]) return error.code == EACCES || error.code == EPERM;
    if ([error.domain isEqualToString:NSCocoaErrorDomain] &&
        (error.code == NSFileReadNoPermissionError || error.code == NSFileWriteNoPermissionError)) return YES;
    return error.userInfo[NSUnderlyingErrorKey] ? CCBQPermissionError(error.userInfo[NSUnderlyingErrorKey]) : NO;
}

static BOOL CCBQName(NSString *name) {
    return [name isKindOfClass:NSString.class] && name.length && [name lengthOfBytesUsingEncoding:NSUTF8StringEncoding] <= 255 &&
        ![name isEqualToString:@"."] && ![name isEqualToString:@".."] &&
        [name rangeOfCharacterFromSet:NSCharacterSet.controlCharacterSet].location == NSNotFound &&
        ![name containsString:@"/"] && ![name containsString:@"\\"];
}

static NSString *CCBQPath(id value) {
    if (![value isKindOfClass:NSString.class] || ![value isAbsolutePath] || [value lengthOfBytesUsingEncoding:NSUTF8StringEncoding] > 4096) return nil;
    if ([value isEqualToString:@"/"]) return value;
    NSArray *parts = [[value substringFromIndex:1] componentsSeparatedByString:@"/"];
    if (parts.count > 64) return nil;
    for (NSString *part in parts) if (!CCBQName(part)) return nil;
    if ([value hasPrefix:@"/private/var/"]) return [value substringFromIndex:8];
    return value;
}

static BOOL CCBQWorkspacePath(NSString *path) {
    return [path isEqualToString:@"/CC365"] || [path hasPrefix:@"/CC365/"];
}

static NSString *CCBQActualPath(NSString *path) {
    if (!CCBQWorkspacePath(path)) return path;
    return [BQDocuments() stringByAppendingString:[path substringFromIndex:6]];
}

static NSString *CCBQRequestPath(NSDictionary *request, NSError **error) {
    NSString *path = CCBQPath(request[@"path"]);
    if (!path && error) *error = CCBQError(EINVAL, @"Đường dẫn tệp không hợp lệ.", NO);
    return path;
}

static int CCBQOpenDirectory(NSString *path) {
    return open(path.fileSystemRepresentation, O_RDONLY | O_DIRECTORY | O_CLOEXEC | O_NOFOLLOW);
}



static int CCBQOpenRelativeParent(NSString *base, NSArray<NSString *> *parts, NSError **error) {
    int fd = CCBQOpenDirectory(base);
    if (fd < 0) { if (error) *error = CCBQPOSIX(errno, NO); return -1; }
    for (NSString *part in parts) {
        int next = openat(fd, part.fileSystemRepresentation, O_RDONLY | O_DIRECTORY | O_NOFOLLOW | O_CLOEXEC);
        int code = errno;
        close(fd);
        if (next < 0) { if (error) *error = CCBQPOSIX(code, NO); return -1; }
        fd = next;
    }
    return fd;
}

static int CCBQWorkspaceParent(NSString *path, NSString **leaf, NSError **error) {
    if (!CCBQWorkspacePath(path) || [path isEqualToString:@"/CC365"]) {
        if (error) *error = CCBQError(EPERM, @"Chỉ có thể thay đổi tệp bên trong Tệp PhamQuang IOS.", NO);
        return -1;
    }
    NSArray *parts = [[path substringFromIndex:7] componentsSeparatedByString:@"/"];
    for (NSString *part in parts) {
        if (!CCBQName(part) || [part.lowercaseString hasPrefix:CCBQPartPrefix]) {
            if (error) *error = CCBQError(EINVAL, @"Tên tệp hoặc thư mục không hợp lệ.", NO);
            return -1;
        }
    }
    if (leaf) *leaf = parts.lastObject;
    return CCBQOpenRelativeParent(BQDocuments(), [parts subarrayWithRange:NSMakeRange(0, parts.count - 1)], error);
}

static int CCBQTemporaryParent(NSString *path, NSString **leaf, NSError **error) {
    NSString *temporary = CCBQPath([NSTemporaryDirectory() stringByStandardizingPath]);
    NSString *normalized = CCBQPath(path);
    if (!temporary || !normalized || ![normalized hasPrefix:[temporary stringByAppendingString:@"/"]]) {
        if (error) *error = CCBQError(EPERM, @"Tệp chuyển phải nằm trong thư mục tạm riêng của ứng dụng.", NO);
        return -1;
    }
    NSArray *parts = [[normalized substringFromIndex:temporary.length + 1] componentsSeparatedByString:@"/"];
    if (leaf) *leaf = parts.lastObject;
    return CCBQOpenRelativeParent(temporary, [parts subarrayWithRange:NSMakeRange(0, parts.count - 1)], error);
}

static BOOL CCBQCopyBytes(int input, int output, NSProgress *progress, uint64_t *bytes, NSError **error) {
    struct stat before, after;
    if (fstat(input, &before) != 0) { if (error) *error = CCBQPOSIX(errno, YES); return NO; }
    if (!S_ISREG(before.st_mode)) { if (error) *error = CCBQError(EINVAL, @"Chỉ có thể chuyển tệp thông thường, không phải liên kết.", NO); return NO; }
    if (before.st_size < 0 || (uint64_t)before.st_size > CCBQTransferLimit) { if (error) *error = CCBQPOSIX(EFBIG, NO); return NO; }
    progress.totalUnitCount = MAX((int64_t)before.st_size, 1);
    progress.completedUnitCount = 0;
    uint64_t total = 0;
    uint8_t buffer[64 * 1024];
    for (;;) {
        if (CCBQCancelled(progress, error)) return NO;
        ssize_t count = read(input, buffer, (size_t)MIN(sizeof(buffer), CCBQTransferLimit - total + 1));
        if (count < 0 && errno == EINTR) continue;
        if (count < 0) { if (error) *error = CCBQPOSIX(errno, YES); return NO; }
        if (!count) break;
        if (total + (uint64_t)count > CCBQTransferLimit) { if (error) *error = CCBQPOSIX(EFBIG, NO); return NO; }
        for (ssize_t position = 0; position < count;) {
            if (CCBQCancelled(progress, error)) return NO;
            ssize_t wrote = write(output, buffer + position, (size_t)(count - position));
            if (wrote < 0 && errno == EINTR) continue;
            if (wrote <= 0) { if (error) *error = CCBQPOSIX(wrote == 0 ? EIO : errno, NO); return NO; }
            position += wrote;
        }
        total += (uint64_t)count;
        progress.completedUnitCount = (int64_t)total;
    }
    if (fstat(input, &after) != 0 || before.st_dev != after.st_dev || before.st_ino != after.st_ino ||
        before.st_size != after.st_size || total != (uint64_t)before.st_size ||
        before.st_mtimespec.tv_sec != after.st_mtimespec.tv_sec || before.st_mtimespec.tv_nsec != after.st_mtimespec.tv_nsec) {
        if (error) *error = CCBQError(EBUSY, @"Tệp đã thay đổi trong lúc chuyển. Hãy thử lại.", NO);
        return NO;
    }
    if (fsync(output) != 0) { if (error) *error = CCBQPOSIX(errno, NO); return NO; }
    if (CCBQCancelled(progress, error)) return NO;
    if (bytes) *bytes = total;
    progress.completedUnitCount = progress.totalUnitCount;
    return YES;
}

static NSDictionary *CCBQPage(NSArray<NSDictionary *> *entries, NSUInteger offset, NSString *notice) {
    NSUInteger start = MIN(offset, entries.count);
    NSUInteger end = start + MIN(CCBQPageSize, entries.count - start);
    NSMutableDictionary *page = [@{@"entries": [entries subarrayWithRange:NSMakeRange(start, end - start)],
        @"total": @(entries.count), @"nextOffset": end < entries.count ? @(end) : NSNull.null} mutableCopy];
    if (notice.length) page[@"notice"] = notice;
    return page;
}

static NSArray *CCBQSorted(NSArray<NSDictionary *> *entries) {
    return [entries sortedArrayUsingComparator:^NSComparisonResult(NSDictionary *a, NSDictionary *b) {
        BOOL ad = [a[@"kind"] isEqualToString:@"directory"], bd = [b[@"kind"] isEqualToString:@"directory"];
        if (ad != bd) return ad ? NSOrderedAscending : NSOrderedDescending;
        NSComparisonResult r = [(a[@"display_name"] ?: a[@"name"]) localizedCaseInsensitiveCompare:(b[@"display_name"] ?: b[@"name"])];
        return r == NSOrderedSame ? [(a[@"path"] ?: a[@"name"]) compare:(b[@"path"] ?: b[@"name"])] : r;
    }];
}



static NSDictionary *CCBQBrowserPage(NSArray<NSDictionary *> *entries, NSUInteger offset,
                                    NSString *notice, NSDictionary *options) {
    if (!options[@"sort"] && !options[@"query"] && !options[@"show_hidden"] && !options[@"ascending"] && !options[@"folders_first"])
        return CCBQPage(entries, offset, notice);
    NSString *query = [options[@"query"] isKindOfClass:NSString.class] ? options[@"query"] : @"";
    NSString *sort = options[@"sort"] ?: @"name";
    BOOL hidden = !options[@"show_hidden"] || [options[@"show_hidden"] boolValue];
    BOOL ascending = !options[@"ascending"] || [options[@"ascending"] boolValue];
    BOOL folders = !options[@"folders_first"] || [options[@"folders_first"] boolValue];
    NSMutableArray *filtered = [NSMutableArray array];
    for (NSDictionary *row in entries) {
        if (!hidden && [row[@"name"] hasPrefix:@"."]) continue;
        if (query.length) {
            NSString *text = [NSString stringWithFormat:@"%@ %@ %@", row[@"name"], row[@"display_name"] ?: @"", row[@"subtitle"] ?: @""];
            if ([text rangeOfString:query options:NSCaseInsensitiveSearch | NSDiacriticInsensitiveSearch].location == NSNotFound) continue;
        }
        [filtered addObject:row];
    }
    NSArray *ordered = [filtered sortedArrayUsingComparator:^NSComparisonResult(NSDictionary *a, NSDictionary *b) {
        BOOL ad = [a[@"kind"] isEqual:@"directory"], bd = [b[@"kind"] isEqual:@"directory"];
        if (folders && ad != bd) return ad ? NSOrderedAscending : NSOrderedDescending;
        NSComparisonResult result = NSOrderedSame;
        if (![sort isEqual:@"name"]) {
            NSNumber *av = [a[sort] isKindOfClass:NSNumber.class] ? a[sort] : @0;
            NSNumber *bv = [b[sort] isKindOfClass:NSNumber.class] ? b[sort] : @0;
            result = [av compare:bv];
        }
        if (result == NSOrderedSame) result = [(a[@"display_name"] ?: a[@"name"]) localizedStandardCompare:(b[@"display_name"] ?: b[@"name"])];
        if (result == NSOrderedSame) result = [(a[@"path"] ?: a[@"name"]) compare:(b[@"path"] ?: b[@"name"])];
        return ascending ? result : -result;
    }];
    return CCBQPage(ordered, offset, notice);
}

static BOOL CCBQSameStat(struct stat a, struct stat b) {
    return a.st_dev == b.st_dev && a.st_ino == b.st_ino && a.st_mode == b.st_mode && a.st_size == b.st_size &&
        a.st_mtimespec.tv_sec == b.st_mtimespec.tv_sec && a.st_mtimespec.tv_nsec == b.st_mtimespec.tv_nsec;
}

static BOOL CCBQEqualFiles(int a, int b, NSError **error) {
    struct stat beforeA, beforeB, afterA, afterB;
    if (fstat(a, &beforeA) || fstat(b, &beforeB) || !S_ISREG(beforeA.st_mode) || !S_ISREG(beforeB.st_mode) ||
        beforeA.st_size < 0 || beforeA.st_size > (int64_t)CCBQTransferLimit || beforeA.st_size != beforeB.st_size ||
        lseek(a, 0, SEEK_SET) < 0 || lseek(b, 0, SEEK_SET) < 0) goto changed;
    uint8_t left[64 * 1024], right[64 * 1024];
    for (off_t position = 0; position < beforeA.st_size;) {
        size_t wanted = (size_t)MIN((off_t)sizeof(left), beforeA.st_size - position);
        ssize_t x = pread(a, left, wanted, position), y = pread(b, right, wanted, position);
        if (x < 0 && errno == EINTR) continue;
        if (x <= 0 || x != y || memcmp(left, right, (size_t)x)) goto changed;
        position += x;
    }
    if (fstat(a, &afterA) || fstat(b, &afterB) || !CCBQSameStat(beforeA, afterA) || !CCBQSameStat(beforeB, afterB)) goto changed;
    return YES;
changed:
    if (error) *error = CCBQError(EBUSY, @"Tệp gốc đã thay đổi. Hãy mở lại tệp trước khi lưu để tránh ghi đè thay đổi khác.", NO);
    return NO;
}

static BOOL CCBQCopyTree(int source, int destination, NSUInteger depth, NSUInteger *nodes, NSUInteger *files,
                       uint64_t *bytes, NSProgress *progress, NSError **error) {
    if (depth > 32) { if (error) *error = CCBQError(EFBIG, @"Cây thư mục quá sâu.", NO); return NO; }
    struct stat directoryBefore, directoryAfter;
    if (fstat(source, &directoryBefore)) { if (error) *error = CCBQPOSIX(errno, NO); return NO; }
    DIR *listing = fdopendir(dup(source));
    if (!listing) { if (error) *error = CCBQPOSIX(errno, NO); return NO; }
    BOOL ok = NO;
    @try {
        for (;;) {
            if (CCBQCancelled(progress, error)) return NO;
            errno = 0; struct dirent *item = readdir(listing);
            if (!item) { if (errno) { if (error) *error = CCBQPOSIX(errno, NO); return NO; } break; }
            if (!strcmp(item->d_name, ".") || !strcmp(item->d_name, "..")) continue;
            NSString *name = [NSFileManager.defaultManager stringWithFileSystemRepresentation:item->d_name length:strlen(item->d_name)];
            if (!CCBQName(name) || [name.lowercaseString hasPrefix:CCBQPartPrefix] || ++*nodes > 4096) {
                if (error) *error = CCBQError(EINVAL, @"Thư mục có tên không hỗ trợ hoặc quá nhiều mục.", NO); return NO;
            }
            struct stat before, opened;
            if (fstatat(source, item->d_name, &before, AT_SYMLINK_NOFOLLOW)) { if (error) *error = CCBQPOSIX(errno, NO); return NO; }
            BOOL directory = S_ISDIR(before.st_mode);
            if (!directory && !S_ISREG(before.st_mode)) { if (error) *error = CCBQError(EINVAL, @"Không sao chép liên kết hoặc tệp đặc biệt.", NO); return NO; }
            int input = openat(source, item->d_name, O_RDONLY | O_NOFOLLOW | O_CLOEXEC | (directory ? O_DIRECTORY : O_NONBLOCK));
            if (input < 0) { if (error) *error = CCBQPOSIX(errno, NO); return NO; }
            if (fstat(input, &opened) || !CCBQSameStat(before, opened)) { close(input); if (error) *error = CCBQError(EBUSY, @"Nguồn đã thay đổi trong lúc sao chép.", NO); return NO; }
            if (directory) {
                if (mkdirat(destination, item->d_name, 0700)) { close(input); if (error) *error = CCBQPOSIX(errno, NO); return NO; }
                int output = openat(destination, item->d_name, O_RDONLY | O_DIRECTORY | O_NOFOLLOW | O_CLOEXEC);
                if (output < 0) { close(input); if (error) *error = CCBQPOSIX(errno, NO); return NO; }
                BOOL copied = CCBQCopyTree(input, output, depth + 1, nodes, files, bytes, progress, error);
                close(output); close(input);
                if (!copied) return NO;
            } else {
                if (++*files > 1024 || before.st_size < 0 || before.st_size > 128LL * 1024 * 1024 ||
                    (uint64_t)before.st_size > CCBQTransferLimit - *bytes) {
                    close(input); if (error) *error = CCBQError(EFBIG, @"Tối đa 1.024 tệp, 128 MiB mỗi tệp và 256 MiB tổng cộng.", NO); return NO;
                }
                int output = openat(destination, item->d_name, O_WRONLY | O_CREAT | O_EXCL | O_NOFOLLOW | O_CLOEXEC, 0600);
                if (output < 0) { close(input); if (error) *error = CCBQPOSIX(errno, NO); return NO; }
                uint64_t copiedBytes = 0;
                BOOL copied = CCBQCopyBytes(input, output, progress, &copiedBytes, error);
                close(output); close(input);
                if (!copied || copiedBytes != (uint64_t)before.st_size) return NO;
                *bytes += copiedBytes;
            }
        }
        if (fstat(source, &directoryAfter) || !CCBQSameStat(directoryBefore, directoryAfter)) {
            if (error) *error = CCBQError(EBUSY, @"Thư mục nguồn đã thay đổi khi sao chép.", NO); return NO;
        }
        ok = fsync(destination) == 0;
        if (!ok && error) *error = CCBQPOSIX(errno, NO);
    } @finally { closedir(listing); }
    return ok;
}



static BOOL CCBQRemoveOwnedTree(int parent, const char *leaf, NSUInteger depth) {
    if (depth > 34) return NO;
    struct stat st;
    if (fstatat(parent, leaf, &st, AT_SYMLINK_NOFOLLOW)) return errno == ENOENT;
    if (!S_ISDIR(st.st_mode)) return unlinkat(parent, leaf, 0) == 0;
    int fd = openat(parent, leaf, O_RDONLY | O_DIRECTORY | O_NOFOLLOW | O_CLOEXEC);
    if (fd < 0) return NO;
    struct stat opened;
    if (fstat(fd, &opened) || st.st_dev != opened.st_dev || st.st_ino != opened.st_ino) { close(fd); return NO; }
    DIR *dir = fdopendir(fd);
    if (!dir) { close(fd); return NO; }
    BOOL ok = YES;
    for (;;) {
        errno = 0; struct dirent *entry = readdir(dir);
        if (!entry) { if (errno) ok = NO; break; }
        if (!strcmp(entry->d_name, ".") || !strcmp(entry->d_name, "..")) continue;
        if (!CCBQRemoveOwnedTree(fd, entry->d_name, depth + 1)) ok = NO;
    }
    struct stat current;
    if (fstatat(parent, leaf, &current, AT_SYMLINK_NOFOLLOW) || current.st_dev != st.st_dev || current.st_ino != st.st_ino) ok = NO;
    closedir(dir);
    return ok && unlinkat(parent, leaf, AT_REMOVEDIR) == 0;
}

static BOOL CCBQNamedIdentity(int parent, NSString *name, struct stat identity) {
    struct stat current;
    return !fstatat(parent, name.fileSystemRepresentation, &current, AT_SYMLINK_NOFOLLOW) &&
        current.st_dev == identity.st_dev && current.st_ino == identity.st_ino;
}

static NSString *CCBQRecoverFile(int parent, NSString *temporary, NSString *path, struct stat identity) {
    if (!CCBQNamedIdentity(parent, temporary, identity)) return [path.stringByDeletingLastPathComponent stringByAppendingPathComponent:temporary];
    NSString *name = [NSString stringWithFormat:@"Recovered-%@-%@", NSUUID.UUID.UUIDString, path.lastPathComponent];
    if (!CCBQName(name)) name = [@"Recovered-" stringByAppendingString:NSUUID.UUID.UUIDString];
    if (renameatx_np(parent, temporary.fileSystemRepresentation, parent, name.fileSystemRepresentation, RENAME_EXCL)) name = temporary;
    return [path.stringByDeletingLastPathComponent stringByAppendingPathComponent:name];
}

static BOOL CCBQNamedContainerRoot(NSString *path) {
    return [path isEqualToString:@"/var/mobile/Containers/Data/Application"] ||
        [path isEqualToString:@"/var/mobile/Containers/Data/PluginKitPlugin"];
}



static NSArray *CCBQNamedRows(NSString *root, NSArray<NSDictionary *> *rows, NSProgress *progress,
                              NSString **notice, NSError **error) {
    if (!CCBQNamedContainerRoot(root)) return rows;
    if (CCBQCancelled(progress, error)) return nil;
    NSString *lookupNotice = nil;
    NSArray<BQContainerEntry *> *catalog = BQDiscoverContainers(^BOOL { return progress.cancelled; }, &lookupNotice);
    if (CCBQCancelled(progress, error)) return nil;
    NSMutableDictionary<NSString *, NSMutableDictionary *> *merged = [NSMutableDictionary dictionary];
    for (NSDictionary *row in rows) merged[row[@"path"]] = [row mutableCopy];
    NSMutableDictionary<NSString *, BQContainerEntry *> *identities = [NSMutableDictionary dictionary];
    NSMutableSet<NSString *> *conflicts = [NSMutableSet set];
    for (BQContainerEntry *entry in catalog) {
        if (CCBQCancelled(progress, error)) return nil;
        NSString *path = CCBQPath(entry.path);
        if (!path || ![path.stringByDeletingLastPathComponent isEqualToString:root]) continue;
        struct stat st;
        int inspected = lstat(path.fileSystemRepresentation, &st);
        BOOL restricted = inspected < 0 && (errno == EACCES || errno == EPERM);
        if ((inspected == 0 && !S_ISDIR(st.st_mode)) || (inspected < 0 && !restricted)) continue;
        NSMutableDictionary *row = merged[path];
        if (row && ![row[@"kind"] isEqualToString:@"directory"]) continue;
        if (!row) {
            row = [@{@"name": path.lastPathComponent, @"path": path, @"kind": @"directory",
                @"size": NSNull.null, @"modified": inspected == 0 ? @((int64_t)st.st_mtimespec.tv_sec) : NSNull.null} mutableCopy];
            merged[path] = row;
        }
        BQContainerEntry *prior = identities[path];
        if (prior.identifier.length && entry.identifier.length && ![prior.identifier isEqualToString:entry.identifier]) {
            [conflicts addObject:path];
        } else if (!prior || (!prior.identifier.length && entry.identifier.length)) identities[path] = entry;
    }
    BOOL unresolved = NO;
    for (NSString *path in merged) {
        if (CCBQCancelled(progress, error)) return nil;
        NSMutableDictionary *row = merged[path];
        BQContainerEntry *entry = identities[path];
        if (![conflicts containsObject:path] && entry.identifier.length) {
            row[@"display_name"] = entry.name.length && ![entry.name isEqualToString:path.lastPathComponent] ? entry.name : entry.identifier;
            row[@"subtitle"] = entry.identifier;
        } else if ([row[@"kind"] isEqualToString:@"directory"]) unresolved = YES;
    }
    NSArray *result = CCBQSorted(merged.allValues);
    NSMutableArray<NSString *> *messages = [NSMutableArray array];
    if (notice && (*notice).length) [messages addObject:*notice];
    if (lookupNotice.length && (unresolved || !result.count) && ![messages containsObject:lookupNotice]) [messages addObject:lookupNotice];
    if (result.count > 1024) {
        result = [result subarrayWithRange:NSMakeRange(0, 1024)];
        [messages addObject:@"Danh sách giới hạn ở 1.024 mục và có thể còn thiếu."];
    }
    if (notice) *notice = messages.count ? [messages componentsJoinedByString:@" "] : nil;
    if (CCBQCancelled(progress, error)) return nil;
    return result;
}

@implementation CCBQFileSystem

+ (BOOL)withDirectory:(NSString *)path progress:(NSProgress *)progress
            operation:(BOOL (^)(NSString *, NSError **))operation error:(NSError **)error {
    if (error) *error = nil;
    if (CCBQCancelled(progress, error)) return NO;
    NSString *directory = CCBQPath(path);
    if (!directory || !operation) { if (error) *error = CCBQError(EINVAL, @"Thư mục không hợp lệ.", NO); return NO; }
    int fd = CCBQOpenDirectory(directory);
    NSError *failure = nil;
    if (fd >= 0) {
        close(fd);
        if (operation(directory, &failure)) return YES;
        if (!CCBQPermissionError(failure) || ![failure.userInfo[CCBQRetrySafeKey] boolValue]) {
            if (error) *error = failure ?: CCBQError(EIO, @"Không hoàn tất được thao tác trong thư mục.", NO);
            return NO;
        }
    } else {
        failure = CCBQPOSIX(errno, YES);
        if (!CCBQPermissionError(failure)) { if (error) *error = failure; return NO; }
    }
    if (CCBQCancelled(progress, error)) return NO;
    NSString *accessible = nil;
    int64_t lease = BQEscape(directory, &accessible);
    if (lease < 0) {
        NSString *message = lease == -7 ? @"BQCore chưa hỗ trợ các API cần thiết trên bản iOS này. Tệp PhamQuang IOS vẫn dùng được."
            : @"Chưa mở được quyền truy cập thư mục này trên thiết bị hiện tại. Tệp PhamQuang IOS vẫn dùng được.";
        if (error) *error = CCBQError(EACCES, message, NO);
        return NO;
    }
    @try {
        if (CCBQCancelled(progress, error)) return NO;
        if (!accessible.length) { if (error) *error = CCBQError(EIO, @"BQCore không trả về đường dẫn có thể mở.", NO); return NO; }
        failure = nil;
        BOOL ok = operation(accessible, &failure);
        if (!ok && error) *error = failure ?: CCBQError(EIO, @"Không hoàn tất được thao tác trong thư mục.", NO);
        return ok;
    } @finally { BQEndEscape(lease); }
}

+ (NSDictionary *)catalogAtOffset:(NSUInteger)offset includeMedia:(BOOL)includeMedia progress:(NSProgress *)progress error:(NSError **)error {
    NSString *notice = nil;
    NSArray<BQContainerEntry *> *containers = BQDiscoverContainers(^BOOL { return progress.cancelled; }, &notice);
    if (CCBQCancelled(progress, error)) return nil;
    NSMutableArray *entries = [NSMutableArray array];
    if (includeMedia) {
        NSString *media = @"/var/mobile/Media";
        struct stat st;
        int result = lstat(media.fileSystemRepresentation, &st);
        if ((result == 0 && S_ISDIR(st.st_mode)) || (result < 0 && (errno == EACCES || errno == EPERM))) {
            [entries addObject:@{@"name": @"Media", @"path": media, @"kind": @"directory", @"size": NSNull.null,
                @"modified": NSNull.null, @"subtitle": @"Dữ liệu Media trên thiết bị"}];
        }
    }
    for (BQContainerEntry *container in containers) {
        NSString *kindName = [container.kind isEqualToString:@"app"] ? @"Ứng dụng" : ([container.kind isEqualToString:@"group"] ? @"Nhóm ứng dụng" : @"Nhóm hệ thống");
        NSString *subtitle = container.identifier.length ? [NSString stringWithFormat:@"%@ · %@", kindName, container.identifier] : kindName;
        [entries addObject:@{@"name": container.name, @"path": container.path, @"kind": @"directory", @"size": NSNull.null,
            @"modified": NSNull.null, @"subtitle": subtitle, @"accessRestricted": @(container.accessRestricted)}];
    }
    return CCBQPage(CCBQSorted(entries), offset, notice);
}

+ (NSDictionary *)listPath:(NSString *)path offset:(NSUInteger)offset options:(NSDictionary *)options progress:(NSProgress *)progress error:(NSError **)error {
    if ([path isEqualToString:@"/"]) {
        NSMutableArray *locations = [NSMutableArray array];
        for (NSString *root in CCBQBrowseRoots()) {
            [locations addObject:@{@"name": root.lastPathComponent, @"path": root,
                @"kind": @"directory", @"size": NSNull.null, @"modified": NSNull.null, @"subtitle": root}];
        }
        return CCBQBrowserPage(locations, offset, nil, options);
    }
    BOOL containerRoot = [CCBQBrowseRoots() containsObject:path];
    __block NSArray *result = nil;
    BOOL (^readDirectory)(NSString *, NSError **) = ^BOOL(NSString *accessible, NSError **failure) {


        DIR *dir = NULL;
        if (CCBQWorkspacePath(path)) {
            NSArray *parts = [path isEqualToString:@"/CC365"] ? @[] : [[path substringFromIndex:7] componentsSeparatedByString:@"/"];
            int fd = CCBQOpenRelativeParent(BQDocuments(), parts, failure);
            if (fd < 0) return NO;
            dir = fdopendir(fd);
            if (!dir) { int code = errno; close(fd); *failure = CCBQPOSIX(code, NO); return NO; }
        } else dir = opendir(accessible.fileSystemRepresentation);
        if (!dir) { *failure = CCBQPOSIX(errno, YES); return NO; }
        NSMutableArray *rows = [NSMutableArray array];
        @try {
            for (;;) {
                if (CCBQCancelled(progress, failure)) return NO;
                errno = 0;
                struct dirent *child = readdir(dir);
                if (!child) {
                    if (errno) { *failure = CCBQPOSIX(errno, YES); return NO; }
                    break;
                }
                if (!strcmp(child->d_name, ".") || !strcmp(child->d_name, "..")) continue;
                NSString *name = [[NSFileManager defaultManager] stringWithFileSystemRepresentation:child->d_name length:strlen(child->d_name)];
                if (!CCBQName(name) || (CCBQWorkspacePath(path) && [name.lowercaseString hasPrefix:CCBQPartPrefix])) continue;
                struct stat st;
                NSString *kind = @"other";
                id size = NSNull.null, modified = NSNull.null, created = NSNull.null;
                if (fstatat(dirfd(dir), child->d_name, &st, AT_SYMLINK_NOFOLLOW) == 0) {
                    kind = S_ISDIR(st.st_mode) ? @"directory" : (S_ISREG(st.st_mode) ? @"file" : (S_ISLNK(st.st_mode) ? @"symlink" : @"other"));
                    if (S_ISREG(st.st_mode) && st.st_size >= 0) size = @((uint64_t)st.st_size);
                    modified = @((int64_t)st.st_mtimespec.tv_sec);
                    created = @((int64_t)st.st_birthtimespec.tv_sec);
                } else if (errno == EACCES || errno == EPERM) {


                    if (child->d_type == DT_DIR || (containerRoot && child->d_type == DT_UNKNOWN)) kind = @"directory";
                    else if (child->d_type == DT_LNK) kind = @"symlink";
                }
                [rows addObject:@{@"name": name, @"kind": kind, @"size": size, @"modified": modified,
                    @"path": [path stringByAppendingPathComponent:name], @"created": created}];
            }
            result = CCBQSorted(rows);
            return YES;
        } @finally { closedir(dir); }
    };
    NSError *failure = nil;


    BOOL ok = CCBQWorkspacePath(path) ? readDirectory(nil, &failure)
        : (containerRoot ? readDirectory(path, &failure)
            : [self withDirectory:CCBQActualPath(path) progress:progress operation:readDirectory error:&failure]);
    if (!ok && containerRoot && CCBQPermissionError(failure)) {
        BOOL stoppedEarly = NO;
        NSString *scanError = nil;
        NSArray<NSString *> *observed = BQDiscoverContainerPaths(path, 1.5, 1024,
            ^BOOL { return progress.cancelled; }, &stoppedEarly, &scanError);
        if (CCBQCancelled(progress, error)) return nil;
        NSMutableArray *rows = [NSMutableArray array];
        NSMutableSet *seen = [NSMutableSet set];
        for (NSString *candidate in observed) {
            NSString *child = CCBQPath(candidate);
            if (!child || ![child.stringByDeletingLastPathComponent isEqualToString:path] || [seen containsObject:child]) continue;
            struct stat st;
            int inspected = lstat(child.fileSystemRepresentation, &st);
            BOOL restricted = inspected < 0 && (errno == EACCES || errno == EPERM);
            if ((inspected == 0 && !S_ISDIR(st.st_mode)) || (inspected < 0 && !restricted)) continue;
            [seen addObject:child];
            [rows addObject:@{@"name": child.lastPathComponent, @"path": child, @"kind": @"directory",
                @"size": NSNull.null, @"modified": inspected == 0 ? @((int64_t)st.st_mtimespec.tv_sec) : NSNull.null}];
        }
        NSMutableString *notice = [NSMutableString stringWithString:
            @"iOS không cho phép liệt kê đầy đủ vị trí này. Danh sách chỉ gồm các thư mục quan sát được trong lượt quét giới hạn và có thể còn thiếu."];
        if (stoppedEarly) [notice appendString:@" Lượt quét đã chạm giới hạn thời gian hoặc số mục."];
        if (scanError.length) [notice appendString:@" Thiết bị chưa cung cấp đủ thông tin để hoàn tất lượt quét."];
        NSString *mergedNotice = notice;
        NSArray *named = CCBQNamedRows(path, rows, progress, &mergedNotice, error);
        if (!named) return nil;
        if (!named.count) mergedNotice = [mergedNotice stringByAppendingString:@" Chưa tìm thấy mục nào; điều này không có nghĩa là thư mục trống."];
        if (error) *error = nil;
        return CCBQBrowserPage(named, offset, mergedNotice, options);
    }
    if (!ok && error) *error = failure;
    if (!ok) return nil;
    NSString *notice = nil;
    NSArray *named = CCBQNamedRows(path, result ?: @[], progress, &notice, error);
    return named ? CCBQBrowserPage(named, offset, notice, options) : nil;
}

+ (NSDictionary *)downloadPath:(NSString *)path to:(NSString *)destination progress:(NSProgress *)progress error:(NSError **)error {
    NSString *destinationLeaf = nil;
    int destinationParent = CCBQTemporaryParent(destination, &destinationLeaf, error);
    if (destinationParent < 0) return nil;
    __block uint64_t bytes = 0;
    BOOL ok = NO;
    @try {
        NSString *source = CCBQActualPath(path);
        BOOL (^copyFile)(NSString *, NSError **) = ^BOOL(NSString *accessible, NSError **failure) {
            int parent;
            if (CCBQWorkspacePath(path)) parent = CCBQWorkspaceParent(path, NULL, failure);
            else parent = open(accessible.fileSystemRepresentation, O_RDONLY | O_DIRECTORY | O_CLOEXEC);
            if (parent < 0) { *failure = CCBQPOSIX(errno, YES); return NO; }
            int input = openat(parent, source.lastPathComponent.fileSystemRepresentation, O_RDONLY | O_NOFOLLOW | O_NONBLOCK | O_CLOEXEC);
            int code = errno;
            close(parent);
            if (input < 0) { *failure = CCBQPOSIX(code, YES); return NO; }
            int output = openat(destinationParent, destinationLeaf.fileSystemRepresentation, O_WRONLY | O_CREAT | O_EXCL | O_NOFOLLOW | O_CLOEXEC, 0600);
            if (output < 0) { code = errno; close(input); *failure = CCBQPOSIX(code, NO); return NO; }
            BOOL copied = NO;
            @try { copied = CCBQCopyBytes(input, output, progress, &bytes, failure); }
            @finally {
                close(input);
                if (close(output) != 0 && copied) { copied = NO; *failure = CCBQPOSIX(errno, NO); }
                if (!copied && unlinkat(destinationParent, destinationLeaf.fileSystemRepresentation, 0) != 0) {
                    *failure = CCBQError(EIO, @"Chuyển tệp chưa hoàn tất và chưa dọn được bản sao tạm.", NO);
                }
            }
            return copied;
        };
        ok = CCBQWorkspacePath(path) ? copyFile(nil, error)
            : [self withDirectory:source.stringByDeletingLastPathComponent progress:progress operation:copyFile error:error];
    } @finally { close(destinationParent); }
    return ok ? @{@"bytes": @(bytes)} : nil;
}

+ (NSDictionary *)importPath:(NSString *)source to:(NSString *)destination progress:(NSProgress *)progress error:(NSError **)error {
    NSString *targetLeaf = nil;
    int parent = CCBQWorkspaceParent(destination, &targetLeaf, error);
    if (parent < 0) return nil;
    NSString *temporary = [CCBQPartPrefix stringByAppendingString:NSUUID.UUID.UUIDString];
    BOOL created = NO, published = NO;
    uint64_t bytes = 0;
    NSString *warning = nil;
    @try {
        NSString *sourceLeaf = nil;
        int sourceParent = CCBQTemporaryParent(source, &sourceLeaf, error);
        if (sourceParent < 0) return nil;
        int input = openat(sourceParent, sourceLeaf.fileSystemRepresentation, O_RDONLY | O_NOFOLLOW | O_NONBLOCK | O_CLOEXEC);
        int code = errno;
        close(sourceParent);
        if (input < 0) { if (error) *error = CCBQPOSIX(code, NO); return nil; }
        int output = openat(parent, temporary.fileSystemRepresentation, O_WRONLY | O_CREAT | O_EXCL | O_NOFOLLOW | O_CLOEXEC, 0600);
        if (output < 0) { code = errno; close(input); if (error) *error = CCBQPOSIX(code, NO); return nil; }
        created = YES;
        BOOL copied = NO;
        @try { copied = CCBQCopyBytes(input, output, progress, &bytes, error); }
        @finally {
            close(input);
            if (close(output) != 0 && copied) { copied = NO; if (error) *error = CCBQPOSIX(errno, NO); }
        }
        if (!copied) return nil;
        if (CCBQCancelled(progress, error)) return nil;


        if (linkat(parent, temporary.fileSystemRepresentation, parent, targetLeaf.fileSystemRepresentation, 0) != 0) {
            if (error) *error = CCBQPOSIX(errno, NO);
            return nil;
        }
        published = YES;
        if (unlinkat(parent, temporary.fileSystemRepresentation, 0) == 0) created = NO;
        else warning = @"Đã nhập tệp, nhưng chưa dọn được một tệp tạm trong Tệp PhamQuang IOS.";
    } @finally {
        if (created && !published && unlinkat(parent, temporary.fileSystemRepresentation, 0) != 0 && error) {
            *error = CCBQError(EIO, @"Nhập tệp chưa hoàn tất và chưa dọn được tệp tạm trong Tệp PhamQuang IOS.", NO);
        }
        close(parent);
    }
    NSMutableDictionary *receipt = [@{@"bytes": @(bytes)} mutableCopy];
    if (warning) receipt[@"warning"] = warning;
    return receipt;
}

+ (NSDictionary *)detailsPath:(NSString *)path progress:(NSProgress *)progress error:(NSError **)error {
    __block NSDictionary *result = nil;
    BOOL (^inspect)(NSString *, NSError **) = ^BOOL(NSString *accessible, NSError **failure) {
        NSString *leaf = path.lastPathComponent;
        int parent = CCBQWorkspacePath(path) ? ([path isEqual:@"/CC365"] ? CCBQOpenDirectory(BQDocuments()) : CCBQWorkspaceParent(path, &leaf, failure))
            : open(accessible.fileSystemRepresentation, O_RDONLY | O_DIRECTORY | O_CLOEXEC);
        if (parent < 0) { if (failure) *failure = CCBQPOSIX(errno, YES); return NO; }
        struct stat st;
        int status = [path isEqual:@"/CC365"] ? fstat(parent, &st) : fstatat(parent, leaf.fileSystemRepresentation, &st, AT_SYMLINK_NOFOLLOW);
        int code = errno; close(parent);
        if (status) { if (failure) *failure = CCBQPOSIX(code, YES); return NO; }
        result = @{@"name": leaf, @"path": path,
            @"kind": S_ISDIR(st.st_mode) ? @"directory" : S_ISREG(st.st_mode) ? @"file" : S_ISLNK(st.st_mode) ? @"symlink" : @"other",
            @"size": @((uint64_t)MAX(st.st_size, 0)), @"modified": @((int64_t)st.st_mtimespec.tv_sec),
            @"created": @((int64_t)st.st_birthtimespec.tv_sec), @"permissions": [NSString stringWithFormat:@"%04o", st.st_mode & 07777],
            @"owner": @(st.st_uid), @"group": @(st.st_gid), @"inode": @((uint64_t)st.st_ino)};
        return YES;
    };
    BOOL ok = CCBQWorkspacePath(path) ? inspect(nil, error)
        : [self withDirectory:path.stringByDeletingLastPathComponent progress:progress operation:inspect error:error];
    return ok ? result : nil;
}

+ (NSDictionary *)movePath:(NSString *)source to:(NSString *)destination progress:(NSProgress *)progress error:(NSError **)error {
    if ([destination isEqual:source] || [destination hasPrefix:[source stringByAppendingString:@"/"]]) {
        if (error) *error = CCBQError(EINVAL, @"Không thể chuyển mục vào chính nó hoặc thư mục con của nó.", NO); return nil;
    }
    NSString *fromLeaf = nil, *toLeaf = nil;
    int from = CCBQWorkspaceParent(source, &fromLeaf, error);
    if (from < 0) return nil;
    int to = CCBQWorkspaceParent(destination, &toLeaf, error);
    if (to < 0) { close(from); return nil; }
    @try {
        if (CCBQCancelled(progress, error)) return nil;
        struct stat st;
        if (fstatat(from, fromLeaf.fileSystemRepresentation, &st, AT_SYMLINK_NOFOLLOW)) { if (error) *error = CCBQPOSIX(errno, NO); return nil; }
        if (!S_ISREG(st.st_mode) && !S_ISDIR(st.st_mode)) { if (error) *error = CCBQError(EINVAL, @"Chỉ đổi tên hoặc di chuyển tệp thường và thư mục.", NO); return nil; }
        if (renameatx_np(from, fromLeaf.fileSystemRepresentation, to, toLeaf.fileSystemRepresentation, RENAME_EXCL)) {
            if (error) *error = CCBQPOSIX(errno, NO); return nil;
        }
        return @{@"bytes": @0};
    } @finally { close(from); close(to); }
}

+ (NSDictionary *)importTree:(NSString *)source to:(NSString *)destination progress:(NSProgress *)progress error:(NSError **)error {
    NSString *sourceLeaf = nil, *targetLeaf = nil;
    int sourceParent = CCBQTemporaryParent(source, &sourceLeaf, error);
    if (sourceParent < 0) return nil;
    int input = openat(sourceParent, sourceLeaf.fileSystemRepresentation, O_RDONLY | O_DIRECTORY | O_NOFOLLOW | O_CLOEXEC);
    int code = errno; close(sourceParent);
    if (input < 0) { if (error) *error = CCBQPOSIX(code, NO); return nil; }
    int parent = CCBQWorkspaceParent(destination, &targetLeaf, error);
    if (parent < 0) { close(input); return nil; }
    NSString *temporary = [CCBQPartPrefix stringByAppendingString:NSUUID.UUID.UUIDString];
    BOOL created = NO, published = NO;
    struct stat ownedRoot = {0};
    BOOL identified = NO;
    @try {
        if (CCBQCancelled(progress, error)) return nil;
        struct stat existing;
        if (!fstatat(parent, targetLeaf.fileSystemRepresentation, &existing, AT_SYMLINK_NOFOLLOW)) { if (error) *error = CCBQPOSIX(EEXIST, NO); return nil; }
        if (errno != ENOENT) { if (error) *error = CCBQPOSIX(errno, NO); return nil; }
        if (mkdirat(parent, temporary.fileSystemRepresentation, 0700)) { if (error) *error = CCBQPOSIX(errno, NO); return nil; }
        created = YES;
        int output = openat(parent, temporary.fileSystemRepresentation, O_RDONLY | O_DIRECTORY | O_NOFOLLOW | O_CLOEXEC);
        if (output < 0) { if (error) *error = CCBQPOSIX(errno, NO); return nil; }
        identified = fstat(output, &ownedRoot) == 0;
        if (!identified) { close(output); if (error) *error = CCBQPOSIX(errno, NO); return nil; }
        NSUInteger nodes = 0, files = 0; uint64_t bytes = 0;
        BOOL copied = CCBQCopyTree(input, output, 0, &nodes, &files, &bytes, progress, error);
        close(output);
        if (!copied || CCBQCancelled(progress, error)) return nil;
        if (!CCBQNamedIdentity(parent, temporary, ownedRoot)) { if (error) *error = CCBQError(EBUSY, @"Thư mục tạm đã thay đổi; chưa công bố đích.", NO); return nil; }
        if (renameatx_np(parent, temporary.fileSystemRepresentation, parent, targetLeaf.fileSystemRepresentation, RENAME_EXCL)) {
            if (error) *error = CCBQPOSIX(errno, NO); return nil;
        }
        published = YES;
        return @{@"bytes": @(bytes)};
    } @finally {
        if (created && !published && (!identified || !CCBQNamedIdentity(parent, temporary, ownedRoot) || !CCBQRemoveOwnedTree(parent, temporary.fileSystemRepresentation, 0)) && error)
            *error = CCBQError(EIO, @"Chưa công bố thư mục và chưa dọn được bản sao tạm. Tệp đích cũ được giữ nguyên.", NO);
        close(input); close(parent);
    }
}

+ (NSDictionary *)replacePath:(NSString *)path source:(NSString *)source expected:(NSString *)expected progress:(NSProgress *)progress error:(NSError **)error {
    NSString *leaf = nil, *sourceLeaf = nil, *expectedLeaf = nil;
    int parent = CCBQWorkspaceParent(path, &leaf, error);
    if (parent < 0) return nil;
    int sourceParent = CCBQTemporaryParent(source, &sourceLeaf, error);
    int expectedParent = sourceParent >= 0 ? CCBQTemporaryParent(expected, &expectedLeaf, error) : -1;
    int input = -1, old = -1, reference = -1;
    NSString *temporary = [CCBQPartPrefix stringByAppendingString:NSUUID.UUID.UUIDString];
    BOOL created = NO, retainRecovery = NO;
    struct stat temporaryIdentity = {0};
    BOOL temporaryIdentified = NO;
    @try {
        if (sourceParent < 0 || expectedParent < 0) return nil;
        input = openat(sourceParent, sourceLeaf.fileSystemRepresentation, O_RDONLY | O_NOFOLLOW | O_NONBLOCK | O_CLOEXEC);
        reference = openat(expectedParent, expectedLeaf.fileSystemRepresentation, O_RDONLY | O_NOFOLLOW | O_NONBLOCK | O_CLOEXEC);
        old = openat(parent, leaf.fileSystemRepresentation, O_RDONLY | O_NOFOLLOW | O_NONBLOCK | O_CLOEXEC);
        if (input < 0 || reference < 0 || old < 0) { if (error) *error = CCBQPOSIX(errno, NO); return nil; }
        if (!CCBQEqualFiles(old, reference, error) || CCBQCancelled(progress, error)) return nil;
        int output = openat(parent, temporary.fileSystemRepresentation, O_WRONLY | O_CREAT | O_EXCL | O_NOFOLLOW | O_CLOEXEC, 0600);
        if (output < 0) { if (error) *error = CCBQPOSIX(errno, NO); return nil; }
        created = YES;
        temporaryIdentified = fstat(output, &temporaryIdentity) == 0;
        if (!temporaryIdentified) { close(output); if (error) *error = CCBQPOSIX(errno, NO); return nil; }
        uint64_t bytes = 0;
        BOOL copied = CCBQCopyBytes(input, output, progress, &bytes, error);
        struct stat replacement; BOOL identified = fstat(output, &replacement) == 0;
        close(output);
        if (!copied || !identified || CCBQCancelled(progress, error)) return nil;
        if (!CCBQNamedIdentity(parent, temporary, replacement)) { if (error) *error = CCBQError(EBUSY, @"Tệp tạm đã thay đổi; chưa ghi đè tệp gốc.", NO); return nil; }
        struct stat original, named;
        if (fstat(old, &original) || fstatat(parent, leaf.fileSystemRepresentation, &named, AT_SYMLINK_NOFOLLOW) ||
            !CCBQSameStat(original, named) || !CCBQEqualFiles(old, reference, error)) {
            if (error && !*error) *error = CCBQError(EBUSY, @"Tệp gốc đã thay đổi. Hãy mở lại trước khi lưu.", NO); return nil;
        }
        if (renameatx_np(parent, temporary.fileSystemRepresentation, parent, leaf.fileSystemRepresentation, RENAME_SWAP)) {
            if (error) *error = CCBQPOSIX(errno, NO); return nil;
        }


        struct stat displaced;
        BOOL foundDisplaced = !fstatat(parent, temporary.fileSystemRepresentation, &displaced, AT_SYMLINK_NOFOLLOW);
        temporaryIdentity = original;
        BOOL intact = foundDisplaced && CCBQNamedIdentity(parent, leaf, replacement) &&
            displaced.st_dev == original.st_dev && displaced.st_ino == original.st_ino && CCBQEqualFiles(old, reference, error);
        if (!intact) {
            int current = openat(parent, leaf.fileSystemRepresentation, O_RDONLY | O_NOFOLLOW | O_NONBLOCK | O_CLOEXEC);
            BOOL ours = current >= 0 && CCBQNamedIdentity(parent, leaf, replacement) && CCBQEqualFiles(current, input, nil);
            if (current >= 0) close(current);
            if (!ours || !temporaryIdentified || !CCBQNamedIdentity(parent, temporary, temporaryIdentity) ||
                renameatx_np(parent, temporary.fileSystemRepresentation, parent, leaf.fileSystemRepresentation, RENAME_SWAP)) retainRecovery = YES;
            else temporaryIdentity = replacement;
            NSString *recoveryPath = retainRecovery && temporaryIdentified ? CCBQRecoverFile(parent, temporary, path, temporaryIdentity) : nil;
            if (error) *error = CCBQError(EBUSY, retainRecovery ? [NSString stringWithFormat:@"Tệp thay đổi khi lưu. Chưa hoàn tất khôi phục; kiểm tra %@ trước khi thử tiếp.", recoveryPath ?: path] : @"Tệp thay đổi khi lưu. Đã giữ nguyên bản gốc; hãy mở lại.", NO);
            return nil;
        }
        return @{@"bytes": @(bytes)};
    } @finally {
        if (created && !retainRecovery && (!temporaryIdentified || !CCBQNamedIdentity(parent, temporary, temporaryIdentity) || unlinkat(parent, temporary.fileSystemRepresentation, 0)) && error)
            *error = CCBQError(EIO, @"Thao tác đã kết thúc nhưng chưa dọn được bản tạm. Hãy tải lại tệp trước khi thử tiếp.", NO);
        if (input >= 0) close(input); if (reference >= 0) close(reference); if (old >= 0) close(old);
        if (sourceParent >= 0) close(sourceParent); if (expectedParent >= 0) close(expectedParent); close(parent);
    }
}

+ (NSDictionary *)checkWithProgress:(NSProgress *)progress error:(NSError **)error {
    int directory = CCBQOpenDirectory(BQDocuments());
    if (directory < 0) { if (error) *error = CCBQPOSIX(errno, NO); return nil; }
    NSString *leaf = [CCBQPartPrefix stringByAppendingFormat:@"check-%@", NSUUID.UUID.UUIDString];
    BOOL created = NO, exact = NO, cleaned = YES;
    @try {
        int fd = openat(directory, leaf.fileSystemRepresentation, O_RDWR | O_CREAT | O_EXCL | O_NOFOLLOW | O_CLOEXEC, 0600);
        if (fd < 0) { if (error) *error = CCBQPOSIX(errno, NO); return nil; }
        created = YES;
        const char sample[] = "cc365_File local file access check";
        char received[sizeof(sample)] = {0};
        exact = write(fd, sample, sizeof(sample)) == sizeof(sample) && fsync(fd) == 0 && lseek(fd, 0, SEEK_SET) == 0 &&
            read(fd, received, sizeof(received)) == sizeof(received) && memcmp(sample, received, sizeof(sample)) == 0;
        if (close(fd) != 0) exact = NO;
    } @finally {
        if (created) cleaned = unlinkat(directory, leaf.fileSystemRepresentation, 0) == 0;
        close(directory);
    }
    if (CCBQCancelled(progress, error)) return nil;
    NSString *notice = nil;
    NSArray *catalog = BQDiscoverContainers(^BOOL { return progress.cancelled; }, &notice);
    if (CCBQCancelled(progress, error)) return nil;
    NSString *message = [NSString stringWithFormat:@"%@ %@ Tìm thấy %lu container; quyền mở từng container được kiểm tra khi bạn chọn thư mục.",
        exact ? @"Đọc và ghi thử trong Tệp PhamQuang IOS thành công." : @"Chưa xác nhận được đọc và ghi trong Tệp PhamQuang IOS.",
        cleaned ? @"Đã dọn tệp thử." : @"Chưa dọn được tệp thử.", (unsigned long)catalog.count];
    return @{@"exactBytesRecovered": @(exact), @"cleanupComplete": @(cleaned), @"recoveryOnly": @NO,
        @"booksRestored": NSNull.null, @"message": message};
}

+ (NSDictionary *)request:(NSDictionary *)request progress:(NSProgress *)progress error:(NSError **)error {
    if (CCBQCancelled(progress, error)) return nil;
    NSString *action = [request[@"action"] isKindOfClass:NSString.class] ? request[@"action"] : nil;
    if ([action isEqualToString:@"ensureWorkspace"]) {
        if (mkdir(BQDocuments().fileSystemRepresentation, 0700) != 0 && errno != EEXIST) { if (error) *error = CCBQPOSIX(errno, NO); return nil; }
        int fd = CCBQOpenDirectory(BQDocuments());
        if (fd < 0) { if (error) *error = CCBQPOSIX(errno, NO); return nil; }
        close(fd); return @{@"bytes": @0};
    }
    if ([action isEqualToString:@"check"]) return [self checkWithProgress:progress error:error];
    NSUInteger offset = 0;
    if (request[@"offset"]) {
        if (![request[@"offset"] isKindOfClass:NSNumber.class] || [request[@"offset"] longLongValue] < 0) {
            if (error) *error = CCBQError(EINVAL, @"Vị trí trang không hợp lệ.", NO); return nil;
        }
        offset = [request[@"offset"] unsignedIntegerValue];
    }
    if ([action isEqualToString:@"catalog"]) return [self catalogAtOffset:offset includeMedia:NO progress:progress error:error];
    NSString *path = nil;
    if (([action isEqualToString:@"mkdir"] || [action isEqualToString:@"import"]) && !request[@"path"]) {
        NSString *parent = CCBQPath(request[@"parent"]);
        NSString *name = request[@"name"];
        if (parent && CCBQName(name)) path = CCBQPath([parent stringByAppendingPathComponent:name]);
        if (!path && error) *error = CCBQError(EINVAL, @"Tên hoặc thư mục đích không hợp lệ.", NO);
    } else path = CCBQRequestPath(request, error);
    if (!path) return nil;
    if ([action isEqualToString:@"list"]) {
        if ((request[@"query"] && (![request[@"query"] isKindOfClass:NSString.class] || [request[@"query"] length] > 256)) ||
            (request[@"sort"] && ![@[@"name", @"size", @"modified", @"created"] containsObject:request[@"sort"]])) {
            if (error) *error = CCBQError(EINVAL, @"Tùy chọn danh sách không hợp lệ.", NO); return nil;
        }
        for (NSString *key in @[@"show_hidden", @"ascending", @"folders_first"]) {
            if (request[key] && ![request[key] isKindOfClass:NSNumber.class]) { if (error) *error = CCBQPOSIX(EINVAL, NO); return nil; }
        }
        return [self listPath:path offset:offset options:request progress:progress error:error];
    }
    if ([action isEqual:@"details"]) return [self detailsPath:path progress:progress error:error];
    if ([action isEqual:@"move"]) {
        NSString *destination = CCBQPath(request[@"destination"]);
        if (!destination) { if (error) *error = CCBQPOSIX(EINVAL, NO); return nil; }
        return [self movePath:path to:destination progress:progress error:error];
    }
    if ([action isEqualToString:@"download"] || [action isEqualToString:@"import"] ||
        [action isEqual:@"importTree"] || [action isEqual:@"replace"]) {
        NSString *local = CCBQPath(request[@"local_path"]);
        if (!local) { if (error) *error = CCBQError(EINVAL, @"Tệp tạm không hợp lệ.", NO); return nil; }
        if ([action isEqual:@"importTree"]) return [self importTree:local to:path progress:progress error:error];
        if ([action isEqual:@"replace"]) {
            NSString *expected = CCBQPath(request[@"expected_path"]);
            if (!expected) { if (error) *error = CCBQPOSIX(EINVAL, NO); return nil; }
            return [self replacePath:path source:local expected:expected progress:progress error:error];
        }
        return [action isEqualToString:@"download"] ? [self downloadPath:path to:local progress:progress error:error]
            : [self importPath:local to:path progress:progress error:error];
    }
    if ([action isEqualToString:@"mkdir"] || [action isEqualToString:@"delete"]) {
        NSString *leaf = nil;
        int parent = CCBQWorkspaceParent(path, &leaf, error);
        if (parent < 0) return nil;
        @try {
            if (CCBQCancelled(progress, error)) return nil;
            if ([action isEqualToString:@"mkdir"]) {
                if (mkdirat(parent, leaf.fileSystemRepresentation, 0700) != 0) { if (error) *error = CCBQPOSIX(errno, NO); return nil; }
            } else {
                struct stat st;
                if (fstatat(parent, leaf.fileSystemRepresentation, &st, AT_SYMLINK_NOFOLLOW) != 0) { if (error) *error = CCBQPOSIX(errno, NO); return nil; }
                if (!S_ISREG(st.st_mode) && !S_ISDIR(st.st_mode)) { if (error) *error = CCBQError(EINVAL, @"Chỉ có thể xóa tệp thường hoặc thư mục trống.", NO); return nil; }
                if (unlinkat(parent, leaf.fileSystemRepresentation, S_ISDIR(st.st_mode) ? AT_REMOVEDIR : 0) != 0) { if (error) *error = CCBQPOSIX(errno, NO); return nil; }
            }
            return @{@"bytes": @0};
        } @finally { close(parent); }
    }
    if (error) *error = CCBQError(EINVAL, @"Thao tác tệp không được hỗ trợ.", NO);
    return nil;
}

+ (void)performRequest:(NSDictionary *)request progress:(NSProgress *)progress
            completion:(void (^)(NSDictionary *, NSError *))completion {
    NSDictionary *snapshot = [request copy];
    dispatch_async(BQWorkQueue(), ^{
        @autoreleasepool {
            NSError *error = nil;
            NSDictionary *result = nil;
            @try { result = [self request:snapshot progress:progress error:&error]; }
            @catch (__unused NSException *exception) { error = CCBQError(EIO, @"Không hoàn tất được thao tác tệp trên bản iOS này.", NO); }
            if (!result && !error) error = CCBQError(EIO, @"Không nhận được kết quả thao tác tệp.", NO);
            dispatch_async(dispatch_get_main_queue(), ^{ completion(result, error); });
        }
    });
}
@end
