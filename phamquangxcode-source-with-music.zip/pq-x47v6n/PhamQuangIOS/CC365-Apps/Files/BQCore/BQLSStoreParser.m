#import "BQLSStoreParser.h"
#import <stdint.h>
#import <stdlib.h>
#import <string.h>





enum { BQLSMaximumID = 0x1000000, BQLSMaximumRecords = 100000,
       BQLSMaximumStrings = 200000, BQLSMaximumDecodedBytes = 8 * 1024 * 1024 };
static const NSUInteger BQLSMaximumBytes = 64 * 1024 * 1024;

typedef struct {
    uint32_t owners[2];
    uint32_t path;
    uint32_t name;
    uint32_t display;
    uint32_t plugin;
} BQLSRecord;

static uint32_t BQLSWord(const uint8_t *bytes) {
    return (uint32_t)bytes[0] | (uint32_t)bytes[1] << 8 |
        (uint32_t)bytes[2] << 16 | (uint32_t)bytes[3] << 24;
}
static uint32_t BQLSReference(const uint8_t *bytes) {
    uint32_t reference = BQLSWord(bytes);
    return reference && !(reference & 3) && (reference >> 2) < BQLSMaximumID ? reference >> 2 : 0;
}
static BOOL BQLSStopped(BOOL (^cancelled)(void), NSString **notice) {
    if (cancelled && cancelled()) {
        if (notice) *notice = @"Đã dừng đọc tên ứng dụng từ cơ sở dữ liệu hệ thống.";
        return YES;
    }
    return NO;
}
static NSArray *BQLSReject(NSString **notice, NSString *message) {
    if (notice) *notice = message;
    return nil;
}
static BOOL BQLSBundle(NSString *value) {
    if (![value isKindOfClass:NSString.class] || !value.length || value.length > 255) return NO;
    static NSCharacterSet *invalid;
    static dispatch_once_t once;
    dispatch_once(&once, ^{ invalid = [[NSCharacterSet characterSetWithCharactersInString:
        @"abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789._-"] invertedSet]; });
    NSArray *components = [value componentsSeparatedByString:@"."];
    return components.count >= 2 && ![components containsObject:@""] &&
        [value rangeOfCharacterFromSet:invalid].location == NSNotFound;
}
static NSString *BQLSDataPath(NSString *value) {
    if (![value isKindOfClass:NSString.class]) return nil;
    if ([value hasPrefix:@"/private/var/"]) value = [value substringFromIndex:8];
    if ([value hasSuffix:@"/"]) value = [value substringToIndex:value.length - 1];
    NSArray *parts = [value componentsSeparatedByString:@"/"];
    if (parts.count != 7 || ![parts[0] isEqual:@""] || ![parts[1] isEqual:@"var"] ||
        ![parts[2] isEqual:@"mobile"] || ![parts[3] isEqual:@"Containers"] || ![parts[4] isEqual:@"Data"] ||
        ![@[@"Application", @"PluginKitPlugin"] containsObject:parts[5]] || [parts[6] length] != 36) return nil;
    NSUUID *uuid = [[NSUUID alloc] initWithUUIDString:parts[6]];
    return uuid ? [NSString stringWithFormat:@"/var/mobile/Containers/Data/%@/%@", parts[5], uuid.UUIDString] : nil;
}
static NSString *BQLSName(id raw) {
    if (![raw isKindOfClass:NSString.class] || ![raw length] || [raw length] > 512 || [raw hasPrefix:@"/"]) return nil;
    NSMutableString *safe = [NSMutableString string];
    NSCharacterSet *controls = NSCharacterSet.controlCharacterSet;
    for (NSUInteger i = 0; i < [raw length]; i++) {
        unichar c = [raw characterAtIndex:i];
        BOOL format = c == 0x00ad || c == 0x061c || c == 0x180e ||
            (c >= 0x200b && c <= 0x200f) || (c >= 0x2028 && c <= 0x202e) ||
            (c >= 0x2060 && c <= 0x206f) || c == 0xfeff;
        [safe appendFormat:@"%C", (unichar)((format || [controls characterIsMember:c]) ? 0xfffd : c)];
    }
    NSString *name = [[safe precomposedStringWithCanonicalMapping] stringByTrimmingCharactersInSet:NSCharacterSet.whitespaceAndNewlineCharacterSet];
    return name.length ? name : nil;
}

NSArray<NSDictionary *> *BQParseLSStore(NSData *data, BOOL (^cancelled)(void), NSString **notice) {
    if (notice) *notice = nil;
    if (BQLSStopped(cancelled, notice)) return nil;
    if (![data isKindOfClass:NSData.class] || data.length < 4096 || data.length > BQLSMaximumBytes ||
        memcmp(data.bytes, "bdsl", 4))
        return BQLSReject(notice, @"Cơ sở dữ liệu tên ứng dụng không hợp lệ hoặc vượt 64 MiB.");

    const uint8_t *bytes = data.bytes;
    NSUInteger length = data.length;
    uint8_t *wanted = calloc(BQLSMaximumID / 8, 1);
    if (!wanted) return BQLSReject(notice, @"Chưa đủ bộ nhớ để đọc tên ứng dụng.");
    @try {
        NSMutableData *packed = [NSMutableData data];

        for (NSUInteger offset = 0; offset <= length - 8; offset += 4) {
            if (!(offset & 0x3fff) && BQLSStopped(cancelled, notice)) return nil;
            uint32_t size = BQLSWord(bytes + offset + 4);
            if (size != 0x250 && size != 0x23c && size != 0x25c && size != 0x118 && size != 0x104 && size != 0x120) continue;
            if (size > length - offset - 8) continue;
            const uint8_t *body = bytes + offset + 8;
            BQLSRecord record = {0};
            BOOL modern = size == 0x25c || size == 0x120;
            record.plugin = size == 0x118 || size == 0x104 || size == 0x120;
            if (record.plugin) {
                record.owners[0] = BQLSReference(body);
                if (modern) record.owners[1] = BQLSReference(body + 4);
                record.path = BQLSReference(body + (size == 0x104 ? 0x50 : modern ? 0x58 : 0x54));
            } else {
                record.owners[0] = BQLSReference(body + 0x0c);
                if (modern) record.owners[1] = BQLSReference(body + 0x10);
                NSUInteger base = size == 0x23c ? 0x64 : modern ? 0x6c : 0x68;
                record.path = BQLSReference(body + base);
                record.name = BQLSReference(body + base + 4);
                record.display = BQLSReference(body + base + 12);
            }
            if (!record.path || (!record.owners[0] && !record.owners[1])) continue;
            if (packed.length / sizeof(record) >= BQLSMaximumRecords)
                return BQLSReject(notice, @"Cơ sở dữ liệu có quá nhiều bản ghi ứng dụng.");
            [packed appendBytes:&record length:sizeof(record)];
            uint32_t refs[] = {record.owners[0], record.owners[1], record.path, record.name, record.display};
            for (NSUInteger i = 0; i < 5; i++) if (refs[i]) wanted[refs[i] / 8] |= 1 << (refs[i] % 8);
        }
        if (!packed.length) return BQLSReject(notice, @"Chưa nhận diện được cấu trúc bản ghi ứng dụng trên bản iOS này.");

        NSRange heap = [data rangeOfData:[@"<string>" dataUsingEncoding:NSUTF8StringEncoding] options:0 range:NSMakeRange(0, length)];
        NSMutableDictionary<NSNumber *, id> *general = [NSMutableDictionary dictionary];
        NSMutableDictionary<NSNumber *, id> *paths = [NSMutableDictionary dictionary];
        NSMutableSet<NSNumber *> *preferred = [NSMutableSet set];
        NSUInteger decoded = 0, decodedBytes = 0;


        for (NSUInteger offset = 0; offset <= length - 8; offset += 4) {
            if (!(offset & 0x3fff) && BQLSStopped(cancelled, notice)) return nil;
            uint32_t identifier = BQLSWord(bytes + offset);
            if (!identifier || identifier >= BQLSMaximumID || !(wanted[identifier / 8] & (1 << (identifier % 8)))) continue;
            uint32_t count = BQLSWord(bytes + offset + 4);
            NSUInteger padding = (4 - (count % 4)) % 4;
            if (!count || count >= 2048 || count > length - offset - 8 || padding > length - offset - 8 - count) continue;
            const uint8_t *text = bytes + offset + 8;
            if (memchr(text, 0, count)) continue;
            BOOL terminated = YES;
            for (NSUInteger i = 0; i < padding; i++) if (text[count + i]) terminated = NO;
            if (!terminated) continue;
            NSString *value = [[NSString alloc] initWithBytes:text length:count encoding:NSUTF8StringEncoding];
            if (!value) continue;
            if (++decoded > BQLSMaximumStrings || count > BQLSMaximumDecodedBytes - decodedBytes)
                return BQLSReject(notice, @"Cơ sở dữ liệu vượt giới hạn chuỗi tên ứng dụng.");
            decodedBytes += count;
            NSNumber *key = @(identifier);
            NSString *path = BQLSDataPath(value);
            if ([value hasPrefix:@"/"]) {




                BOOL dataNamespace = [value rangeOfString:@"/Containers/Data/" options:NSCaseInsensitiveSearch].location != NSNotFound;
                if (dataNamespace) {
                    id old = paths[key];
                    if (!path) paths[key] = NSNull.null;
                    else if (!old) paths[key] = path;
                    else if (![old isEqual:path]) paths[key] = NSNull.null;
                }
                continue;
            }
            BOOL inHeap = heap.location != NSNotFound && offset > heap.location;
            id old = general[key];
            if (!old || (inHeap && ![preferred containsObject:key])) general[key] = value;
            else if (inHeap == [preferred containsObject:key] && ![old isEqual:value]) general[key] = NSNull.null;
            if (inHeap) [preferred addObject:key];
        }

        NSMutableDictionary<NSString *, id> *owners = [NSMutableDictionary dictionary];
        NSMutableDictionary<NSString *, id> *names = [NSMutableDictionary dictionary];
        NSMutableSet<NSString *> *ambiguous = [NSMutableSet set];
        const BQLSRecord *records = packed.bytes;
        for (NSUInteger i = 0; i < packed.length / sizeof(BQLSRecord); i++) {
            if (!(i & 255) && BQLSStopped(cancelled, notice)) return nil;
            BQLSRecord record = records[i];
            id path = paths[@(record.path)];
            if (![path isKindOfClass:NSString.class]) continue;
            BOOL plugin = [path containsString:@"/Data/PluginKitPlugin/"];
            if (plugin != (BOOL)record.plugin) continue;


            if (general[@(record.owners[0])] == NSNull.null || general[@(record.owners[1])] == NSNull.null) {
                owners[path] = NSNull.null;
                [ambiguous addObject:path];
                continue;
            }
            NSString *name = BQLSName(general[@(record.display)]) ?: BQLSName(general[@(record.name)]);
            for (NSUInteger alternative = 0; alternative < 2; alternative++) {
                id owner = general[@(record.owners[alternative])];
                if (!BQLSBundle(owner)) continue;
                id previous = owners[path];
                if (!previous) owners[path] = owner;
                else if (![previous isEqual:owner]) { owners[path] = NSNull.null; [ambiguous addObject:path]; }
                if (name) {
                    id oldName = names[path];
                    if (!oldName) names[path] = name;
                    else if (![oldName isEqual:name]) names[path] = NSNull.null;
                }
            }
        }
        NSMutableArray<NSDictionary *> *result = [NSMutableArray array];
        for (NSString *path in [owners.allKeys sortedArrayUsingSelector:@selector(compare:)]) {
            id owner = owners[path];
            if (![owner isKindOfClass:NSString.class]) continue;
            NSString *name = [names[path] isKindOfClass:NSString.class] ? names[path] : owner;
            [result addObject:@{@"path":path, @"kind":[path containsString:@"/Data/PluginKitPlugin/"] ? @"plugin" : @"app",
                               @"identifier":owner, @"name":name, @"source":@"csstore"}];
        }
        if (BQLSStopped(cancelled, notice)) return nil;
        if (notice && ambiguous.count) *notice = [NSString stringWithFormat:@"Đã bỏ qua %lu container có định danh mâu thuẫn trong cơ sở dữ liệu.", (unsigned long)ambiguous.count];
        else if (notice && !result.count) *notice = @"Cơ sở dữ liệu chưa cung cấp ánh xạ container rõ ràng; không suy đoán tên từ UUID.";
        return [result copy];
    } @finally { free(wanted); }
}
