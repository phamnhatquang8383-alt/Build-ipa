#pragma once
#import <Foundation/Foundation.h>
NS_ASSUME_NONNULL_BEGIN
FOUNDATION_EXPORT NSString *const CCBQResolveErrorDomain;
typedef NS_ENUM(NSInteger, CCBQResolveError) {
    CCBQResolveUnavailable = 1,
    CCBQResolveConflict = 2,
};



NSDictionary * _Nullable BQResolveApplicationTarget(NSString *bundleID,
    BOOL (^ _Nullable cancelled)(void), NSError * _Nullable * _Nullable error);
NS_ASSUME_NONNULL_END
