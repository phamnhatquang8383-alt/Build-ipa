#import "BQAppTargetResolver.h"
#ifndef BQ_RESOLVER_TESTING
#import "BQCore.h"
#else
extern NSString *BQLookupApplicationDataPath(NSString *bundleID);
#endif
#import <dlfcn.h>
#import <objc/message.h>
#import <sys/stat.h>
#import <errno.h>

NSString *const CCBQResolveErrorDomain = @"CC365.BQResolve";
static NSString *const BQTargetUnavailable = @"iOS chưa cung cấp container của ứng dụng trong gói patch. Không thể xác định đích an toàn bằng bundle ID này.";
static BOOL BQTargetFail(NSError **error, NSString *message) {
    if (error) *error = [NSError errorWithDomain:CCBQResolveErrorDomain code:CCBQResolveUnavailable userInfo:@{NSLocalizedDescriptionKey:message}];
    return NO;
}
static BOOL BQTargetConflict(NSError **error, NSString *message) {
    if (error) *error = [NSError errorWithDomain:CCBQResolveErrorDomain code:CCBQResolveConflict userInfo:@{NSLocalizedDescriptionKey:message}];
    return NO;
}
static BOOL BQTargetCancelled(BOOL (^cancelled)(void), NSError **error) {
    if (!cancelled || !cancelled()) return NO;
    if (error) *error = [NSError errorWithDomain:NSCocoaErrorDomain code:NSUserCancelledError userInfo:@{NSLocalizedDescriptionKey:@"Đã dừng tìm ứng dụng."}];
    return YES;
}
static BOOL BQTargetBundle(NSString *bundle) {
    if (![bundle isKindOfClass:NSString.class] || !bundle.length || bundle.length > 255) return NO;
    NSCharacterSet *allowed = [NSCharacterSet characterSetWithCharactersInString:@"ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789.-_"];
    if ([bundle rangeOfCharacterFromSet:allowed.invertedSet].location != NSNotFound) return NO;
    for (NSString *part in [bundle componentsSeparatedByString:@"."]) if (!part.length) return NO;
    return YES;
}
static NSString *BQTargetPath(id value) {
    if (![value isKindOfClass:NSString.class] || ![value isAbsolutePath] || [value length] > 4096 ||
        [value rangeOfCharacterFromSet:NSCharacterSet.controlCharacterSet].location != NSNotFound || [[value pathComponents] containsObject:@".."]) return nil;
    NSString *path = [value stringByStandardizingPath];
    return [path hasPrefix:@"/private/var/"] ? [path substringFromIndex:8] : path;
}
static NSString *BQTargetDataRoot(id value) {
    NSString *path = BQTargetPath(value);
    if (![path.stringByDeletingLastPathComponent isEqual:@"/var/mobile/Containers/Data/Application"] || ![[NSUUID alloc] initWithUUIDString:path.lastPathComponent]) return nil;
    return path;
}
static BOOL BQTargetDirectory(NSString *path) {
    struct stat st;
    if (lstat(path.fileSystemRepresentation, &st) == 0) return S_ISDIR(st.st_mode);


    return errno == EACCES || errno == EPERM;
}
static id BQTargetGetter(id object, NSString *name) {
    if (!object) return nil;
    @try {
        SEL selector = NSSelectorFromString(name);
        if (![object respondsToSelector:selector]) return nil;
        NSMethodSignature *sig = [object methodSignatureForSelector:selector];
        if (!sig || sig.numberOfArguments != 2 || sig.methodReturnType[0] != '@') return nil;
        return ((id (*)(id, SEL))objc_msgSend)(object, selector);
    } @catch (__unused NSException *exception) { return nil; }
}
static NSString *BQTargetURL(id value) {
    return [value isKindOfClass:NSURL.class] && [value isFileURL] ? BQTargetPath([value path]) : nil;
}
static NSDictionary *BQTargetLSRecord(NSString *bundle, NSError **error) {
    static dispatch_once_t once;
    dispatch_once(&once, ^{
        if (!NSClassFromString(@"LSApplicationProxy")) dlopen("/System/Library/Frameworks/MobileCoreServices.framework/MobileCoreServices", RTLD_LAZY | RTLD_LOCAL);
    });
    Class cls = NSClassFromString(@"LSApplicationProxy");
    SEL selector = NSSelectorFromString(@"applicationProxyForIdentifier:");
    @try {
        if (![cls respondsToSelector:selector]) return nil;
        NSMethodSignature *sig = [cls methodSignatureForSelector:selector];
        if (!sig || sig.numberOfArguments != 3 || sig.methodReturnType[0] != '@' || [sig getArgumentTypeAtIndex:2][0] != '@') return nil;
        id proxy = ((id (*)(id, SEL, id))objc_msgSend)(cls, selector, bundle);
        id identifier = BQTargetGetter(proxy, @"bundleIdentifier") ?: BQTargetGetter(proxy, @"applicationIdentifier");
        if (![identifier isKindOfClass:NSString.class] || ![identifier length]) return nil;
        if (![identifier isEqual:bundle]) { BQTargetConflict(error, @"iOS trả về định danh ứng dụng khác với yêu cầu."); return nil; }
        NSMutableDictionary *record = [@{@"bundle_id":bundle} mutableCopy];
        id url = BQTargetGetter(proxy, @"dataContainerURL");
        NSString *path = BQTargetDataRoot(BQTargetURL(url));
        if (url && !path) { BQTargetConflict(error, @"iOS trả về đường dẫn container không hợp lệ."); return nil; }
        if (path) record[@"data_path"] = path;



        return record;
    } @catch (__unused NSException *exception) { return nil; }
}

@interface BQTargetLookup : NSObject
@property (atomic) BOOL abandoned;
@property (atomic) BOOL finished;
@property (atomic, copy) NSDictionary *record;
@property (atomic, strong) NSError *error;
@end
@implementation BQTargetLookup
@end

NSDictionary *BQResolveApplicationTarget(NSString *bundleID, BOOL (^cancelled)(void), NSError **error) {
    if (BQTargetCancelled(cancelled, error)) return nil;
    if (!BQTargetBundle(bundleID)) { BQTargetConflict(error, @"Bundle ID trong gói patch không hợp lệ."); return nil; }

    if ([bundleID isEqual:NSBundle.mainBundle.bundleIdentifier]) {
        NSString *root = BQTargetDataRoot(NSHomeDirectory());
        if (root && BQTargetDirectory(root)) return @{@"target_id":[@"path:" stringByAppendingString:root], @"bundle_id":bundleID,
            @"name":bundleID, @"data_path":root, @"bundle_path":NSBundle.mainBundle.bundlePath};
    }
    static dispatch_semaphore_t available;
    static dispatch_once_t once;
    dispatch_once(&once, ^{ available = dispatch_semaphore_create(1); });
    if (dispatch_semaphore_wait(available, DISPATCH_TIME_NOW) != 0) {
        BQTargetFail(error, @"Lượt tìm ứng dụng trước vẫn đang kết thúc. Hãy thử lại sau."); return nil;
    }
    BQTargetLookup *lookup = [BQTargetLookup new];
    dispatch_async(dispatch_get_global_queue(QOS_CLASS_UTILITY, 0), ^{
        @autoreleasepool { @try {
            NSError *failure = nil;
            NSMutableDictionary *record = [BQTargetLSRecord(bundleID, &failure) mutableCopy] ?: [NSMutableDictionary dictionary];
            if (failure) { lookup.error = failure; return; }
            if (lookup.abandoned) return;
            NSString *root = record[@"data_path"];



            if (!root) {
                NSString *mcmPath = BQLookupApplicationDataPath(bundleID);
                root = BQTargetDataRoot(mcmPath);
                if (mcmPath && !root) { BQTargetConflict(&failure, @"iOS trả về đường dẫn container không hợp lệ."); lookup.error = failure; return; }
            }
            if (lookup.abandoned) return;
            if (root && BQTargetDirectory(root)) {
                record[@"data_path"] = root; record[@"bundle_id"] = bundleID;
                record[@"target_id"] = [@"path:" stringByAppendingString:root];
                if (!record[@"name"]) record[@"name"] = bundleID;
                lookup.record = record;
            }
        } @catch (__unused NSException *exception) { }
          @finally { lookup.finished = YES; dispatch_semaphore_signal(available); }
        }
    });
    NSTimeInterval deadline = NSProcessInfo.processInfo.systemUptime + 3.0;
    while (!lookup.finished) {
        if (BQTargetCancelled(cancelled, error)) { lookup.abandoned = YES; return nil; }
        if (NSProcessInfo.processInfo.systemUptime >= deadline) {
            lookup.abandoned = YES; BQTargetFail(error, @"iOS chưa trả lời truy vấn ứng dụng. Hãy thử lại sau."); return nil;
        }
        [NSThread sleepForTimeInterval:0.02];
    }
    if (BQTargetCancelled(cancelled, error)) return nil;
    if (lookup.error) { if (error) *error = lookup.error; return nil; }
    if (!lookup.record) BQTargetFail(error, BQTargetUnavailable);
    return lookup.record;
}
