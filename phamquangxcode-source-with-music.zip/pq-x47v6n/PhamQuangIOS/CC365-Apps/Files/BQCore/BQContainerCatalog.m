#import "BQContainerCatalog.h"
#import "BQCore.h"
#import "BQLSApplicationCatalog.h"
#import <dirent.h>
#import <dlfcn.h>
#import <errno.h>
#import <fcntl.h>
#import <objc/message.h>
#import <string.h>
#import <sys/stat.h>
#import <unistd.h>
#import <sys/sysctl.h>
#import <sys/xattr.h>

static const NSUInteger BQCatalogLimit = 1024;
static const NSTimeInterval BQCatalogTimeLimit = 7.0;
static const NSTimeInterval BQPatchMetadataTimeLimit = 8.0;
static const NSUInteger BQPatchMetadataLeaseLimit = 16;

@interface BQContainerEntry ()
@property (nonatomic, copy, readwrite) NSString *name;
@property (nonatomic, copy, readwrite) NSString *identifier;
@property (nonatomic, copy, readwrite) NSString *path;
@property (nonatomic, copy, readwrite) NSString *kind;
@property (nonatomic, copy, readwrite) NSString *bundlePath;
@property (nonatomic, readwrite) BOOL accessRestricted;
@end
@implementation BQContainerEntry
@end



@interface BQCatalogLookup : NSObject
@property (atomic) BOOL abandoned;
@property (atomic) BOOL finished;
@property (atomic, copy) NSArray<NSDictionary *> *records;
@property (atomic, copy) NSString *notice;
@property (atomic) NSInteger allCount;
@property (atomic) NSInteger installedCount;
@end
@implementation BQCatalogLookup
@end

static NSDictionary<NSString *, NSString *> *BQContainerRoots(void) {
    return @{@"app": @"/var/mobile/Containers/Data/Application",
             @"plugin": @"/var/mobile/Containers/Data/PluginKitPlugin",
             @"group": @"/var/mobile/Containers/Shared/AppGroup",
             @"system": @"/var/containers/Shared/SystemGroup"};
}

static NSString *BQCatalogString(id value) {
    if (![value isKindOfClass:NSString.class]) return nil;
    NSString *text = [value stringByTrimmingCharactersInSet:NSCharacterSet.whitespaceAndNewlineCharacterSet];
    return text.length ? text : nil;
}

static NSString *BQCatalogPath(id value) {
    if (![value isKindOfClass:NSString.class] || ![value isAbsolutePath]) return nil;
    NSData *bytes = [value dataUsingEncoding:NSUTF8StringEncoding];
    if (!bytes.length || memchr(bytes.bytes, 0, bytes.length)) return nil;
    NSMutableArray *parts = [NSMutableArray array];
    for (NSString *part in [value componentsSeparatedByString:@"/"]) {
        if ([part isEqualToString:@".."]) return nil;
        if (part.length && ![part isEqualToString:@"."]) [parts addObject:part];
    }
    NSString *path = [@"/" stringByAppendingString:[parts componentsJoinedByString:@"/"]];
    if ([path isEqualToString:@"/private/var"] || [path hasPrefix:@"/private/var/"]) path = [path substringFromIndex:8];
    return path;
}

static NSString *BQCatalogURLPath(id value) {
    return [value isKindOfClass:NSURL.class] && [value isFileURL] ? BQCatalogPath([value path]) : nil;
}

static NSString *BQCatalogKind(NSString *path) {
    NSString *parent = path.stringByDeletingLastPathComponent;
    NSDictionary *roots = BQContainerRoots();
    for (NSString *kind in @[@"app", @"plugin", @"group", @"system"]) {
        if ([parent isEqualToString:roots[kind]]) return kind;
    }
    return nil;
}

static id BQCatalogGetter(id object, NSString *name) {
    if (!object) return nil;
    @try {
        SEL selector = NSSelectorFromString(name);
        if (![object respondsToSelector:selector]) return nil;
        NSMethodSignature *signature = [object methodSignatureForSelector:selector];
        if (!signature || signature.numberOfArguments != 2 || signature.methodReturnType[0] != '@') return nil;
        return ((id (*)(id, SEL))objc_msgSend)(object, selector);
    } @catch (__unused NSException *exception) {
        return nil;
    }
}

static void BQPublishRecord(BQCatalogLookup *lookup, NSMutableArray<NSDictionary *> *records,
                            NSMutableDictionary *record, NSUInteger *index) {
    if (*index == NSNotFound) {
        *index = records.count;
        [records addObject:[record copy]];
    } else records[*index] = [record copy];


    lookup.records = records;
}

static void BQReadApplicationRecords(BQCatalogLookup *lookup) {
    @autoreleasepool {
        @try {
            static dispatch_once_t once;
            dispatch_once(&once, ^{
                if (!NSClassFromString(@"LSApplicationWorkspace")) {
                    dlopen("/System/Library/Frameworks/MobileCoreServices.framework/MobileCoreServices", RTLD_LAZY | RTLD_LOCAL);
                }
            });
            if (lookup.abandoned) return;
            id workspace = BQCatalogGetter(NSClassFromString(@"LSApplicationWorkspace"), @"defaultWorkspace");
            NSMutableArray *records = [NSMutableArray array];
            NSUInteger inspected = 0;
            BOOL receivedCatalog = NO;



            for (NSString *query in @[@"allApplications", @"allInstalledApplications"]) {
                if (lookup.abandoned) return;
                BOOL installed = [query isEqualToString:@"allInstalledApplications"];
                if (installed) lookup.installedCount = -1; else lookup.allCount = -1;
                id applications = BQCatalogGetter(workspace, query);
                if (![applications isKindOfClass:NSArray.class]) continue;
                if (installed) lookup.installedCount = [applications count]; else lookup.allCount = [applications count];
                receivedCatalog = YES;
                for (id proxy in applications) {
                    if (lookup.abandoned) return;
                    if (++inspected > BQCatalogLimit || records.count >= BQCatalogLimit) {
                        lookup.notice = @"The application catalog reached its result limit.";
                        return;
                    }
                    NSString *identifier = BQCatalogString(BQCatalogGetter(proxy, @"bundleIdentifier"));
                    if (lookup.abandoned) return;
                    if (!identifier) identifier = BQCatalogString(BQCatalogGetter(proxy, @"applicationIdentifier"));
                    if (lookup.abandoned) return;
                    NSUInteger recordIndex = NSNotFound;
                    NSMutableDictionary *record = identifier ? [@{@"kind": @"app", @"source": query, @"identifier": identifier, @"name": @""} mutableCopy] : nil;
                    if (record) BQPublishRecord(lookup, records, record, &recordIndex);
                    NSString *name = BQCatalogString(BQCatalogGetter(proxy, @"localizedName"));
                    if (record) {
                        record[@"name"] = name ?: @"";
                        BQPublishRecord(lookup, records, record, &recordIndex);
                    }
                    if (lookup.abandoned) return;
                    NSString *path = BQCatalogURLPath(BQCatalogGetter(proxy, @"dataContainerURL"));
                    if (path && [BQCatalogKind(path) isEqualToString:@"app"]) {
                        if (!record) record = [@{@"kind": @"app", @"source": query, @"identifier": @"", @"name": name ?: @""} mutableCopy];
                        record[@"path"] = path;
                        BQPublishRecord(lookup, records, record, &recordIndex);
                    }
                    if (lookup.abandoned) return;
                    if (record) {


                        NSString *bundlePath = BQCatalogURLPath(BQCatalogGetter(proxy, @"bundleURL"));
                        if ([bundlePath.pathExtension.lowercaseString isEqualToString:@"app"]) record[@"bundlePath"] = bundlePath;
                        BQPublishRecord(lookup, records, record, &recordIndex);
                    }
                    if (lookup.abandoned) return;
                    id groups = BQCatalogGetter(proxy, @"groupContainerURLs");
                    if (![groups isKindOfClass:NSDictionary.class]) continue;
                    for (id key in groups) {
                        if (lookup.abandoned) return;
                        if (records.count >= BQCatalogLimit) break;
                        NSString *groupID = BQCatalogString(key);
                        NSString *groupPath = BQCatalogURLPath(groups[key]);
                        NSString *kind = BQCatalogKind(groupPath);
                        if (groupPath && ([kind isEqualToString:@"group"] || [kind isEqualToString:@"system"])) {
                            [records addObject:@{@"path": groupPath, @"kind": kind, @"identifier": groupID ?: @"", @"name": groupID ?: @""}];
                        }
                    }
                    lookup.records = records;
                }
            }
            if (!receivedCatalog) lookup.notice = @"iOS did not expose the application catalog; showing filesystem results.";
            else if (records.count == 0 && !lookup.notice) lookup.notice = @"Application container paths are hidden on this device; showing filesystem results.";
        } @catch (__unused NSException *exception) {
            lookup.notice = @"The application catalog is unavailable on this iOS build.";
        }
    }
}

static NSDictionary *BQLookupStatistics(BQCatalogLookup *lookup, NSArray *records, NSString *state) {
    NSMutableDictionary *result = [NSMutableDictionary dictionaryWithObject:state forKey:@"state"];
    for (NSString *source in @[@"allApplications", @"allInstalledApplications"]) {
        NSUInteger ids = 0, names = 0, paths = 0, bundles = 0;
        for (NSDictionary *record in records) {
            if (![record[@"source"] isEqualToString:source]) continue;
            if ([record[@"identifier"] length]) ids++;
            if ([record[@"name"] length]) names++;
            if ([record[@"path"] length]) paths++;
            if ([record[@"bundlePath"] length]) bundles++;
        }
        NSInteger returned = !lookup ? -2 : ([source isEqualToString:@"allApplications"] ? lookup.allCount : lookup.installedCount);
        result[source] = @{@"returned": @(returned), @"ids": @(ids), @"names": @(names), @"paths": @(paths), @"bundles": @(bundles)};
    }
    return result;
}

static NSArray<NSDictionary *> *BQApplicationRecords(BOOL (^cancelled)(void), NSString **notice, NSDictionary **statistics) {
    static dispatch_semaphore_t available;
    static dispatch_once_t once;
    dispatch_once(&once, ^{ available = dispatch_semaphore_create(1); });
    if (dispatch_semaphore_wait(available, DISPATCH_TIME_NOW) != 0) {
        if (notice) *notice = @"An earlier application lookup is still finishing; showing filesystem results.";
        if (statistics) *statistics = BQLookupStatistics(nil, @[], @"busy");
        return @[];
    }
    BQCatalogLookup *lookup = [BQCatalogLookup new];
    lookup.allCount = -2; lookup.installedCount = -2;
    dispatch_async(dispatch_get_global_queue(QOS_CLASS_UTILITY, 0), ^{
        @try { BQReadApplicationRecords(lookup); }
        @finally {
            dispatch_semaphore_signal(available);
            lookup.finished = YES;
        }
    });
    NSTimeInterval deadline = NSProcessInfo.processInfo.systemUptime + 2.0;
    while (!lookup.finished) {
        if ((cancelled && cancelled()) || NSProcessInfo.processInfo.systemUptime >= deadline) {
            lookup.abandoned = YES;
            if (notice) *notice = @"The application lookup stopped early; showing available filesystem results.";
            NSArray *records = lookup.records ?: @[];
            if (statistics) *statistics = BQLookupStatistics(lookup, records, (cancelled && cancelled()) ? @"cancel" : @"timeout");
            return records;
        }
        [NSThread sleepForTimeInterval:0.02];
    }
    if (notice) *notice = lookup.notice;
    NSArray *records = lookup.records ?: @[];
    if (statistics) *statistics = BQLookupStatistics(lookup, records, @"complete");
    return records;
}

static BOOL BQCatalogDirectory(NSString *path, BOOL observed, BOOL *restricted) {
    struct stat st;
    *restricted = NO;
    if (lstat(path.fileSystemRepresentation, &st) == 0) {
        if (!S_ISDIR(st.st_mode)) return NO;
        if (access(path.fileSystemRepresentation, R_OK | X_OK) != 0) {
            if (errno == ENOENT || errno == ENOTDIR) return NO;
            *restricted = YES;
        }
        return YES;
    }


    if (observed && (errno == EACCES || errno == EPERM)) {
        *restricted = YES;
        return YES;
    }
    return NO;
}

static NSString *BQObservedBundlePath(id value) {
    NSString *path = BQCatalogPath(value);
    BOOL restricted = NO;
    return [path.pathExtension.lowercaseString isEqualToString:@"app"] && BQCatalogDirectory(path, YES, &restricted) ? path : nil;
}

static NSDictionary<NSString *, NSDictionary *> *BQApplicationIdentityIndex(NSArray<NSDictionary *> *records, NSUInteger *conflicts) {
    NSMutableDictionary *identities = [NSMutableDictionary dictionary];
    NSMutableSet *ambiguous = [NSMutableSet set];
    NSMutableDictionary<NSString *, NSMutableSet<NSString *> *> *pathOwners = [NSMutableDictionary dictionary];
    for (NSDictionary *record in records) {
        NSString *identifier = BQCatalogString(record[@"identifier"]);
        if (![record[@"kind"] isEqualToString:@"app"] || !identifier) continue;
        NSMutableDictionary *candidate = [NSMutableDictionary dictionary];
        NSString *path = BQCatalogPath(record[@"path"]);
        BOOL restricted = NO;
        if ([BQCatalogKind(path) isEqualToString:@"app"] && BQCatalogDirectory(path, YES, &restricted)) {
            candidate[@"path"] = path;
            if (!pathOwners[path]) pathOwners[path] = [NSMutableSet set];
            [pathOwners[path] addObject:identifier];
        }
        if ([ambiguous containsObject:identifier]) continue;
        NSString *name = BQCatalogString(record[@"name"]);
        if (name && ![name isEqualToString:identifier]) candidate[@"name"] = name;
        NSString *bundle = BQObservedBundlePath(record[@"bundlePath"]);
        if (bundle) candidate[@"bundlePath"] = bundle;
        NSDictionary *existing = identities[identifier];
        BOOL conflict = NO;
        for (NSString *key in @[@"name", @"path", @"bundlePath"]) {
            if (existing[key] && candidate[key] && ![existing[key] isEqual:candidate[key]]) { conflict = YES; break; }
        }
        if (conflict) {
            [identities removeObjectForKey:identifier];
            [ambiguous addObject:identifier];
        } else {
            NSMutableDictionary *merged = existing ? [existing mutableCopy] : [NSMutableDictionary dictionary];
            [merged addEntriesFromDictionary:candidate];
            identities[identifier] = [merged copy];
        }
    }
    for (NSSet<NSString *> *owners in pathOwners.allValues) {
        if (owners.count < 2) continue;
        for (NSString *identifier in owners) {
            [identities removeObjectForKey:identifier];
            [ambiguous addObject:identifier];
        }
    }
    if (conflicts) *conflicts = ambiguous.count;
    return [identities copy];
}

static void BQApplyApplicationIdentities(NSArray<BQContainerEntry *> *entries, NSDictionary<NSString *, NSDictionary *> *identities, BOOL includeBundle) {
    NSMutableDictionary<NSString *, NSNumber *> *counts = [NSMutableDictionary dictionary];
    for (BQContainerEntry *entry in entries) {
        if ([entry.kind isEqualToString:@"app"] && entry.identifier.length) counts[entry.identifier] = @([counts[entry.identifier] unsignedIntegerValue] + 1);
    }
    for (BQContainerEntry *entry in entries) {
        if (![entry.kind isEqualToString:@"app"] || !entry.identifier.length) continue;
        NSDictionary *identity = identities[entry.identifier];
        if (!identity) continue;
        NSString *observedPath = identity[@"path"];
        if (observedPath && ![observedPath isEqualToString:entry.path]) continue;
        if ([counts[entry.identifier] unsignedIntegerValue] > 1 && ![observedPath isEqualToString:entry.path]) continue;
        if ([entry.name isEqualToString:entry.path.lastPathComponent] || [entry.name isEqualToString:entry.identifier] || !entry.name.length) {
            NSString *name = identity[@"name"];
            if (name.length) entry.name = name;
        }


        if (includeBundle && !entry.bundlePath.length) entry.bundlePath = identity[@"bundlePath"];
    }
}


static NSString *BQAttributeIdentifier(const char *bytes, ssize_t length) {
    if (length <= 0 || length > 512) return nil;
    if (bytes[length - 1] == 0) length--;
    if (length <= 0 || memchr(bytes, 0, (size_t)length)) return nil;
    NSString *value = [[NSString alloc] initWithBytes:bytes length:(NSUInteger)length encoding:NSUTF8StringEncoding];
    NSCharacterSet *allowed = [NSCharacterSet characterSetWithCharactersInString:@"abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789.-_"];
    return value.length && [value rangeOfCharacterFromSet:allowed.invertedSet].location == NSNotFound ? value : nil;
}

static NSString *BQReadAttributeIdentifier(NSString *path) {
    char bytes[512];
    ssize_t length = getxattr(path.fileSystemRepresentation, "com.apple.containermanager.identifier", bytes, sizeof(bytes), 0, XATTR_NOFOLLOW);
    return BQAttributeIdentifier(bytes, length);
}

static NSString *BQMetadataFailure(int *readError, NSMutableDictionary *diagnostic, NSString *stage, int code, int64_t size) {
    if (readError) *readError = code;
    if (diagnostic) [diagnostic addEntriesFromDictionary:@{@"stage":stage, @"errno":@(code), @"size":@(size)}];
    return nil;
}


static NSString *BQReadIdentifierDescriptor(int fd, BOOL (^cancelled)(void), int *readError, NSMutableDictionary *diagnostic) {
    @try {
        struct stat st;
        if (fstat(fd, &st) != 0) return BQMetadataFailure(readError, diagnostic, @"stat", errno, -1);
        if (!S_ISREG(st.st_mode)) return BQMetadataFailure(readError, diagnostic, @"type", EINVAL, st.st_size);
        if (st.st_size < 0 || st.st_size > 64 * 1024) return BQMetadataFailure(readError, diagnostic, @"size", EFBIG, st.st_size);
        NSMutableData *data = [NSMutableData data];
        uint8_t buffer[4096];
        for (;;) {
            if (cancelled && cancelled()) return BQMetadataFailure(readError, diagnostic, @"cancel", ECANCELED, st.st_size);
            ssize_t n = read(fd, buffer, MIN(sizeof(buffer), 64 * 1024 + 1 - data.length));
            if (n < 0 && errno == EINTR) continue;
            if (n < 0) return BQMetadataFailure(readError, diagnostic, @"read", errno, st.st_size);
            if (n == 0) break;
            [data appendBytes:buffer length:(NSUInteger)n];
            if (data.length > 64 * 1024) return BQMetadataFailure(readError, diagnostic, @"size", EFBIG, data.length);
        }
        if (cancelled && cancelled()) return BQMetadataFailure(readError, diagnostic, @"cancel", ECANCELED, st.st_size);
        id plist = [NSPropertyListSerialization propertyListWithData:data options:NSPropertyListImmutable format:nil error:nil];
        if (![plist isKindOfClass:NSDictionary.class]) return BQMetadataFailure(readError, diagnostic, @"plist", EINVAL, st.st_size);
        if (!plist[@"MCMMetadataIdentifier"]) return BQMetadataFailure(readError, diagnostic, @"missing-id", EINVAL, st.st_size);
        NSString *identifier = BQCatalogString(plist[@"MCMMetadataIdentifier"]);
        NSCharacterSet *invalid = [[NSCharacterSet characterSetWithCharactersInString:@"abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789.-_"] invertedSet];
        if (!identifier.length || identifier.length > 512 || [identifier rangeOfCharacterFromSet:invalid].location != NSNotFound)
            return BQMetadataFailure(readError, diagnostic, @"invalid-id", EINVAL, st.st_size);
        if (diagnostic) [diagnostic addEntriesFromDictionary:@{@"stage":@"ok", @"errno":@0, @"size":@(st.st_size)}];
        return identifier;
    } @finally { close(fd); }
}

static NSString *BQReadContainerIdentifierDetailed(NSString *path, BOOL (^cancelled)(void), int *readError, NSMutableDictionary *diagnostic) {
    if (readError) *readError = 0;
    if (cancelled && cancelled()) return BQMetadataFailure(readError, diagnostic, @"cancel", ECANCELED, -1);
    NSString *attribute = BQReadAttributeIdentifier(path);
    if (attribute) {
        if (readError) *readError = 0;
        if (diagnostic) [diagnostic addEntriesFromDictionary:@{@"stage":@"xattr", @"errno":@0, @"size":@(attribute.length)}];
        return attribute;
    }
    NSString *metadata = [path stringByAppendingPathComponent:@".com.apple.mobile_container_manager.metadata.plist"];
    int fd = open(metadata.fileSystemRepresentation, O_RDONLY | O_NOFOLLOW | O_NONBLOCK | O_CLOEXEC);
    if (fd < 0) return BQMetadataFailure(readError, diagnostic, @"open", errno, -1);
    return BQReadIdentifierDescriptor(fd, cancelled, readError, diagnostic);
}
static NSString *BQReadContainerIdentifier(NSString *path, BOOL (^cancelled)(void), int *readError) {
    return BQReadContainerIdentifierDetailed(path, cancelled, readError, nil);
}

static NSString *BQReadObservedChildIdentifierDetailed(int root, NSString *child, BOOL (^cancelled)(void), int *readError, NSMutableDictionary *diagnostic) {
    if (readError) *readError = 0;
    if (cancelled && cancelled()) return BQMetadataFailure(readError, diagnostic, @"cancel", ECANCELED, -1);
    int directory = openat(root, child.fileSystemRepresentation, O_RDONLY | O_DIRECTORY | O_NOFOLLOW | O_CLOEXEC);
    if (directory < 0) return BQMetadataFailure(readError, diagnostic, @"open-container", errno, -1);
    @try {
        char bytes[512];
        NSString *attribute = BQAttributeIdentifier(bytes, fgetxattr(directory, "com.apple.containermanager.identifier", bytes, sizeof(bytes), 0, 0));
        if (attribute) {
            if (readError) *readError = 0;
            if (diagnostic) [diagnostic addEntriesFromDictionary:@{@"stage":@"xattr", @"errno":@0, @"size":@(attribute.length)}];
            return attribute;
        }
        int metadata = openat(directory, ".com.apple.mobile_container_manager.metadata.plist", O_RDONLY | O_NOFOLLOW | O_NONBLOCK | O_CLOEXEC);
        if (metadata < 0) return BQMetadataFailure(readError, diagnostic, @"open", errno, -1);
        return BQReadIdentifierDescriptor(metadata, cancelled, readError, diagnostic);
    } @finally { close(directory); }
}
static __attribute__((unused)) NSString *BQReadObservedChildIdentifier(int root, NSString *child, BOOL (^cancelled)(void), int *readError) {
    return BQReadObservedChildIdentifierDetailed(root, child, cancelled, readError, nil);
}

static void BQSetObservedIdentifier(BQContainerEntry *entry, NSString *identifier) {
    if (!identifier.length) return;
    if ([entry.name isEqualToString:entry.path.lastPathComponent] || !entry.name.length) entry.name = identifier;
    entry.identifier = identifier;
}

static void BQAddContainer(NSMutableDictionary<NSString *, BQContainerEntry *> *entries,
                          NSString *rawPath, NSString *name, NSString *identifier, NSString *kind,
                          BOOL observed, BOOL ownApp) {
    NSString *path = BQCatalogPath(rawPath);
    if (!path || (!ownApp && ![BQCatalogKind(path) isEqualToString:kind])) return;
    BOOL restricted = NO;
    if (!BQCatalogDirectory(path, observed, &restricted)) return;
    BQContainerEntry *existing = entries[path];
    if (!existing && entries.count >= BQCatalogLimit) return;
    name = BQCatalogString(name);
    identifier = BQCatalogString(identifier);
    NSString *directIdentifier = BQReadAttributeIdentifier(path);
    if (!directIdentifier && !restricted) directIdentifier = BQReadContainerIdentifier(path, nil, nil);
    if (directIdentifier.length) {


        if (identifier.length && ![identifier isEqual:directIdentifier]) name = nil;
        identifier = directIdentifier;
    }
    if (existing) {
        if (directIdentifier.length && ![existing.identifier isEqual:directIdentifier]) {
            existing.identifier = directIdentifier;
            existing.name = name ?: directIdentifier;
            existing.bundlePath = nil;
        }
        if (!existing.identifier.length && identifier.length) existing.identifier = identifier;
        if (([existing.name isEqualToString:path.lastPathComponent] || [existing.name isEqualToString:existing.identifier]) && name.length) existing.name = name;
        existing.accessRestricted = restricted;
        return;
    }
    BQContainerEntry *entry = [BQContainerEntry new];
    entry.path = path;
    entry.identifier = identifier ?: @"";
    entry.name = name ?: identifier ?: path.lastPathComponent;
    entry.kind = kind;
    entry.accessRestricted = restricted;
    entries[path] = entry;
}

static NSArray<BQContainerEntry *> *BQDiscoverContainersWithIdentities(BOOL (^cancelled)(void), NSString **notice,
    NSDictionary<NSString *, NSDictionary *> **identitiesOut, NSDictionary **lookupStatistics);

static void BQCount(NSMutableDictionary *counts, NSString *key) { counts[key] = @([counts[key] unsignedIntegerValue] + 1); }
static NSString *BQDiagnosticVersion(id value) {
    if (![value isKindOfClass:NSString.class] || ![value length] || [value length] > 64) return @"unknown";
    NSCharacterSet *allowed = [NSCharacterSet characterSetWithCharactersInString:@"0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz._-"];
    return [value rangeOfCharacterFromSet:allowed.invertedSet].location == NSNotFound ? value : @"unknown";
}
static void BQRecordMetadata(NSString *phase, NSUInteger ordinal, NSDictionary *result, NSMutableDictionary *counts,
                             NSMutableDictionary *stages, NSMutableDictionary *finalReads) {
    BQCount(counts, [phase stringByAppendingString:[phase isEqualToString:@"direct"] ? @"_attempts" : @"_reads"]);
    NSString *stage = result[@"stage"] ?: @"exception";
    BQCount(stages, [NSString stringWithFormat:@"%@.%@", phase, stage]);
    if ([phase isEqualToString:@"direct"] && ([result[@"size"] longLongValue] >= 0 || [stage isEqualToString:@"stat"])) BQCount(counts, @"direct_opened");
    if ([stage isEqualToString:@"ok"]) BQCount(counts, [phase stringByAppendingString:@"_resolved"]);
    NSInteger code = [result[@"errno"] integerValue];


    if (![phase isEqualToString:@"direct"] || (code != EACCES && code != EPERM)) {
        NSMutableDictionary *final = [result mutableCopy];
        final[@"phase"] = phase;
        finalReads[@(ordinal)] = final;
    }
}
static NSString *BQStageCounts(NSDictionary *stages) {
    NSMutableArray *parts = [NSMutableArray array];
    for (NSString *key in [stages.allKeys sortedArrayUsingSelector:@selector(compare:)]) [parts addObject:[NSString stringWithFormat:@"%@:%@", key, stages[key]]];
    return parts.count ? [parts componentsJoinedByString:@","] : @"none";
}

NSArray<BQContainerEntry *> *BQDiscoverPatchTargets(BOOL (^cancelled)(void), NSString **notice) {
    static NSUInteger nextScan = 0;  
    NSUInteger scan = ++nextScan;
    NSTimeInterval started = NSProcessInfo.processInfo.systemUptime;
    NSOperatingSystemVersion os = NSProcessInfo.processInfo.operatingSystemVersion;
    char build[64] = {0}; size_t buildSize = sizeof(build);
    if (sysctlbyname("kern.osversion", build, &buildSize, NULL, 0) != 0) build[0] = 0;
    build[sizeof(build) - 1] = 0;
    BQLog(@"catalog scan=%lu start app=%@ build=%@ os=%ld.%ld.%ld os_build=%@", (unsigned long)scan,
        BQDiagnosticVersion(NSBundle.mainBundle.infoDictionary[@"CFBundleShortVersionString"]),
        BQDiagnosticVersion(NSBundle.mainBundle.infoDictionary[@"CFBundleVersion"]),
        (long)os.majorVersion, (long)os.minorVersion, (long)os.patchVersion, BQDiagnosticVersion([NSString stringWithUTF8String:build]));
    NSString *discoveryNotice = nil;
    NSDictionary *identities = nil, *lookupStatistics = nil;
    NSArray<BQContainerEntry *> *containers = BQDiscoverContainersWithIdentities(cancelled, &discoveryNotice, &identities, &lookupStatistics);
    NSDictionary *all = lookupStatistics[@"allApplications"], *installed = lookupStatistics[@"allInstalledApplications"];
    BQLog(@"catalog scan=%lu ls state=%@ all_returned=%@ all_ids=%@ all_names=%@ all_paths=%@ all_bundles=%@ installed_returned=%@ installed_ids=%@ installed_names=%@ installed_paths=%@ installed_bundles=%@", (unsigned long)scan,
        lookupStatistics[@"state"] ?: @"skipped", all[@"returned"] ?: @-2, all[@"ids"] ?: @0, all[@"names"] ?: @0, all[@"paths"] ?: @0, all[@"bundles"] ?: @0,
        installed[@"returned"] ?: @-2, installed[@"ids"] ?: @0, installed[@"names"] ?: @0, installed[@"paths"] ?: @0, installed[@"bundles"] ?: @0);
    NSMutableArray<BQContainerEntry *> *apps = [NSMutableArray array];
    for (BQContainerEntry *entry in containers) if ([entry.kind isEqualToString:@"app"]) [apps addObject:entry];
    NSUInteger beforeKnown = 0;
    for (BQContainerEntry *entry in apps) if (entry.identifier.length) beforeKnown++;
    NSMutableDictionary *counts = [NSMutableDictionary dictionary], *stages = [NSMutableDictionary dictionary], *finalReads = [NSMutableDictionary dictionary];

    NSTimeInterval deadline = NSProcessInfo.processInfo.systemUptime + BQPatchMetadataTimeLimit;
    BOOL (^stop)(void) = ^BOOL {
        return (cancelled && cancelled()) || NSProcessInfo.processInfo.systemUptime >= deadline;
    };
    NSUInteger leases = 0;
    BOOL unavailable = NO, limited = NO, unsupported = NO;
    NSMutableArray<BQContainerEntry *> *pending = [NSMutableArray array];
    for (BQContainerEntry *entry in apps) {
        if (entry.identifier.length) continue;
        if (stop()) { limited = YES; break; }



        if (![BQCatalogKind(entry.path) isEqualToString:@"app"]) continue;
        BOOL restricted = NO;
        if (!BQCatalogDirectory(entry.path, YES, &restricted)) continue;
        int readError = 0;
        NSMutableDictionary *diagnostic = [NSMutableDictionary dictionary];
        NSString *identifier = BQReadContainerIdentifierDetailed(entry.path, stop, &readError, diagnostic);
        BQRecordMetadata(@"direct", [apps indexOfObjectIdenticalTo:entry] + 1, diagnostic, counts, stages, finalReads);
        BQSetObservedIdentifier(entry, identifier);
        if (!identifier && (readError == EACCES || readError == EPERM)) [pending addObject:entry];
    }
    NSMutableArray<BQContainerEntry *> *fallback = [NSMutableArray array];
    if (pending.count && !stop()) {
        NSString *accessible = nil;
        int64_t lease = -1;
        int directory = -1;
        NSUInteger readOrdinal = 0;
        leases++;
        BQCount(counts, @"root_attempts");
        @try {


            lease = BQEscape(BQContainerRoots()[@"app"], &accessible);
            if (lease >= 0) BQCount(counts, @"root_grants");
            if (lease >= 0 && [accessible isAbsolutePath] && !stop()) {


                directory = open(accessible.fileSystemRepresentation, O_RDONLY | O_DIRECTORY | O_CLOEXEC);
            }
            if (directory >= 0) {
                for (BQContainerEntry *entry in pending) {
                    if (stop()) { limited = YES; break; }
                    int readError = 0;
                    NSMutableDictionary *diagnostic = [NSMutableDictionary dictionary];
                    readOrdinal = [apps indexOfObjectIdenticalTo:entry] + 1;
                    BQSetObservedIdentifier(entry, BQReadObservedChildIdentifierDetailed(directory, entry.path.lastPathComponent, stop, &readError, diagnostic));
                    BQRecordMetadata(@"root", readOrdinal, diagnostic, counts, stages, finalReads);
                    readOrdinal = 0;
                    if (readError == EACCES || readError == EPERM) [fallback addObject:entry];
                }
            } else if (!stop()) {
                unavailable = YES;
                [fallback addObjectsFromArray:pending];
            }
        } @catch (__unused NSException *exception) {
            unavailable = YES;
            if (readOrdinal) BQRecordMetadata(@"root", readOrdinal, @{@"stage":@"exception", @"errno":@0, @"size":@-1}, counts, stages, finalReads);
            else BQCount(stages, @"root.access-exception");
        } @finally {
            if (directory >= 0) close(directory);
            if (lease >= 0) BQEndEscape(lease);
        }
        unsupported = lease == -7 || lease == -6;
    }
    for (BQContainerEntry *entry in fallback) {
        if (unsupported) break;
        if (stop() || leases >= BQPatchMetadataLeaseLimit) { limited = YES; break; }
        NSString *accessible = nil;
        int64_t lease = -1;
        BOOL readingMetadata = NO;
        leases++;
        BQCount(counts, @"child_attempts");
        @try {
            lease = BQEscape(entry.path, &accessible);
            if (lease >= 0) BQCount(counts, @"child_grants");
            if (lease >= 0 && [accessible isAbsolutePath] && !stop()) {
                int readError = 0;
                NSMutableDictionary *diagnostic = [NSMutableDictionary dictionary];
                readingMetadata = YES;
                BQSetObservedIdentifier(entry, BQReadContainerIdentifierDetailed(accessible, stop, &readError, diagnostic));
                BQRecordMetadata(@"child", [apps indexOfObjectIdenticalTo:entry] + 1, diagnostic, counts, stages, finalReads);
                readingMetadata = NO;
            } else if (lease < 0) unavailable = YES;
        } @catch (__unused NSException *exception) {
            unavailable = YES;
            if (readingMetadata) BQRecordMetadata(@"child", [apps indexOfObjectIdenticalTo:entry] + 1, @{@"stage":@"exception", @"errno":@0, @"size":@-1}, counts, stages, finalReads);
            else BQCount(stages, @"child.access-exception");
        } @finally {
            if (lease >= 0) BQEndEscape(lease);
        }

        unsupported = lease == -7 || lease == -6;
    }
    if (stop()) limited = YES;
    BQApplyApplicationIdentities(apps, identities, NO);
    NSUInteger unknown = 0, named = 0, failedReads = 0, samples = 0;
    NSMutableDictionary *reasons = [NSMutableDictionary dictionary];
    for (NSUInteger index = 0; index < apps.count; index++) {
        BQContainerEntry *entry = apps[index];
        if (entry.identifier.length) {
            if (entry.name.length && ![entry.name isEqualToString:entry.identifier] && ![entry.name isEqualToString:entry.path.lastPathComponent]) named++;
            continue;
        }
        unknown++;
        NSDictionary *result = finalReads[@(index + 1)];
        NSString *stage = result[@"stage"];
        if (!result || [stage isEqualToString:@"cancel"] || [stage isEqualToString:@"ok"]) continue;
        failedReads++;
        NSInteger code = [result[@"errno"] integerValue];
        NSString *reason = code == EACCES || code == EPERM ? @"permission" : ([stage isEqualToString:@"open"] && code == ENOENT ? @"missing" : @"unrecognized");
        BQCount(reasons, reason);
        if (samples++ < 8) BQLog(@"catalog scan=%lu failure ordinal=%lu phase=%@ stage=%@ errno=%ld size=%@", (unsigned long)scan,
            (unsigned long)index + 1, result[@"phase"], stage, (long)code, result[@"size"] ?: @-1);
    }
    BQLog(@"catalog scan=%lu end candidates=%lu before_known=%lu direct_attempts=%@ direct_opened=%@ direct_resolved=%@ root_attempts=%@ root_grants=%@ root_reads=%@ root_resolved=%@ child_attempts=%@ child_grants=%@ child_reads=%@ child_resolved=%@ named=%lu unknown=%lu failed_reads=%lu unknown_unread=%lu elapsed_ms=%.0f stopped_count=%d stopped_time=%d stopped_cancel=%d stages=%@",
        (unsigned long)scan, (unsigned long)apps.count, (unsigned long)beforeKnown,
        counts[@"direct_attempts"] ?: @0, counts[@"direct_opened"] ?: @0, counts[@"direct_resolved"] ?: @0,
        counts[@"root_attempts"] ?: @0, counts[@"root_grants"] ?: @0, counts[@"root_reads"] ?: @0, counts[@"root_resolved"] ?: @0,
        counts[@"child_attempts"] ?: @0, counts[@"child_grants"] ?: @0, counts[@"child_reads"] ?: @0, counts[@"child_resolved"] ?: @0,
        (unsigned long)named, (unsigned long)unknown, (unsigned long)failedReads, (unsigned long)(unknown - failedReads),
        (NSProcessInfo.processInfo.systemUptime - started) * 1000, limited && leases >= BQPatchMetadataLeaseLimit,
        NSProcessInfo.processInfo.systemUptime >= deadline, cancelled && cancelled(), BQStageCounts(stages));
    NSMutableArray<NSString *> *notes = [NSMutableArray array];
    if (discoveryNotice.length) [notes addObject:discoveryNotice];
    if (cancelled && cancelled()) [notes addObject:@"Đã dừng nhận diện ứng dụng; các container đã tìm thấy vẫn được giữ lại."];
    else if (limited) [notes addObject:@"Đã đạt giới hạn thời gian hoặc số lần đọc metadata; các container còn lại vẫn có thể chọn bằng đường dẫn."];
    if (unavailable && unknown) [notes addObject:@"BQCore chưa đọc được metadata của một số container trên thiết bị này."];
    NSString *dominant = nil;
    for (NSString *reason in @[@"permission", @"missing", @"unrecognized"]) if ([reasons[reason] unsignedIntegerValue] > [reasons[dominant ?: @""] unsignedIntegerValue]) dominant = reason;
    if ([dominant isEqualToString:@"permission"]) [notes addObject:@"iOS chưa cho đọc thông tin nhận diện của một số container đã kiểm tra."];
    else if ([dominant isEqualToString:@"missing"]) [notes addObject:@"Không tìm thấy thông tin nhận diện trong một số container đã kiểm tra."];
    else if ([dominant isEqualToString:@"unrecognized"]) [notes addObject:@"Chưa nhận diện được thông tin ứng dụng trong một số container đã kiểm tra."];
    if (unknown) [notes addObject:[NSString stringWithFormat:@"%lu container ứng dụng chưa xác định được bundle ID; không suy đoán định danh từ UUID.", (unsigned long)unknown]];
    if (notice) *notice = [notes componentsJoinedByString:@"\n\n"];
    return [apps sortedArrayUsingComparator:^NSComparisonResult(BQContainerEntry *a, BQContainerEntry *b) {
        NSComparisonResult order = [a.name localizedCaseInsensitiveCompare:b.name];
        return order == NSOrderedSame ? [a.path compare:b.path] : order;
    }];
}

static NSArray<BQContainerEntry *> *BQDiscoverContainersWithIdentities(BOOL (^cancelled)(void), NSString **notice,
    NSDictionary<NSString *, NSDictionary *> **identitiesOut, NSDictionary **lookupStatistics) {
    if (notice) *notice = nil;
    if (identitiesOut) *identitiesOut = @{};
    NSDictionary *identities = @{};
    NSMutableDictionary<NSString *, BQContainerEntry *> *entries = [NSMutableDictionary dictionary];
    NSDictionary *info = NSBundle.mainBundle.infoDictionary;
    BQAddContainer(entries, NSHomeDirectory(), BQCatalogString(info[@"CFBundleDisplayName"]) ?: @"PhamQuang IOS",
        NSBundle.mainBundle.bundleIdentifier, @"app", YES, YES);
    entries[BQCatalogPath(NSHomeDirectory())].bundlePath = BQObservedBundlePath(NSBundle.mainBundle.bundlePath);
    NSMutableOrderedSet<NSString *> *notes = [NSMutableOrderedSet orderedSet];


    NSString *storeNotice = nil;
    NSArray *storeRecords = (cancelled && cancelled()) ? @[] : BQReadLSApplicationRecords(cancelled, &storeNotice);
    if (storeNotice.length) [notes addObject:storeNotice];
    NSTimeInterval deadline = NSProcessInfo.processInfo.systemUptime + BQCatalogTimeLimit;
    BOOL (^stop)(void) = ^BOOL {
        return (cancelled && cancelled()) || entries.count >= BQCatalogLimit || NSProcessInfo.processInfo.systemUptime >= deadline;
    };
    if (!stop()) {
        NSString *lookupNotice = nil;
        NSArray *nativeRecords = BQApplicationRecords(cancelled, &lookupNotice, lookupStatistics);
        NSMutableArray *records = [nativeRecords mutableCopy];
        for (NSDictionary *stored in storeRecords) {
            if (stop()) break;
            NSString *path = BQCatalogPath(stored[@"path"]);
            NSString *kind = stored[@"kind"];
            BOOL restricted = NO;
            if (![@[@"app", @"plugin"] containsObject:kind] || ![BQCatalogKind(path) isEqual:kind] ||
                ![[NSUUID alloc] initWithUUIDString:path.lastPathComponent] || !BQCatalogDirectory(path, YES, &restricted)) continue;
            NSMutableDictionary *record = [stored mutableCopy];
            record[@"path"] = path;


            for (NSDictionary *native in nativeRecords) {
                if ([native[@"identifier"] isEqual:record[@"identifier"]] && BQCatalogString(native[@"name"]).length) {
                    [record removeObjectForKey:@"name"]; break;
                }
            }
            [records addObject:record];
        }
        if (lookupNotice) [notes addObject:lookupNotice];
        NSUInteger conflicts = 0;
        identities = BQApplicationIdentityIndex(records, &conflicts);
        if (identitiesOut) *identitiesOut = identities;
        if (conflicts) [notes addObject:@"Một số định danh ứng dụng có thông tin không thống nhất; PhamQuang IOS chưa ghép tên với các container đó."];
        for (NSDictionary *record in records) {
            if (stop()) break;
            if (!record[@"path"]) continue;  
            if ([record[@"kind"] isEqualToString:@"app"]) {
                NSString *path = BQCatalogPath(record[@"path"]);
                NSDictionary *identity = identities[record[@"identifier"] ?: @""];
                BOOL trusted = identity && [identity[@"path"] isEqualToString:path];


                BQAddContainer(entries, path, trusted ? identity[@"name"] : nil,
                    trusted ? record[@"identifier"] : nil, @"app", YES, NO);
                if (trusted && identity[@"bundlePath"] && [entries[path].identifier isEqual:record[@"identifier"]])
                    entries[path].bundlePath = identity[@"bundlePath"];
            } else BQAddContainer(entries, record[@"path"], record[@"name"], record[@"identifier"], record[@"kind"], YES, NO);
        }
    }
    NSDictionary *roots = BQContainerRoots();
    for (NSString *kind in @[@"app", @"group", @"system"]) {
        if (stop()) break;
        NSString *root = roots[kind];
        DIR *directory = opendir(root.fileSystemRepresentation);
        if (directory) {
            @try {
                while (!stop()) {
                    errno = 0;
                    struct dirent *child = readdir(directory);
                    if (!child) {
                        if (errno) [notes addObject:@"Some container directories could not be fully listed."];
                        break;
                    }
                    if (!strcmp(child->d_name, ".") || !strcmp(child->d_name, "..")) continue;
                    NSString *leaf = [[NSFileManager defaultManager] stringWithFileSystemRepresentation:child->d_name length:strlen(child->d_name)];
                    if (leaf) BQAddContainer(entries, [root stringByAppendingPathComponent:leaf], nil, nil, kind, child->d_type == DT_DIR, NO);
                }
            } @finally { closedir(directory); }
        } else if (errno == EACCES || errno == EPERM) {
            [notes addObject:@"iOS restricts container listing; bounded discovery may miss some apps or groups."];
            BOOL stoppedEarly = NO;
            NSString *scanError = nil;
            NSArray *paths = BQDiscoverContainerPaths(root, MIN(1.0, MAX(0, deadline - NSProcessInfo.processInfo.systemUptime)),
                BQCatalogLimit - entries.count, cancelled, &stoppedEarly, &scanError);
            for (NSString *path in paths) {
                if (stop()) break;
                BQAddContainer(entries, path, nil, nil, kind, YES, NO);
            }
            if (stoppedEarly) [notes addObject:@"The container scan stopped at its time or result limit."];
            if (scanError) [notes addObject:scanError];
        } else {
            [notes addObject:@"Some standard container locations are unavailable on this device."];
        }
    }
    BQApplyApplicationIdentities(entries.allValues, identities, YES);
    if (cancelled && cancelled()) [notes addObject:@"Discovery cancelled; showing results found so far."];
    else if (stop()) [notes addObject:@"Discovery reached its time or result limit; showing partial results."];
    NSUInteger restricted = 0;
    for (BQContainerEntry *entry in entries.allValues) if (entry.accessRestricted) restricted++;
    if (restricted) [notes addObject:@"Some observed containers cannot be checked directly. Access is checked when you open them."];
    [notes addObject:@"Only container paths exposed by this device are shown; this may not include every installed app."];
    if (notice) *notice = [[notes array] componentsJoinedByString:@"\n\n"];
    return [entries.allValues sortedArrayUsingComparator:^NSComparisonResult(BQContainerEntry *a, BQContainerEntry *b) {
        NSInteger ka = [@[@"app", @"plugin", @"group", @"system"] indexOfObject:a.kind];
        NSInteger kb = [@[@"app", @"plugin", @"group", @"system"] indexOfObject:b.kind];
        if (ka != kb) return ka < kb ? NSOrderedAscending : NSOrderedDescending;
        NSComparisonResult result = [a.name localizedCaseInsensitiveCompare:b.name];
        return result == NSOrderedSame ? [a.path compare:b.path] : result;
    }];
}

NSArray<BQContainerEntry *> *BQDiscoverContainers(BOOL (^cancelled)(void), NSString **notice) {
    return BQDiscoverContainersWithIdentities(cancelled, notice, nil, nil);
}
