#pragma once
#import <Foundation/Foundation.h>
NS_ASSUME_NONNULL_BEGIN

@interface BQContainerEntry : NSObject
@property (nonatomic, copy, readonly) NSString *name;
@property (nonatomic, copy, readonly) NSString *identifier;
@property (nonatomic, copy, readonly) NSString *path;
@property (nonatomic, copy, readonly) NSString *kind;  


@property (nonatomic, copy, readonly, nullable) NSString *bundlePath;
@property (nonatomic, readonly) BOOL accessRestricted;
@end









NSArray<BQContainerEntry *> *BQDiscoverContainers(BOOL (^ _Nullable cancelled)(void), NSString * _Nullable * _Nullable notice);







NSArray<BQContainerEntry *> *BQDiscoverPatchTargets(BOOL (^ _Nullable cancelled)(void), NSString * _Nullable * _Nullable notice);
NS_ASSUME_NONNULL_END
