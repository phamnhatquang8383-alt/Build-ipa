#import "BQLSApplicationCatalog.h"
#import "BQLSStoreParser.h"
#import "BQCore.h"
#import <dirent.h>
#import <errno.h>
#import <fcntl.h>
#import <limits.h>
#import <sys/stat.h>
#import <unistd.h>

static NSString *const BQLSPathKey = @"CC365.LaunchServicesStorePath";
static NSString *const BQLSDaemonRoot = @"/private/var/mobile/Containers/Data/InternalDaemon";
static const NSUInteger BQLSMaxBytes = 64 * 1024 * 1024;
static NSTimeInterval BQLSRetryAfter;
static NSString *BQLSLastNotice;

static BOOL BQLSStopped(BOOL (^cancelled)(void), NSTimeInterval deadline) {
    return (cancelled && cancelled()) || NSProcessInfo.processInfo.systemUptime >= deadline;
}

static NSString *BQLSValidatedPath(id value) {
    if (![value isKindOfClass:NSString.class]) return nil;
    NSString *path = value;
    if ([path hasPrefix:@"/var/"]) path = [@"/private" stringByAppendingString:path];
    NSString *prefix = [BQLSDaemonRoot stringByAppendingString:@"/"];
    if (![path hasPrefix:prefix]) return nil;
    NSArray<NSString *> *parts = [[path substringFromIndex:prefix.length] componentsSeparatedByString:@"/"];
    if (parts.count != 4 || parts[0].length != 36 || ![[NSUUID alloc] initWithUUIDString:parts[0]] ||
        ![parts[1] isEqual:@"Library"] || ![parts[2] isEqual:@"Caches"]) return nil;
    NSString *name = parts[3];
    NSString *head = @"com.apple.LaunchServices-", *tail = @".csstore";
    if (![name hasPrefix:head] || ![name hasSuffix:tail] || name.length <= head.length + tail.length ||
        [name lengthOfBytesUsingEncoding:NSUTF8StringEncoding] > 255 || [name containsString:@"\\"] ||
        [name rangeOfCharacterFromSet:NSCharacterSet.controlCharacterSet].location != NSNotFound) return nil;
    return path;
}

static BOOL BQLSSameStat(const struct stat *a, const struct stat *b) {
    return a->st_dev == b->st_dev && a->st_ino == b->st_ino && a->st_mode == b->st_mode &&
        a->st_size == b->st_size && a->st_mtimespec.tv_sec == b->st_mtimespec.tv_sec &&
        a->st_mtimespec.tv_nsec == b->st_mtimespec.tv_nsec &&
        a->st_ctimespec.tv_sec == b->st_ctimespec.tv_sec && a->st_ctimespec.tv_nsec == b->st_ctimespec.tv_nsec;
}

static int BQLSOpenDirectory(NSString *path) {
    return open(path.fileSystemRepresentation, O_SEARCH | O_DIRECTORY | O_NOFOLLOW_ANY | O_CLOEXEC);
}

static BOOL BQLSLeasePathMatches(NSString *accessible, NSString *expected) {
    if (!accessible.length) return NO;
    char *resolved = realpath(accessible.fileSystemRepresentation, NULL);
    if (resolved) {
        NSString *path = [NSString stringWithUTF8String:resolved];
        free(resolved);
        if ([path hasPrefix:@"/var/"]) path = [@"/private" stringByAppendingString:path];
        return [path isEqualToString:expected];
    }



    NSString *parent = accessible.stringByDeletingLastPathComponent;
    if ([parent hasPrefix:@"/var/"]) parent = [@"/private" stringByAppendingString:parent];
    int directory = BQLSOpenDirectory(parent);
    if (directory < 0) return NO;
    char bytes[PATH_MAX];
    ssize_t count = readlinkat(directory, accessible.lastPathComponent.fileSystemRepresentation, bytes, sizeof(bytes));
    close(directory);
    if (count <= 0 || count >= (ssize_t)sizeof(bytes)) return NO;
    NSString *target = [[NSString alloc] initWithBytes:bytes length:(NSUInteger)count encoding:NSUTF8StringEncoding];
    if ([target hasPrefix:@"/var/"]) target = [@"/private" stringByAppendingString:target];
    return [target isEqual:expected];
}

static NSArray<NSDictionary *> *BQLSReadFromRoot(NSString *path, NSString *accessible, BOOL leased,
    BOOL (^cancelled)(void), NSTimeInterval deadline, NSString **stage, int *failure, NSString **parseNotice) {
    NSString *expected = path.stringByDeletingLastPathComponent;
    if (leased && !BQLSLeasePathMatches(accessible, expected)) { *stage = @"lease-path"; *failure = ELOOP; return nil; }
    int directory = leased ? open(accessible.fileSystemRepresentation, O_SEARCH | O_DIRECTORY | O_CLOEXEC)
                           : BQLSOpenDirectory(expected);
    if (directory < 0) { *stage = @"directory"; *failure = errno; return nil; }
    int file = -1;
    @try {
        struct stat directoryBefore;
        if (fstat(directory, &directoryBefore) != 0 || !S_ISDIR(directoryBefore.st_mode)) { *stage = @"directory-stat"; *failure = errno ?: ENOTDIR; return nil; }
        file = openat(directory, path.lastPathComponent.fileSystemRepresentation, O_RDONLY | O_NOFOLLOW | O_NONBLOCK | O_CLOEXEC);
        if (file < 0) { *stage = @"open"; *failure = errno; return nil; }
        struct stat before;
        if (fstat(file, &before) != 0) { *stage = @"stat"; *failure = errno; return nil; }
        if (!S_ISREG(before.st_mode)) { *stage = @"type"; *failure = EINVAL; return nil; }
        if (before.st_size < 4096 || before.st_size > (off_t)BQLSMaxBytes) { *stage = @"size"; *failure = EFBIG; return nil; }
        NSMutableData *data = [NSMutableData dataWithCapacity:(NSUInteger)before.st_size];
        uint8_t buffer[64 * 1024];
        for (;;) {
            if (BQLSStopped(cancelled, deadline)) { *stage = @"cancel-time"; *failure = ECANCELED; return nil; }
            ssize_t count = read(file, buffer, MIN(sizeof(buffer), BQLSMaxBytes - data.length + 1));
            if (count < 0 && errno == EINTR) continue;
            if (count < 0) { *stage = @"read"; *failure = errno; return nil; }
            if (!count) break;
            if ((NSUInteger)count > BQLSMaxBytes - data.length || data.length + (NSUInteger)count > (NSUInteger)before.st_size) {
                *stage = @"changed-size"; *failure = EBUSY; return nil;
            }
            [data appendBytes:buffer length:(NSUInteger)count];
        }
        if (data.length != (NSUInteger)before.st_size) { *stage = @"changed-size"; *failure = EBUSY; return nil; }
        NSArray<NSDictionary *> *records = BQParseLSStore(data, ^BOOL { return BQLSStopped(cancelled, deadline); }, parseNotice);
        if (!records) { *stage = @"parse"; *failure = EINVAL; return nil; }
        if (BQLSStopped(cancelled, deadline)) { *stage = @"cancel-time"; *failure = ECANCELED; return nil; }
        struct stat after, named, directoryAfter;
        if (fstat(file, &after) != 0 || fstatat(directory, path.lastPathComponent.fileSystemRepresentation, &named, AT_SYMLINK_NOFOLLOW) != 0 ||
            !BQLSSameStat(&before, &after) || !BQLSSameStat(&before, &named)) { *stage = @"changed-file"; *failure = EBUSY; return nil; }
        if (leased && !BQLSLeasePathMatches(accessible, expected)) { *stage = @"changed-directory"; *failure = EBUSY; return nil; }
        int current = leased ? open(accessible.fileSystemRepresentation, O_SEARCH | O_DIRECTORY | O_CLOEXEC) : BQLSOpenDirectory(expected);
        BOOL sameDirectory = current >= 0 && fstat(current, &directoryAfter) == 0 &&
            directoryBefore.st_dev == directoryAfter.st_dev && directoryBefore.st_ino == directoryAfter.st_ino;
        if (current >= 0) close(current);
        if (!sameDirectory) { *stage = @"changed-directory"; *failure = EBUSY; return nil; }
        return records;
    } @finally { if (file >= 0) close(file); close(directory); }
}

static NSArray<NSDictionary *> *BQLSTryRead(NSString *path, BOOL (^cancelled)(void), NSTimeInterval deadline,
    NSString **stage, int *failure, NSString **parseNotice, NSUInteger *leases) {
    NSArray *records = BQLSReadFromRoot(path, nil, NO, cancelled, deadline, stage, failure, parseNotice);
    if (records || (*failure != EACCES && *failure != EPERM) || BQLSStopped(cancelled, deadline) || *leases >= 4) return records;
    NSString *accessible = nil;
    (*leases)++;
    int64_t lease = BQEscape(path.stringByDeletingLastPathComponent, &accessible);
    if (lease < 0) { *stage = @"lease"; *failure = EACCES; return nil; }
    @try {
        if (BQLSStopped(cancelled, deadline)) { *stage = @"cancel-time"; *failure = ECANCELED; return nil; }
        return BQLSReadFromRoot(path, accessible, YES, cancelled, deadline, stage, failure, parseNotice);
    } @finally { BQEndEscape(lease); }
}

static NSArray<NSString *> *BQLSDirectCandidates(BOOL (^cancelled)(void), NSTimeInterval deadline) {
    NSMutableArray<NSString *> *candidates = [NSMutableArray new];
    int root = open(BQLSDaemonRoot.fileSystemRepresentation, O_RDONLY | O_DIRECTORY | O_NOFOLLOW_ANY | O_CLOEXEC);
    if (root < 0) return candidates;
    DIR *dirs = fdopendir(root);
    if (!dirs) { close(root); return candidates; }
    @try {
        struct dirent *entry; NSUInteger seen = 0;
        while (!BQLSStopped(cancelled, deadline) && seen < 1024 && (entry = readdir(dirs))) {
            seen++;
            NSString *uuid = [NSString stringWithUTF8String:entry->d_name];
            if (uuid.length != 36 || ![[NSUUID alloc] initWithUUIDString:uuid]) continue;
            NSString *caches = [[BQLSDaemonRoot stringByAppendingPathComponent:uuid] stringByAppendingPathComponent:@"Library/Caches"];
            int fd = open(caches.fileSystemRepresentation, O_RDONLY | O_DIRECTORY | O_NOFOLLOW_ANY | O_CLOEXEC);
            if (fd < 0) continue;
            DIR *files = fdopendir(fd);
            if (!files) { close(fd); continue; }
            @try {
                struct dirent *file; NSUInteger count = 0;
                while (!BQLSStopped(cancelled, deadline) && count++ < 2048 && (file = readdir(files))) {
                    NSString *name = [NSString stringWithUTF8String:file->d_name];
                    NSString *path = name ? BQLSValidatedPath([caches stringByAppendingPathComponent:name]) : nil;
                    if (path) [candidates addObject:path];
                    if (candidates.count >= 8) return candidates;
                }
            } @finally { closedir(files); }
        }
    } @finally { closedir(dirs); }
    return [candidates sortedArrayUsingSelector:@selector(compare:)];
}

NSArray<NSDictionary *> *BQReadLSApplicationRecords(BOOL (^cancelled)(void), NSString **notice) {
    if (notice) *notice = nil;
    NSTimeInterval now = NSProcessInfo.processInfo.systemUptime;
    if (cancelled && cancelled()) { if (notice) *notice = @"Đã dừng đọc danh mục ứng dụng."; return @[]; }
    if (now < BQLSRetryAfter) { if (notice) *notice = BQLSLastNotice; return @[]; }
    NSTimeInterval deadline = now + 12.0;
    NSUserDefaults *defaults = NSUserDefaults.standardUserDefaults;
    id saved = [defaults objectForKey:BQLSPathKey];
    NSString *cached = BQLSValidatedPath(saved);
    if (saved && !cached) [defaults removeObjectForKey:BQLSPathKey];
    NSMutableOrderedSet<NSString *> *candidates = [NSMutableOrderedSet new];
    if (cached) [candidates addObject:cached];
    NSString *stage = @"not-found", *parseNotice = nil;
    int failure = ENOENT;
    NSUInteger leases = 0, attempts = 0;
    BOOL scanned = NO;
    NSArray *result = nil;
    @try {


        for (NSUInteger phase = 0; phase < 3 && !result; phase++) {
            if (phase == 1) [candidates addObjectsFromArray:BQLSDirectCandidates(cancelled, MIN(deadline, now + 1.0))];
            if (phase == 2 && !BQLSStopped(cancelled, deadline)) {
                scanned = YES;
                NSArray *observed = BQDiscoverLSStorePaths(MIN(8.0, deadline - NSProcessInfo.processInfo.systemUptime), 4, cancelled, NULL, NULL);
                for (id value in observed) { NSString *path = BQLSValidatedPath(value); if (path) [candidates addObject:path]; }
            }
            while (attempts < candidates.count && attempts < 8 && !BQLSStopped(cancelled, deadline)) {
                NSString *path = candidates[attempts++];
                result = BQLSTryRead(path, cancelled, deadline, &stage, &failure, &parseNotice, &leases);
                if (result && !result.count) { result = nil; stage = @"no-mappings"; failure = ENODATA; }
                if (result) { [defaults setObject:path forKey:BQLSPathKey]; break; }
                if ([path isEqual:cached]) [defaults removeObjectForKey:BQLSPathKey];
            }
        }
    } @catch (__unused NSException *exception) { result = nil; stage = @"exception"; failure = EIO; }
    BOOL stopped = BQLSStopped(cancelled, deadline);
    BQLog(@"ls-store attempts=%lu leases=%lu scanned=%d rows=%lu stage=%@ errno=%d elapsed_ms=%.0f stopped=%d",
        (unsigned long)attempts, (unsigned long)leases, scanned, (unsigned long)result.count,
        result ? @"ok" : stage, result ? 0 : failure, (NSProcessInfo.processInfo.systemUptime - now) * 1000, stopped);
    if (result && !stopped) {
        BQLSRetryAfter = 0; BQLSLastNotice = nil;
        if (notice) *notice = parseNotice;
        return result;
    }
    NSString *message = stopped ? @"Chưa hoàn tất đọc danh mục ứng dụng. Bạn có thể thử lại."
        : (failure == EPERM || failure == EACCES) ? @"iOS chưa cho phép đọc danh mục tên ứng dụng trên thiết bị này. Các thư mục vẫn có thể hiển thị bằng UUID."
        : failure == ENOENT ? @"Chưa tìm thấy danh mục tên ứng dụng. Các thư mục vẫn có thể hiển thị bằng UUID."
        : failure == ENODATA ? @"Danh mục chưa có thông tin ứng dụng có thể xác nhận. Các thư mục vẫn có thể hiển thị bằng UUID."
        : @"Danh mục tên ứng dụng chưa đọc được hoặc đã thay đổi. Hãy thử lại sau.";
    BQLSLastNotice = message;
    if (!(cancelled && cancelled())) BQLSRetryAfter = NSProcessInfo.processInfo.systemUptime + 20.0;
    if (notice) *notice = message;
    return @[];
}
