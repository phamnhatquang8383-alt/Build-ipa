#pragma once
#import <Foundation/Foundation.h>

extern NSString * const BQErrorDomain;


void BQLog(NSString *fmt, ...);
NSString *BQLogPath(void);
NSString *BQDocuments(void);
NSString *BQGroupRoot(void);
NSString *BQGroupID(void);
NSDictionary *BQProbeEscapeClasses(NSString *target);
NSDictionary *BQProbeClass2Parts(NSString *target);
dispatch_queue_t BQWorkQueue(void);



NSArray<NSString *> *BQDiscoverContainerPaths(NSString *root, NSTimeInterval timeLimit,
    NSUInteger resultLimit, BOOL (^cancelled)(void), BOOL *stoppedEarly, NSString **err);


NSArray<NSString *> *BQDiscoverLSStorePaths(NSTimeInterval timeLimit, NSUInteger resultLimit,
    BOOL (^cancelled)(void), BOOL *stoppedEarly, NSString **err);




BOOL BQCoreInit(void);


NSString *BQLookupApplicationDataPath(NSString *bundleID);






int64_t BQEscape(NSString *target, NSString **linkOut);
void BQEndEscape(int64_t handle);




BOOL BQClass2ParentEnabled(void);
void BQSetClass2ParentEnabled(BOOL on);
BOOL BQCheckAccess(NSString *target, BOOL writable, NSString **err);
