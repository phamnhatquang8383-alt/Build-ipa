import Foundation

struct PatchCaptureSource: Identifiable, Sendable {
    let id = UUID()
    let staging: FileTransferItem
    let sourceURL: URL
    let isDirectory: Bool
    let destination: String?
    let bundleID: String?
    let displayName: String
}



@MainActor enum PatchCaptureService {
    private struct Applications: Decodable, Sendable { let apps: [PatchTargetApp] }
    private static let maximumNodes = 4096

    static func capture(path: String, isDirectory: Bool) async throws -> PatchCaptureSource {
        let source = try canonicalPath(path)
        let name = (source as NSString).lastPathComponent
        guard FileTransferSupport.validName(name), !name.hasPrefix(".") else {
            throw PatchInputError("Chọn một tệp hoặc thư mục thông thường để tạo patch.")
        }
        let staged = try FileTransferItem(name: name)
        var succeeded = false
        defer { if !succeeded { staged.remove() } }
        var files = 0, nodes = 0
        var total: UInt64 = 0

        func copyFile(_ entry: DeviceFileEntry, path remote: String, to local: URL) async throws {
            try Task.checkCancellation()
            guard entry.kind == "file", let size = entry.size, size <= AppPatchSource.perFile,
                  files < AppPatchSource.maxFiles, size <= AppPatchSource.total - total else {
                throw PatchInputError("Nguồn vượt giới hạn: 1.024 tệp, 128 MiB mỗi tệp và 256 MiB tổng cộng.")
            }
            try await VersionedFilesTransport.download(path: remote, to: local)
            try Task.checkCancellation()
            let values = try local.resourceValues(forKeys: [.isRegularFileKey, .isSymbolicLinkKey, .fileSizeKey])
            guard values.isRegularFile == true, values.isSymbolicLink != true,
                  let actual = values.fileSize, actual >= 0, UInt64(actual) == size else {
                throw PatchInputError("Tệp nguồn đã thay đổi trong lúc đọc. Hãy tạo lại bản chụp.")
            }
            files += 1
            total += size
        }

        func contents(_ remote: String, matching leaf: String? = nil) async throws -> [DeviceFileEntry] {
            var offset = 0
            var inspected = 0
            var entries: [DeviceFileEntry] = []
            var seen = Set<String>()
            while true {
                try Task.checkCancellation()
                let page = try await VersionedFilesTransport.list(path: remote, offset: offset)
                if let notice = page.notice, !notice.isEmpty {
                    throw PatchInputError("Chưa đọc được đầy đủ thư mục nguồn. \(notice)")
                }
                for entry in page.entries {
                    inspected += 1
                    guard inspected <= maximumNodes else { throw PatchInputError("Thư mục có quá nhiều mục. Hãy chọn thư mục nhỏ hơn.") }


                    if let leaf, entry.name != leaf { continue }
                    guard FileTransferSupport.validName(entry.name), !entry.name.hasPrefix("."),
                          seen.insert(entry.name).inserted else {
                        throw PatchInputError("Thư mục chứa tên không hỗ trợ hoặc danh sách đã thay đổi. Hãy thử lại.")
                    }
                    let expected = (remote == "/" ? "" : remote) + "/" + entry.name
                    if let supplied = entry.path, try canonicalPath(supplied) != expected {
                        throw PatchInputError("Đường dẫn tệp không khớp thư mục đang đọc.")
                    }
                    entries.append(entry)
                }
                guard entries.count <= maximumNodes else { throw PatchInputError("Thư mục có quá nhiều mục. Hãy chọn thư mục nhỏ hơn.") }
                guard let next = page.nextOffset else { return entries }
                guard next > offset, next <= maximumNodes else { throw PatchInputError("Danh sách thư mục chưa đầy đủ. Hãy thử lại.") }
                offset = next
            }
        }

        func copyDirectory(_ remote: String, to local: URL, depth: Int) async throws {
            try Task.checkCancellation()
            guard depth <= 30 else { throw PatchInputError("Cây thư mục quá sâu. Hãy chọn thư mục con.") }
            try FileManager.default.createDirectory(at: local, withIntermediateDirectories: false,
                                                    attributes: [.posixPermissions: 0o700])
            for entry in try await contents(remote) {
                nodes += 1
                guard nodes <= maximumNodes else { throw PatchInputError("Thư mục có quá nhiều mục. Hãy chọn thư mục nhỏ hơn.") }
                let child = remote + "/" + entry.name
                let localChild = local.appendingPathComponent(entry.name, isDirectory: entry.kind == "directory")
                if entry.kind == "directory" {
                    try await copyDirectory(child, to: localChild, depth: depth + 1)
                } else if entry.kind == "file" {
                    try await copyFile(entry, path: child, to: localChild)
                } else {
                    throw PatchInputError("Không tạo patch từ liên kết hoặc tệp đặc biệt. Hãy chọn nguồn khác.")
                }
            }
        }

        if isDirectory {
            try await copyDirectory(source, to: staged.file, depth: 0)
        } else {
            let parent = (source as NSString).deletingLastPathComponent
            guard let entry = (try await contents(parent, matching: name)).first else {
                throw PatchInputError("Tệp nguồn không còn trong thư mục. Hãy tải lại danh sách.")
            }
            try await copyFile(entry, path: source, to: staged.file)
        }
        guard files > 0 else { throw PatchInputError("Thư mục chưa có tệp để tạo patch.") }

        var owner: String?
        var destination: String?
        let parts = source.split(separator: "/").map(String.init)
        if parts.count > 6, Array(parts.prefix(5)) == ["var", "mobile", "Containers", "Data", "Application"],
           UUID(uuidString: parts[5]) != nil {
            let root = "/" + parts.prefix(6).joined(separator: "/")
            let relative = parts.dropFirst(6).joined(separator: "/")
            if relative == "Documents" || relative.hasPrefix("Documents/") ||
                relative == "Library/Caches" || relative.hasPrefix("Library/Caches/") { destination = relative }
            do {
                let response = try await VersionedFilesTransport.patch("apps", as: Applications.self)
                let matches = response.apps.filter { $0.dataPath == root && $0.bundleID != nil }
                if matches.count == 1 { owner = matches[0].bundleID }
            } catch {
                if FileTransferSupport.cancelled(error) { throw error }


            }
        }
        try Task.checkCancellation()
        succeeded = true
        return PatchCaptureSource(staging: staged, sourceURL: staged.file, isDirectory: isDirectory,
                                  destination: destination, bundleID: owner, displayName: name)
    }

    private static func canonicalPath(_ path: String) throws -> String {
        let normalized = path.hasPrefix("/private/var/") ? String(path.dropFirst(8)) : path
        guard normalized.hasPrefix("/"), normalized != "/", !normalized.contains("//"),
              !normalized.contains("\\"), !normalized.unicodeScalars.contains(where: CharacterSet.controlCharacters.contains),
              (normalized as NSString).standardizingPath == normalized else {
            throw PatchInputError("Đường dẫn nguồn không hợp lệ.")
        }
        return normalized
    }
}
