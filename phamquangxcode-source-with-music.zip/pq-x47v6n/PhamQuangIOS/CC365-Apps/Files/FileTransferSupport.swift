import Foundation



final class FileTransferItem: @unchecked Sendable {
    let directory: URL
    let file: URL

    init(name: String) throws {
        guard FileTransferSupport.validName(name) else { throw FileTransferSupport.Failure.invalidName }
        let fm = FileManager.default
        let scratch = fm.temporaryDirectory.appendingPathComponent("CC365-Files", isDirectory: true)
        try fm.createDirectory(at: scratch, withIntermediateDirectories: true, attributes: [.posixPermissions: 0o700])
        let values = try scratch.resourceValues(forKeys: [.isSymbolicLinkKey, .isDirectoryKey])
        guard values.isSymbolicLink != true, values.isDirectory == true else { throw FileTransferSupport.Failure.staging }
        let unique = scratch.appendingPathComponent(UUID().uuidString, isDirectory: true)
        try fm.createDirectory(at: unique, withIntermediateDirectories: false, attributes: [.posixPermissions: 0o700])
        directory = unique
        file = unique.appendingPathComponent(name, isDirectory: false)
    }

    func remove() { try? FileManager.default.removeItem(at: directory) }
    deinit { remove() }
}

enum FileTransferSupport {
    static let maxSize: UInt64 = 256 * 1024 * 1024

    enum Failure: LocalizedError {
        case invalidName, staging, tooLarge, notRegular
        var errorDescription: String? {
            switch self {
            case .invalidName: return "Tên tệp hoặc thư mục không hợp lệ."
            case .tooLarge: return "Mỗi lần có thể chuyển một tệp tối đa 256 MiB."
            case .staging: return "Chưa tạo được bản sao tạm. Hãy kiểm tra dung lượng trống."
            case .notRegular: return "Hãy chọn một tệp thông thường để nhập."
            }
        }
    }

    static func validName(_ name: String) -> Bool {
        !name.isEmpty && name != "." && name != ".." && name.utf8.count <= 255
            && !name.contains("/") && !name.contains("\\")
            && !name.unicodeScalars.contains(where: CharacterSet.controlCharacters.contains)
    }
    static func cancelled(_ error: Error) -> Bool {
        if error is CancellationError { return true }
        let ns = error as NSError
        return ns.domain == NSCocoaErrorDomain && ns.code == NSUserCancelledError
    }
    static func message(_ error: Error) -> String {
        if let localized = error as? LocalizedError, let text = localized.errorDescription { return text }
        let native = error as NSError
        if let text = native.userInfo[NSLocalizedDescriptionKey] as? String, !text.isEmpty { return text }
        return "Chưa hoàn tất. Hãy kiểm tra quyền truy cập, dung lượng trống và thử lại."
    }



    private final class ImportCoordination: @unchecked Sendable {
        let reader = NSFileCoordinator()
        func cancel() { reader.cancel() }
    }

    static func isPatchArchive(_ source: URL) -> Bool {
        ["zip", "vailon", "vpatch"].contains(source.pathExtension.lowercased())
    }

    static func stageImport(_ source: URL) async throws -> FileTransferItem {
        return try await coordinatedImport(source) { url in
            let staged = try FileTransferItem(name: source.lastPathComponent)
            _ = try copyRegularFile(from: url, to: staged.file, limit: maxSize)
            return staged
        }
    }

    static func coordinatedImport<T: Sendable>(_ source: URL, read: @escaping @Sendable (URL) throws -> T) async throws -> T {
        let coordinator = ImportCoordination()
        let worker = Task.detached(priority: .userInitiated) {
            try Task.checkCancellation()
            let access = source.startAccessingSecurityScopedResource()
            defer { if access { source.stopAccessingSecurityScopedResource() } }
            var coordinationError: NSError?
            var outcome: Result<T, Error>?
            coordinator.reader.coordinate(readingItemAt: source, options: [], error: &coordinationError) { url in
                outcome = Result { try read(url) }
            }
            if let coordinationError { throw coordinationError }
            guard let outcome else { throw Failure.staging }
            try Task.checkCancellation()
            return try outcome.get()
        }
        return try await withTaskCancellationHandler(operation: { try await worker.value }, onCancel: {
            worker.cancel()
            coordinator.cancel()
        })
    }

    static func copyRegularFile(from inputURL: URL, to outputURL: URL, limit: UInt64) throws -> UInt64 {
        try Task.checkCancellation()
        let values = try inputURL.resourceValues(forKeys: [.isRegularFileKey, .isSymbolicLinkKey, .fileSizeKey])
        guard values.isRegularFile == true, values.isSymbolicLink != true else { throw Failure.notRegular }
        if let size = values.fileSize, UInt64(max(0, size)) > limit { throw Failure.tooLarge }
        let input = try FileHandle(forReadingFrom: inputURL)
        defer { try? input.close() }
        guard FileManager.default.createFile(atPath: outputURL.path, contents: nil, attributes: [.posixPermissions: 0o600]) else {
            throw Failure.staging
        }
        let output = try FileHandle(forWritingTo: outputURL)
        defer { try? output.close() }
        var copied: UInt64 = 0
        while true {
            try Task.checkCancellation()
            guard let buffer = try input.read(upToCount: 256 * 1024), !buffer.isEmpty else { break }
            copied += UInt64(buffer.count)
            guard copied <= limit else { throw Failure.tooLarge }
            try output.write(contentsOf: buffer)
        }
        try output.synchronize()
        return copied
    }
}
