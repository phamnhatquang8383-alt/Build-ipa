import Foundation
import CryptoKit
import CommonCrypto
import Security

struct PatchArchivePasswordRequired: LocalizedError, Sendable {
    var errorDescription: String? { "Gói patch này được mã hóa. Hãy nhập mật khẩu để mở trong PhamQuang IOS." }
}

struct PatchArchiveCrypto {
    private static let magic = Data("V99PATCH".utf8)
    private static let version: UInt8 = 1
    private static let saltSize = 16
    private static let noncePrefixSize = 8
    private static let chunkSize = 1_048_576
    private static let rounds: UInt32 = 600_000
    private static let maximumArchiveSize: UInt64 = 264 * 1_048_576

    static func isEncryptedFile(_ url: URL) -> Bool {
        guard let handle = try? FileHandle(forReadingFrom: url) else { return false }
        defer { try? handle.close() }
        return (try? readUpTo(handle, count: magic.count)) == magic
    }

    static func encrypt(_ source: URL, to destination: URL, password: String) throws {
        try validatePassword(password)
        try validateRegularFile(source)
        let attributes = try FileManager.default.attributesOfItem(atPath: source.path)
        guard let sourceSize = attributes[.size] as? NSNumber,
              sourceSize.uint64Value > 0, sourceSize.uint64Value <= maximumArchiveSize else {
            throw PatchArchiveCryptoError.invalidArchive
        }

        var salt = Data(count: saltSize)
        var prefix = Data(count: noncePrefixSize)
        guard salt.withUnsafeMutableBytes({ SecRandomCopyBytes(kSecRandomDefault, saltSize, $0.baseAddress!) }) == errSecSuccess,
              prefix.withUnsafeMutableBytes({ SecRandomCopyBytes(kSecRandomDefault, noncePrefixSize, $0.baseAddress!) }) == errSecSuccess else {
            throw PatchArchiveCryptoError.cryptoFailure
        }

        var header = magic
        header.append(version)
        header.append(salt)
        header.append(prefix)
        header.append(contentsOf: UInt32(chunkSize).bigEndianBytes)
        header.append(contentsOf: sourceSize.uint64Value.bigEndianBytes)
        let key = try deriveKey(password: password, salt: salt)
        try processEncrypt(source: source, destination: destination, header: header, prefix: prefix,
                           expectedSize: sourceSize.uint64Value, key: key)
    }

    static func decrypt(_ source: URL, to destination: URL, password: String) throws {
        try validatePassword(password)
        try validateRegularFile(source)
        let input = try FileHandle(forReadingFrom: source)
        defer { try? input.close() }

        let headerSize = magic.count + 1 + saltSize + noncePrefixSize + 4 + 8
        guard let header = try readUpTo(input, count: headerSize), header.count == headerSize,
              header.prefix(magic.count) == magic,
              header[magic.count] == version else { throw PatchArchiveCryptoError.invalidArchive }
        let saltStart = magic.count + 1
        let salt = header.subdata(in: saltStart..<(saltStart + saltSize))
        let prefixStart = saltStart + saltSize
        let prefix = header.subdata(in: prefixStart..<(prefixStart + noncePrefixSize))
        let chunkOffset = prefixStart + noncePrefixSize
        let chunkSizeValue = header[chunkOffset..<(chunkOffset + 4)].reduce(UInt32(0)) { ($0 << 8) | UInt32($1) }
        let expectedSize = header.suffix(8).reduce(UInt64(0)) { ($0 << 8) | UInt64($1) }
        guard chunkSizeValue == UInt32(chunkSize), expectedSize > 0, expectedSize <= maximumArchiveSize else {
            throw PatchArchiveCryptoError.invalidArchive
        }
        let key = try deriveKey(password: password, salt: salt)
        try processDecrypt(input: input, destination: destination, header: header, prefix: prefix,
                           expectedSize: expectedSize, key: key)
    }

    private static func processEncrypt(source: URL, destination: URL, header: Data, prefix: Data,
                                       expectedSize: UInt64, key: SymmetricKey) throws {
        let input = try FileHandle(forReadingFrom: source)
        defer { try? input.close() }
        let partial = destination.appendingPathExtension("partial-" + UUID().uuidString)
        defer { try? FileManager.default.removeItem(at: partial) }
        guard createProtectedFile(partial) else {
            throw PatchArchiveCryptoError.ioFailure
        }
        let output = try FileHandle(forWritingTo: partial)
        defer { try? output.close() }
        try output.write(contentsOf: header)
        var index: UInt32 = 0
        var total: UInt64 = 0
        while true {
            try Task.checkCancellation()
            guard let chunk = try readUpTo(input, count: chunkSize), !chunk.isEmpty else { break }
            total += UInt64(chunk.count)
            guard total <= maximumArchiveSize, index < 512 else { throw PatchArchiveCryptoError.invalidArchive }
            let nonceData = nonce(prefix: prefix, index: index)
            let box = try AES.GCM.seal(chunk, using: key, nonce: AES.GCM.Nonce(data: nonceData),
                                       authenticating: aad(header: header, index: index, length: UInt32(chunk.count)))
            guard let combined = box.combined else { throw PatchArchiveCryptoError.cryptoFailure }
            try output.write(contentsOf: UInt32(combined.count).bigEndianData)
            try output.write(contentsOf: combined)
            index += 1
        }
        guard total > 0, total == expectedSize else { throw PatchArchiveCryptoError.invalidArchive }
        try output.synchronize()
        try output.close()
        try FileManager.default.moveItem(at: partial, to: destination)
        do { try protect(destination) }
        catch { try? FileManager.default.removeItem(at: destination); throw error }
    }

    private static func processDecrypt(input: FileHandle, destination: URL, header: Data, prefix: Data,
                                       expectedSize: UInt64, key: SymmetricKey) throws {
        let partial = destination.appendingPathExtension("partial-" + UUID().uuidString)
        defer { try? FileManager.default.removeItem(at: partial) }
        guard createProtectedFile(partial) else {
            throw PatchArchiveCryptoError.ioFailure
        }
        let output = try FileHandle(forWritingTo: partial)
        defer { try? output.close() }
        var index: UInt32 = 0
        var total: UInt64 = 0
        while true {
            try Task.checkCancellation()
            guard let lengthData = try readUpTo(input, count: 4) else { break }
            guard lengthData.count == 4 else { throw PatchArchiveCryptoError.invalidArchive }
            let combinedLength = lengthData.reduce(UInt32(0)) { ($0 << 8) | UInt32($1) }
            guard combinedLength >= 28, combinedLength <= UInt32(chunkSize + 28), index < 512,
                  let combined = try readUpTo(input, count: Int(combinedLength)), combined.count == Int(combinedLength) else {
                throw PatchArchiveCryptoError.invalidArchive
            }
            let plainLength = UInt32(combinedLength - 28)
            guard plainLength > 0, plainLength <= UInt32(chunkSize) else { throw PatchArchiveCryptoError.invalidArchive }
            let box = try AES.GCM.SealedBox(combined: combined)
            let expectedNonce = nonce(prefix: prefix, index: index)
            guard Data(box.nonce) == expectedNonce else { throw PatchArchiveCryptoError.invalidArchive }
            let plain: Data
            do {
                plain = try AES.GCM.open(box, using: key,
                    authenticating: aad(header: header, index: index, length: plainLength))
            } catch {
                throw PatchArchiveCryptoError.cryptoFailure
            }
            guard plain.count == Int(plainLength) else { throw PatchArchiveCryptoError.invalidArchive }
            total += UInt64(plain.count)
            guard total <= maximumArchiveSize else { throw PatchArchiveCryptoError.invalidArchive }
            try output.write(contentsOf: plain)
            index += 1
        }
        guard total > 0, total == expectedSize else { throw PatchArchiveCryptoError.invalidArchive }
        try output.synchronize()
        try output.close()
        try FileManager.default.moveItem(at: partial, to: destination)
        do { try protect(destination) }
        catch { try? FileManager.default.removeItem(at: destination); throw error }
    }

    private static func readUpTo(_ handle: FileHandle, count: Int) throws -> Data? {
        var result = Data()
        while result.count < count {
            guard let part = try handle.read(upToCount: count - result.count), !part.isEmpty else { break }
            result.append(part)
        }
        return result.isEmpty ? nil : result
    }

    private static func deriveKey(password: String, salt: Data) throws -> SymmetricKey {
        let passwordData = Data(password.utf8)
        var derived = Data(count: 32)
        let status = passwordData.withUnsafeBytes { passwordBytes in
            salt.withUnsafeBytes { saltBytes in
                derived.withUnsafeMutableBytes { derivedBytes in
                    CCKeyDerivationPBKDF(CCPBKDFAlgorithm(kCCPBKDF2),
                        passwordBytes.bindMemory(to: Int8.self).baseAddress, passwordData.count,
                        saltBytes.bindMemory(to: UInt8.self).baseAddress, salt.count,
                        CCPseudoRandomAlgorithm(kCCPRFHmacAlgSHA256), rounds,
                        derivedBytes.bindMemory(to: UInt8.self).baseAddress, derived.count)
                }
            }
        }
        guard status == kCCSuccess else { throw PatchArchiveCryptoError.cryptoFailure }
        return SymmetricKey(data: derived)
    }

    private static func validatePassword(_ password: String) throws {
        guard password.count >= 12, password.utf8.count <= 1024 else {
            throw PatchArchiveCryptoError.weakPassword
        }
    }

    private static func validateRegularFile(_ url: URL) throws {
        let values = try url.resourceValues(forKeys: [.isRegularFileKey, .isSymbolicLinkKey])
        guard values.isRegularFile == true, values.isSymbolicLink != true else {
            throw PatchArchiveCryptoError.invalidArchive
        }
    }

    private static func createProtectedFile(_ url: URL) -> Bool {
        #if os(iOS)
        return FileManager.default.createFile(atPath: url.path, contents: nil,
            attributes: [.posixPermissions: 0o600, .protectionKey: FileProtectionType.complete])
        #else
        return FileManager.default.createFile(atPath: url.path, contents: nil, attributes: [.posixPermissions: 0o600])
        #endif
    }

    private static func protect(_ url: URL) throws {
        #if os(iOS)
        try FileManager.default.setAttributes([.posixPermissions: 0o600, .protectionKey: FileProtectionType.complete],
                                              ofItemAtPath: url.path)
        #else
        try FileManager.default.setAttributes([.posixPermissions: 0o600], ofItemAtPath: url.path)
        #endif
    }

    private static func nonce(prefix: Data, index: UInt32) -> Data {
        var value = prefix
        value.append(contentsOf: index.bigEndianBytes)
        return value
    }

    private static func aad(header: Data, index: UInt32, length: UInt32) -> Data {
        var value = header
        value.append(contentsOf: index.bigEndianBytes)
        value.append(contentsOf: length.bigEndianBytes)
        return value
    }
}

private enum PatchArchiveCryptoError: LocalizedError, Sendable {
    case weakPassword, invalidArchive, cryptoFailure, ioFailure
    var errorDescription: String? {
        switch self {
        case .weakPassword: return "Mật khẩu patch phải có ít nhất 12 ký tự."
        case .invalidArchive: return "Gói patch mã hóa không hợp lệ, bị cắt cụt hoặc vượt giới hạn."
        case .cryptoFailure: return "Không thể xác thực hoặc giải mã patch. Hãy kiểm tra mật khẩu và tính toàn vẹn của tệp."
        case .ioFailure: return "Không tạo được tệp tạm bảo vệ trong PhamQuang IOS."
        }
    }
}

private extension UInt32 {
    var bigEndianBytes: [UInt8] {
        let value = bigEndian
        return withUnsafeBytes(of: value) { Array($0) }
    }
    var bigEndianData: Data { Data(bigEndianBytes) }
}

private extension UInt64 {
    var bigEndianBytes: [UInt8] {
        let value = bigEndian
        return withUnsafeBytes(of: value) { Array($0) }
    }
}

#if os(iOS)
import SwiftUI

struct PatchPasswordPrompt: View {
    @Environment(\.dismiss) private var dismiss
    @State private var password = ""
    let onOpen: (String) -> Void

    var body: some View {
        NavigationStack {
            Form {
                Section("Mật khẩu patch") {
                    SecureField("Nhập mật khẩu", text: $password)
                        .textContentType(.password)
                        .textInputAutocapitalization(.never)
                        .autocorrectionDisabled()
                        .accessibilityIdentifier("patch-open-password")
                }
                Section {
                    Text("Mật khẩu chỉ được dùng để giải mã trong bộ nhớ và không được lưu lại. Nếu nhập sai, PhamQuang IOS sẽ không giải nén hoặc áp dụng dữ liệu.")
                        .font(.footnote).foregroundStyle(.secondary)
                }
            }
            .navigationTitle("Mở patch mã hóa")
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .cancellationAction) {
                    Button("Hủy") { dismiss() }
                }
                ToolbarItem(placement: .confirmationAction) {
                    Button("Mở") {
                        let submitted = password
                        password = ""
                        onOpen(submitted)
                        dismiss()
                    }
                    .disabled(password.isEmpty)
                }
            }
        }
        .presentationDetents([.medium])
        .interactiveDismissDisabled(false)
    }
}
#endif
