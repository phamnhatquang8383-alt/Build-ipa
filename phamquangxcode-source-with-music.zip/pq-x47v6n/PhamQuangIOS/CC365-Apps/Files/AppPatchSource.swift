import Foundation
import CC365Core

struct PatchTargetApp: Decodable, Hashable, Identifiable, Sendable {
    let bundleID: String?
    let name: String
    let bundlePath: String?
    let dataPath: String?
    var fileSharingEnabled: Bool? = nil
    var targetID: String? = nil
    var id: String { targetID ?? bundleID ?? "path:" + (dataPath ?? bundlePath ?? "") }
    var displayName: String {
        if !name.isEmpty { return name }
        if let bundleID, !bundleID.isEmpty { return bundleID }
        return "Container " + ((dataPath ?? bundlePath).map { URL(fileURLWithPath: $0).lastPathComponent } ?? "")
    }
    var identityDescription: String { bundleID ?? dataPath ?? bundlePath ?? "Chưa nhận diện ứng dụng" }

    enum CodingKeys: String, CodingKey {
        case bundleID = "bundle_id", name, bundlePath = "bundle_path", dataPath = "data_path", fileSharingEnabled = "file_sharing_enabled", targetID = "target_id"
    }
    func root(for scope: PatchScope) -> String? { scope == .bundle ? bundlePath : dataPath }
}

enum PatchScope: String, Hashable, CaseIterable, Decodable, Sendable {
    case data, bundle
    var title: String { self == .bundle ? "Gói .app" : "Dữ liệu" }
}

struct PatchOmission: Decodable, Sendable {
    let path: String
    let reason: String
}

struct PatchStatus: Decodable, Sendable {
    enum State: String, Decodable { case none, applied, pending, restored, unchanged }
    let state: State
    let changed: Int
    let created: Int?
    let omitted_items: [PatchOmission]?
    let restore_paths: [String]?
    let skipped: Int
    let bytes: UInt64
    let message: String
    var hasBackup: Bool { state == .pending || state == .applied }
}

struct PatchFileMapping: Identifiable {
    let destination: String
    let local: URL
    let size: UInt64
    var id: String { destination }
}

struct PatchInputError: LocalizedError {
    let errorDescription: String?
    init(_ text: String) { errorDescription = text }
}

enum PatchDestination {
    static let cacheRoot = "Library/Caches"
    static let selectedCache = "Application//" + cacheRoot + "/"

    static func resolve(_ input: String, app: PatchTargetApp, scope: PatchScope, isDirectory: Bool) throws -> String {
        var path = input
        if input.hasPrefix("Application/") {
            guard scope == .data, app.dataPath != nil else {
                throw PatchInputError("Chọn vùng Dữ liệu để dùng đường dẫn Application//.")
            }
            let suffix = input.dropFirst("Application/".count)
            guard let separator = suffix.firstIndex(of: "/") else {
                throw PatchInputError("Sau Application//, nhập đường dẫn trong Documents hoặc Library/Caches.")
            }
            let owner = suffix[..<separator]
            if !owner.isEmpty && app.bundleID == nil {
                throw PatchInputError("Chưa đọc được bundle ID của container này. Dùng Application// hoặc đường dẫn trong container đã chọn.")
            }
            guard owner.isEmpty || app.bundleID.map({ String(owner) == $0 }) == true else {
                throw PatchInputError("Đường dẫn dành cho ứng dụng khác. Hãy chọn đúng ứng dụng hoặc dùng Application// cho \(app.displayName).")
            }
            path = String(suffix[suffix.index(after: separator)...])
            guard path == cacheRoot || path.hasPrefix(cacheRoot + "/") || path == "Documents" || path.hasPrefix("Documents/") else {
                throw PatchInputError("Sau tên ứng dụng, hãy nhập Documents/ hoặc Library/Caches/ và đường dẫn đích.")
            }
        }
        let relativePath = try relative(path, root: app.root(for: scope), isDirectory: isDirectory)
        if scope == .data && !isDirectory && (relativePath == cacheRoot || relativePath == "Documents") {
            throw PatchInputError("Nhập cả tên tệp đích trong thư mục này.")
        }
        return relativePath
    }


    static func embedded(_ input: String) throws -> String {
        guard input.hasPrefix("Documents/") || input.hasPrefix(cacheRoot + "/") else {
            throw PatchInputError("Đường dẫn trong thư mục phải nằm trong Documents hoặc Library/Caches của ứng dụng.")
        }
        return try relative(input, root: nil, isDirectory: false)
    }

    static func relative(_ input: String, root: String?, isDirectory: Bool) throws -> String {
        var path = input
        var absolute = false
        if path.hasPrefix("/") {
            absolute = true
            func unified(_ value: String) -> String {
                value.hasPrefix("/private/var/") ? String(value.dropFirst(8)) : value
            }
            guard let root, !root.isEmpty else {
                throw PatchInputError("Chưa xác định được thư mục của ứng dụng này. Hãy dùng đường dẫn tương đối.")
            }
            let base = unified(root)
            path = unified(path)
            if path == base { path = "" }
            else if path.hasPrefix(base + "/") { path = String(path.dropFirst(base.count + 1)) }
            else { throw PatchInputError("Đường dẫn nằm ngoài vùng đã chọn của ứng dụng.") }
        }
        if isDirectory, path.hasSuffix("/") { path.removeLast() }
        if path.isEmpty {
            guard isDirectory else {
                throw PatchInputError(absolute ? "Hãy nhập cả tên tệp đích." : "Nhập đường dẫn của tệp đích.")
            }
            return ""
        }
        let components = path.split(separator: "/", omittingEmptySubsequences: false)
        guard path.utf8.count <= 1024, components.count <= 32,
              components.allSatisfy({ !$0.hasPrefix(".") && FileTransferSupport.validName(String($0)) }) else {
            throw PatchInputError("Đường dẫn chứa thành phần không hợp lệ.")
        }
        return path
    }
}

final class AppPatchSource: @unchecked Sendable {
    struct File {
        let path: String
        let local: URL
        let size: UInt64
    }

    static let maxFiles = 1024
    static let perFile: UInt64 = 128 * 1024 * 1024
    static let total: UInt64 = 256 * 1024 * 1024
    let name: String
    let isDirectory: Bool
    let files: [File]
    let size: UInt64


    let embeddedBundleID: String?
    private let observedContainerRoot: String?
    var usesExplicitContainerSelection: Bool { observedContainerRoot != nil }
    private let embeddedTargetID: String?
    private let embeddedMappings: [PatchFileMapping]?
    var hasEmbeddedDestinations: Bool { embeddedMappings != nil }


    private let transfer: FileTransferItem

    private init(name: String, isDirectory: Bool, transfer: FileTransferItem, files: [File], size: UInt64, targetID: String? = nil, bundleID: String? = nil, observedRoot: String? = nil) throws {
        self.name = name
        self.isDirectory = isDirectory
        self.transfer = transfer
        self.files = files
        self.size = size
        self.observedContainerRoot = observedRoot
        self.embeddedTargetID = targetID
        self.embeddedBundleID = bundleID
        if targetID != nil || bundleID != nil {
            let mapped = files.map { PatchFileMapping(destination: $0.path, local: $0.local, size: $0.size) }
            try Self.validate(mapped, scope: .data)
            self.embeddedMappings = mapped
        } else {
            self.embeddedMappings = nil
        }
    }

    private enum Layout {
        case workspace
        case applicationDirectory
        case app(owner: String, base: [String])

        func ownedPath(_ path: String) throws -> (owner: String, relative: String) {
            var parts = path.split(separator: "/").map(String.init)
            let owner: String
            switch self {
            case .workspace:
                guard parts.first == "Application", parts.count >= 3 else {
                    throw PatchInputError("Thư mục đã chọn chứa nhiều vùng dữ liệu. Hãy chọn thư mục của ứng dụng trong Application.")
                }
                owner = parts[1]
                parts.removeFirst(2)
            case .applicationDirectory:
                guard parts.count >= 2 else { throw PatchInputError("Thư mục Application cần chứa thư mục bundle ID.") }
                owner = parts.removeFirst()
            case let .app(identifier, base):
                owner = identifier
                parts = base + parts
            }
            return (owner, try PatchDestination.embedded(parts.joined(separator: "/")))
        }

        static func detect(_ selection: URL, coordinated url: URL, isDirectory: Bool, owner: String?) throws -> Layout? {
            var ancestry = selection.pathComponents
            if !isDirectory { ancestry.removeLast() }




            for index in ancestry.indices where ancestry[index] == "Application" {
                if index == ancestry.count - 1 { return .applicationDirectory }
                let name = ancestry[index + 1]

                if name == owner || UUID(uuidString: name) == nil {
                    return .app(owner: name, base: Array(ancestry.dropFirst(index + 2)))
                }
            }
            guard isDirectory else { return nil }
            if let owner, selection.lastPathComponent == owner { return .app(owner: owner, base: []) }
            let children = try FileManager.default.contentsOfDirectory(atPath: url.path).filter { !$0.hasPrefix(".") && $0 != "__MACOSX" }
            if children.contains("Application") { return .workspace }
            let selectedName = selection.lastPathComponent
            if AppPatchSource.validBundleID(selectedName), selectedName.contains("."), UUID(uuidString: selectedName) == nil,
               !children.isEmpty, children.allSatisfy({ $0 == "Documents" || $0 == "Library" }) {
                if children.contains("Library") {
                    let library = try FileManager.default.contentsOfDirectory(atPath: url.appendingPathComponent("Library").path)
                        .filter { !$0.hasPrefix(".") && $0 != "__MACOSX" }
                    guard library.allSatisfy({ $0 == "Caches" }) else { return nil }
                }
                return .app(owner: selectedName, base: [])
            }
            return nil
        }
    }

    private static func validBundleID(_ value: String) -> Bool {
        let allowed = CharacterSet(charactersIn: "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789.-_")
        return !value.isEmpty && value.utf8.count <= 255 && !value.hasPrefix(".") && !value.hasSuffix(".")
            && !value.contains("..") && value.rangeOfCharacter(from: allowed.inverted) == nil
    }

    private struct SourcePaths {
        let paths: [String]
        let owner: String?
        let targetID: String?
    }



    private static func sourcePaths(_ paths: [String], layout: Layout? = nil,
                                    app: PatchTargetApp?, scope: PatchScope) throws -> SourcePaths {
        var owned: [(owner: String, relative: String)]?
        if let layout {
            owned = try paths.map { try layout.ownedPath($0) }
        } else {
            let components = paths.map { $0.split(separator: "/").map(String.init) }
            var start = 0
            if let first = components.first {
                while start < first.count - 1 && !["Application", "Documents", "Library"].contains(first[start])
                        && components.allSatisfy({ $0.count > start + 1 && $0[start] == first[start] }) { start += 1 }
            }
            let wrapped = components.map { Array($0.dropFirst(start)) }
            if wrapped.contains(where: { $0.first == "Application" }) {
                owned = try wrapped.map {
                    guard $0.count >= 4, $0[0] == "Application" else {
                        throw PatchInputError("Gói nguồn chứa nhiều vùng dữ liệu. Hãy chọn gói của một ứng dụng.")
                    }
                    return ($0[1], try PatchDestination.embedded($0.dropFirst(2).joined(separator: "/")))
                }
            } else if components.contains(where: { parts in



                for part in parts.dropLast() {
                    if part == "Documents" || part == "Library" { return false }
                    if part == "Application" { return true }
                }
                return false
            }) {
                throw PatchInputError("Gói nguồn có nhiều thư mục bao ngoài hoặc lẫn tệp ngoài Application. Hãy chọn riêng nguồn của một ứng dụng.")
            } else if scope == .data, let app, app.dataPath != nil, wrapped.allSatisfy({
                ($0.count > 1 && $0[0] == "Documents") || ($0.count > 2 && $0[0] == "Library" && $0[1] == "Caches")
            }) {
                return SourcePaths(paths: try wrapped.map { try PatchDestination.embedded($0.joined(separator: "/")) }, owner: nil, targetID: app.id)
            }
        }
        guard let owned else { return SourcePaths(paths: paths, owner: nil, targetID: nil) }
        guard let owner = owned.first?.owner, validBundleID(owner), owned.allSatisfy({ validBundleID($0.owner) && $0.owner == owner }) else {
            throw PatchInputError("Gói nguồn chứa bundle ID không hợp lệ hoặc nhiều ứng dụng. Hãy chọn nguồn của một ứng dụng.")
        }
        guard scope == .data else { throw PatchInputError("Gói Application/ cần dùng vùng Dữ liệu.") }
        if let app {
            guard app.dataPath != nil, app.bundleID == owner else {
                throw PatchInputError("Gói này dành cho \(owner). Cần xác định đúng thư mục dữ liệu của ứng dụng đó.")
            }
        }
        return SourcePaths(paths: owned.map(\.relative), owner: owner, targetID: app?.id)
    }

    private struct ZIPMember: Decodable {
        let path: String
        let size: UInt64
        init(from decoder: Decoder) throws {
            var row = try decoder.unkeyedContainer()
            path = try row.decode(String.self)
            size = try row.decode(UInt64.self)
        }
    }



    private static func stageZIP(_ source: URL, name: String, app: PatchTargetApp?, scope: PatchScope, workMode: FileWorkMode) throws -> AppPatchSource {
        let scratch = try FileTransferItem(name: name)
        let status = source.withUnsafeFileSystemRepresentation { input in
            scratch.directory.withUnsafeFileSystemRepresentation { output in
                cc365_patch_extract_zip_with_mode(input, output, workMode.nativeValue) { Task.isCancelled }
            }
        }
        switch status {
        case 0: break
        case 2: throw PatchInputError("ZIP chứa đường dẫn trùng, không hợp lệ hoặc liên kết.")
        case 3: throw PatchInputError("ZIP vượt giới hạn: tối đa 1.024 tệp, 128 MiB mỗi tệp và 256 MiB sau giải nén.")
        case 5: throw PatchInputError("Không đọc được ZIP hoặc không đủ chỗ để giải nén trong PhamQuang IOS.")
        case 6: throw CancellationError()
        case 7: throw PatchInputError("ZIP này không có tệp dữ liệu để nhập.")
        default: throw PatchInputError("Không giải nén được ZIP. Hãy kiểm tra tệp có bị hỏng, có mật khẩu hoặc dùng kiểu nén chưa được hỗ trợ không.")
        }
        try Task.checkCancellation()
        let members = try JSONDecoder().decode([ZIPMember].self, from: Data(contentsOf: scratch.directory.appendingPathComponent("members.json")))
        let mapped = try sourcePaths(members.map(\.path), app: app, scope: scope)
        let embedded = mapped.owner != nil || mapped.targetID != nil
        let files: [File] = try members.indices.map { index in
            let path = mapped.paths[index]
            let checked = try embedded ? PatchDestination.embedded(path) : PatchDestination.relative(path, root: nil, isDirectory: false)
            return File(path: checked, local: scratch.directory.appendingPathComponent(String(index)), size: members[index].size)
        }


        if !embedded {
            try validate(files.map { PatchFileMapping(destination: $0.path, local: $0.local, size: $0.size) }, scope: .bundle)
        }
        return try AppPatchSource(name: name, isDirectory: true, transfer: scratch, files: files.sorted { $0.path < $1.path },
                                  size: files.reduce(0) { $0 + $1.size }, targetID: mapped.targetID, bundleID: mapped.owner)
    }

    static func stage(_ selection: URL, app: PatchTargetApp? = nil, scope: PatchScope = .data,
                      expectDirectory: Bool? = nil, password: String? = nil) async throws -> AppPatchSource {
        let settings = AppFileSettings.load()
        return try await FileTransferSupport.coordinatedImport(selection) { source in
            let fm = FileManager.default
            let keys: Set<URLResourceKey> = [.isDirectoryKey, .isSymbolicLinkKey, .isRegularFileKey, .fileSizeKey]
            let entry = try source.resourceValues(forKeys: keys)
            guard entry.isSymbolicLink != true else { throw PatchInputError("Hãy chọn tệp hoặc thư mục gốc thay cho liên kết.") }
            let isDirectory = entry.isDirectory == true
            if let expectDirectory, isDirectory != expectDirectory {
                throw PatchInputError(expectDirectory ? "Hãy chọn một thư mục nguồn." : "Hãy chọn một tệp nguồn hoặc dùng nút chọn thư mục.")
            }
            if entry.isRegularFile == true {
                if PatchArchiveCrypto.isEncryptedFile(source) {
                    guard let password else { throw PatchArchivePasswordRequired() }
                    let plaintext = try FileTransferItem(name: "decrypted-patch.zip")
                    defer { plaintext.remove() }
                    try PatchArchiveCrypto.decrypt(source, to: plaintext.file, password: password)
                    return try stageZIP(plaintext.file, name: selection.lastPathComponent, app: app,
                                        scope: scope, workMode: settings.workMode)
                }
                if FileTransferSupport.isPatchArchive(selection) {
                    return try stageZIP(source, name: selection.lastPathComponent, app: app, scope: scope, workMode: settings.workMode)
                }
            }
            let scratch = try FileTransferItem(name: selection.lastPathComponent)
            let layout = try Layout.detect(selection, coordinated: source, isDirectory: isDirectory, owner: app?.bundleID)
            var files: [File] = []
            var bytes: UInt64 = 0
            var visited = 0

            func collect(_ url: URL, path: String, depth: Int) throws {
                try Task.checkCancellation()
                visited += 1
                guard depth <= 34, visited <= 4096, path.utf8.count <= 1536 else {
                    throw PatchInputError("Cây thư mục quá lớn. Hãy chia patch thành các thư mục nhỏ hơn.")
                }
                let values = try url.resourceValues(forKeys: keys)
                guard values.isSymbolicLink != true else { throw PatchInputError("Thư mục đã chọn chứa liên kết tại “\(path)”.") }
                if values.isDirectory == true {
                    let children = try fm.contentsOfDirectory(at: url, includingPropertiesForKeys: Array(keys), options: .skipsHiddenFiles)
                    for child in children {
                        let name = child.lastPathComponent

                        if name.hasPrefix(".") || name == "__MACOSX" { continue }
                        guard FileTransferSupport.validName(name) else { throw FileTransferSupport.Failure.invalidName }
                        try collect(child, path: path.isEmpty ? name : path + "/" + name, depth: depth + 1)
                    }
                    return
                }
                guard values.isRegularFile == true else { throw FileTransferSupport.Failure.notRegular }
                guard files.count < maxFiles else { throw PatchInputError("Một patch hỗ trợ tối đa \(maxFiles) tệp.") }
                let limit = min(perFile, total - bytes)
                let local = scratch.directory.appendingPathComponent(UUID().uuidString)
                do {
                    let size = try FileTransferSupport.copyRegularFile(from: url, to: local, limit: limit)
                    files.append(File(path: path, local: local, size: size))
                    bytes += size
                } catch FileTransferSupport.Failure.tooLarge {
                    throw PatchInputError("Mỗi tệp tối đa 128 MiB, toàn bộ patch tối đa 256 MiB.")
                }
            }

            try collect(source, path: isDirectory ? "" : selection.lastPathComponent, depth: 0)
            guard !files.isEmpty else { throw PatchInputError("Thư mục này chưa có tệp nào để áp dụng.") }
            let mapped = try sourcePaths(files.map(\.path), layout: layout, app: app, scope: scope)
            let mappedFiles = files.indices.map { File(path: mapped.paths[$0], local: files[$0].local, size: files[$0].size) }
            return try AppPatchSource(name: selection.lastPathComponent, isDirectory: isDirectory, transfer: scratch,
                                      files: mappedFiles.sorted { $0.path < $1.path }, size: bytes,
                                      targetID: mapped.targetID, bundleID: mapped.owner)
        }
    }




    func targetingUnownedSource(app: PatchTargetApp, scope: PatchScope) throws -> AppPatchSource {
        guard embeddedBundleID == nil, embeddedTargetID == nil, observedContainerRoot == nil else {
            throw PatchInputError("Nguồn đã gắn với một ứng dụng. Hãy chọn lại nguồn nếu muốn đổi đích.")
        }
        let mapped = try Self.sourcePaths(files.map(\.path), app: app, scope: scope)
        let mappedFiles = files.indices.map { File(path: mapped.paths[$0], local: files[$0].local, size: files[$0].size) }
        return try AppPatchSource(name: name, isDirectory: isDirectory, transfer: transfer,
            files: mappedFiles.sorted { $0.path < $1.path }, size: size,
            targetID: mapped.targetID, bundleID: mapped.owner)
    }



    func binding(toObservedContainer app: PatchTargetApp) throws -> AppPatchSource {
        guard embeddedMappings != nil, let owner = embeddedBundleID,
              embeddedTargetID == nil, observedContainerRoot == nil,
              let root = app.dataPath, root.hasPrefix("/var/mobile/Containers/Data/Application/"),
              root.split(separator: "/").count == 6,
              UUID(uuidString: URL(fileURLWithPath: root).lastPathComponent) != nil,
              app.targetID == "path:" + root,
              app.bundleID == nil || app.bundleID == owner else {
            throw PatchInputError("Chỉ chọn container dữ liệu đã quan sát, không có định danh mâu thuẫn. Hãy chọn lại nguồn nếu muốn đổi đích.")
        }
        return try AppPatchSource(name: name, isDirectory: isDirectory, transfer: transfer, files: files,
            size: size, targetID: app.id, bundleID: owner, observedRoot: root)
    }

    func mappings(destination: String, app: PatchTargetApp, scope: PatchScope) throws -> [PatchFileMapping] {
        if let embeddedMappings {
            guard scope == .data, let root = app.dataPath, !root.isEmpty,
                  embeddedTargetID == nil || app.id == embeddedTargetID,
                  observedContainerRoot == nil || app.dataPath == observedContainerRoot,
                  embeddedBundleID == nil || app.bundleID == embeddedBundleID || (observedContainerRoot != nil && app.bundleID == nil) else {
                throw PatchInputError("Cần xác định đúng ứng dụng và thư mục dữ liệu trước khi áp dụng gói này.")
            }
            return embeddedMappings
        }
        let base = try PatchDestination.resolve(destination, app: app, scope: scope, isDirectory: isDirectory)
        let mappings = try files.map { file in
            let path = isDirectory ? (base.isEmpty ? file.path : base + "/" + file.path) : base
            _ = try PatchDestination.relative(path, root: nil, isDirectory: false)
            return PatchFileMapping(destination: path, local: file.local, size: file.size)
        }
        try Self.validate(mappings, scope: scope)
        return mappings
    }


    static func validate(_ mappings: [PatchFileMapping], scope: PatchScope) throws {
        var files = Set<String>()
        var parents = Set<String>()
        for item in mappings {
            let key = item.destination.precomposedStringWithCanonicalMapping.lowercased()
            guard files.insert(key).inserted else { throw PatchInputError("Hai tệp trong patch trỏ tới cùng một đường dẫn.") }
            var prefix = key[...]
            while let slash = prefix.lastIndex(of: "/") {
                prefix = prefix[..<slash]
                parents.insert(String(prefix))
            }
        }
        guard files.isDisjoint(with: parents) else { throw PatchInputError("Một đường dẫn trong patch vừa là tệp vừa là thư mục.") }

    }
}
