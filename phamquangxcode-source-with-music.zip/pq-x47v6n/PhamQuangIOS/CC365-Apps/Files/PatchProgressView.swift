import SwiftUI

struct PatchProgressView: View {
    let feed: PatchProgressFeed
    let stopping: Bool
    let stop: () -> Void
    @State private var frame: PatchProgressFrame?
    @Environment(\.accessibilityReduceMotion) private var reduceMotion
    @Environment(\.colorSchemeContrast) private var contrast
    @ScaledMetric(relativeTo: .body) private var activeHeight: CGFloat = 46

    private var title: String {
        if stopping { return "Đang dừng an toàn" }
        switch frame?.event.phase {
        case "checking", "skipped": return "Kiểm tra và sao lưu"
        case "comparing": return "Đối chiếu tệp gốc"
        case "staging": return "Chuẩn bị tệp"
        case "applying", "applied": return "Áp dụng patch"
        case "unchanged": return "Tệp đã khớp"
        case "omitted": return "Bỏ qua tệp"
        case "restoring", "restored": return "Khôi phục bản gốc"
        case "preserved": return "Giữ tệp đã thay đổi"
        case "finishing": return "Hoàn tất phiên"
        case "complete": return "Đang xác nhận kết quả"
        default: return "Đang chuẩn bị xử lý"
        }
    }
    private func basename(_ path: String) -> String { path.split(separator: "/").last.map(String.init) ?? path }
    var body: some View {
        VStack(alignment: .leading, spacing: 10) {
            CC365TaskProgress(title: title,
                              completed: stopping ? nil : frame.map { Int64($0.event.done) },
                              total: stopping ? nil : frame.map { Int64($0.event.total) },
                              phaseKey: counterPhase)

            if let frame, !frame.active.isEmpty {
                VStack(spacing: 3) {
                    contextRow(frame.previous, above: true, label: "Trước đó")
                    Text(basename(frame.active))
                        .font(.callout.weight(.semibold))
                        .foregroundStyle(.primary)
                        .multilineTextAlignment(.center)
                        .lineLimit(2).truncationMode(.middle)
                        .id(frame.active).transition(rowTransition)
                        .frame(maxWidth: .infinity).frame(minHeight: activeHeight)
                        .padding(.horizontal, 4)
                        .accessibilityLabel("\(title): \(frame.active)")
                    contextRow(frame.upcoming, above: false, label: "Tiếp theo trong danh sách")
                }
                .clipped()
                .animation(reduceMotion ? nil : .easeInOut(duration: 0.20), value: frame.active)
            }
            if !stopping {
                Button(action: stop) {
                    Text("Dừng").frame(minWidth: 52, minHeight: 44)
                }.buttonStyle(.borderless).accessibilityLabel("Dừng xử lý patch")
            }
        }
        .padding(.vertical, 4)
        .accessibilityIdentifier("patch-working")
        .task(id: ObjectIdentifier(feed)) {
            for await item in feed.frames {
                guard !Task.isCancelled else { break }
                frame = item

                do { try await Task.sleep(for: .milliseconds(100)) } catch { break }
            }
        }
    }

    private var counterPhase: String {
        switch frame?.event.phase {
        case "checking", "skipped": return "checking"
        case "applying", "applied": return "apply"
        case "restoring", "restored", "preserved": return "restore"
        default: return frame?.event.phase ?? "preparing"
        }
    }

    private var rowTransition: AnyTransition {
        reduceMotion ? .identity : .asymmetric(insertion: .move(edge: .bottom).combined(with: .opacity),
                                               removal: .move(edge: .top).combined(with: .opacity))
    }
    private func contextRow(_ path: String, above: Bool, label: String) -> some View {


        let stronger = contrast == .increased
        return Text(path.isEmpty ? " " : basename(path))
            .font(.footnote)
            .foregroundStyle(.secondary)
            .lineLimit(1).truncationMode(.middle)
            .id(path).transition(rowTransition)
            .blur(radius: stronger ? 0 : 1.35)
            .opacity(stronger ? 0.9 : 0.50)
            .frame(maxWidth: .infinity, minHeight: 22)
            .mask(LinearGradient(colors: above ? [.black.opacity(stronger ? 1 : 0.55), .black] : [.black, .black.opacity(stronger ? 1 : 0.55)],
                                 startPoint: .top, endPoint: .bottom))
            .accessibilityLabel("\(label): \(path)").accessibilityHidden(path.isEmpty)
    }
}
