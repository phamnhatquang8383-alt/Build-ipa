import SwiftUI
import QuickLook

struct FilePresentation: Identifiable {
    let id = UUID()
    let staged: FileTransferItem
    let preferPreview: Bool
}

struct FilePresentationView: View {
    let item: FilePresentation
    let finish: () -> Void
    @State private var exporting = false

    var body: some View {
        if item.preferPreview && QLPreviewController.canPreview(item.staged.file as NSURL) {
            NavigationStack {
                FileQuickLook(url: item.staged.file)
                    .navigationTitle(item.staged.file.lastPathComponent)
                    .navigationBarTitleDisplayMode(.inline)
                    .toolbar {
                        ToolbarItem(placement: .cancellationAction) { Button("Đóng", action: finish) }
                        ToolbarItem(placement: .primaryAction) {
                            Button { exporting = true } label: { Image(systemName: "square.and.arrow.down") }
                                .accessibilityLabel("Lưu vào Tệp")
                        }
                    }
            }
            .sheet(isPresented: $exporting) { FileCopyPicker(url: item.staged.file) { exporting = false } }
        } else {
            FileCopyPicker(url: item.staged.file, finish: finish)
        }
    }
}

private struct FileQuickLook: UIViewControllerRepresentable {
    let url: URL
    final class Source: NSObject, QLPreviewControllerDataSource {
        let url: URL
        init(_ url: URL) { self.url = url }
        func numberOfPreviewItems(in controller: QLPreviewController) -> Int { 1 }
        func previewController(_ controller: QLPreviewController, previewItemAt index: Int) -> QLPreviewItem { url as NSURL }
    }
    func makeCoordinator() -> Source { Source(url) }
    func makeUIViewController(context: Context) -> QLPreviewController {
        let controller = QLPreviewController()
        controller.dataSource = context.coordinator
        return controller
    }
    func updateUIViewController(_ controller: QLPreviewController, context: Context) {}
}

private struct FileCopyPicker: UIViewControllerRepresentable {
    let url: URL
    let finish: () -> Void
    final class Delegate: NSObject, UIDocumentPickerDelegate {
        let finish: () -> Void
        init(finish: @escaping () -> Void) { self.finish = finish }
        func documentPickerWasCancelled(_ controller: UIDocumentPickerViewController) { finish() }
        func documentPicker(_ controller: UIDocumentPickerViewController, didPickDocumentsAt urls: [URL]) { finish() }
    }
    func makeCoordinator() -> Delegate { Delegate(finish: finish) }
    func makeUIViewController(context: Context) -> UIDocumentPickerViewController {
        let picker = UIDocumentPickerViewController(forExporting: [url], asCopy: true)
        picker.delegate = context.coordinator
        picker.shouldShowFileExtensions = true
        return picker
    }
    func updateUIViewController(_ controller: UIDocumentPickerViewController, context: Context) {}
}
