import Foundation
import CC365Core

struct FileBrowserSnapshot: Sendable {
    let item: FileTransferItem
    let isDirectory: Bool
    let fileCount: Int
    let bytes: UInt64
}



@MainActor enum FileBrowserOperations {
    static func writable(_ path: String) -> Bool { path == "/CC365" || path.hasPrefix("/CC365/") }
    static func child(_ parent: String, _ name: String) throws -> String {
        guard FileTransferSupport.validName(name), !name.lowercased().hasPrefix(".cc365-bq-part-") else {
            throw FileTransferSupport.Failure.invalidName
        }
        return (parent == "/" ? "" : parent) + "/" + name
    }

    static func snapshot(path: String, isDirectory: Bool) async throws -> FileBrowserSnapshot {
        let item = try FileTransferItem(name: (path as NSString).lastPathComponent)
        var files = 0, nodes = 0
        var bytes: UInt64 = 0
        func copy(_ remote: String, to local: URL, directory: Bool, depth: Int) async throws {
            try Task.checkCancellation()
            nodes += 1
            guard nodes <= 4096, depth <= 32 else { throw PatchInputError("Nguồn có quá nhiều mục hoặc cây thư mục quá sâu.") }
            let before = try await VersionedFilesTransport.details(path: remote)
            guard before.kind == (directory ? "directory" : "file") else {
                throw PatchInputError("Nguồn đã thay đổi hoặc là liên kết/tệp đặc biệt.")
            }
            if directory {
                try FileManager.default.createDirectory(at: local, withIntermediateDirectories: false, attributes: [.posixPermissions: 0o700])
                var offset = 0, seen = Set<String>()
                while true {
                    let page = try await VersionedFilesTransport.list(path: remote, offset: offset)
                    if let notice = page.notice, !notice.isEmpty { throw PatchInputError("Chưa đọc đủ nguồn. " + notice) }
                    for entry in page.entries {
                        let key = entry.name.precomposedStringWithCanonicalMapping.lowercased()
                        guard seen.insert(key).inserted, entry.kind == "directory" || entry.kind == "file" else {
                            throw PatchInputError("Nguồn có tên trùng, liên kết hoặc tệp đặc biệt; chưa tạo bản sao.")
                        }
                        let remoteChild = try child(remote, entry.name)
                        guard entry.path == nil || entry.path == remoteChild else { throw PatchInputError("Đường dẫn nguồn không khớp thư mục.") }
                        try await copy(remoteChild, to: local.appendingPathComponent(entry.name), directory: entry.kind == "directory", depth: depth + 1)
                    }
                    guard let next = page.nextOffset else { break }
                    guard next > offset, next <= 4096 else { throw PatchInputError("Danh sách nguồn chưa đầy đủ hoặc quá lớn.") }
                    offset = next
                }
            } else {
                guard files < 1024, before.size <= 128 * 1024 * 1024, before.size <= 256 * 1024 * 1024 - bytes else {
                    throw PatchInputError("Tối đa 1.024 tệp, 128 MiB mỗi tệp và 256 MiB tổng cộng.")
                }
                try await VersionedFilesTransport.download(path: remote, to: local)
                let actual = try local.resourceValues(forKeys: [.fileSizeKey]).fileSize
                guard let actual, actual >= 0, UInt64(actual) == before.size else { throw PatchInputError("Kích thước nguồn đã thay đổi khi sao chép.") }
                files += 1; bytes += before.size
            }
            let after = try await VersionedFilesTransport.details(path: remote)
            guard after.inode == before.inode, after.modified == before.modified, after.kind == before.kind,
                  directory || after.size == before.size else { throw PatchInputError("Nguồn đang thay đổi. Hãy thử lại khi ứng dụng đã ngừng ghi.") }
            try Task.checkCancellation()
        }
        try await copy(path, to: item.file, directory: isDirectory, depth: 0)
        return FileBrowserSnapshot(item: item, isDirectory: isDirectory, fileCount: files, bytes: bytes)
    }

    static func copy(path: String, isDirectory: Bool, to parent: String, name: String) async throws {
        guard writable(parent) else { throw PatchInputError("Chọn thư mục trong Tệp PhamQuang IOS để lưu bản sao.") }
        let destination = try child(parent, name)
        guard destination != path, !destination.hasPrefix(path + "/") else { throw PatchInputError("Không sao chép mục vào chính nó hoặc thư mục con của nó.") }
        let captured = try await snapshot(path: path, isDirectory: isDirectory)
        defer { withExtendedLifetime(captured) {} }
        try Task.checkCancellation()
        if isDirectory { try await VersionedFilesTransport.uploadTree(local: captured.item.file, to: destination) }
        else { _ = try await VersionedFilesTransport.upload(local: captured.item.file, parent: parent, name: name) }
    }

    static func compress(path: String, isDirectory: Bool, to parent: String, name: String,
                         settings: AppFileSettings = .load()) async throws {
        guard writable(parent), name.lowercased().hasSuffix(".zip") else { throw PatchInputError("Chọn tên .zip trong Tệp PhamQuang IOS.") }
        _ = try child(parent, name)
        let captured = try await snapshot(path: path, isDirectory: isDirectory)
        defer { withExtendedLifetime(captured) {} }
        let archive = try await buildArchive(snapshot: captured, name: name, settings: settings)
        defer { withExtendedLifetime(archive) {} }
        try Task.checkCancellation()
        _ = try await VersionedFilesTransport.upload(local: archive.file, parent: parent, name: name)
    }

    static func extract(path: String, to parent: String, name: String, settings: AppFileSettings = .load()) async throws {
        guard writable(parent) else { throw PatchInputError("Chọn thư mục trong Tệp PhamQuang IOS để giải nén.") }
        let destination = try child(parent, name)
        let archive = try FileTransferItem(name: (path as NSString).lastPathComponent)
        defer { withExtendedLifetime(archive) {} }
        try await VersionedFilesTransport.download(path: path, to: archive.file)
        let extracted = try await extractArchive(archive.file, settings: settings)
        defer { withExtendedLifetime(extracted) {} }
        try Task.checkCancellation()
        try await VersionedFilesTransport.uploadTree(local: extracted.directory.appendingPathComponent("contents"), to: destination)
    }


    nonisolated static func buildArchive(snapshot: FileBrowserSnapshot, name: String, settings: AppFileSettings) async throws -> FileTransferItem {
        try await work {
            defer { withExtendedLifetime(snapshot) {} }
            struct Entry: Encodable { let archive_path: String; var local_path: String? = nil; var kind: String? = nil }
            struct Manifest: Encodable { let entries: [Entry]; let compression_level: Int; let work_mode: String }
            var entries: [Entry] = []
            func collect(_ url: URL, relative: String, depth: Int) throws {
                try Task.checkCancellation()
                guard depth <= 32, entries.count < 4096 else { throw PatchInputError("Cây thư mục quá lớn để nén.") }
                let attributes = try url.resourceValues(forKeys: [.isDirectoryKey, .isRegularFileKey, .isSymbolicLinkKey])
                guard attributes.isSymbolicLink != true else { throw PatchInputError("Không nén liên kết.") }
                if attributes.isDirectory == true {
                    entries.append(Entry(archive_path: relative, kind: "directory"))
                    for child in try FileManager.default.contentsOfDirectory(at: url, includingPropertiesForKeys: nil).sorted(by: { $0.lastPathComponent < $1.lastPathComponent }) {
                        try collect(child, relative: relative + "/" + child.lastPathComponent, depth: depth + 1)
                    }
                } else {
                    guard attributes.isRegularFile == true else { throw PatchInputError("Không nén tệp đặc biệt.") }
                    entries.append(Entry(archive_path: relative, local_path: url.path))
                }
            }
            try collect(snapshot.item.file, relative: snapshot.item.file.lastPathComponent, depth: 0)
            let output = try FileTransferItem(name: name)
            let manifest = output.directory.appendingPathComponent("manifest.json")
            try JSONEncoder().encode(Manifest(entries: entries, compression_level: settings.compressionLevel, work_mode: settings.workMode.rawValue)).write(to: manifest)
            let code = manifest.withUnsafeFileSystemRepresentation { input in
                output.file.withUnsafeFileSystemRepresentation { destination in cc365_create_zip(input, destination) { Task.isCancelled } }
            }
            try archiveResult(code)
            try Task.checkCancellation()
            return output
        }
    }

    nonisolated static func extractArchive(_ archive: URL, settings: AppFileSettings) async throws -> FileTransferItem {
        try await work {
            let output = try FileTransferItem(name: "contents")
            let code = archive.withUnsafeFileSystemRepresentation { source in
                output.directory.withUnsafeFileSystemRepresentation { destination in
                    cc365_extract_zip(source, destination, settings.workMode.nativeValue) { Task.isCancelled }
                }
            }
            try archiveResult(code)
            try Task.checkCancellation()
            return output
        }
    }

    nonisolated private static func archiveResult(_ code: Int32) throws {
        switch code {
        case 0: return
        case 6: throw CancellationError()
        case 2: throw PatchInputError("ZIP chứa đường dẫn trùng/không an toàn, liên kết hoặc kiểu tệp chưa hỗ trợ.")
        case 3: throw PatchInputError("ZIP vượt giới hạn: 1.024 tệp, 128 MiB mỗi tệp và 256 MiB dữ liệu.")
        default: throw PatchInputError("Chưa hoàn tất ZIP (mã \(code)). Hãy kiểm tra dung lượng trống và nguồn.")
        }
    }

    nonisolated private static func work<T: Sendable>(_ body: @escaping @Sendable () throws -> T) async throws -> T {
        let job = Task.detached(priority: .userInitiated) { try Task.checkCancellation(); return try body() }
        return try await withTaskCancellationHandler { try await job.value } onCancel: { job.cancel() }
    }
}
