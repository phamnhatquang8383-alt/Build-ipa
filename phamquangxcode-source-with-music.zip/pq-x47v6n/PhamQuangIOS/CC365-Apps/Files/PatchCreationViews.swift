import SwiftUI
import UniformTypeIdentifiers

struct PatchCreationView: View {
    var seed: PatchCaptureSource? = nil
    @State private var projects: [PatchCreationProject] = []
    @State private var loading = false
    @State private var issue: String?
    @State private var creating = false
    @State private var openingCreated = false
    @State private var created: PatchCreationProject?
    @State private var deleting: PatchCreationProject?

    var body: some View {
        List {
            Section {
                Button { created = nil; creating = true } label: { Label("Tạo bản nháp", systemImage: "plus") }
                    .accessibilityIdentifier("creator-new")
                Text("Thêm tệp hoặc thư mục, chọn ứng dụng và đường dẫn đích rồi xuất gói để chia sẻ.")
                    .font(.footnote).foregroundStyle(.secondary)
            }
            Section("Bản nháp đã lưu") {
                if loading && projects.isEmpty { CC365TaskProgress(title: "Đang đọc bản nháp…") }
                ForEach(projects) { project in
                    NavigationLink { PatchCreationEditor(project: project, seed: seed) } label: {
                        VStack(alignment: .leading, spacing: 4) {
                            Text(project.name)
                            Text("\(project.mappings.count) mục · \(project.mappings.reduce(0) { $0 + $1.files.count }) tệp")
                                .font(.caption).foregroundStyle(.secondary)
                            if !project.author.isEmpty { Text(project.author).font(.caption).foregroundStyle(.secondary) }
                        }
                    }
                    .swipeActions { Button("Xóa", role: .destructive) { deleting = project } }
                }
                if !loading && projects.isEmpty { Text("Chưa có bản nháp.").foregroundStyle(.secondary) }
                if let issue { Text(issue).font(.callout); Button("Thử lại") { Task { await reload() } } }
            }
        }
        .cc365Canvas()
        .navigationTitle("Tạo patch")
        .navigationBarTitleDisplayMode(.inline)
        .task { await reload() }
        .refreshable { await reload() }
        .sheet(isPresented: $creating, onDismiss: { openingCreated = created != nil }) {
            PatchProjectMetadataForm(name: seed?.displayName ?? "", author: "", title: "Bản nháp mới") { name, author in
                let project = try await PatchCreationStore.shared.create(name: name, author: author)
                creating = false
                created = project
                await reload()
            }
        }
        .navigationDestination(isPresented: $openingCreated) {
            if let created { PatchCreationEditor(project: created, seed: seed) }
        }
        .confirmationDialog("Xóa bản nháp?", isPresented: Binding(get: { deleting != nil }, set: { if !$0 { deleting = nil } }), titleVisibility: .visible, presenting: deleting) { project in
            Button("Xóa bản nháp", role: .destructive) {
                Task {
                    do { try await PatchCreationStore.shared.delete(projectID: project.id); await reload() }
                    catch { issue = FileTransferSupport.message(error) }
                    deleting = nil
                }
            }
        } message: { _ in Text("Xóa bản nháp và các bản sao nguồn đã lưu. Tệp gốc bạn chọn không bị thay đổi.") }
    }

    @MainActor private func reload() async {
        guard !loading else { return }
        loading = true
        defer { loading = false }
        do { projects = try await PatchCreationStore.shared.projects(); issue = nil }
        catch { issue = FileTransferSupport.message(error) }
    }
}

private struct PatchProjectMetadataForm: View {
    @Environment(\.dismiss) private var dismiss
    @State var name: String
    @State var author: String
    let title: String
    let save: (String, String) async throws -> Void
    @State private var busy = false
    @State private var issue: String?

    var body: some View {
        NavigationStack {
            Form {
                Section("Thông tin patch") {
                    TextField("Tên patch", text: $name).accessibilityIdentifier("creator-name")
                    TextField("Tác giả (không bắt buộc)", text: $author).accessibilityIdentifier("creator-author")
                }
                if let issue { Section { Text(issue).foregroundStyle(.secondary) } }
            }
            .disabled(busy)
            .cc365Canvas()
            .navigationTitle(title).navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .cancellationAction) { Button("Hủy") { dismiss() }.disabled(busy) }
                ToolbarItem(placement: .confirmationAction) {
                    Button(busy ? "Đang lưu…" : "Lưu") {
                        busy = true
                        Task {
                            defer { busy = false }
                            do { try await save(name, author); dismiss() }
                            catch { issue = FileTransferSupport.message(error) }
                        }
                    }.disabled(busy || name.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty)
                    .accessibilityIdentifier("creator-save-project")
                }
            }
            .interactiveDismissDisabled(busy)
        }
    }
}

private struct PatchExportPresentation: Identifiable {
    let id = UUID()
    let value: PatchCreationExport
}

struct PatchCreationEditor: View {
    @State var project: PatchCreationProject
    var seed: PatchCaptureSource? = nil
    @State private var usedSeed = false
    @State private var editingMetadata = false
    @State private var adding = false
    @State private var addingBundleID: String?
    @State private var editingMapping: PatchCreationMapping?
    @State private var removing: PatchCreationMapping?
    @State private var format = "zip"
    @State private var exportPassword = ""
    @State private var confirmExportPassword = ""
    @State private var issue: String?
    @State private var worker: Task<Void, Never>?
    @State private var exporting = false
    @State private var shared: PatchExportPresentation?

    var body: some View {
        Form {
            Group {
                Section("Thông tin patch") {
                    LabeledContent("Tên", value: project.name)
                    if !project.author.isEmpty { LabeledContent("Tác giả", value: project.author) }
                    Button("Sửa thông tin") { editingMetadata = true }
                }
                if project.mappings.isEmpty {
                    Section {
                        Button { addingBundleID = nil; adding = true } label: { Label("Thêm ánh xạ đầu tiên", systemImage: "plus") }
                            .accessibilityIdentifier("creator-add-mapping")
                    } header: { Text("Bundle đích và ánh xạ") }
                      footer: { Text("Chọn bundle ID một lần, rồi thêm nhiều tệp hoặc thư mục với đường dẫn đích riêng cho ứng dụng đó.") }
                }
                ForEach(project.bundleIDs, id: \.self) { bundle in
                    Section {
                        ForEach(project.mappings.filter { $0.bundleID == bundle }) { mapping in
                            Button { editingMapping = mapping } label: {
                                VStack(alignment: .leading, spacing: 5) {
                                    Text(mapping.sourceName).foregroundStyle(.primary)
                                    Text("→ " + mapping.destination).font(.caption.monospaced()).foregroundStyle(.secondary)
                                    Text("\(mapping.files.count) tệp").font(.caption).foregroundStyle(.secondary)
                                }.frame(maxWidth: .infinity, alignment: .leading)
                            }
                            .buttonStyle(.plain)
                            .contextMenu { Button("Xóa ánh xạ", role: .destructive) { removing = mapping } }
                        }
                        Button { addingBundleID = bundle; adding = true } label: {
                            Label("Thêm ánh xạ", systemImage: "plus")
                        }.accessibilityIdentifier("creator-add-mapping-" + bundle)
                    } header: { Text(bundle).textCase(nil) }
                      footer: { Text("Các ánh xạ này cùng thuộc một ứng dụng. Mỗi nguồn có đường dẫn đích riêng trong Documents hoặc Library/Caches.") }
                }
                if !project.mappings.isEmpty {
                    Section {
                        NavigationLink("Xem toàn bộ đường dẫn") { PatchCreationPreview(project: project) }
                            .accessibilityIdentifier("creator-preview")
                        Picker("Định dạng", selection: $format) {
                            Text("ZIP").tag("zip")
                            Text(".vailon").tag("vailon")
                            Text(".vpatch · Mã hóa").tag("vpatch")
                        }.accessibilityIdentifier("creator-format")
                        if format == "vpatch" {
                            SecureField("Mật khẩu (ít nhất 12 ký tự)", text: $exportPassword)
                                .textContentType(.newPassword)
                                .textInputAutocapitalization(.never)
                                .autocorrectionDisabled()
                                .accessibilityIdentifier("creator-export-password")
                            SecureField("Nhập lại mật khẩu", text: $confirmExportPassword)
                                .textContentType(.newPassword)
                                .textInputAutocapitalization(.never)
                                .autocorrectionDisabled()
                                .accessibilityIdentifier("creator-export-password-confirm")
                        }
                        Button { export() } label: { Label("Xuất và chia sẻ", systemImage: "square.and.arrow.up") }
                            .disabled(format == "vpatch" && (exportPassword.utf8.count < 12 || exportPassword != confirmExportPassword))
                            .accessibilityIdentifier("creator-export")
                    } header: { Text("Xuất patch") }
                      footer: {
                          Text(format == "vpatch"
                               ? ".vpatch dùng AES-256-GCM và PBKDF2-HMAC-SHA256. Chỉ PhamQuang IOS có luồng mở định dạng này; mật khẩu không được lưu. Quên mật khẩu sẽ không thể khôi phục nội dung."
                               : "Mỗi ứng dụng được xuất thành một gói riêng. .vailon vẫn là ZIP đổi phần mở rộng để tương thích bản cũ.")
                      }
                }
            }.disabled(exporting)
            if exporting {
                Section {
                    CC365TaskProgress(title: "Đang tạo gói patch…")
                    Button("Dừng", role: .cancel) { worker?.cancel() }
                }
            }
            if let issue { Section { Text(issue).foregroundStyle(.secondary).accessibilityIdentifier("creator-error") } }
        }
        .cc365Canvas()
        .navigationTitle(project.name).navigationBarTitleDisplayMode(.inline)
        .sheet(isPresented: $editingMetadata) {
            PatchProjectMetadataForm(name: project.name, author: project.author, title: "Sửa thông tin") { name, author in
                project = try await PatchCreationStore.shared.update(projectID: project.id, name: name, author: author)
            }
        }
        .sheet(isPresented: $adding) {
            PatchCreationMappingForm(projectID: project.id, mapping: nil, seed: usedSeed ? nil : seed,
                defaultBundleID: addingBundleID ?? (project.bundleIDs.count == 1 ? project.bundleIDs.first : nil)) {
                project = $0; usedSeed = true
            }
        }
        .sheet(item: $editingMapping) { mapping in
            PatchCreationMappingForm(projectID: project.id, mapping: mapping) { project = $0 }
        }
        .sheet(item: $shared) { item in PatchCreationShareSheet(urls: item.value.urls) }
        .confirmationDialog("Xóa mục nguồn này?", isPresented: Binding(get: { removing != nil }, set: { if !$0 { removing = nil } }), titleVisibility: .visible, presenting: removing) { mapping in
            Button("Xóa mục", role: .destructive) {
                Task {
                    do { project = try await PatchCreationStore.shared.removeMapping(projectID: project.id, mappingID: mapping.id) }
                    catch { issue = FileTransferSupport.message(error) }
                    removing = nil
                }
            }
        }
        .onAppear { if seed != nil && !usedSeed { adding = true } }
        .toolbar {
            if exporting { ToolbarItem(placement: .cancellationAction) { Button("Dừng") { worker?.cancel() } } }
        }
        .navigationBarBackButtonHidden(exporting)
        .onDisappear { worker?.cancel() }
    }

    private func export() {
        guard worker == nil else { return }
        exporting = true
        issue = nil
        worker = Task { @MainActor in
            defer {
                exporting = false
                worker = nil
                exportPassword = ""
                confirmExportPassword = ""
            }
            do {
                let value = try await PatchCreationStore.shared.export(projectID: project.id, fileExtension: format,
                    password: format == "vpatch" ? exportPassword : nil)
                try Task.checkCancellation()
                exportPassword = ""
                confirmExportPassword = ""
                shared = PatchExportPresentation(value: value)
            } catch { issue = FileTransferSupport.cancelled(error) ? "Đã dừng xuất. Bản nháp vẫn được giữ." : FileTransferSupport.message(error) }
        }
    }
}

private struct PatchCreationMappingForm: View {
    let projectID: UUID
    let mapping: PatchCreationMapping?
    var seed: PatchCaptureSource? = nil
    var defaultBundleID: String? = nil
    let saved: (PatchCreationProject) -> Void
    @Environment(\.dismiss) private var dismiss
    @State private var bundleID = ""
    @State private var destination = "Documents/"
    @State private var source: URL?
    @State private var folder = false
    @State private var pickingFolder = false
    @State private var importing = false
    @State private var busy = false
    @State private var issue: String?
    @State private var worker: Task<Void, Never>?
    @State private var pickingApp = false
    @State private var initialized = false

    var body: some View {
        NavigationStack {
            Form {
                Section("Nguồn") {
                    if let name = source?.lastPathComponent ?? mapping?.sourceName { Text(name).lineLimit(3) }
                    Button("Chọn tệp") { pickingFolder = false; importing = true }
                    Button("Chọn thư mục") { pickingFolder = true; importing = true }
                    Text("Chọn dữ liệu đã giải nén. Tệp ZIP được giữ nguyên như một tệp nguồn khi tạo patch.")
                        .font(.footnote).foregroundStyle(.secondary)
                }
                Section("Ứng dụng và đường dẫn đích") {
                    TextField("Bundle ID, ví dụ com.example.game", text: $bundleID)
                        .textInputAutocapitalization(.never).autocorrectionDisabled()
                        .accessibilityIdentifier("creator-bundle-id")
                    Button("Chọn ứng dụng trên máy…") { pickingApp = true }
                    Menu("Chọn thư mục gốc") {
                        Button("Documents") { destination = "Documents/" + selectedLeaf }
                        Button("Library/Caches") { destination = "Library/Caches/" + selectedLeaf }
                    }
                    TextField("Documents/tệp hoặc thư mục", text: $destination, axis: .vertical)
                        .textInputAutocapitalization(.never).autocorrectionDisabled().font(.body.monospaced())
                        .accessibilityIdentifier("creator-destination")
                    Text((source != nil ? folder : mapping?.isDirectory == true)
                         ? "Đường dẫn là thư mục nhận nội dung; giữ các thư mục con của nguồn."
                         : "Đường dẫn phải gồm tên tệp đích.")
                        .font(.footnote).foregroundStyle(.secondary)
                }
                if let mapping, source == nil {
                    Section("Các tệp đã lưu") {
                        ForEach(mapping.files, id: \.payloadName) { file in
                            Text(file.relativePath.isEmpty ? mapping.sourceName : file.relativePath).font(.caption.monospaced())
                        }
                    }
                }
                if busy { Section { CC365TaskProgress(title: "Đang sao chép và kiểm tra nguồn…") } }
                if let issue { Section { Text(issue).foregroundStyle(.secondary) } }
            }
            .disabled(busy)
            .cc365Canvas()
            .navigationTitle(mapping == nil ? "Thêm mục nguồn" : "Sửa mục nguồn").navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .cancellationAction) {
                    Button(busy ? "Dừng" : "Hủy") { if busy { worker?.cancel() } else { dismiss() } }
                }
                ToolbarItem(placement: .confirmationAction) {
                    Button("Lưu") { save() }.disabled(busy || bundleID.isEmpty || destination.isEmpty || (source == nil && mapping == nil))
                        .accessibilityIdentifier("creator-save-mapping")
                }
            }
            .interactiveDismissDisabled(busy)
            .sheet(isPresented: $pickingApp) {
                PatchCreationAppPicker { identifier in bundleID = identifier; pickingApp = false }
            }
            .cc365FilePicker(isPresented: $importing, kind: pickingFolder ? .folder : .file) { url in
                guard let url else { return }
                source = url
                folder = pickingFolder
                if !folder && ["Documents/", "Library/Caches/"].contains(destination) { destination += url.lastPathComponent }
            }
            .onAppear {
                guard !initialized else { return }
                initialized = true
                if let mapping { bundleID = mapping.bundleID; destination = mapping.destination; folder = mapping.isDirectory }
                else if let seed {
                    source = seed.sourceURL; bundleID = seed.bundleID ?? defaultBundleID ?? ""; folder = seed.isDirectory
                    destination = seed.destination ?? (seed.isDirectory ? "Documents" : "Documents/" + seed.sourceURL.lastPathComponent)
                } else { bundleID = defaultBundleID ?? "" }
            }
            .onDisappear { worker?.cancel() }
        }
    }

    private var selectedLeaf: String { (source != nil ? folder : mapping?.isDirectory == true) ? "" : (source?.lastPathComponent ?? mapping?.sourceName ?? "") }

    private func save() {
        guard worker == nil else { return }
        busy = true; issue = nil
        worker = Task { @MainActor in
            defer { busy = false; worker = nil }
            do {
                let project: PatchCreationProject
                let directory = source != nil ? folder : mapping?.isDirectory == true
                let finalDestination = directory && destination.hasSuffix("/") ? String(destination.dropLast()) : destination
                if let source {
                    project = try await PatchCreationStore.shared.importMapping(projectID: projectID, bundleID: bundleID,
                        destination: finalDestination, source: source, replacing: mapping?.id)
                } else if let mapping {
                    project = try await PatchCreationStore.shared.editMapping(projectID: projectID, mappingID: mapping.id,
                        bundleID: bundleID, destination: finalDestination)
                } else { return }


                saved(project)
                dismiss()
            } catch { issue = FileTransferSupport.cancelled(error) ? "Đã dừng. Bản nháp cũ vẫn được giữ." : FileTransferSupport.message(error) }
        }
    }
}

private struct PatchCreationAppPicker: View {
    let select: (String) -> Void
    private struct Response: Decodable, Sendable { let apps: [PatchTargetApp]; let notice: String? }
    @State private var apps: [PatchTargetApp] = []
    @State private var loading = false
    @State private var notice: String?
    @State private var worker: Task<Void, Never>?

    var body: some View {
        PatchAppPicker(apps: apps, selected: nil, loading: loading, notice: notice, reload: reload) { app in
            if let identifier = app.bundleID { select(identifier) }
        }
        .onAppear { reload() }
        .onDisappear { worker?.cancel() }
    }

    private func reload() {
        guard worker == nil else { return }
        loading = true; notice = nil; apps = []
        worker = Task { @MainActor in
            defer { loading = false; worker = nil }
            do {
                let response = try await VersionedFilesTransport.patch("apps", as: Response.self)
                try Task.checkCancellation()
                apps = response.apps.filter { $0.bundleID != nil }
                notice = apps.isEmpty ? "Chưa đọc được bundle ID của ứng dụng. Bạn vẫn có thể đóng danh sách và nhập bundle ID thủ công." : response.notice
            } catch {
                if !FileTransferSupport.cancelled(error) { notice = FileTransferSupport.message(error) }
            }
        }
    }
}

private struct PatchCreationPreview: View {
    let project: PatchCreationProject
    var body: some View {
        List {
            ForEach(project.mappings) { mapping in
                Section(mapping.bundleID) {
                    ForEach(mapping.files, id: \.payloadName) { file in
                        VStack(alignment: .leading, spacing: 6) {
                            Text(mapping.sourceName + (mapping.isDirectory ? "/" + file.relativePath : ""))
                                .font(.caption).foregroundStyle(.secondary)
                            Text("Application/" + mapping.bundleID + "/" + mapping.target(for: file))
                                .font(.callout.monospaced()).textSelection(.enabled)
                            Text(ByteCountFormatter.string(fromByteCount: Int64(file.size), countStyle: .file))
                                .font(.caption).foregroundStyle(.secondary)
                        }
                    }
                }
            }
        }
        .cc365Canvas().navigationTitle("Nguồn → Đích").navigationBarTitleDisplayMode(.inline)
    }
}

private struct PatchCreationShareSheet: UIViewControllerRepresentable {
    let urls: [URL]
    func makeUIViewController(context: Context) -> UIActivityViewController {
        UIActivityViewController(activityItems: urls, applicationActivities: nil)
    }
    func updateUIViewController(_ controller: UIActivityViewController, context: Context) {}
}
