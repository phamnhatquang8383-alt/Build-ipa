import SwiftUI

private struct PatchAppList: Decodable, Sendable {
    let apps: [PatchTargetApp]
    let notice: String?
}

struct AppPatchView: View {
    @Environment(\.accessibilityReduceMotion) private var reduceMotion
    @StateObject private var history = PatchHistoryModel()
    private struct EditorID: Hashable { let target: String; let source: ObjectIdentifier }
    @State private var source: AppPatchSource?
    @State private var app: PatchTargetApp?
    @State private var picking: PatchSourceChoice?
    @State private var activity: String?
    @State private var issue: String?
    @State private var worker: Task<Void, Never>?
    @State private var ticket = UUID()
    @State private var stopping = false
    @State private var editingLocked = false
    @State private var canSelectContainer = false
    @State private var showingContainers = false
    @State private var containerRows: [PatchTargetApp] = []
    @State private var containerNotice: String?
    @State private var showingContainerConfirmation = false
    @State private var pendingContainer: PatchTargetApp?
    @State private var pendingEncryptedSelection: URL?
    @State private var showingEncryptedPassword = false

    var body: some View {
        ZStack {
            if let app, let source {
                PatchEditor(app: app, scope: .data, locked: $editingLocked, initialSource: source,
                            onPickSource: { picking = $0 }) {
                    Section("Ứng dụng đích") {
                        Text(app.displayName)
                        if source.usesExplicitContainerSelection {
                            Text("Container do bạn chọn · Chưa xác minh danh tính ứng dụng")
                                .font(.footnote).foregroundStyle(.secondary)
                            Text(app.dataPath ?? "").font(.footnote.monospaced()).textSelection(.enabled)
                        }
                        if app.displayName != source.embeddedBundleID {
                            Text(source.embeddedBundleID ?? "").font(.caption).foregroundStyle(.secondary)
                        }
                        DisclosureGroup("Đường dẫn gốc") {
                            Text(app.dataPath ?? "").font(.footnote.monospaced()).textSelection(.enabled)
                        }
                    }
                }
                .id(EditorID(target: app.id, source: ObjectIdentifier(source)))
                .transition(.opacity)
            } else {
                sourceForm
                    .transition(.opacity)
            }
        }
        .animation(reduceMotion ? nil : .easeInOut(duration: 0.22), value: app?.id)
        .cc365Canvas()
        .navigationTitle("Áp dụng patch")
        .navigationBarTitleDisplayMode(.inline)
        .navigationBarBackButtonHidden(editingLocked)
        .toolbar {
            ToolbarItem(placement: .topBarTrailing) {
                Menu {
                    NavigationLink { PatchCreationView() } label: {
                        Label("Tạo patch", systemImage: "doc.badge.plus")
                    }
                    NavigationLink {
                        SavedPatchesView(history: history)
                    } label: {
                        Label("Ứng dụng đã patch", systemImage: "clock.arrow.circlepath")
                    }
                    NavigationLink {
                        ManualAppPatchView()
                    } label: {
                        Label("Patch thủ công / khôi phục", systemImage: "slider.horizontal.3")
                    }
                } label: { Image(systemName: "ellipsis.circle") }
                .accessibilityLabel("Tùy chọn patch")
                .accessibilityIdentifier("patch-options")
                .disabled(editingLocked || activity != nil)
            }
        }
        .patchSourcePicker(choice: $picking) { url, choice in sourcePicked(url, choice: choice) }
        .sheet(isPresented: $showingEncryptedPassword) {
            PatchPasswordPrompt { password in
                guard let selection = pendingEncryptedSelection else { return }
                pendingEncryptedSelection = nil
                run("Đang giải mã và kiểm tra patch…") {
                    try await stageAndResolve(selection, choice: .file, password: password)
                }
            }
        }
        .sheet(isPresented: $showingContainers, onDismiss: { showingContainerConfirmation = pendingContainer != nil }) {
            PatchAppPicker(apps: containerRows, selected: nil, loading: activity != nil, notice: containerNotice,
                reload: { loadContainers() }) { target in
                showingContainers = false
                pendingContainer = target
            }
        }
        .alert("Dùng container đã chọn?", isPresented: $showingContainerConfirmation, presenting: pendingContainer) { target in
            Button("Dùng container này") { selectContainer(target) }
            Button("Hủy", role: .cancel) { pendingContainer = nil }
        } message: { target in
            Text("Gói patch khai báo \(source?.embeddedBundleID ?? "ứng dụng chưa rõ"). Chưa xác minh được danh tính của thư mục này. Chỉ tiếp tục nếu bạn biết đây là đúng container:\n\n\(target.dataPath ?? "")")
        }
        .task { await history.refresh() }

        .onDisappear {
            worker?.cancel()
            ticket = UUID()
            worker = nil
            activity = nil
            stopping = false
        }
    }

    private var sourceForm: some View {
        Form {
            Section {
                NavigationLink { PatchCreationView() } label: {
                    Label("Tạo patch", systemImage: "doc.badge.plus")
                }.accessibilityIdentifier("patch-create")
            }
            if !history.patches.isEmpty || history.isLoading || history.issue != nil || history.notice != nil {
                SavedPatchSection(history: history)
                    .disabled(activity != nil)
            }
            Section {
                if let source {
                    LabeledContent("Nguồn đã chọn") {
                        Text(source.name).lineLimit(2).truncationMode(.middle)
                    }.accessibilityIdentifier("patch-selected-source")
                    LabeledContent("Nội dung", value: "\(source.files.count) tệp · \(formatted(source.size))")
                    if let bundle = source.embeddedBundleID {
                        LabeledContent("Ứng dụng đích") {
                            Text(bundle).font(.callout).textSelection(.enabled)
                        }.accessibilityIdentifier("patch-detected-owner")
                    }
                }
                Button { picking = .file } label: {
                    Label("Chọn gói patch", systemImage: "doc.zipper")
                        .frame(maxWidth: .infinity, minHeight: 44, alignment: .leading)
                }.accessibilityIdentifier("patch-source-file")
                Button { picking = .folder } label: {
                    Label("Chọn thư mục", systemImage: "folder")
                        .frame(maxWidth: .infinity, minHeight: 44, alignment: .leading)
                }.accessibilityIdentifier("patch-source-folder")
            } header: { Text("Nguồn patch") }
              footer: {
                  Text("Chọn ZIP, .vailon hoặc .vpatch mã hóa để tự nhận diện ứng dụng đích. Bản gốc được lưu trong “Ứng dụng đã patch” để khôi phục sau này.")
              }
              .disabled(activity != nil)
            if let activity {
                Section {
                    VStack(alignment: .leading, spacing: 10) {
                        CC365TaskProgress(title: stopping ? "Đang dừng…" : activity,
                            detail: stopping ? "Đang hoàn tất bước hiện tại trước khi dừng." : nil,
                            phaseKey: stopping ? "stopping" : activity)
                        if !stopping {
                            Button("Dừng") { stopping = true; worker?.cancel() }.buttonStyle(.borderless)
                        }
                    }.accessibilityIdentifier("patch-resolving")
                }
            }
            if let issue {
                Section {
                    Label(issue, systemImage: "exclamationmark.circle")
                        .foregroundStyle(.secondary)
                        .accessibilityIdentifier("patch-source-issue")
                    if canSelectContainer {
                        Button("Chọn container theo đường dẫn") { loadContainers() }
                            .accessibilityIdentifier("patch-select-container")
                    }
                    if source?.embeddedBundleID != nil {
                        Button("Tìm lại thư mục ứng dụng") {
                            run("Đang tìm thư mục ứng dụng…") { try await resolveSource() }
                        }.accessibilityIdentifier("patch-resolve-retry")
                    }
                }.disabled(activity != nil)
            }

        }
    }

    private func formatted(_ bytes: UInt64) -> String {
        ByteCountFormatter.string(fromByteCount: Int64(bytes), countStyle: .file)
    }

    @MainActor private func sourcePicked(_ selection: URL?, choice: PatchSourceChoice) {
        picking = nil
        guard let selection, !editingLocked, activity == nil else { return }
        run("Đang đọc cấu trúc patch…") {
            do { try await stageAndResolve(selection, choice: choice, password: nil) }
            catch is PatchArchivePasswordRequired {
                pendingEncryptedSelection = selection
                showingEncryptedPassword = true
            }
        }
    }

    @MainActor private func stageAndResolve(_ selection: URL, choice: PatchSourceChoice, password: String?) async throws {
        app = nil
        source = nil
        canSelectContainer = false
        let staged = try await AppPatchSource.stage(selection, scope: .data,
            expectDirectory: choice == .folder, password: password)
        try Task.checkCancellation()
        source = staged
        guard staged.embeddedBundleID != nil else {
            throw PatchInputError("Gói này chưa ghi ứng dụng đích. Hãy chọn thư mục hoặc ZIP chứa Application/<bundle ID>/, hoặc dùng Patch thủ công trong menu.")
        }
        activity = "Đang tìm thư mục ứng dụng…"
        try await resolveSource()
    }

    @MainActor private func resolveSource() async throws {
        guard let source, let bundle = source.embeddedBundleID else { return }
        canSelectContainer = false
        struct Resolution: Decodable, Sendable { let app: PatchTargetApp }
        let target: PatchTargetApp
        do {
            let result = try await VersionedFilesTransport.patch("resolve", fields: ["bundle_id": bundle], as: Resolution.self)
            target = result.app
        } catch {
            let failure = error as NSError
            canSelectContainer = failure.domain == "CC365.BQResolve" && failure.code == 1
            throw error
        }
        try Task.checkCancellation()
        guard target.bundleID == bundle, target.dataPath != nil else {
            throw PatchInputError("Thư mục trả về không khớp ứng dụng trong patch. Chưa có tệp nào được thay đổi.")
        }
        _ = try source.mappings(destination: "", app: target, scope: .data)
        app = target
    }

    @MainActor private func loadContainers() {
        run("Đang đọc container trên máy…") {
            let result = try await VersionedFilesTransport.patch("apps", as: PatchAppList.self)
            try Task.checkCancellation()
            containerRows = result.apps.filter { $0.dataPath != nil && ($0.bundleID == nil || $0.bundleID == source?.embeddedBundleID) }
            containerNotice = result.notice ?? "Chọn theo đường dẫn đầy đủ. Container chưa nhận diện không được coi là đã xác minh ứng dụng."
            showingContainers = true
        }
    }

    @MainActor private func selectContainer(_ target: PatchTargetApp) {
        pendingContainer = nil
        guard let source else { return }
        do {
            let bound = try source.binding(toObservedContainer: target)
            _ = try bound.mappings(destination: "", app: target, scope: .data)
            self.source = bound
            app = target
            issue = nil
            canSelectContainer = false
        } catch { issue = FileTransferSupport.message(error) }
    }

    @MainActor private func run(_ text: String, operation: @escaping @MainActor () async throws -> Void) {
        guard worker == nil, activity == nil else { return }
        let current = UUID()
        ticket = current
        issue = nil
        activity = text
        stopping = false
        worker = Task { @MainActor in
            defer {
                if ticket == current { worker = nil; activity = nil; stopping = false }
            }
            do { try await operation() }
            catch {
                if ticket == current {
                    issue = FileTransferSupport.cancelled(error) ? "Đã dừng. Bạn có thể chọn lại gói hoặc tìm lại thư mục ứng dụng." : FileTransferSupport.message(error)
                }
            }
        }
    }
}

private struct SavedPatchSection: View {
    @ObservedObject var history: PatchHistoryModel

    var body: some View {
        Section {
            if history.isLoading && history.patches.isEmpty {
                CC365TaskProgress(title: "Đang đọc bản sao khôi phục…", phaseKey: "history")
            }
            ForEach(history.patches) { item in
                NavigationLink {
                    SavedPatchRecoveryView(patch: item)
                } label: {
                    VStack(alignment: .leading, spacing: 5) {
                        Text(item.app.displayName).foregroundStyle(.primary)
                        if item.app.displayName != item.app.identityDescription {
                            Text(item.app.identityDescription).font(.caption).foregroundStyle(.secondary)
                        }
                        Text(item.status.state == .pending
                             ? "Phiên bị gián đoạn · Cần khôi phục"
                             : "\(item.status.changed) tệp · \(item.patchScope.title) · Có bản gốc")
                            .font(.footnote).foregroundStyle(.secondary)
                        if let notice = item.notice {
                            Text(notice).font(.footnote).foregroundStyle(.secondary)
                        }
                    }.padding(.vertical, 3)
                }
                .disabled(!item.canRestore)
                .accessibilityIdentifier("patch-saved-" + item.id)
            }
            if let issue = history.issue {
                Label(issue, systemImage: "exclamationmark.circle").font(.callout)
                Button("Tải lại bản sao khôi phục") { Task { await history.refresh() } }
            } else if !history.isLoading && history.patches.isEmpty {
                Text("Chưa có ứng dụng cần khôi phục.")
                    .foregroundStyle(.secondary).accessibilityIdentifier("patch-history-empty")
            }
            if let notice = history.notice {
                Text(notice).font(.footnote).foregroundStyle(.secondary)
                if history.issue == nil {
                    Button("Tải lại bản sao khôi phục") { Task { await history.refresh() } }
                        .disabled(history.isLoading)
                }
            }
        } header: { Text("Ứng dụng đã patch") }
          footer: { Text("Chọn ứng dụng để khôi phục bản gốc, không cần tìm lại ứng dụng hoặc chọn gói ZIP. Danh sách được lưu trên iPhone này.") }
    }
}

private struct SavedPatchesView: View {
    @ObservedObject var history: PatchHistoryModel

    var body: some View {
        Form { SavedPatchSection(history: history) }
            .cc365Canvas()
            .navigationTitle("Ứng dụng đã patch")
            .navigationBarTitleDisplayMode(.inline)
            .task { await history.refresh() }
    }
}

private struct SavedPatchRecoveryView: View {
    let patch: SavedPatch
    @State private var editingLocked = false

    var body: some View {
        PatchEditor(app: patch.app, scope: patch.patchScope,
                    locked: $editingLocked, recoveryOnly: true) {
            Section("Ứng dụng đã patch") {
                Text(patch.app.displayName)
                if patch.app.displayName != patch.app.identityDescription {
                    Text(patch.app.identityDescription).font(.caption).foregroundStyle(.secondary)
                }
                DisclosureGroup("Bản sao đã lưu") {
                    LabeledContent("Vùng đích", value: patch.patchScope.title)
                    Text(patch.app.root(for: patch.patchScope) ?? "")
                        .font(.footnote.monospaced()).textSelection(.enabled)
                }
            }
        }
        .cc365Canvas()
        .navigationTitle("Khôi phục patch")
        .navigationBarTitleDisplayMode(.inline)
        .navigationBarBackButtonHidden(editingLocked)
    }
}

private struct ManualAppPatchView: View {
    @State private var apps: [PatchTargetApp] = []
    @State private var app: PatchTargetApp?
    @State private var scope = PatchScope.data
    @State private var showingApps = false
    @State private var loading = false
    @State private var loadError: String?
    @State private var discoveryNotice: String?
    @State private var editingLocked = false

    var body: some View {
        Group {
            if let app {
                PatchEditor(app: app, scope: scope, locked: $editingLocked) { manualDestination }
                    .id(app.id + "/" + scope.rawValue)
            } else {
                Form {
                    manualDestination

                }
            }
        }
        .cc365Canvas()
        .navigationTitle("Patch thủ công")
        .navigationBarTitleDisplayMode(.inline)
        .navigationBarBackButtonHidden(editingLocked)
        .task {
            if apps.isEmpty { await loadApps() }
        }

        .sheet(isPresented: $showingApps) {
            PatchAppPicker(apps: apps, selected: app?.id, loading: loading, notice: loadError ?? discoveryNotice,
                           reload: { Task { await loadApps() } }) { item in
                if app?.id != item.id { scope = item.dataPath == nil ? .bundle : .data }
                app = item
                showingApps = false
            }
        }
    }

    @ViewBuilder private var manualDestination: some View {
        destinationSection
    }

    private var destinationSection: some View {
        Section("Đích đến") {
            if loading {
                CC365TaskProgress(title: "Đang tìm ứng dụng trên thiết bị…", phaseKey: "discovery")
            } else if let loadError {
                Text(loadError).foregroundStyle(.secondary)
                Button("Thử lại") { Task { await loadApps() } }
            } else if apps.isEmpty {
                Text("Chưa tìm thấy ứng dụng đã cài.").foregroundStyle(.secondary)
                Button("Tải lại danh sách") { Task { await loadApps() } }
            } else {
                Button { showingApps = true } label: {
                    HStack {
                        Label(app?.displayName ?? "Chọn ứng dụng", systemImage: "app.dashed")
                        Spacer()
                        Image(systemName: "chevron.up.chevron.down")
                            .font(.caption).foregroundStyle(.secondary).accessibilityHidden(true)
                    }
                    .frame(minHeight: 32)
                }.accessibilityIdentifier("patch-app")
                .disabled(editingLocked)
            }
            if let app {
                Text(app.identityDescription).font(.caption.monospaced()).textSelection(.enabled)
                if app.bundleID == nil {
                    Text("Chưa nhận diện được tên ứng dụng. Đích patch được giữ theo đường dẫn container đã chọn.")
                        .font(.footnote).foregroundStyle(.secondary)
                }
                Picker("Vùng đích", selection: $scope) {
                    ForEach(PatchScope.allCases.filter { app.root(for: $0) != nil }, id: \.self) {
                        Text($0.title).tag($0)
                    }
                }.disabled(editingLocked)
                if app.dataPath == nil {
                    Text("iOS chưa cung cấp thư mục dữ liệu của ứng dụng này. Hãy chọn ứng dụng khác để thay tệp trong Library/Caches.")
                        .font(.footnote).foregroundStyle(.secondary)
                }
                if let root = app.root(for: scope) {
                    DisclosureGroup("Đường dẫn gốc") {
                        Text(root).font(.footnote.monospaced()).textSelection(.enabled)
                    }
                }
            }
        }
    }

    @MainActor private func loadApps() async {
        guard !loading, !editingLocked else { return }
        loading = true
        loadError = nil
        defer { loading = false }
        do {
            let response = try await VersionedFilesTransport.patch("apps", as: PatchAppList.self)
            try Task.checkCancellation()
            let available = response.apps
            discoveryNotice = response.notice
            apps = available.sorted { $0.displayName.localizedStandardCompare($1.displayName) == .orderedAscending }
            if let selected = app, let updated = apps.first(where: { $0.id == selected.id }) { app = updated }
        } catch {
            if !FileTransferSupport.cancelled(error) { loadError = FileTransferSupport.message(error) }
        }
    }
}

struct PatchAppPicker: View {
    let apps: [PatchTargetApp]
    let selected: String?
    let loading: Bool
    let notice: String?
    let reload: () -> Void
    let select: (PatchTargetApp) -> Void
    @Environment(\.dismiss) private var dismiss
    @State private var query = ""

    var body: some View {
        NavigationStack {
            List {
                if loading {
                    Section { CC365TaskProgress(title: "Đang nhận diện ứng dụng…", phaseKey: "discovery") }
                }
                if !identified.isEmpty {
                    Section("Ứng dụng đã nhận diện") { ForEach(identified) { appRow($0) } }
                }
                if !unidentified.isEmpty {
                    Section {
                        ForEach(unidentified) { appRow($0) }
                    } header: { Text("Container chưa nhận diện") }
                    footer: { Text("iOS chưa cung cấp tên hoặc bundle ID. Bạn vẫn có thể chọn theo đường dẫn container.") }
                }
                if let notice, !notice.isEmpty, query.isEmpty {
                    Section { Text(notice).font(.footnote).foregroundStyle(.secondary) }
                }
            }
            .overlay { if filtered.isEmpty && !loading && !query.isEmpty { CC365SearchUnavailableView(query: query) } }
            .cc365Canvas()
            .searchable(text: $query, prompt: "Tên ứng dụng, bundle ID hoặc container")
            .navigationTitle("Chọn ứng dụng")
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .cancellationAction) { Button("Đóng") { dismiss() } }
                ToolbarItem(placement: .primaryAction) {
                    Button(action: reload) { Image(systemName: "arrow.clockwise") }
                        .disabled(loading).accessibilityLabel("Tải lại danh sách ứng dụng")
                }
            }
        }
    }

    private func appRow(_ app: PatchTargetApp) -> some View {
        Button { select(app) } label: {
            HStack {
                VStack(alignment: .leading, spacing: 4) {
                    Text(app.displayName).foregroundStyle(.primary).lineLimit(2)
                    Text(app.identityDescription).font(.caption).foregroundStyle(.secondary)
                    if let path = app.dataPath, path != app.identityDescription {
                        Text(path).font(.caption.monospaced()).foregroundStyle(.secondary)
                    }
                }
                Spacer()
                if selected == app.id { Image(systemName: "checkmark").accessibilityLabel("Đã chọn") }
            }
            .frame(minHeight: 44)
            .contentShape(Rectangle())
        }.buttonStyle(.plain)
    }

    private var identified: [PatchTargetApp] { filtered.filter { $0.bundleID != nil } }
    private var unidentified: [PatchTargetApp] { filtered.filter { $0.bundleID == nil } }

    private var filtered: [PatchTargetApp] {
        query.isEmpty ? apps : apps.filter {
            $0.displayName.localizedCaseInsensitiveContains(query) || $0.identityDescription.localizedCaseInsensitiveContains(query)
                || ($0.dataPath?.localizedCaseInsensitiveContains(query) ?? false)
        }
    }
}

private struct PatchEditor<Destination: View>: View {
    @Environment(\.accessibilityReduceMotion) private var reduceMotion
    let app: PatchTargetApp
    let scope: PatchScope
    @Binding var locked: Bool
    @ViewBuilder let selection: () -> Destination
    private let onPickSource: ((PatchSourceChoice) -> Void)?
    private let recoveryOnly: Bool

    @State private var plan: AppPatchPlan
    @State private var replacingEntry: UUID?
    @State private var status: PatchStatus?
    @State private var elapsed: Duration?
    @State private var issue: String?
    @State private var activity: String?
    @State private var picking: PatchSourceChoice?
    @State private var checkingStatus = false
    @State private var statusIssue: String?
    @State private var preview: Result<[PatchFileMapping], Error>?
    @State private var dialog: Change?
    @State private var worker: Task<Void, Never>?
    @State private var runFiles: [PatchRunFile] = []
    @State private var runInterrupted = false
    @State private var progressFeed: PatchProgressFeed?
    @State private var stopping = false
    @State private var completedAction: Change?
    @State private var pendingEncryptedSelection: URL?
    @State private var pendingEncryptedChoice: PatchSourceChoice = .file
    @State private var pendingEncryptedReplacement: UUID?
    @State private var showingEncryptedPassword = false
    enum Change { case apply, restore }

    init(app: PatchTargetApp, scope: PatchScope, locked: Binding<Bool>,
         initialSource: AppPatchSource? = nil, onPickSource: ((PatchSourceChoice) -> Void)? = nil,
         recoveryOnly: Bool = false,
         @ViewBuilder selection: @escaping () -> Destination) {
        self.app = app
        self.scope = scope
        self._locked = locked
        self.selection = selection
        self.onPickSource = onPickSource
        self.recoveryOnly = recoveryOnly
        self._plan = State(initialValue: AppPatchPlan(app: app, scope: scope,
            entries: initialSource.map { [AppPatchPlan.Entry(source: $0, destination: "")] } ?? []))
    }

    var body: some View {
        ScrollViewReader { proxy in
            editorForm
                .onChange(of: plan.entries.map(\.id)) { _ in
                    guard let entry = plan.entries.last else { return }
                    reveal(entry.source.hasEmbeddedDestinations ? "patch-preview" : "patch-source-" + entry.id.uuidString, using: proxy)
                }
                .onChange(of: issue) { error in
                    if error != nil { reveal("patch-source-error", using: proxy) }
                }
                .onChange(of: activity) { message in
                    if message != nil { reveal("patch-working", using: proxy) }
                }
        }
        .patchSourcePicker(choice: $picking) { url, choice in sourcePicked(url, choice: choice) }
        .sheet(isPresented: $showingEncryptedPassword) {
            PatchPasswordPrompt { password in
                guard let selection = pendingEncryptedSelection else { return }
                let choice = pendingEncryptedChoice
                let replacement = pendingEncryptedReplacement
                pendingEncryptedSelection = nil
                pendingEncryptedReplacement = nil
                stagePicked(selection, choice: choice, replacement: replacement, password: password)
            }
        }
        .confirmationDialog(dialog == .restore ? "Khôi phục bản gốc?" : "Áp dụng patch cho \(app.displayName)?",
                            isPresented: Binding(get: { dialog != nil }, set: { if !$0 { dialog = nil } }),
                            titleVisibility: .visible, presenting: dialog) { change in
            if change == .restore {
                Button("Khôi phục bản gốc") { restore() }
            } else {
                Button("Áp dụng patch") { apply() }
            }
            Button("Hủy", role: .cancel) {}
        } message: { change in
            if change == .restore {
                Text("PhamQuang IOS sẽ kiểm tra nội dung từng tệp, trả lại các bản gốc và gỡ các tệp mà patch đã thêm.")
            } else {
                Text("Áp dụng \(plan.entries.count) mục nguồn, tổng cộng \(plan.fileCount) tệp vào cùng ứng dụng. Hãy đóng \(app.displayName) trước khi tiếp tục để ứng dụng không thay đổi tệp trong lúc PhamQuang IOS đang ghi.")
            }
        }
        .task {
            if preview == nil { updatePreview() }
            await refreshStatus()
        }

    }

    private var editorForm: some View {
        Form {
            selection()

            if let issue {
                Section {
                    Label(issue, systemImage: "exclamationmark.circle")
                        .accessibilityIdentifier("patch-issue")
                        .id("patch-source-error")
                }
            }
            if status == nil {
                Section {
                    if checkingStatus {
                        CC365TaskProgress(title: "Đang kiểm tra trạng thái patch…", phaseKey: "status")
                    } else if let statusIssue {
                        Label(statusIssue, systemImage: "exclamationmark.circle")
                        Button("Kiểm tra lại trạng thái") { Task { await refreshStatus() } }
                    }
                }
            }
            if let activity {
                Section {
                    if let progressFeed {
                        PatchProgressView(feed: progressFeed, stopping: stopping) {
                            stopping = true
                            worker?.cancel()
                        }.id("patch-working")
                    } else {
                        VStack(alignment: .leading, spacing: 10) {
                            CC365TaskProgress(title: stopping ? "Đang dừng…" : activity,
                                detail: stopping ? "Đang hoàn tất bước hiện tại trước khi dừng." : nil,
                                phaseKey: stopping ? "stopping" : activity)
                            if !stopping { Button("Dừng") { stopping = true; worker?.cancel() }.buttonStyle(.borderless) }
                        }.id("patch-working")
                    }
                }
            }
            if let status, status.hasBackup {
                Section(status.state == .pending ? "Chờ khôi phục" : ((status.omitted_items ?? []).isEmpty ? "Patch đã áp dụng" : "Đã áp dụng một phần")) {
                    if completedAction == .apply, activity == nil {
                        CC365TaskResult(success: true, title: "Patch đã áp dụng", detail: status.message)
                            .accessibilityIdentifier("patch-operation-complete")
                    } else if !status.message.isEmpty { Text(status.message) }
                    if status.state == .applied {
                        if let created = status.created, created > 0 {
                            LabeledContent("Đã thêm", value: "\(created) tệp")
                            if status.changed > created {
                                LabeledContent("Đã thay", value: "\(status.changed - created) tệp")
                            }
                            LabeledContent("Tổng dung lượng", value: formatted(status.bytes))
                        } else {
                            LabeledContent("Đã thay", value: "\(status.changed) tệp · \(formatted(status.bytes))")
                        }
                        if status.skipped > 0 { LabeledContent("Đã khớp từ trước", value: "\(status.skipped) tệp") }
                        elapsedRow
                    }
                    Button { dialog = .restore } label: {
                        Label("Khôi phục bản gốc", systemImage: "arrow.uturn.backward")
                    }.disabled(activity != nil)
                     .accessibilityIdentifier("patch-restore")
                }
            } else if recoveryOnly {
                if let status {
                    Section("Bản gốc") {
                        if completedAction == .restore, activity == nil {
                            CC365TaskResult(success: true, title: "Đã khôi phục bản gốc", detail: status.message)
                                .accessibilityIdentifier("patch-recovery-complete")
                        } else {
                            Label(status.state == .restored ? "Đã khôi phục bản gốc" : "Không còn bản sao cần khôi phục",
                                  systemImage: "checkmark.circle")
                                .accessibilityIdentifier("patch-recovery-complete")
                            if !status.message.isEmpty { Text(status.message).font(.callout) }
                        }
                    }
                }
            } else {
                ForEach(plan.entries) { entry in sourceEntrySection(entry) }
                sourceSection
                if let preview { mappingSection(result: preview) }
                if let status, status.state == .unchanged || status.state == .restored {
                    Section("Kết quả") {
                        if completedAction != nil, activity == nil {
                            CC365TaskResult(success: true,
                                title: status.state == .restored ? "Đã khôi phục bản gốc" : "Các tệp đã khớp",
                                detail: status.message)
                                .accessibilityIdentifier("patch-operation-complete")
                        } else { Text(status.message) }
                        if status.state == .unchanged { elapsedRow }
                    }
                }
            }

            if !runFiles.isEmpty, activity == nil {
                Section {
                    NavigationLink {
                        List {
                            if runInterrupted {
                                Text("Phiên đã dừng. Đây là bước cuối PhamQuang IOS ghi nhận cho từng tệp. Xem trạng thái khôi phục để biết việc cần làm tiếp.")
                                    .font(.footnote).foregroundStyle(.secondary)
                            }
                            ForEach(runFiles) { item in
                                VStack(alignment: .leading, spacing: 5) {
                                    Text(item.path).font(.callout).textSelection(.enabled)
                                    Text(item.label).font(.footnote).foregroundStyle(.secondary)
                                }.accessibilityElement(children: .combine)
                            }
                        }.navigationTitle("Từng tệp").navigationBarTitleDisplayMode(.inline)
                    } label: {
                        LabeledContent("Chi tiết lượt vừa chạy", value: "\(runFiles.count) tệp")
                    }
                }
            }
            if let omitted = status?.omitted_items, !omitted.isEmpty {
                Section("Tệp không áp dụng") {
                    NavigationLink {
                        List(omitted, id: \.path) { item in
                            VStack(alignment: .leading, spacing: 6) {
                                Text(item.path).font(.callout).textSelection(.enabled)
                                Text(item.reason).font(.footnote).foregroundStyle(.secondary)
                            }.accessibilityElement(children: .combine)
                        }
                        .navigationTitle("Tệp đã bỏ qua").navigationBarTitleDisplayMode(.inline)
                    } label: {
                        LabeledContent("Xem lý do bỏ qua", value: "\(omitted.count) tệp")
                    }
                }
            }
        }
    }

    @MainActor private func reveal(_ id: String, using proxy: ScrollViewProxy) {
        if reduceMotion { proxy.scrollTo(id, anchor: .center) }
        else { withAnimation(.easeInOut(duration: 0.22)) { proxy.scrollTo(id, anchor: .center) } }
    }

    private var sourceSection: some View {
        Section {
            Button { beginSourcePicker(.file) } label: {
                Label("Thêm tệp, ZIP, .vailon hoặc .vpatch", systemImage: "doc.badge.plus")
                    .frame(maxWidth: .infinity, minHeight: 44, alignment: .leading)
            }.accessibilityIdentifier("patch-source-file")
            Button { beginSourcePicker(.folder) } label: {
                Label("Thêm thư mục", systemImage: "folder.badge.plus")
                    .frame(maxWidth: .infinity, minHeight: 44, alignment: .leading)
            }.accessibilityIdentifier("patch-source-folder")
            if let onPickSource {
                Menu("Chọn lại gói và ứng dụng") {
                    Button("Chọn gói patch") { onPickSource(.file) }
                    Button("Chọn thư mục") { onPickSource(.folder) }
                }
            }
        } header: { Text("Thêm nguồn patch") }
          footer: {
              Text("Mỗi nguồn có đường dẫn đích riêng trong cùng ứng dụng. Các mục được kiểm tra chung và áp dụng trong một lượt, dùng cùng bản sao khôi phục.")
          }
          .disabled(activity != nil)
    }

    private func sourceEntrySection(_ entry: AppPatchPlan.Entry) -> some View {
        Section {
            LabeledContent("Nguồn đã chọn") {
                Text(entry.source.name).lineLimit(2).truncationMode(.middle)
            }.accessibilityIdentifier("patch-selected-source")
            Text("\(entry.source.files.count) tệp · \(formatted(entry.source.size))")
                .font(.caption).foregroundStyle(.secondary)
            if entry.source.hasEmbeddedDestinations {
                Text("Dùng các đường dẫn đã ghi trong nguồn patch.")
                    .font(.footnote).foregroundStyle(.secondary)
            } else {
                TextField(entry.source.isDirectory ? "Documents/thư mục đích" : "Documents/tên-tệp", text: destinationBinding(entry.id), axis: .vertical)
                    .textInputAutocapitalization(.never).autocorrectionDisabled().font(.body.monospaced())
                    .accessibilityLabel(entry.source.isDirectory ? "Thư mục nhận nội dung" : "Đường dẫn đích")
                    .accessibilityIdentifier("patch-destination")
                Text(entry.source.isDirectory ? "Giữ các thư mục con của nguồn trong thư mục đích này." : "Đường dẫn đích phải gồm tên tệp.")
                    .font(.footnote).foregroundStyle(.secondary)
            }
            Menu("Thay nguồn") {
                Button("Chọn gói patch") { beginSourcePicker(.file, replacing: entry.id) }
                Button("Chọn thư mục") { beginSourcePicker(.folder, replacing: entry.id) }
            }
            Button("Bỏ mục nguồn", role: .destructive) {
                plan.entries.removeAll { $0.id == entry.id }
                updatePreview()
            }.accessibilityIdentifier("patch-remove-source")
        } header: {
            Text("Nguồn \((plan.entries.firstIndex(where: { $0.id == entry.id }) ?? 0) + 1) → Đích")
        }
        .disabled(activity != nil)
        .id("patch-source-" + entry.id.uuidString)
    }

    private func destinationBinding(_ id: UUID) -> Binding<String> {
        Binding(get: { plan.entries.first(where: { $0.id == id })?.destination ?? "" }, set: { value in
            guard activity == nil, let index = plan.entries.firstIndex(where: { $0.id == id }) else { return }
            plan.entries[index].destination = value
            updatePreview()
        })
    }

    private func beginSourcePicker(_ choice: PatchSourceChoice, replacing id: UUID? = nil) {
        guard activity == nil, status?.hasBackup != true else { return }
        replacingEntry = id
        picking = choice
    }

    @MainActor private func sourcePicked(_ selection: URL?, choice: PatchSourceChoice) {
        picking = nil
        let replacement = replacingEntry
        replacingEntry = nil
        guard let url = selection, activity == nil else { return }
        guard status?.hasBackup != true else {
            issue = "Hãy khôi phục bản gốc của ứng dụng này trước khi chọn nguồn mới."
            return
        }
        stagePicked(url, choice: choice, replacement: replacement, password: nil)
    }

    @MainActor private func stagePicked(_ url: URL, choice: PatchSourceChoice,
                                        replacement: UUID?, password: String?) {
        let openingArchive = choice != .folder && FileTransferSupport.isPatchArchive(url)
        start(openingArchive ? "Đang giải mã/giải nén và kiểm tra patch…" : "Đang đọc nguồn patch…") {
            let source: AppPatchSource
            do {
                source = try await plan.stageSource(url, expectDirectory: choice == .folder, password: password)
            } catch is PatchArchivePasswordRequired {
                guard password == nil else { throw PatchArchivePasswordRequired() }
                pendingEncryptedSelection = url
                pendingEncryptedChoice = choice
                pendingEncryptedReplacement = replacement
                showingEncryptedPassword = true
                return
            } catch let error as CocoaError where error.code == .fileReadNoPermission {
                throw PatchInputError("PhamQuang IOS chưa đọc được nguồn đã chọn. Hãy kiểm tra trong Tệp → Trên iPhone của tôi → PhamQuang IOS rồi chọn lại.")
            }
            try Task.checkCancellation()
            var candidate = plan
            if let replacement {
                guard let index = candidate.entries.firstIndex(where: { $0.id == replacement }) else {
                    throw PatchInputError("Mục nguồn đã thay đổi. Hãy chọn lại mục cần sửa.")
                }
                candidate.entries[index].source = source
            } else {
                candidate.entries.append(AppPatchPlan.Entry(source: source, destination: ""))
            }
            try candidate.validateSources()
            try Task.checkCancellation()
            plan = candidate
            updatePreview()
        }
    }

    private func updatePreview() {
        guard !plan.entries.isEmpty, plan.entries.allSatisfy({ $0.source.hasEmbeddedDestinations || !$0.destination.isEmpty }) else {
            preview = nil
            return
        }
        preview = Result { try plan.mappings(app: app, scope: scope) }
    }

    @ViewBuilder private func mappingSection(result: Result<[PatchFileMapping], Error>) -> some View {
        switch result {
        case .success(let files):
            Section {
                if files.count == 1, let file = files.first {
                    mappingRow(file)
                } else {
                    NavigationLink {
                        List(files) { file in mappingRow(file) }
                            .navigationTitle("Đường dẫn đích")
                            .navigationBarTitleDisplayMode(.inline)
                    } label: { Text("\(files.count) tệp · \(formatted(plan.size))") }
                }
                Button { dialog = .apply } label: { Label("Áp dụng patch", systemImage: "square.and.arrow.up") }
                    .disabled(activity != nil || status == nil)
                    .accessibilityIdentifier("patch-apply")
                    .id("patch-preview")
            } header: { Text("Xem trước đường dẫn") }
              footer: {
                  if scope == .bundle {
                      Text("Tệp và thư mục cha phải có sẵn trong gói .app. iOS có thể từ chối ghi. Thay tài nguyên đã ký có thể khiến ứng dụng không mở được.")
                  } else if files.allSatisfy({ $0.destination.hasPrefix(PatchDestination.cacheRoot + "/") }) {
                      Text("Chọn tệp đích đã có trong Library/Caches. PhamQuang IOS lưu bản gốc để bạn có thể khôi phục sau.")
                  } else if files.allSatisfy({ $0.destination.hasPrefix("Documents/") }) {
                      Text("PhamQuang IOS sao lưu các tệp đã có và thêm tệp mới vào thư mục đích. Chọn Khôi phục bản gốc để hoàn tác cả hai.")
                  } else {
                      Text("Thư mục cha phải có sẵn. PhamQuang IOS lưu bản gốc trước khi thay tệp.")
                  }
              }
        case .failure(let error):
            Section { Text(FileTransferSupport.message(error)).font(.footnote).foregroundStyle(.secondary) }
        }
    }

    private func mappingRow(_ file: PatchFileMapping) -> some View {
        VStack(alignment: .leading, spacing: 4) {
            Text(file.destination).font(.callout.monospaced()).textSelection(.enabled)
            Text(formatted(file.size)).font(.caption).foregroundStyle(.secondary)
        }.accessibilityElement(children: .combine)
    }

    @ViewBuilder private var elapsedRow: some View {
        if let elapsed {
            LabeledContent("Thời gian áp dụng", value: elapsed.formatted(.units(allowed: [.minutes, .seconds], width: .abbreviated)))
        }
    }

    private func formatted(_ bytes: UInt64) -> String {
        ByteCountFormatter.string(fromByteCount: Int64(bytes), countStyle: .file)
    }

    private var targetFields: [String: Any] {
        fields(for: app)
    }

    private func fields(for target: PatchTargetApp) -> [String: Any] {
        var fields: [String: Any] = ["patch_scope": scope.rawValue]
        if let targetID = target.targetID { fields["target_id"] = targetID }
        if let bundleID = target.bundleID { fields["bundle_id"] = bundleID }
        return fields
    }

    @MainActor private func refreshStatus() async {
        guard !checkingStatus, worker == nil, activity == nil else { return }


        status = nil
        completedAction = nil
        checkingStatus = true
        statusIssue = nil
        defer { checkingStatus = false }
        do { try await readStatus() }
        catch {
            statusIssue = FileTransferSupport.cancelled(error)
                ? "Chưa kiểm tra xong trạng thái. Hãy thử lại."
                : FileTransferSupport.message(error)
        }
    }

    @MainActor private func readStatus() async throws {
        let result = try await VersionedFilesTransport.patch("status", fields: targetFields, as: PatchStatus.self)
        try Task.checkCancellation()
        status = result
    }

    @MainActor private func start(_ text: String, changing: Bool = false,
                                  operation: @escaping @MainActor () async throws -> Void) {
        guard activity == nil, worker == nil else { return }
        issue = nil
        completedAction = nil
        runFiles = []
        runInterrupted = false
        activity = text
        locked = true
        worker = Task { @MainActor in
            defer {
                if let feed = progressFeed { feed.finish(); runFiles = feed.fileDetails() }
                progressFeed = nil
                stopping = false
                activity = nil
                worker = nil
                locked = false
            }
            do { try await operation() }
            catch {
                runInterrupted = changing
                let cancelled = FileTransferSupport.cancelled(error)
                let original = cancelled ? "Đã dừng. Kiểm tra trạng thái bản gốc để tiếp tục." : FileTransferSupport.message(error)
                if changing {


                    status = nil

                    let refresh = Task { @MainActor in try await readStatus() }
                    do { try await refresh.value }
                    catch { statusIssue = FileTransferSupport.message(error); issue = original; return }
                }
                if !cancelled || changing { issue = original }
            }
        }
    }

    @MainActor private func apply() {
        guard !plan.entries.isEmpty, let status, !status.hasBackup else { return }
        let submitted = plan
        start("Đang áp dụng và kiểm tra tệp…", changing: true) {
            defer { withExtendedLifetime(submitted) {} }
            let target = app
            try Task.checkCancellation()
            let files = try submitted.mappings(app: target, scope: scope)
            var fields = fields(for: target)
            fields["app_name"] = target.displayName
            if let owner = try submitted.declaredBundleID() { fields["declared_bundle_id"] = owner }
            if let root = target.root(for: scope) { fields["expected_root"] = root }
            fields["patch_items"] = files.map { ["relative_path": $0.destination, "local_path": $0.local.path] }
            activity = "Đang áp dụng và kiểm tra tệp…"
            let feed = PatchProgressFeed(plan: files.map(\.destination))
            progressFeed = feed
            let start = ContinuousClock.now
            self.status = try await VersionedFilesTransport.patch("apply", fields: fields, as: PatchStatus.self) { feed.receive($0) }
            if let receipt = self.status, (receipt.state == .applied || receipt.state == .unchanged), (receipt.omitted_items ?? []).isEmpty {
                completedAction = .apply
            }
            elapsed = start.duration(to: .now)
            plan = AppPatchPlan(app: app, scope: scope)
            preview = nil
        }
    }

    @MainActor private func restore() {
        guard status?.hasBackup == true else { return }
        start("Đang khôi phục và kiểm tra tệp…", changing: true) {
            let feed = PatchProgressFeed(plan: status?.restore_paths ?? [])
            progressFeed = feed
            self.status = try await VersionedFilesTransport.patch("restore", fields: targetFields, as: PatchStatus.self) { feed.receive($0) }
            if self.status?.state == .restored { completedAction = .restore }
            elapsed = nil
            plan = AppPatchPlan(app: app, scope: scope)
            preview = nil
        }
    }
}
