import Foundation
import Combine

struct SavedPatch: Decodable, Identifiable, Sendable {
    let id: String
    let app: PatchTargetApp
    let patchScope: PatchScope
    let status: PatchStatus
    let updatedAt: Double?
    let canRestore: Bool
    let notice: String?

    enum CodingKeys: String, CodingKey {
        case id, app, status, notice
        case patchScope = "patch_scope", updatedAt = "updated_at", canRestore = "can_restore"
    }
}

private struct PatchHistoryResponse: Decodable, Sendable {
    let patches: [SavedPatch]
    let notice: String?
}

@MainActor
final class PatchHistoryModel: ObservableObject {
    @Published private(set) var patches: [SavedPatch] = []
    @Published private(set) var isLoading = false
    @Published private(set) var issue: String?
    @Published private(set) var notice: String?

    func refresh() async {
        guard !isLoading else { return }
        isLoading = true
        issue = nil
        defer { isLoading = false }
        do {
            let response = try await VersionedFilesTransport.patch("history", as: PatchHistoryResponse.self)
            try Task.checkCancellation()
            patches = response.patches
            notice = response.notice
        } catch {
            issue = FileTransferSupport.cancelled(error)
                ? "Chưa tải xong bản sao khôi phục. Hãy thử lại."
                : FileTransferSupport.message(error)
        }
    }
}
