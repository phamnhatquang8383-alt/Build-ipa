import Foundation

struct PatchRunFile: Sendable, Identifiable {
    let path: String
    let phase: String
    var id: String { path }
    var label: String {
        switch phase {
        case "applied": return "Đã áp dụng"
        case "skipped", "unchanged": return "Đã khớp từ trước"
        case "omitted": return "Đã bỏ qua"
        case "restored": return "Đã khôi phục"
        case "preserved": return "Giữ nội dung đã thay đổi"
        case "checking": return "Đã bắt đầu kiểm tra"
        case "staging": return "Đã bắt đầu chuẩn bị"
        case "comparing": return "Đã bắt đầu đối chiếu"
        case "applying": return "Đã bắt đầu áp dụng"
        case "restoring": return "Đã bắt đầu khôi phục"
        default: return "Chưa có kết quả"
        }
    }
}

struct PatchProgressFrame: Sendable {
    let event: RustPatchProgress
    let previous: String
    let active: String
    let upcoming: String
}




final class PatchProgressFeed: @unchecked Sendable {
    let frames: AsyncStream<PatchProgressFrame>
    private let output: AsyncStream<PatchProgressFrame>.Continuation
    private let lock = NSLock()
    private let plan: [String]
    private let indexes: [String: Int]
    private var active = ""
    private var previous = ""
    private var phases = [String: String]()
    private var seenPaths = [String]()

    init(plan: [String]) {
        self.plan = plan
        indexes = Dictionary(plan.enumerated().map { ($0.element, $0.offset) }, uniquingKeysWith: { first, _ in first })
        (frames, output) = AsyncStream.makeStream(bufferingPolicy: .bufferingNewest(1))
    }

    func receive(_ event: RustPatchProgress) {
        lock.lock()
        defer { lock.unlock() }
        if !event.path.isEmpty {
            if phases.updateValue(event.phase, forKey: event.path) == nil { seenPaths.append(event.path) }
        }
        if !event.path.isEmpty, active != event.path {
            previous = active
            active = event.path
        }
        let next = indexes[active].flatMap { $0 + 1 < plan.count ? plan[$0 + 1] : nil } ?? ""
        output.yield(.init(event: event, previous: previous, active: active, upcoming: next))
    }

    func fileDetails() -> [PatchRunFile] {
        lock.lock()
        defer { lock.unlock() }
        return seenPaths.map { PatchRunFile(path: $0, phase: phases[$0] ?? "") }
    }

    func finish() { output.finish() }
}
