import Foundation

struct DeviceFileEntry: Decodable, Sendable, Identifiable {
    let name: String
    let displayName: String?
    let kind: String
    let size: UInt64?
    let modified: Int64?
    let path: String?
    let subtitle: String?
    var created: Int64? = nil
    var id: String { path ?? name }

    private enum CodingKeys: String, CodingKey {
        case name, kind, size, modified, path, subtitle, created
        case displayName = "display_name"
    }
}
struct DeviceFileDetails: Decodable, Sendable, Identifiable {
    let name: String
    let path: String
    let kind: String
    let size: UInt64
    let modified: Int64
    let created: Int64
    let permissions: String
    let owner: UInt32
    let group: UInt32
    let inode: UInt64
    var id: String { path }
}

struct FileListOptions: Hashable, Sendable {
    var query = ""
    var sort = "name"
    var ascending = true
    var foldersFirst = true
    var showHidden = true
}
struct DeviceFilesPage: Decodable, Sendable {
    let entries: [DeviceFileEntry]
    let nextOffset: Int?
    let total: Int
    var notice: String? = nil
}
struct FileAccessReceipt: Decodable, Sendable {
    let exactBytesRecovered: Bool
    let cleanupComplete: Bool
    let recoveryOnly: Bool
    let message: String
}



@MainActor enum DeviceFilesTransport {
    private struct Receipt: Decodable, Sendable {
        let bytes: UInt64
        let warning: String?
    }

    private static func perform<T: Decodable & Sendable>(_ parameters: [String: Any],
        as type: T.Type, patch: Bool = false,
        onProgress: @escaping @Sendable (RustPatchProgress) -> Void = { _ in }) async throws -> T {
        let progress = Progress(totalUnitCount: 1)
        return try await withTaskCancellationHandler {
            try Task.checkCancellation()
            return try await withCheckedThrowingContinuation { continuation in
                let complete: @Sendable ([AnyHashable: Any]?, Error?) -> Void = { result, error in
                    if let error { continuation.resume(throwing: error); return }
                    guard let result else {
                        continuation.resume(throwing: PatchInputError("Chưa nhận được kết quả thao tác tệp."))
                        return
                    }
                    do {
                        let data = try JSONSerialization.data(withJSONObject: result)
                        continuation.resume(returning: try JSONDecoder().decode(type, from: data))
                    } catch { continuation.resume(throwing: error) }
                }
                if patch {
                    CCBQPatchEngine.perform(request: parameters, progress: progress, onProgress: { event in
                        guard let data = try? JSONSerialization.data(withJSONObject: event),
                              let decoded = try? JSONDecoder().decode(RustPatchProgress.self, from: data) else { return }
                        onProgress(decoded)
                    }, completion: complete)
                } else {
                    CCBQFileSystem.perform(request: parameters, progress: progress, completion: complete)
                }
            }
        } onCancel: { progress.cancel() }
    }

    static func list(path: String, offset: Int, options: FileListOptions = FileListOptions()) async throws -> DeviceFilesPage {
        try await perform(["action": "list", "path": path, "offset": offset, "query": String(options.query.prefix(256)),
                           "sort": options.sort, "ascending": options.ascending, "folders_first": options.foldersFirst,
                           "show_hidden": options.showHidden], as: DeviceFilesPage.self)
    }
    static func ensureWorkspace() async throws {
        _ = try await perform(["action": "ensureWorkspace"], as: Receipt.self)
    }
    static func makeFolder(parent: String, name: String) async throws {
        _ = try await perform(["action": "mkdir", "parent": parent, "name": name], as: Receipt.self)
    }
    static func upload(local: URL, parent: String, name: String) async throws -> String? {
        try await perform(["action": "import", "parent": parent, "name": name,
                           "local_path": local.path], as: Receipt.self).warning
    }
    static func delete(path: String) async throws {
        _ = try await perform(["action": "delete", "path": path], as: Receipt.self)
    }
    static func download(path: String, to local: URL) async throws {
        _ = try await perform(["action": "download", "path": path, "local_path": local.path], as: Receipt.self)
    }
    static func details(path: String) async throws -> DeviceFileDetails {
        try await perform(["action": "details", "path": path], as: DeviceFileDetails.self)
    }
    static func move(path: String, to destination: String) async throws {
        _ = try await perform(["action": "move", "path": path, "destination": destination], as: Receipt.self)
    }
    static func uploadTree(local: URL, to path: String) async throws {
        _ = try await perform(["action": "importTree", "path": path, "local_path": local.path], as: Receipt.self)
    }
    static func replace(local: URL, path: String, expected: URL) async throws {
        _ = try await perform(["action": "replace", "path": path, "local_path": local.path,
                               "expected_path": expected.path], as: Receipt.self)
    }
    static func patch<T: Decodable & Sendable>(_ action: String, fields: [String: Any] = [:],
        as type: T.Type, onProgress: @escaping @Sendable (RustPatchProgress) -> Void = { _ in }) async throws -> T {
        var parameters = fields
        parameters["action"] = action
        return try await perform(parameters, as: type, patch: true, onProgress: onProgress)
    }
    static func checkAccess() async throws -> FileAccessReceipt {
        try await perform(["action": "check"], as: FileAccessReceipt.self)
    }
}
