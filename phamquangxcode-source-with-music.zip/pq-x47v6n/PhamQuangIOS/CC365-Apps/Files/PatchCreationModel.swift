import Foundation

struct PatchCreationError: LocalizedError, Sendable {
    let message: String
    init(_ message: String) { self.message = message }
    var errorDescription: String? { message }
}

struct PatchCreationFile: Codable, Hashable, Sendable {

    let relativePath: String
    let size: UInt64
    let payloadName: String
}

struct PatchCreationMapping: Codable, Identifiable, Hashable, Sendable {
    let id: UUID
    var bundleID: String
    var destination: String
    let isDirectory: Bool
    let sourceName: String
    let snapshotID: UUID
    let files: [PatchCreationFile]
    var fileCount: Int { files.count }
    var totalBytes: UInt64 { files.reduce(0) { $0 + $1.size } }
    func target(for file: PatchCreationFile) -> String {
        isDirectory ? destination + "/" + file.relativePath : destination
    }
}

struct PatchCreationProject: Codable, Identifiable, Hashable, Sendable {
    let id: UUID
    var name: String
    var author: String
    let createdAt: Date
    var updatedAt: Date
    var mappings: [PatchCreationMapping]
    var fileCount: Int { mappings.reduce(0) { $0 + $1.fileCount } }
    var totalBytes: UInt64 { mappings.reduce(0) { $0 + $1.totalBytes } }
    var bundleIDs: [String] { Array(Set(mappings.map(\.bundleID))).sorted() }
}

enum PatchCreationValidation {
    static let maximumFiles = 1_024
    static let maximumFileBytes: UInt64 = 128 * 1_024 * 1_024
    static let maximumTotalBytes: UInt64 = 256 * 1_024 * 1_024

    static func metadata(name: String, author: String) throws {
        guard !name.isEmpty, name == name.trimmingCharacters(in: .whitespacesAndNewlines),
              name.utf8.count <= 120, author.utf8.count <= 160,
              author == author.trimmingCharacters(in: .whitespacesAndNewlines),
              !name.unicodeScalars.contains(where: CharacterSet.controlCharacters.contains),
              !author.unicodeScalars.contains(where: CharacterSet.controlCharacters.contains) else {
            throw PatchCreationError("Nhập tên dự án tối đa 120 byte và tác giả tối đa 160 byte, không chứa ký tự điều khiển.")
        }
    }

    static func bundle(_ value: String) throws {
        let allowed = CharacterSet(charactersIn: "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789.-_")
        let parts = value.split(separator: ".", omittingEmptySubsequences: false)
        guard !value.isEmpty, value.utf8.count <= 255, parts.count >= 2,
              parts.allSatisfy({ !$0.isEmpty }), UUID(uuidString: value) == nil,
              value.rangeOfCharacter(from: allowed.inverted) == nil else {
            throw PatchCreationError("Nhập bundle ID của ứng dụng, ví dụ com.example.app; không dùng UUID container.")
        }
    }

    static func path(_ value: String) throws {
        let parts = value.split(separator: "/", omittingEmptySubsequences: false)
        guard !value.isEmpty, value.utf8.count <= 1_024, parts.count <= 32,
              parts.allSatisfy({ FileTransferSupport.validName(String($0)) && !$0.hasPrefix(".") && $0 != "__MACOSX" }) else {
            throw PatchCreationError("Đường dẫn không hợp lệ: không dùng đường dẫn tuyệt đối, tệp ẩn, liên kết hay dấu .. .")
        }
    }

    static func destination(_ value: String, isDirectory: Bool) throws {
        try path(value)
        let root = value == "Documents" || value == "Library/Caches"
        guard value.hasPrefix("Documents/") || value.hasPrefix("Library/Caches/") || (isDirectory && root) else {
            throw PatchCreationError("Đích phải nằm trong Documents hoặc Library/Caches. Với tệp, hãy nhập cả tên tệp đích.")
        }
    }

    static func normalized(_ value: String) -> String {
        value.precomposedStringWithCanonicalMapping.lowercased(with: Locale(identifier: "en_US_POSIX"))
    }



    static func project(_ project: PatchCreationProject, allowEmpty: Bool = true) throws {
        try metadata(name: project.name, author: project.author)
        guard project.mappings.count <= maximumFiles, allowEmpty || !project.mappings.isEmpty else {
            throw PatchCreationError("Thêm ít nhất một tệp trước khi xuất patch.")
        }
        var ids = Set<UUID>(), snapshots = Set<UUID>(), targets = Set<String>()
        var count = 0
        var bytes: UInt64 = 0
        for mapping in project.mappings {
            try bundle(mapping.bundleID)
            try destination(mapping.destination, isDirectory: mapping.isDirectory)
            guard ids.insert(mapping.id).inserted, snapshots.insert(mapping.snapshotID).inserted,
                  FileTransferSupport.validName(mapping.sourceName), !mapping.sourceName.hasPrefix("."),
                  !mapping.files.isEmpty, mapping.isDirectory || mapping.files.count == 1 else {
                throw PatchCreationError("Ánh xạ nguồn không hợp lệ hoặc thư mục không có tệp.")
            }
            var payloads = Set<String>()
            for file in mapping.files {
                if mapping.isDirectory { try path(file.relativePath) }
                else if !file.relativePath.isEmpty { throw PatchCreationError("Ánh xạ tệp có đường dẫn nguồn không hợp lệ.") }
                guard let payload = UUID(uuidString: file.payloadName), payload.uuidString == file.payloadName,
                      payloads.insert(file.payloadName).inserted,
                      file.size <= maximumFileBytes, bytes <= maximumTotalBytes - file.size else {
                    throw PatchCreationError("Mỗi tệp tối đa 128 MiB; toàn bộ dự án tối đa 256 MiB.")
                }
                count += 1
                guard count <= maximumFiles else { throw PatchCreationError("Một dự án hỗ trợ tối đa 1.024 tệp.") }
                bytes += file.size
                let target = mapping.target(for: file)
                try destination(target, isDirectory: false)
                let key = normalized(mapping.bundleID) + "/" + normalized(target)
                guard targets.insert(key).inserted else {
                    throw PatchCreationError("Các ánh xạ trùng đường dẫn đích, kể cả khác chữ hoa hoặc cách viết Unicode.")
                }
            }
        }
        for target in targets {
            var parent = target
            while let slash = parent.lastIndex(of: "/") {
                parent = String(parent[..<slash])
                if targets.contains(parent) { throw PatchCreationError("Một đường dẫn đích vừa là tệp vừa là thư mục của tệp khác.") }
            }
        }
    }
}


final class PatchCreationExport: @unchecked Sendable {
    let urls: [URL]
    private let transfer: FileTransferItem
    init(urls: [URL], transfer: FileTransferItem) { self.urls = urls; self.transfer = transfer }
}
