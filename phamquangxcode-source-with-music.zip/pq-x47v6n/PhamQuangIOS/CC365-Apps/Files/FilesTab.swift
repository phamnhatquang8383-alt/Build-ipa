import Combine
import SwiftUI
import UniformTypeIdentifiers

struct FilesTab: View {
    @State private var navigation: [FilesRoute] = []
    @StateObject private var clipboard = FileBrowserClipboard()

    var body: some View {
        NavigationStack(path: $navigation) {
            FileDirectoryView(folder: .root)
            .navigationDestination(for: FilesRoute.self) { route in
                switch route {
                case .folder(let folder): FileDirectoryView(folder: folder)
                case .accessCheck: BQAccessCheckView()
                }
            }
        }
        .environmentObject(clipboard)
    }
}

private enum FilesRoute: Hashable {
    case folder(FileFolder)
    case accessCheck
}

private struct FileFolder: Hashable {
    let path: String
    let createWorkspace: Bool
    let displayTitle: String?
    static let root = FileFolder(path: "/", createWorkspace: false)
    static let workspace = FileFolder(path: "/CC365", createWorkspace: true)

    init(path: String, createWorkspace: Bool, displayTitle: String? = nil) {
        self.path = path
        self.createWorkspace = createWorkspace
        self.displayTitle = displayTitle
    }

    var title: String {
        if let displayTitle, !displayTitle.isEmpty { return displayTitle }
        switch path {
        case "/": return "Tệp"
        case "/CC365": return "Tệp PhamQuang IOS"
        default: return String(path.split(separator: "/").last ?? "")
        }
    }
    var writable: Bool { path == "/CC365" || path.hasPrefix("/CC365/") }
    func child(_ name: String) -> String { path == "/" ? "/" + name : path + "/" + name }
}

private struct FileDirectoryView: View {
    let folder: FileFolder
    @EnvironmentObject private var clipboard: FileBrowserClipboard
    @StateObject private var listing = FileListing()
    @State private var importing = false
    @State private var naming = false
    @State private var newName = ""
    @State private var issue: String?
    @State private var deleteCandidate: DeviceFileEntry?
    @State private var transferLabel: String?
    @State private var transfer: Task<Void, Never>?
    @State private var ticket = UUID()
    @State private var sheet: FilePresentation?
    @State private var presentedFile: FileTransferItem?
    @State private var capturedPatch: PatchCaptureSource?
    @State private var details: DeviceFileDetails?
    @State private var inspector: FileInspectorRequest?
    @State private var renameCandidate: DeviceFileEntry?
    @State private var pasteNaming = false
    @State private var query = ""
    @AppStorage("cc365.files.sort") private var sort = "name"
    @AppStorage("cc365.files.ascending") private var ascending = true
    @AppStorage("cc365.files.foldersFirst") private var foldersFirst = true
    @AppStorage("cc365.files.showHidden") private var showHidden = false

    private var options: FileListOptions {
        FileListOptions(query: query, sort: sort, ascending: ascending, foldersFirst: foldersFirst, showHidden: showHidden)
    }

    var body: some View {
        directoryContent
        .cc365FilePicker(isPresented: $importing, kind: .file) { file in
            if let file { upload(file) }
        }
        .alert("Tạo thư mục", isPresented: $naming) {
            TextField("Tên thư mục", text: $newName).autocorrectionDisabled()
            Button("Hủy", role: .cancel) {}
            Button("Tạo") { makeFolder() }
                .disabled(!FileTransferSupport.validName(newName.trimmingCharacters(in: .whitespacesAndNewlines)))
        }
        .alert("Đổi tên", isPresented: Binding(get: { renameCandidate != nil }, set: { if !$0 { renameCandidate = nil } })) {
            TextField("Tên mới", text: $newName).autocorrectionDisabled()
            Button("Hủy", role: .cancel) { renameCandidate = nil }
            Button("Đổi tên") { rename() }.disabled(!FileTransferSupport.validName(newName))
        } message: { Text("Tên đã tồn tại sẽ được giữ nguyên.") }
        .alert(clipboard.selection?.operation.title ?? "Lưu tại đây", isPresented: $pasteNaming) {
            TextField("Tên đích", text: $newName).autocorrectionDisabled()
            Button("Hủy", role: .cancel) {}
            Button("Lưu") { paste() }.disabled(!FileTransferSupport.validName(newName))
        } message: { Text("Lưu trong \(folder.path). Không ghi đè mục đã tồn tại.") }
        .confirmationDialog("Xóa “" + (deleteCandidate?.name ?? "") + "”?",
                            isPresented: Binding(get: { deleteCandidate != nil }, set: { if !$0 { deleteCandidate = nil } }),
                            titleVisibility: .visible, presenting: deleteCandidate) { entry in
            Button("Xóa", role: .destructive) { delete(entry) }
            Button("Hủy", role: .cancel) {}
        } message: { entry in
            if entry.kind == "directory" { Text("Chỉ có thể xóa thư mục trống.") }
        }
        .alert("Thao tác tệp", isPresented: Binding(get: { issue != nil }, set: { if !$0 { issue = nil } })) {
            Button("Đóng") { issue = nil }
        } message: { Text(issue ?? "") }
        .sheet(item: $capturedPatch) { source in
            NavigationStack { PatchCreationView(seed: source) }
        }
        .sheet(item: $details) { value in FileDetailsView(details: value) }
        .sheet(item: $inspector) { request in
            FileInspectorView(request: request, onSaved: { load(0) }, finish: { inspector = nil })
        }
        .sheet(item: $sheet, onDismiss: clearPresentedFile) { item in
            FilePresentationView(item: item) {
                sheet = nil
                clearPresentedFile()
            }
        }
    }

    private var directoryList: some View {
        List {
            if folder == .root {
                Section {
                    NavigationLink(value: FilesRoute.folder(.workspace)) {
                        Label("Tệp PhamQuang IOS", systemImage: "folder.fill")
                    }.accessibilityIdentifier("files-workspace")
                    NavigationLink(value: FilesRoute.accessCheck) {
                        Label("Kiểm tra truy cập", systemImage: "checkmark.shield")
                    }.accessibilityIdentifier("files-access-check")
                }
            }
            if let selection = clipboard.selection {
                Section {
                    Label(selection.operation.title + ": " + selection.name, systemImage: selection.operation.symbol)
                        .font(.subheadline)
                    if folder.writable {
                        Button("Lưu tại đây…") { newName = selection.suggestedName; pasteNaming = true }
                            .disabled(transfer != nil).accessibilityIdentifier("files-paste-here")
                    } else {
                        NavigationLink(value: FilesRoute.folder(.workspace)) { Text("Chọn đích trong Tệp PhamQuang IOS") }
                    }
                    Button("Hủy lựa chọn", role: .cancel) { clipboard.selection = nil }.disabled(transfer != nil)
                } footer: { Text("Có thể sao chép nguồn BQCore vào vùng tệp riêng. Di chuyển và thay đổi chỉ áp dụng trong Tệp PhamQuang IOS.") }
            }
            if let transferLabel {
                Section {
                    VStack(alignment: .leading, spacing: 8) {
                        CC365TaskProgress(title: transferLabel)
                        Button("Hủy") { transfer?.cancel() }.buttonStyle(.borderless)
                    }
                }
            }
            Section {
                if let error = listing.error {
                    VStack(alignment: .leading, spacing: 8) {
                        Text(error).foregroundStyle(.secondary)
                        Button("Thử lại") { load(listing.failedOffset) }.accessibilityIdentifier("files-retry")
                    }
                }
                if let notice = listing.notice {
                    Text(notice).font(.caption).foregroundStyle(.secondary)
                        .accessibilityIdentifier("files-listing-notice")
                }
                ForEach(visibleEntries) { entry in fileRow(entry) }
                if listing.loading {
                    CC365TaskProgress(title: listing.rows.isEmpty ? "Đang mở thư mục…" : "Đang tải…")
                } else if listing.rows.isEmpty && listing.error == nil && listing.loaded {
                    Text(!query.isEmpty ? "Không tìm thấy kết quả" : listing.notice == nil ? "Không có mục phù hợp" : "Chưa có mục nào được hiển thị.").foregroundStyle(.secondary)
                    if folder.writable {
                        Button { importing = true } label: {
                            Label("Nhập tệp", systemImage: "square.and.arrow.down")
                        }
                        .disabled(transfer != nil)
                        .accessibilityIdentifier("files-import-empty")
                    }
                }
                if !listing.loading, listing.error == nil, let offset = listing.nextOffset {
                    Button("Xem thêm (\(listing.rows.count)/\(listing.total))") { load(offset) }
                        .accessibilityIdentifier("files-more")
                }
            } header: {
                if folder == .root { Text("Thư mục trên thiết bị") }
                else {
                    Text(folder.path).font(.caption).textCase(nil).textSelection(.enabled)
                        .accessibilityIdentifier("files-current-path")
                }
            }
        }
    }

    private var directoryContent: some View {
        directoryList
        .listStyle(.insetGrouped)
        .cc365Canvas()
        .navigationTitle(folder.title)
        .searchable(text: $query, prompt: "Tìm tên tệp hoặc ứng dụng")
        .toolbar {
            ToolbarItem(placement: .topBarTrailing) {
                Menu {
                    Menu {
                        Picker("Sắp xếp", selection: $sort) {
                            Text("Tên").tag("name")
                            Text("Kích thước").tag("size")
                            Text("Ngày sửa").tag("modified")
                            Text("Ngày tạo").tag("created")
                        }
                        Toggle("Tăng dần", isOn: $ascending)
                        Toggle("Thư mục trước", isOn: $foldersFirst)
                    } label: { Label("Sắp xếp", systemImage: "arrow.up.arrow.down") }
                    Toggle("Hiện tệp ẩn", isOn: $showHidden)
                    Button { UIPasteboard.general.string = folder.path } label: { Label("Sao chép đường dẫn", systemImage: "doc.on.doc") }
                    NavigationLink { SourceLicensesView() } label: {
                        Label("Giấy phép nguồn mở", systemImage: "doc.text")
                    }
                    if folder.writable {
                        Button { importing = true } label: { Label("Nhập tệp", systemImage: "square.and.arrow.down") }
                        Button { newName = ""; naming = true } label: { Label("Tạo thư mục", systemImage: "folder.badge.plus") }
                    }
                    Button { load(0) } label: { Label("Làm mới", systemImage: "arrow.clockwise") }
                } label: {
                    Image(systemName: "ellipsis.circle")
                }
                .disabled(transfer != nil)
                .accessibilityLabel("Thao tác thư mục")
                .accessibilityIdentifier("files-actions")
            }
        }
        .task(id: options) {
            listing.reset()
            if !query.isEmpty { try? await Task.sleep(for: .milliseconds(250)) }
            if !Task.isCancelled { await load(0)?.value }
        }
        .refreshable { await load(0)?.value }
        .onDisappear {
            listing.cancel()
            transfer?.cancel()
            ticket = UUID()
            transfer = nil
            transferLabel = nil
        }
    }

    private func clearPresentedFile() {
        presentedFile?.remove()
        presentedFile = nil
    }

    private var visibleEntries: [DeviceFileEntry] {

        folder == .root ? listing.rows.filter { ($0.path ?? folder.child($0.name)) != "/CC365" || $0.kind != "directory" } : listing.rows
    }

    @ViewBuilder private func fileRow(_ entry: DeviceFileEntry) -> some View {
        let row = DeviceFileRow(entry: entry)
        let deletable = folder.writable && (entry.kind == "file" || entry.kind == "directory")
        Group {
            if entry.kind == "directory" {
                NavigationLink(value: FilesRoute.folder(FileFolder(path: entry.path ?? folder.child(entry.name),
                    createWorkspace: false, displayTitle: entry.displayName ?? entry.name))) { row }
                    .disabled(transfer != nil)
            } else if entry.kind == "file" {
                Button { fetch(entry, preview: true) } label: { row }
                    .buttonStyle(.plain)
                    .disabled(transfer != nil)
                    .accessibilityHint("Xem hoặc lưu tệp")
            } else {
                row
            }
        }
        .contextMenu {
            Button { showDetails(entry) } label: { Label("Thông tin", systemImage: "info.circle") }
            Button { UIPasteboard.general.string = entry.path ?? folder.child(entry.name) } label: { Label("Sao chép đường dẫn", systemImage: "doc.on.doc") }
            if entry.kind == "file" || entry.kind == "directory" {
                Button { select(entry, operation: .copy) } label: { Label("Sao chép…", systemImage: "doc.on.doc") }
                Button { select(entry, operation: .compress) } label: { Label("Nén thành ZIP…", systemImage: "doc.zipper") }
                if folder.writable {
                    Button { select(entry, operation: .move) } label: { Label("Di chuyển…", systemImage: "folder") }
                    Button { newName = entry.name; renameCandidate = entry } label: { Label("Đổi tên", systemImage: "pencil") }
                }
                Button {
                    run("Đang chụp nguồn patch…") {
                        capturedPatch = try await PatchCaptureService.capture(path: entry.path ?? folder.child(entry.name), isDirectory: entry.kind == "directory")
                    }
                } label: { Label("Tạo patch từ " + (entry.kind == "directory" ? "thư mục" : "tệp"), systemImage: "doc.badge.plus") }
                .disabled(transfer != nil)
            }
            if entry.kind == "file" {
                Menu {
                    ForEach(FileInspectorMode.allCases) { mode in
                        Button { inspect(entry, mode: mode) } label: { Label(mode.title, systemImage: mode.systemImage) }
                    }
                } label: { Label("Mở bằng", systemImage: "doc.text.magnifyingglass") }
                if ["zip", "vailon"].contains((entry.name as NSString).pathExtension.lowercased()) {
                    Button { select(entry, operation: .extract) } label: { Label("Giải nén…", systemImage: "archivebox") }
                }
                Button { fetch(entry, preview: false) } label: { Label("Lưu vào Tệp…", systemImage: "square.and.arrow.down") }
                    .disabled(transfer != nil)
            }
            if deletable { deleteButton(entry) }
        }
        .swipeActions(edge: .trailing, allowsFullSwipe: false) {
            if deletable { deleteButton(entry) }
        }
    }

    private func deleteButton(_ entry: DeviceFileEntry) -> some View {
        Button(role: .destructive) { deleteCandidate = entry } label: {
            Label("Xóa", systemImage: "trash")
        }
        .disabled(transfer != nil)
    }

    private func delete(_ entry: DeviceFileEntry) {
        guard folder.writable, entry.kind == "file" || entry.kind == "directory" else { return }
        run("Đang xóa…", refresh: true) {
            try await VersionedFilesTransport.delete(path: entry.path ?? folder.child(entry.name))
        }
    }

    @discardableResult @MainActor private func load(_ offset: Int) -> Task<Void, Never>? {
        guard transfer == nil else { return nil }
        return listing.load(folder: folder, offset: offset, options: options)
    }

    @MainActor private func run(_ label: String, refresh: Bool = false, _ operation: @escaping @MainActor () async throws -> Void) {
        guard transfer == nil else { return }
        listing.cancel()
        let current = UUID()
        ticket = current
        transferLabel = label
        transfer = Task { @MainActor in
            do {
                try await operation()
            } catch {
                if !Task.isCancelled && current == ticket && !FileTransferSupport.cancelled(error) {
                    issue = FileTransferSupport.message(error)
                }
            }
            guard current == ticket else { return }
            transfer = nil
            transferLabel = nil
            if refresh || !listing.loaded { load(0) }
        }
    }

    private func upload(_ selectedFile: URL) {
        run("Đang nhập tệp…", refresh: true) {
            let staged = try await FileTransferSupport.stageImport(selectedFile)
            defer { staged.remove() }
            try Task.checkCancellation()
            let notice = try await VersionedFilesTransport.upload(local: staged.file, parent: folder.path,
                                                             name: staged.file.lastPathComponent)
            if let notice, !Task.isCancelled { issue = notice }
        }
    }

    private func showDetails(_ entry: DeviceFileEntry) {
        run("Đang đọc thông tin…") { details = try await VersionedFilesTransport.details(path: entry.path ?? folder.child(entry.name)) }
    }

    private func inspect(_ entry: DeviceFileEntry, mode: FileInspectorMode) {
        run("Đang mở \(entry.name)…") {
            let result = try await FileInspectorRequest.prepare(path: entry.path ?? folder.child(entry.name), name: entry.name, mode: mode)
            try Task.checkCancellation()
            inspector = result
        }
    }

    private func select(_ entry: DeviceFileEntry, operation: FileBrowserSelection.Operation) {
        guard transfer == nil else { return }
        clipboard.selection = FileBrowserSelection(name: entry.name, path: entry.path ?? folder.child(entry.name),
            isDirectory: entry.kind == "directory", operation: operation)
        if folder.writable && (operation == .compress || operation == .extract) {
            newName = clipboard.selection?.suggestedName ?? entry.name
            pasteNaming = true
        }
    }

    private func rename() {
        guard let entry = renameCandidate, folder.writable else { return }
        renameCandidate = nil
        let name = newName
        run("Đang đổi tên…", refresh: true) {
            try await VersionedFilesTransport.move(path: entry.path ?? folder.child(entry.name), to: FileBrowserOperations.child(folder.path, name))
        }
    }

    private func paste() {
        guard folder.writable, let selected = clipboard.selection else { return }
        let name = newName
        run(selected.operation.title + "…", refresh: true) {
            switch selected.operation {
            case .copy:
                try await FileBrowserOperations.copy(path: selected.path, isDirectory: selected.isDirectory, to: folder.path, name: name)
            case .move:
                try await VersionedFilesTransport.move(path: selected.path, to: FileBrowserOperations.child(folder.path, name))
            case .compress:
                try await FileBrowserOperations.compress(path: selected.path, isDirectory: selected.isDirectory, to: folder.path, name: name)
            case .extract:
                try await FileBrowserOperations.extract(path: selected.path, to: folder.path, name: name)
            }
            if clipboard.selection?.id == selected.id { clipboard.selection = nil }
        }
    }

    private func makeFolder() {
        let name = newName.trimmingCharacters(in: .whitespacesAndNewlines)
        guard FileTransferSupport.validName(name) else { return }
        run("Đang tạo thư mục…", refresh: true) {
            try await VersionedFilesTransport.makeFolder(parent: folder.path, name: name)
        }
    }

    private func fetch(_ entry: DeviceFileEntry, preview: Bool) {
        if let size = entry.size, size > FileTransferSupport.maxSize {
            issue = "Mỗi lần có thể chuyển một tệp tối đa 256 MiB."
            return
        }
        run("Đang lấy \(entry.name)…") {
            let staged = try FileTransferItem(name: entry.name)
            try await VersionedFilesTransport.download(path: entry.path ?? folder.child(entry.name), to: staged.file)
            try Task.checkCancellation()
            presentedFile = staged
            sheet = FilePresentation(staged: staged, preferPreview: preview)
        }
    }
}

@MainActor private final class FileListing: ObservableObject {
    @Published private(set) var rows: [DeviceFileEntry] = []
    @Published private(set) var nextOffset: Int?
    @Published private(set) var total = 0
    @Published private(set) var loading = false
    @Published private(set) var loaded = false
    @Published private(set) var error: String?
    @Published private(set) var notice: String?
    private(set) var failedOffset = 0
    private var task: Task<Void, Never>?
    private var ticket = UUID()
    private var workspacePrepared = false

    func load(folder: FileFolder, offset: Int, options: FileListOptions) -> Task<Void, Never> {
        cancel()
        let current = UUID()
        ticket = current
        error = nil
        loading = true
        let running = Task { @MainActor in
            defer { if ticket == current { loading = false; task = nil } }
            do {
                if folder.createWorkspace && !workspacePrepared {
                    try await VersionedFilesTransport.ensureWorkspace()
                    try Task.checkCancellation()
                    workspacePrepared = true
                }
                let page = try await VersionedFilesTransport.list(path: folder.path, offset: offset, options: options)
                guard !Task.isCancelled && ticket == current else { return }
                var unique = Set<String>()
                rows = ((offset == 0 ? [] : rows) + page.entries).filter { unique.insert($0.id).inserted }
                total = page.total
                notice = page.notice
                nextOffset = page.nextOffset.flatMap { $0 > offset ? $0 : nil }
                loaded = true
            } catch {
                guard !Task.isCancelled && ticket == current && !FileTransferSupport.cancelled(error) else { return }
                failedOffset = offset
                self.error = FileTransferSupport.message(error)
            }
        }
        task = running
        return running
    }

    func cancel() {
        ticket = UUID()
        task?.cancel()
        task = nil
        loading = false
    }

    func reset() {
        cancel()
        rows = []; nextOffset = nil; total = 0; loaded = false; error = nil; notice = nil
    }
}

private struct FileBrowserSelection: Identifiable {
    enum Operation {
        case copy, move, compress, extract
        var title: String {
            switch self { case .copy: return "Sao chép"; case .move: return "Di chuyển"; case .compress: return "Nén ZIP"; case .extract: return "Giải nén" }
        }
        var symbol: String {
            switch self { case .copy: return "doc.on.doc"; case .move: return "folder"; case .compress: return "doc.zipper"; case .extract: return "archivebox" }
        }
    }
    let id = UUID()
    let name: String
    let path: String
    let isDirectory: Bool
    let operation: Operation
    var suggestedName: String {
        switch operation {
        case .compress: return String(name.prefix(220)) + ".zip"
        case .extract: return (name as NSString).deletingPathExtension.isEmpty ? "Đã giải nén" : (name as NSString).deletingPathExtension
        default: return name
        }
    }
}

@MainActor private final class FileBrowserClipboard: ObservableObject {
    @Published var selection: FileBrowserSelection?
}

private struct FileDetailsView: View {
    let details: DeviceFileDetails
    @Environment(\.dismiss) private var dismiss
    var body: some View {
        NavigationStack {
            List {
                Section {
                    LabeledContent("Tên", value: details.name)
                    LabeledContent("Loại", value: details.kind == "directory" ? "Thư mục" : details.kind == "file" ? "Tệp" : details.kind == "symlink" ? "Liên kết" : "Đặc biệt")
                    LabeledContent("Kích thước", value: ByteCountFormatter.string(fromByteCount: Int64(clamping: details.size), countStyle: .file))
                    LabeledContent("Ngày sửa", value: Date(timeIntervalSince1970: Double(details.modified)).formatted())
                    LabeledContent("Ngày tạo", value: Date(timeIntervalSince1970: Double(details.created)).formatted())
                }
                Section("Đường dẫn") {
                    Text(details.path).font(.footnote).textSelection(.enabled)
                    Button("Sao chép đường dẫn") { UIPasteboard.general.string = details.path }
                }
                Section("Thông tin hệ thống") {
                    LabeledContent("Quyền", value: details.permissions)
                    LabeledContent("UID / GID", value: "\(details.owner) / \(details.group)")
                    LabeledContent("Inode", value: String(details.inode))
                }
            }
            .cc365Canvas().navigationTitle("Thông tin")
            .toolbar { ToolbarItem(placement: .confirmationAction) { Button("Xong") { dismiss() } } }
        }
    }
}

private struct DeviceFileRow: View {
    let entry: DeviceFileEntry
    private var symbol: String {
        switch entry.kind {
        case "directory": return "folder.fill"
        case "file": return "doc"
        case "symlink": return "link"
        default: return "questionmark.square.dashed"
        }
    }
    var body: some View {
        HStack(spacing: 12) {
            Image(systemName: symbol)
                .foregroundStyle(entry.kind == "directory" ? Color.accentColor : Color.secondary)
                .font(.title3)
                .frame(width: 28)
                .accessibilityHidden(true)
            VStack(alignment: .leading, spacing: 2) {
                Text(entry.displayName ?? entry.name).foregroundStyle(.primary).lineLimit(2).truncationMode(.middle)
                if let subtitle = entry.subtitle, !subtitle.isEmpty {
                    Text(subtitle).font(.caption).foregroundStyle(.secondary)
                } else if entry.kind == "file", let size = entry.size, size <= UInt64(Int64.max) {
                    Text(ByteCountFormatter.string(fromByteCount: Int64(size), countStyle: .file))
                        .font(.caption).foregroundStyle(.secondary)
                } else if entry.kind == "symlink" {
                    Text("Liên kết").font(.caption).foregroundStyle(.secondary)
                }
            }
        }
        .frame(maxWidth: .infinity, minHeight: 40, alignment: .leading)
        .contentShape(Rectangle())
    }
}
