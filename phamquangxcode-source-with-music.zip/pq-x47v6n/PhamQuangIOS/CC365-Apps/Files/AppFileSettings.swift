import Foundation

enum FileWorkMode: String, Sendable {
    case eco, balanced, fast
    var nativeValue: Int32 {
        switch self { case .eco: return 0; case .balanced: return 1; case .fast: return 2 }
    }
}

enum FileWorkPreset: String, CaseIterable, Identifiable, Sendable {
    case automatic, eco, fast
    var id: String { rawValue }
    var title: String {
        switch self { case .automatic: return "Tự động"; case .eco: return "Tiết kiệm"; case .fast: return "Nhanh" }
    }
    var detail: String {
        switch self {
        case .automatic: return "Tự cân đối tốc độ và dung lượng gói, giảm tải khi máy nóng hoặc bật chế độ nguồn điện thấp."
        case .eco: return "Ưu tiên giảm tải cho thiết bị. Gói nén có thể lớn hơn và tác vụ có thêm nhịp nghỉ."
        case .fast: return "Ưu tiên hoàn tất sớm. Gói nén có thể lớn hơn."
        }
    }
    func resolved(reducedLoad: Bool) -> AppFileSettings {
        switch self {
        case .automatic: return reducedLoad ? Self.eco.resolved(reducedLoad: false) : AppFileSettings(compressionLevel: 6, workMode: .balanced)
        case .eco: return AppFileSettings(compressionLevel: 1, workMode: .eco)
        case .fast: return AppFileSettings(compressionLevel: 1, workMode: .fast)
        }
    }
}


struct AppFileSettings: Sendable, Equatable {
    static let workModeKey = "cc365.workMode"
    static let showFilesTabKey = "viet99.showFilesTab"
    let compressionLevel: Int
    let workMode: FileWorkMode

    static func load(defaults: UserDefaults = .standard) -> Self {
        let preset = FileWorkPreset(rawValue: defaults.string(forKey: workModeKey) ?? "") ?? .automatic
        let thermal = ProcessInfo.processInfo.thermalState
        let reducedLoad = ProcessInfo.processInfo.isLowPowerModeEnabled || thermal == .serious || thermal == .critical
        return preset.resolved(reducedLoad: reducedLoad)
    }
}
