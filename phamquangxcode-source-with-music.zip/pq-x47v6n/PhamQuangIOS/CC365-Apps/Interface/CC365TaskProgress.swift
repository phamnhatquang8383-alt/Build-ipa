import SwiftUI



struct CC365TaskProgress: View {
    let title: String
    var detail: String? = nil
    var completed: Int64? = nil
    var total: Int64? = nil
    var phaseKey: String? = nil
    @Environment(\.accessibilityReduceMotion) private var reduceMotion

    private var fraction: Double? {
        guard let completed, let total, total > 0, completed >= 0, completed <= total else { return nil }
        return Double(completed) / Double(total)
    }

    var body: some View {
        VStack(alignment: .leading, spacing: 10) {
            HStack(alignment: .center, spacing: 12) {
                if fraction == nil {
                    if reduceMotion {
                        Image(systemName: "hourglass").foregroundStyle(.secondary)
                            .frame(width: 20, height: 20).accessibilityHidden(true)
                    } else {
                        ProgressView().controlSize(.small).frame(width: 20, height: 20)
                            .accessibilityHidden(true)
                    }
                }
                VStack(alignment: .leading, spacing: 4) {
                    Text(title).font(.subheadline.weight(.medium))
                        .contentTransition(.opacity)
                    if let detail, !detail.isEmpty {
                        Text(detail).font(.footnote).foregroundStyle(.secondary)
                    }
                }
                .frame(maxWidth: .infinity, alignment: .leading)
            }
            if let fraction, let completed, let total {
                VStack(alignment: .leading, spacing: 6) {
                    ProgressView(value: fraction).progressViewStyle(.linear)
                        .accessibilityLabel(title)
                        .accessibilityValue("\(completed) trên \(total) tệp")
                        .animation(reduceMotion ? nil : .linear(duration: 0.18), value: fraction)
                    Text("\(completed) / \(total) tệp")
                        .font(.caption.monospacedDigit()).foregroundStyle(.secondary)
                        .contentTransition(reduceMotion ? .identity : .numericText())
                        .animation(reduceMotion ? nil : .easeOut(duration: 0.18), value: completed)
                }
                .id(phaseKey ?? title)
            }
        }
        .padding(.vertical, 4)
        .animation(reduceMotion ? nil : .easeInOut(duration: 0.18), value: title)
        .transaction { if reduceMotion { $0.disablesAnimations = true } }
        .accessibilityElement(children: .combine)
    }
}


struct CC365TaskResult: View {
    let success: Bool
    let title: String
    var detail: String? = nil
    @Environment(\.accessibilityReduceMotion) private var reduceMotion
    @State private var appeared = false

    var body: some View {
        HStack(alignment: .top, spacing: 12) {
            Image(systemName: success ? "checkmark.circle.fill" : "exclamationmark.circle")
                .font(.title3)
                .foregroundStyle(success ? Color.green : Color.secondary)
                .cc365CompletionAnimation(appeared: appeared, enabled: success && !reduceMotion)
                .accessibilityHidden(true)
            VStack(alignment: .leading, spacing: 4) {
                Text(title).font(.subheadline.weight(.medium))
                if let detail, !detail.isEmpty { Text(detail).font(.footnote).foregroundStyle(.secondary) }
            }
            .frame(maxWidth: .infinity, alignment: .leading)
        }
        .padding(.vertical, 4)
        .transition(reduceMotion ? .identity : .opacity)
        .onAppear { if success && !reduceMotion { appeared = true } }
        .transaction { if reduceMotion { $0.disablesAnimations = true } }
        .accessibilityElement(children: .combine)
    }
}
