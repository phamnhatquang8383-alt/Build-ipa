import SwiftUI


enum CC365Glyph: String {
    case files = "CCGlyphFiles"
    var assetName: String { rawValue }
    var image: Image { Image(decorative: assetName).renderingMode(.template) }
}
