import SwiftUI


struct CC365UnavailableView: View {
    let title: String
    let systemImage: String
    let description: String

    var body: some View {
        if #available(iOS 17.0, *) {
            ContentUnavailableView(title, systemImage: systemImage, description: Text(description))
        } else {
            VStack(spacing: 12) {
                Image(systemName: systemImage)
                    .font(.system(size: 44, weight: .regular))
                    .foregroundStyle(.secondary)
                    .accessibilityHidden(true)
                Text(title).font(.title2.bold())
                Text(description).font(.body).foregroundStyle(.secondary)
            }
            .multilineTextAlignment(.center)
            .padding(24)
            .frame(maxWidth: .infinity, maxHeight: .infinity)
            .accessibilityElement(children: .combine)
        }
    }
}

struct CC365SearchUnavailableView: View {
    let query: String

    var body: some View {
        if #available(iOS 17.0, *) {
            ContentUnavailableView.search(text: query)
        } else {
            CC365UnavailableView(title: "Không tìm thấy kết quả", systemImage: "magnifyingglass",
                                 description: "Không có mục phù hợp với “\(query)”. Hãy thử từ khóa khác.")
        }
    }
}

extension View {
    @ViewBuilder
    func cc365CompletionAnimation(appeared: Bool, enabled: Bool) -> some View {
        if #available(iOS 17.0, *) {
            symbolEffect(.bounce, value: appeared)
        } else {
            scaleEffect(enabled && !appeared ? 0.82 : 1)
                .animation(enabled ? .spring(response: 0.35, dampingFraction: 0.55) : nil, value: appeared)
        }
    }
}
