import SwiftUI


struct CC365Surface: View {
    @Environment(\.colorScheme) private var scheme

    var body: some View {
        let dark = scheme == .dark
        LinearGradient(stops: [
            .init(color: dark ? Color(red: 0.175, green: 0.153, blue: 0.115)
                              : Color(red: 0.980, green: 0.929, blue: 0.765), location: 0),
            .init(color: dark ? Color(red: 0.086, green: 0.082, blue: 0.074)
                              : Color(red: 0.988, green: 0.980, blue: 0.957), location: 0.49),
            .init(color: dark ? Color(red: 0.066, green: 0.064, blue: 0.059)
                              : Color(red: 0.973, green: 0.965, blue: 0.941), location: 1)
        ], startPoint: .topLeading, endPoint: .bottomTrailing)
        .ignoresSafeArea()
        .accessibilityHidden(true)
    }
}

extension View {
    func cc365Canvas() -> some View {
        scrollContentBackground(.hidden)
            .background { CC365Surface() }
    }
}
