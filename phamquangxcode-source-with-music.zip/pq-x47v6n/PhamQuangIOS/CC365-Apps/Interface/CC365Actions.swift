import SwiftUI

extension View {


    func cc365ActionStyle(prominent: Bool = false) -> some View {
        modifier(DeviceActionStyle(prominent: prominent))
    }
}

private struct DeviceActionStyle: ViewModifier {
    let prominent: Bool

    @ViewBuilder
    func body(content: Content) -> some View {
        Group {
            if #available(iOS 26.0, *) {
                if prominent {
                    content.buttonStyle(.glassProminent)
                } else {
                    content.buttonStyle(.glass)
                }
            } else if prominent {
                content.buttonStyle(.borderedProminent)
            } else {
                content.buttonStyle(.bordered)
            }
        }


        .labelStyle(.titleOnly)
        .multilineTextAlignment(.center)
        .controlSize(.large)
    }
}
