import AVFoundation
import MediaPlayer
import UIKit

/// Plays the app's bundled background track for as long as the app is alive.
///
/// By design there is no pause/stop entry point anywhere in the UI: `start()` is called once
/// at launch, the track loops forever (`numberOfLoops = -1`), and the audio session uses the
/// `.playback` category so the hardware silent switch cannot mute it. Interruptions (phone
/// calls, Siri, another app's audio, a route change such as unplugging headphones) are resumed
/// automatically once they end. The system's lock-screen / Control Center "Now Playing" pause
/// and stop commands are explicitly disabled so there is no remote way to stop playback either.
final class AppMusicPlayer: NSObject, ObservableObject {
    static let shared = AppMusicPlayer()

    private var player: AVAudioPlayer?
    private let trackName = "audio_nang_cap"
    private let trackExtension = "mp3"

    private override init() {
        super.init()
        let center = NotificationCenter.default
        center.addObserver(self, selector: #selector(handleInterruption(_:)),
                            name: AVAudioSession.interruptionNotification, object: nil)
        center.addObserver(self, selector: #selector(handleRouteChange(_:)),
                            name: AVAudioSession.routeChangeNotification, object: nil)
        center.addObserver(self, selector: #selector(handleAppDidBecomeActive),
                            name: UIApplication.didBecomeActiveNotification, object: nil)
        center.addObserver(self, selector: #selector(handleMediaServicesReset),
                            name: AVAudioSession.mediaServicesWereResetNotification, object: nil)
        disableRemoteStopControls()
    }

    /// Starts playback if it hasn't started yet, or resumes it if something paused it.
    func start() {
        guard player == nil else {
            resumeIfNeeded()
            return
        }
        configureSession()
        guard let url = Bundle.main.url(forResource: trackName, withExtension: trackExtension) else {
            assertionFailure("Missing bundled track \(trackName).\(trackExtension)")
            return
        }
        do {
            let newPlayer = try AVAudioPlayer(contentsOf: url)
            newPlayer.numberOfLoops = -1
            newPlayer.volume = 1
            newPlayer.prepareToPlay()
            player = newPlayer
            newPlayer.play()
        } catch {
            assertionFailure("Failed to start background music: \(error)")
        }
    }

    private func configureSession() {
        let session = AVAudioSession.sharedInstance()
        // .playback ignores the ring/silent switch and keeps playing with the screen locked,
        // as long as the "audio" background mode is enabled (see Info.plist).
        try? session.setCategory(.playback, mode: .default, options: [.mixWithOthers])
        try? session.setActive(true, options: [])
    }

    private func resumeIfNeeded() {
        guard let player, !player.isPlaying else { return }
        configureSession()
        player.play()
    }

    /// Disables the pause/stop/toggle commands iOS exposes on the lock screen and in Control
    /// Center, so there is no system-level way to stop the track either.
    private func disableRemoteStopControls() {
        let commandCenter = MPRemoteCommandCenter.shared()
        commandCenter.pauseCommand.isEnabled = false
        commandCenter.stopCommand.isEnabled = false
        commandCenter.togglePlayPauseCommand.isEnabled = false
        commandCenter.playCommand.isEnabled = true
        commandCenter.playCommand.addTarget { [weak self] _ in
            self?.resumeIfNeeded()
            return .success
        }
    }

    @objc private func handleInterruption(_ note: Notification) {
        guard let info = note.userInfo,
              let typeValue = info[AVAudioSessionInterruptionTypeKey] as? UInt,
              let type = AVAudioSession.InterruptionType(rawValue: typeValue) else { return }
        if type == .ended {
            resumeIfNeeded()
        }
    }

    @objc private func handleRouteChange(_ note: Notification) {
        resumeIfNeeded()
    }

    @objc private func handleAppDidBecomeActive() {
        resumeIfNeeded()
    }

    @objc private func handleMediaServicesReset() {
        // The audio server died and all AVAudioSession/AVAudioPlayer state is now invalid;
        // rebuild the player from scratch.
        player = nil
        start()
    }
}
