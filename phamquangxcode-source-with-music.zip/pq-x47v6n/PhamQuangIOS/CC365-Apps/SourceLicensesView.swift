import SwiftUI

struct SourceLicensesView: View {
    private let documents = [
        ("Thành phần mã nguồn mở", "ThirdPartyNotices"),
        ("Giấy phép ứng dụng", "AGPL-3.0"),
        ("KAMUI · BQCore", "KAMUI-LICENSE"),
        ("Thư viện nén và giải nén ZIP", "ZIP-Dependency-Licenses"),
        ("Truy cập trực tiếp trên iOS cũ", "Legacy-Direct-Notices"),
        ("Giấy phép thành phần truy cập trực tiếp", "GPL-3.0"),
        ("AirLift và thư viện kết nối", "Legacy-AirLift-Licenses"),
        ("VPN nội bộ · StosVPN License", "LocalDevVPN-StosVPN")
    ]

    var body: some View {
        List {
            Section {
                LabeledContent("Ứng dụng", value: "PhamQuang IOS")
                LabeledContent("Ứng dụng và mã nguồn", value: "phamquangxcode")
                LabeledContent("Phiên bản", value: Bundle.main.object(forInfoDictionaryKey: "CFBundleShortVersionString") as? String ?? "1.4.0")
                Text("Duyệt tệp, tạo và áp dụng patch với cách truy cập phù hợp cho phiên bản iOS.")
                    .font(.footnote).foregroundStyle(.secondary)
            }
            Section("Đóng góp") {
                contribution("BQCore · KAMUI", detail: "Truy cập tệp trên thiết bị và nền tảng tích hợp BQCore.", url: "https://github.com/murk-sus/kamui-escape")
                contribution("WQFiles · kolbicz", detail: "Tham khảo cách nhận diện ứng dụng và các công cụ duyệt tệp.", url: "https://github.com/kolbicz/WQFiles")
                contribution("LocalDevVPN · Stossy11 / SideStore Team", detail: "Thiết kế phản xạ gói tin cho VPN nội bộ, theo giấy phép StosVPN. PhamQuang IOS chạy extension riêng trong ứng dụng.", url: "https://github.com/jkcoxson/LocalDevVPN")
                VStack(alignment: .leading, spacing: 5) {
                    Text("zip · flate2")
                    Text("Thư viện nén, giải nén ZIP và tạo gói patch.").font(.footnote).foregroundStyle(.secondary)
                }
            }
            Section("Truy cập trên iOS cũ") {
                Text("Legacy Direct · FilzaSlop và các tác giả được ghi trong giấy phép gốc")
                Text("AirLift · idevice và các thư viện kết nối")
                    .foregroundStyle(.secondary)
            }
            Section("Giấy phép") {
                ForEach(documents, id: \.1) { title, name in
                    if let url = Bundle.main.url(forResource: name, withExtension: "txt"),
                       let text = try? String(contentsOf: url, encoding: .utf8) {
                        NavigationLink(title) {
                            ScrollView { Text(text).font(.caption).textSelection(.enabled).padding() }
                                .cc365Canvas()
                                .navigationTitle(title)
                        }
                    }
                }
            }
        }
        .cc365Canvas()
        .navigationTitle("Đóng góp")
        .navigationBarTitleDisplayMode(.inline)
    }

    private func contribution(_ name: String, detail: String, url: String) -> some View {
        VStack(alignment: .leading, spacing: 5) {
            if let link = URL(string: url) { Link(name, destination: link) }
            Text(detail).font(.footnote).foregroundStyle(.secondary)
        }
    }
}
