import Foundation

struct DiagnosticsReportInput: Equatable {
    let generatedAt: Date
    let appVersion: String
    let osVersion: String
    let modeTitle: String
    let supportedVersions: String
    let status: String
    let pairing: String
    let freeSpace: String
    let totalSpace: String
}

enum DiagnosticsReport {
    static let privacyFooter = "Báo cáo không chứa pairing file, khóa, đường dẫn riêng tư hoặc nội dung tệp."

    static func text(_ input: DiagnosticsReportInput) -> String {
        [
            "PhamQuang IOS — Báo cáo chẩn đoán",
            "Thời gian: \(ISO8601DateFormatter().string(from: input.generatedAt))",
            "Phiên bản ứng dụng: \(input.appVersion)",
            "Hệ điều hành: \(input.osVersion)",
            "Chế độ truy cập: \(input.modeTitle)",
            "Dải phiên bản: \(input.supportedVersions)",
            "Trạng thái: \(input.status)",
            "Pairing AirLift: \(input.pairing)",
            "Dung lượng trống: \(input.freeSpace)",
            "Tổng dung lượng: \(input.totalSpace)",
            "",
            privacyFooter
        ].joined(separator: "\n")
    }
}
