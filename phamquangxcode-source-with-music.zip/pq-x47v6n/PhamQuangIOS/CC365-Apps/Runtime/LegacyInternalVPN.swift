import Combine
import Foundation
@preconcurrency import NetworkExtension

enum LegacyVPNStatus: Sendable { case invalid, disconnected, connecting, connected, reasserting, disconnecting }
struct LegacyVPNError: LocalizedError, Sendable {
    let message: String
    var errorDescription: String? { message }
}

@MainActor protocol LegacyVPNDriver: AnyObject {
    var status: LegacyVPNStatus { get }
    func load(providerIdentifier: String) async throws -> Bool
    func configure(providerIdentifier: String) async throws
    func start() throws
    func stop()
}



@MainActor final class LegacyInternalVPN: ObservableObject {
    static let shared = LegacyInternalVPN()
    @Published private(set) var isBusy = false
    @Published private(set) var status = LegacyVPNStatus.invalid
    @Published private(set) var error: String?
    var isConnected: Bool { driver.status == .connected }

    private let driver: any LegacyVPNDriver
    private let mode: @MainActor () -> DeviceAccessMode
    private let providerIdentifier: @MainActor () throws -> String
    private let sleep: @MainActor (UInt64) async throws -> Void
    private let connectPolls: Int
    private let stopPolls: Int
    private var generation: UInt64 = 0

    init(driver: (any LegacyVPNDriver)? = nil,
         mode: @escaping @MainActor () -> DeviceAccessMode = { DeviceSupportPolicy.current },
         providerIdentifier: @escaping @MainActor () throws -> String = {
             guard let identifier = Bundle.main.bundleIdentifier, !identifier.isEmpty else {
                 throw LegacyVPNError(message: "Bản cài thiếu định danh ứng dụng.")
             }
             return identifier + ".tunnel"
         },
         sleep: @escaping @MainActor (UInt64) async throws -> Void = { try await Task.sleep(nanoseconds: $0) },
         connectPolls: Int = 125, stopPolls: Int = 25) {
        self.driver = driver ?? SystemLegacyVPNDriver()
        self.mode = mode
        self.providerIdentifier = providerIdentifier
        self.sleep = sleep
        self.connectPolls = connectPolls
        self.stopPolls = stopPolls
    }



    func ensureConnected() async throws { try await connect(allowConfiguration: false) }



    func authorizeAndConnect() async throws { try await connect(allowConfiguration: true) }

    private func connect(allowConfiguration: Bool) async throws {
        guard mode() == .airLift else { throw LegacyVPNError(message: "Phiên bản này không dùng VPN nội bộ AirLift.") }
        try Task.checkCancellation()
        guard !isBusy else { throw LegacyVPNError(message: "VPN nội bộ đang cập nhật. Hãy chờ thao tác hiện tại kết thúc.") }
        if driver.status == .connected { status = .connected; return }
        isBusy = true
        error = nil
        let operation = generation
        var startedHere = false
        defer { isBusy = false; status = driver.status }
        do {
            let identifier = try providerIdentifier()
            let configured = try await driver.load(providerIdentifier: identifier)
            try check(operation)
            if configured && driver.status == .connected { return }
            if !configured {
                guard allowConfiguration else {
                    throw LegacyVPNError(message: "Nhấn “Thiết lập VPN nội bộ” để cho phép iOS thêm kết nối của PhamQuang IOS.")
                }
                try await driver.configure(providerIdentifier: identifier)
                try check(operation)
            }
            if driver.status == .disconnecting {
                for _ in 0..<stopPolls {
                    try check(operation)
                    if driver.status != .disconnecting { break }
                    try await sleep(200_000_000)
                }
                guard driver.status != .disconnecting else { throw LegacyVPNError(message: "VPN nội bộ chưa ngắt xong. Hãy thử lại sau một chút.") }
            }
            if driver.status != .connecting && driver.status != .reasserting {
                try driver.start()
                startedHere = true
            }
            for index in 0..<connectPolls {
                try check(operation)
                status = driver.status
                if status == .connected { return }
                if status == .invalid || (status == .disconnected && index >= 8) {
                    throw LegacyVPNError(message: "VPN nội bộ chưa khởi động được. Kiểm tra bản ký có giữ extension và quyền Network Extension.")
                }
                try await sleep(200_000_000)
            }
            throw LegacyVPNError(message: "Hết thời gian chờ VPN nội bộ kết nối. Hãy thử lại.")
        } catch {
            if startedHere || operation != generation { driver.stop() }
            if !(error is CancellationError) { self.error = error.localizedDescription }
            throw error
        }
    }

    private func check(_ operation: UInt64) throws {
        try Task.checkCancellation()
        if operation != generation { throw CancellationError() }
    }

    func stop() {
        guard mode() == .airLift else { return }
        generation &+= 1
        driver.stop()
        status = driver.status
    }



    func disconnectAfterPatch() async {
        guard mode() == .airLift else { return }
        let cleanup = Task { @MainActor in
            self.isBusy = true
            self.error = nil
            self.stop()
            defer { self.isBusy = false; self.status = self.driver.status }
            for _ in 0..<self.stopPolls {
                if self.driver.status == .disconnected || self.driver.status == .invalid { return }
                try? await self.sleep(200_000_000)
            }
            self.error = "Chưa xác nhận VPN nội bộ đã tắt. Bạn có thể tắt kết nối PhamQuang IOS trong Cài đặt VPN của iOS."
        }
        await cleanup.value
    }
}



@MainActor final class SystemLegacyVPNDriver: LegacyVPNDriver {
    private var manager: NETunnelProviderManager?
    var status: LegacyVPNStatus {
        switch manager?.connection.status ?? .invalid {
        case .invalid: return .invalid
        case .disconnected: return .disconnected
        case .connecting: return .connecting
        case .connected: return .connected
        case .reasserting: return .reasserting
        case .disconnecting: return .disconnecting
        @unknown default: return .invalid
        }
    }
    func load(providerIdentifier: String) async throws -> Bool {
        let candidates = try await NETunnelProviderManager.loadAllFromPreferences().filter {
            ($0.protocolConfiguration as? NETunnelProviderProtocol)?.providerBundleIdentifier == providerIdentifier
        }
        manager = candidates.first(where: { $0.connection.status == .connected }) ?? candidates.first
        return manager?.isEnabled == true
    }
    func configure(providerIdentifier: String) async throws {
        guard let directory = Bundle.main.builtInPlugInsURL,
              let plugins = try? FileManager.default.contentsOfDirectory(at: directory, includingPropertiesForKeys: nil),
              plugins.contains(where: { url in
                  guard url.pathExtension == "appex", let bundle = Bundle(url: url), bundle.bundleIdentifier == providerIdentifier,
                        let info = bundle.object(forInfoDictionaryKey: "NSExtension") as? [String: Any] else { return false }
                  return info["NSExtensionPointIdentifier"] as? String == "com.apple.networkextension.packet-tunnel"
              }) else {
            throw LegacyVPNError(message: "Bản cài thiếu VPN extension của PhamQuang IOS. Hãy ký và cài cả ứng dụng cùng extension.")
        }
        let selected = manager ?? NETunnelProviderManager()
        let configuration = NETunnelProviderProtocol()
        configuration.providerBundleIdentifier = providerIdentifier
        configuration.serverAddress = "PhamQuang IOS — VPN nội bộ"
        configuration.disconnectOnSleep = false
        configuration.includeAllNetworks = false
        configuration.excludeLocalNetworks = false
        selected.protocolConfiguration = configuration
        selected.localizedDescription = "PhamQuang IOS — VPN nội bộ"
        selected.isEnabled = true
        selected.isOnDemandEnabled = false
        manager = selected
        try await selected.saveToPreferences()
        try await selected.loadFromPreferences()
    }
    func start() throws {
        guard let manager else { throw LegacyVPNError(message: "Chưa có cấu hình VPN nội bộ của PhamQuang IOS.") }
        try manager.connection.startVPNTunnel()
    }
    func stop() { manager?.connection.stopVPNTunnel() }
}
