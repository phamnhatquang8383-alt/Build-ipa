import Foundation

enum DeviceAccessMode: String, CaseIterable, Sendable {
    case directLegacy
    case airLift
    case bqCore
    case unsupported

    var supportedVersions: String {
        switch self {
        case .directLegacy: return "iOS 16.0–16.7.x, 17.0–17.7.x, 18.0–18.7.1"
        case .airLift: return "iOS 18.7.2–18.8.x"
        case .bqCore: return "iOS 26.0–26.7.2, 27.0–27.3.x"
        case .unsupported: return "Ngoài các dải phiên bản đã cấu hình"
        }
    }
}



struct DeviceSupportPolicy {
    static func unsupportedReason(for version: OperatingSystemVersion) -> String? {
        guard mode(for: version) == .unsupported else { return nil }
        let text = "\(version.majorVersion).\(version.minorVersion).\(version.patchVersion)"
        guard version.majorVersion >= 0, version.minorVersion >= 0, version.patchVersion >= 0 else {
            return "Không đọc được phiên bản iOS của thiết bị (\(text))."
        }
        switch version.majorVersion {
        case ..<16:
            return "iOS \(text) thấp hơn 16.0. PhamQuang IOS chưa có đường truy cập cho dải này."
        case 16, 17:
            return "iOS \(text) chưa có offset kernel đã kiểm chứng cho đường truy cập trực tiếp."
        case 18:
            return "iOS \(text) chưa có đường truy cập đã kiểm chứng. Dải hiện tại dừng ở iOS 18.8."
        case 26, 27:
            return "iOS \(text) nằm ngoài dải BQCore đã kiểm chứng (26.0–26.7.2 và 27.0–27.3.x)."
        default:
            return "iOS \(text) chưa có đường truy cập đã kiểm chứng."
        }
    }

    static var current: DeviceAccessMode {
        mode(for: ProcessInfo.processInfo.operatingSystemVersion)
    }

    static func mode(for version: OperatingSystemVersion) -> DeviceAccessMode {
        guard version.majorVersion >= 0, version.minorVersion >= 0, version.patchVersion >= 0 else {
            return .unsupported
        }
        switch (version.majorVersion, version.minorVersion, version.patchVersion) {
        case (16, 0...7, _), (17, 0...7, _), (18, 0...6, _), (18, 7, 0...1):
            return .directLegacy
        case (18, 7, 2...), (18, 8, _):
            return .airLift
        case (26, 0...6, _), (26, 7, 0...2), (27, 0...3, _):
            return .bqCore
        default:


            return .unsupported
        }
    }
}
