import SwiftUI
import UIKit

struct DeviceAccessView: View {
    @ObservedObject var access: DeviceAccessModel
    var onboarding = false
    @Environment(\.scenePhase) private var scenePhase
    @State private var picking = false
    @State private var removing = false

    var body: some View {
        Form {
            Section {
                LabeledContent("Phiên bản", value: access.versionText)
                LabeledContent("Cách truy cập", value: access.title)
                Text(access.detail).foregroundStyle(.secondary)
            } header: { Text(onboarding ? "Thiết lập cho iPhone này" : "Tự động theo phiên bản iOS") }

            if access.mode == .unsupported {
                Section {
                    Label("Không thể mở PhamQuang IOS trên \(access.versionText)", systemImage: "lock.slash")
                        .foregroundStyle(.red)
                    Text(access.blockedReason ?? "Phiên bản này chưa được hỗ trợ.")
                        .font(.footnote).foregroundStyle(.secondary)
                } header: { Text("Không được hỗ trợ") }
            }

            if access.mode == .airLift {
                Section {
                    Label(access.hasPairing ? "Đã nhập pairing file" : "Nhập pairing file từ máy tính",
                          systemImage: access.hasPairing ? "checkmark.circle" : "doc.badge.plus")
                    Button(access.hasPairing ? "Thay pairing file" : "Chọn Tệp") { picking = true }
                        .disabled(access.isChecking)
                    DisclosureGroup("Cách lấy pairing file") {
                        Text("Kết nối iPhone với máy tính bằng USB, mở khóa và chọn Tin cậy. Dùng idevice_pair để tạo và kiểm tra file Lockdown pairing, lưu file rồi chuyển sang iPhone để nhập tại đây.")
                            .font(.footnote)
                        Link("Mở hướng dẫn idevice_pair", destination: URL(string: "https://github.com/jkcoxson/idevice_pair")!)
                    }
                } header: { Text("1. Ghép nối") }
                  footer: { Text("File được lưu riêng trên thiết bị. PhamQuang IOS không gửi file này lên máy chủ.") }

                Section {
                    Button("Thiết lập VPN nội bộ") { Task { await access.configureVPN() } }
                        .disabled(access.isChecking)
                    Text("Cho phép iOS thêm cấu hình VPN của PhamQuang IOS trong lần đầu. Kết nối chỉ chạy trên thiết bị; không cần ứng dụng VPN khác.")
                        .font(.footnote).foregroundStyle(.secondary)
                } header: { Text("2. Kết nối trên thiết bị") }
                  footer: { Text("PhamQuang IOS tự bật VPN khi cần và tự tắt sau khi phiên áp dụng hoặc khôi phục patch đã dọn xong, kể cả dừng hoặc lỗi.") }
            }

            if access.isChecking {
                Section {
                    CC365TaskProgress(title: access.mode == .directLegacy ? "Đang chuẩn bị truy cập…" : "Đang kiểm tra kết nối…",
                        detail: access.mode == .directLegacy ? "Giữ ứng dụng mở đến khi hoàn tất." : nil,
                        phaseKey: "device-setup")
                }
            } else if let message = access.message {
                Section {
                    Label(message, systemImage: access.hasIssue ? "exclamationmark.circle" :
                        access.vpnPausedAfterPatch ? "pause.circle" : "checkmark.circle")
                        .foregroundStyle(.secondary)
                    if access.requiresRelaunch {
                        Text("Đóng hẳn rồi mở lại PhamQuang IOS để thử chuẩn bị một lần nữa. Bạn vẫn có thể tiếp tục với tệp riêng.")
                            .font(.footnote).foregroundStyle(.secondary)
                    }
                }
            }

            if !access.isChecking {
                Section {
                    if access.canRetry {
                        Button(access.isReady ? "Kiểm tra lại" : "Thử lại") { Task { await access.prepare() } }
                    }
                    if onboarding && access.mode != .unsupported {
                        Button(access.isReady ? "Mở PhamQuang IOS" : "Dùng tệp trong PhamQuang IOS") { access.continueLocally() }
                            .cc365ActionStyle(prominent: true)
                    }
                    if access.mode == .airLift && access.hasPairing {
                        Button("Xóa pairing file", role: .destructive) { removing = true }
                    }
                }
            }
        }
        .cc365Canvas()
        .navigationTitle(onboarding ? "PhamQuang IOS" : "Truy cập thiết bị")
        .navigationBarTitleDisplayMode(.inline)
        .cc365FilePicker(isPresented: $picking, kind: .file) { url in
            if let url { Task { await access.importPairing(from: url) } }
        }
        .confirmationDialog("Xóa pairing file khỏi PhamQuang IOS?", isPresented: $removing, titleVisibility: .visible) {
            Button("Xóa pairing file", role: .destructive) { access.removePairing() }
            Button("Hủy", role: .cancel) { }
        }
        .task {
            if !onboarding && access.canAutomaticallyPrepare {
                await access.prepare(automatically: true)
            }
        }
        .onChange(of: scenePhase) { phase in
            if phase == .active && access.canAutomaticallyPrepare {
                Task { await access.prepare(automatically: true) }
            }
        }
    }

}
