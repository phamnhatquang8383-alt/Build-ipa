import Foundation



@MainActor enum VersionedFilesTransport {
    private struct Receipt: Decodable, Sendable { let bytes: UInt64; let warning: String? }

    private static func route<T: Decodable & Sendable>(_ parameters: [String: Any],
        patch: Bool = false, as type: T.Type,
        onProgress: @escaping @Sendable (RustPatchProgress) -> Void = { _ in },
        bq: () async throws -> T) async throws -> T {
        let access = DeviceAccessModel.shared
        if access.mode == .bqCore { return try await bq() }
        let action = parameters["action"] as? String ?? ""
        let paths = ["path", "parent", "destination"].compactMap { parameters[$0] as? String }
        let local = !patch && (action == "ensureWorkspace" ||
            (!paths.isEmpty && paths.allSatisfy { $0 == "/CC365" || $0.hasPrefix("/CC365/") }))

        if local { return try await bq() }
        if access.mode == .airLift {
            let data = try await LegacyAirLiftService.perform(parameters, patch: patch, onProgress: onProgress, onCompletion: {
                if patch && (action == "apply" || action == "restore") {
                    await LegacyInternalVPN.shared.disconnectAfterPatch()
                    if let issue = LegacyInternalVPN.shared.error { access.pauseAfterPatch(message: issue) }
                    else { access.pauseAfterPatch() }
                }
            })
            return try JSONDecoder().decode(type, from: data)
        }
        let localMetadata = (patch && action == "history") || (action == "list" && paths == ["/"])
        if !localMetadata { try access.requireDirectAccess() }
        return try await direct(parameters, patch: patch, as: type, onProgress: onProgress)
    }

    private static func direct<T: Decodable & Sendable>(_ parameters: [String: Any],
        patch: Bool, as type: T.Type,
        onProgress: @escaping @Sendable (RustPatchProgress) -> Void) async throws -> T {
        let progress = Progress(totalUnitCount: 1)
        return try await withTaskCancellationHandler {
            try Task.checkCancellation()
            return try await withCheckedThrowingContinuation { continuation in
                let complete: @Sendable ([AnyHashable: Any]?, Error?) -> Void = { result, error in
                    if let error { continuation.resume(throwing: error); return }
                    guard let result else {
                        continuation.resume(throwing: PatchInputError("Chưa nhận được kết quả thao tác tệp.")); return
                    }
                    do {
                        continuation.resume(returning: try JSONDecoder().decode(type,
                            from: JSONSerialization.data(withJSONObject: result)))
                    } catch { continuation.resume(throwing: error) }
                }
                if patch {
                    VVDirectPatchEngine.perform(request: parameters, progress: progress, onProgress: { event in
                        guard let data = try? JSONSerialization.data(withJSONObject: event),
                              let decoded = try? JSONDecoder().decode(RustPatchProgress.self, from: data) else { return }
                        onProgress(decoded)
                    }, completion: complete)
                } else {
                    VVDirectFileSystem.perform(request: parameters, progress: progress, completion: complete)
                }
            }
        } onCancel: { progress.cancel() }
    }

    static func list(path: String, offset: Int, options: FileListOptions = FileListOptions()) async throws -> DeviceFilesPage {
        try await route(["action":"list", "path":path, "offset":offset, "query":String(options.query.prefix(256)),
            "sort":options.sort, "ascending":options.ascending, "folders_first":options.foldersFirst,
            "show_hidden":options.showHidden], as: DeviceFilesPage.self) {
                try await DeviceFilesTransport.list(path: path, offset: offset, options: options)
            }
    }
    static func ensureWorkspace() async throws { try await DeviceFilesTransport.ensureWorkspace() }
    private static func requireLocalWrite(_ paths: String...) throws {
        if DeviceAccessModel.shared.mode == .bqCore { return }
        guard paths.allSatisfy({ $0 == "/CC365" || $0.hasPrefix("/CC365/") }) else {
            throw PatchInputError("Chỉ có thể thay đổi tệp trong Tệp PhamQuang IOS. Dùng chức năng patch để thay tệp của ứng dụng khác.")
        }
    }
    static func makeFolder(parent: String, name: String) async throws {
        try requireLocalWrite(parent)
        try await DeviceFilesTransport.makeFolder(parent: parent, name: name)
    }
    static func upload(local: URL, parent: String, name: String) async throws -> String? {
        try requireLocalWrite(parent)
        return try await DeviceFilesTransport.upload(local: local, parent: parent, name: name)
    }
    static func delete(path: String) async throws {
        try requireLocalWrite(path)
        try await DeviceFilesTransport.delete(path: path)
    }
    static func download(path: String, to local: URL) async throws {
        _ = try await route(["action":"download", "path":path, "local_path":local.path], as: Receipt.self) {
            try await DeviceFilesTransport.download(path: path, to: local)
            return Receipt(bytes: 0, warning: nil)
        }
    }
    static func details(path: String) async throws -> DeviceFileDetails {
        try await route(["action":"details", "path":path], as: DeviceFileDetails.self) {
            try await DeviceFilesTransport.details(path: path)
        }
    }
    static func move(path: String, to destination: String) async throws {
        try requireLocalWrite(path, destination)
        try await DeviceFilesTransport.move(path: path, to: destination)
    }
    static func uploadTree(local: URL, to path: String) async throws {
        try requireLocalWrite(path)
        try await DeviceFilesTransport.uploadTree(local: local, to: path)
    }
    static func replace(local: URL, path: String, expected: URL) async throws {
        try requireLocalWrite(path)
        try await DeviceFilesTransport.replace(local: local, path: path, expected: expected)
    }
    static func checkAccess() async throws -> FileAccessReceipt {
        if DeviceAccessModel.shared.mode == .bqCore { return try await DeviceFilesTransport.checkAccess() }


        return try await direct(["action":"check"], patch: false, as: FileAccessReceipt.self, onProgress: { _ in })
    }
    static func patch<T: Decodable & Sendable>(_ action: String, fields: [String: Any] = [:],
        as type: T.Type, onProgress: @escaping @Sendable (RustPatchProgress) -> Void = { _ in }) async throws -> T {
        var request = fields
        request["action"] = action
        return try await route(request, patch: true, as: type, onProgress: onProgress) {
            try await DeviceFilesTransport.patch(action, fields: fields, as: type, onProgress: onProgress)
        }
    }
}
