import Foundation
import LegacyAirLiftCore
#if canImport(UIKit)
import UIKit
#endif

struct LegacyAirLiftError: LocalizedError, Sendable {
    let message: String
    var errorDescription: String? { message }
}
private struct LegacyAirLiftEvent: Decodable, Sendable {
    let kind: String
    let message: String?
    let progress: RustPatchProgress?
    let cancelled: Bool?
}


private final class LegacyAirLiftJob: @unchecked Sendable {
    private let lock = NSLock()
    private var handle: OpaquePointer?
    private var cancelled = false
    private var result: Result<Data, Error>?
    private var waiter: CheckedContinuation<Data, Error>?
    private var hasWaiter = false
    private let onProgress: @Sendable (RustPatchProgress) -> Void

    init(request: [String: Any], onProgress: @escaping @Sendable (RustPatchProgress) -> Void) throws {
        self.onProgress = onProgress
        let data = try JSONSerialization.data(withJSONObject: request)
        let context = Unmanaged.passRetained(self).toOpaque()
        var returned: OpaquePointer?
        let code = data.withUnsafeBytes { bytes in
            viet99_airlift_job_start(bytes.bindMemory(to: UInt8.self).baseAddress, data.count,
                                    legacyAirLiftCallback, context, &returned)
        }
        guard code == 0, let returned else {
            Unmanaged<LegacyAirLiftJob>.fromOpaque(context).release()
            throw LegacyAirLiftError(message: code == 2
                ? "Phiên AirLift trước đang dọn dẹp. Hãy chờ phiên đó kết thúc."
                : "Yêu cầu AirLift không hợp lệ hoặc chưa hỗ trợ thao tác này.")
        }
        lock.lock()
        if result != nil || cancelled { viet99_airlift_job_release(returned) }
        else { handle = returned }
        lock.unlock()
    }
    func value() async throws -> Data {
        try await withTaskCancellationHandler {
            try await withCheckedThrowingContinuation { continuation in
                lock.lock()
                guard !hasWaiter else { lock.unlock(); continuation.resume(throwing: LegacyAirLiftError(message: "Kết quả AirLift đã được nhận.")); return }
                hasWaiter = true
                if let result { lock.unlock(); continuation.resume(with: result) }
                else { waiter = continuation; lock.unlock() }
            }
        } onCancel: { self.cancel() }
    }
    func cancel() {
        lock.lock(); cancelled = true
        if let handle { viet99_airlift_job_cancel(handle) }
        lock.unlock()
    }
    fileprivate func receive(_ data: Data, event: LegacyAirLiftEvent) {
        guard event.kind == "complete" || event.kind == "error" else {
            if let progress = event.progress { onProgress(progress) }
            return
        }
        let outcome: Result<Data, Error>
        if event.kind == "complete" {
            do {
                guard let envelope = try JSONSerialization.jsonObject(with: data) as? [String: Any], let value = envelope["result"] else {
                    throw LegacyAirLiftError(message: "AirLift trả về dữ liệu không hợp lệ.")
                }
                outcome = .success(try JSONSerialization.data(withJSONObject: value))
            } catch { outcome = .failure(error) }
        } else if event.cancelled == true { outcome = .failure(CancellationError()) }
        else { outcome = .failure(LegacyAirLiftError(message: event.message ?? "AirLift chưa hoàn tất thao tác.")) }
        lock.lock()
        let wasFinished = result != nil
        if !wasFinished { result = outcome }
        let continuation = waiter; waiter = nil
        let owned = handle; handle = nil
        lock.unlock()
        if let owned { viet99_airlift_job_release(owned) }
        if !wasFinished { continuation?.resume(with: outcome) }
    }
}
private let legacyAirLiftCallback: @convention(c) (UnsafeMutableRawPointer?, UnsafePointer<UInt8>?, Int) -> Void = { context, bytes, length in
    guard let context, let bytes, length > 0, length <= 16 * 1024 * 1024 else { return }
    let job = Unmanaged<LegacyAirLiftJob>.fromOpaque(context).takeUnretainedValue()
    let data = Data(bytes: bytes, count: length)
    guard let event = try? JSONDecoder().decode(LegacyAirLiftEvent.self, from: data) else { job.cancel(); return }
    job.receive(data, event: event)
    if event.kind == "complete" || event.kind == "error" { Unmanaged<LegacyAirLiftJob>.fromOpaque(context).release() }
}

@MainActor enum LegacyAirLiftService {
    private static var networkBusy = false
    private static var pairingURL: URL {
        FileManager.default.urls(for: .applicationSupportDirectory, in: .userDomainMask)[0]
            .appendingPathComponent("Viet99-AirLift", isDirectory: true).appendingPathComponent("pairing.plist")
    }
    static var hasPairing: Bool { (try? storage(["action": "exists"]))?["exists"] as? Bool == true }
    static func importPairing(from url: URL) async throws {
        try Task.checkCancellation()
        let access = url.startAccessingSecurityScopedResource()
        defer { if access { url.stopAccessingSecurityScopedResource() } }
        var directory = pairingURL.deletingLastPathComponent()
        var attributes: [FileAttributeKey: Any] = [.posixPermissions: 0o700]
        #if os(iOS)
        attributes[.protectionKey] = FileProtectionType.complete
        #endif
        try FileManager.default.createDirectory(at: directory, withIntermediateDirectories: true, attributes: attributes)
        try FileManager.default.setAttributes(attributes, ofItemAtPath: directory.path)
        var values = URLResourceValues(); values.isExcludedFromBackup = true
        try directory.setResourceValues(values)
        let path = pairingURL.path
        let source = url.path


        let task = Task.detached(priority: .userInitiated) {
            try Task.checkCancellation()
            _ = try localStorage(["action": "import", "path": path, "source": source])
        }
        try await withTaskCancellationHandler { try await task.value } onCancel: { task.cancel() }
    }
    static func removePairing() throws { _ = try storage(["action": "remove"]) }
    static func checkConnection() async throws -> String {
        let data = try await perform(["action": "probe"], patch: false, onProgress: { _ in })
        let report = try JSONSerialization.jsonObject(with: data) as? [String: Any]
        return report?["message"] as? String ?? "Đã xác thực kết nối nội bộ."
    }
    static func perform(_ parameters: [String: Any], patch: Bool,
                        onProgress: @escaping @Sendable (RustPatchProgress) -> Void = { _ in },
                        onCompletion: @MainActor () async -> Void = {}) async throws -> Data {
        try Task.checkCancellation()
        let network = !(patch && parameters["action"] as? String == "history")
        if network {
            guard !networkBusy else { throw LegacyAirLiftError(message: "Phiên AirLift trước đang xử lý hoặc đóng VPN. Hãy chờ hoàn tất.") }
            networkBusy = true
        }
        defer { if network { networkBusy = false } }
        if network { try await LegacyInternalVPN.shared.ensureConnected() }
        try Task.checkCancellation()
        var request = parameters
        request["patch"] = patch
        request["pairing_path"] = pairingURL.path
        request["host"] = "10.7.0.1"
        request["port"] = 49152  
        request["own_bundle"] = Bundle.main.bundleIdentifier ?? ""
        request["own_home"] = NSHomeDirectory()
        #if canImport(UIKit)
        request["expected_os"] = UIDevice.current.systemVersion
        #else
        request["expected_os"] = "unsupported-host"
        #endif
        let job = try LegacyAirLiftJob(request: request, onProgress: onProgress)
        do {
            let value = try await job.value()
            await onCompletion()
            return value
        } catch {
            await onCompletion()
            throw error
        }
    }
    private static func storage(_ request: [String: Any]) throws -> [String: Any] {
        var request = request; request["path"] = pairingURL.path
        return try localStorage(request)
    }
    nonisolated private static func localStorage(_ request: [String: Any]) throws -> [String: Any] {
        let data = try JSONSerialization.data(withJSONObject: request)
        let output = data.withUnsafeBytes { bytes in
            viet99_airlift_storage(bytes.bindMemory(to: UInt8.self).baseAddress, data.count)
        }
        defer { viet99_airlift_buffer_free(output) }
        guard let pointer = output.data, output.length > 0, output.length <= 1_048_576,
              let value = try JSONSerialization.jsonObject(with: Data(bytes: pointer, count: output.length)) as? [String: Any] else {
            throw LegacyAirLiftError(message: "Không xử lý được pairing.")
        }
        if let message = value["error"] as? String { throw LegacyAirLiftError(message: message) }
        return value
    }
}
