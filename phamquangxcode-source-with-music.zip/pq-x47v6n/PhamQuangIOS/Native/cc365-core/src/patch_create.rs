use serde_json::Value;
use std::{
    collections::HashSet,
    ffi::{CStr, CString, c_char, c_void},
    fs::{File, Metadata},
    io::{Read, Seek, SeekFrom, Write},
    os::{
        fd::{AsRawFd, FromRawFd},
        unix::{ffi::OsStrExt, fs::MetadataExt},
    },
    path::{Component, Path, PathBuf},
};
use zip::{CompressionMethod, ZipWriter, write::SimpleFileOptions};

const BAD: i32 = 1;
const PATH: i32 = 2;
const LIMIT: i32 = 3;
const DISK: i32 = 5;
const CANCEL: i32 = 6;
const EMPTY: i32 = 7;
const FILE_MAX: u64 = 128 << 20;
const TOTAL: u64 = 256 << 20;
const ARCHIVE_MAX: u64 = TOTAL + (8 << 20);
const MANIFEST_MAX: u64 = 8 << 20;

#[cfg(test)]
#[path = "patch_create_tests.rs"]
mod tests;

#[link(name = "CoreFoundation", kind = "framework")]
unsafe extern "C" {
    fn CFStringCreateWithBytes(
        a: *const c_void,
        bytes: *const u8,
        len: isize,
        encoding: u32,
        external: u8,
    ) -> *const c_void;
    fn CFStringCreateMutableCopy(a: *const c_void, cap: isize, value: *const c_void)
    -> *mut c_void;
    fn CFStringNormalize(value: *mut c_void, form: isize);
    fn CFStringLowercase(value: *mut c_void, locale: *const c_void);
    fn CFStringGetLength(value: *const c_void) -> isize;
    fn CFStringGetMaximumSizeForEncoding(len: isize, encoding: u32) -> isize;
    fn CFStringGetCString(
        value: *const c_void,
        buffer: *mut c_char,
        size: isize,
        encoding: u32,
    ) -> u8;
    fn CFRelease(value: *const c_void);
}

pub(crate) fn canonical_key(value: &str) -> Result<String, i32> {
    struct OwnedCF(*const c_void);
    impl Drop for OwnedCF {
        fn drop(&mut self) {
            unsafe {
                CFRelease(self.0);
            }
        }
    }
    const UTF8: u32 = 0x0800_0100;
    unsafe {
        let original = CFStringCreateWithBytes(
            std::ptr::null(),
            value.as_ptr(),
            value.len() as isize,
            UTF8,
            0,
        );
        if original.is_null() {
            return Err(BAD);
        }
        let original = OwnedCF(original);
        let normalized = CFStringCreateMutableCopy(std::ptr::null(), 0, original.0);
        if normalized.is_null() {
            return Err(BAD);
        }
        let normalized = OwnedCF(normalized);
        CFStringNormalize(normalized.0.cast_mut(), 2);
        CFStringLowercase(normalized.0.cast_mut(), std::ptr::null());
        let size = CFStringGetMaximumSizeForEncoding(CFStringGetLength(normalized.0), UTF8);
        if !(0..=16384).contains(&size) {
            return Err(LIMIT);
        }
        let mut bytes = vec![0u8; size as usize + 1];
        if CFStringGetCString(
            normalized.0,
            bytes.as_mut_ptr().cast(),
            bytes.len() as isize,
            UTF8,
        ) == 0
        {
            return Err(BAD);
        }
        let end = bytes.iter().position(|b| *b == 0).ok_or(BAD)?;
        bytes.truncate(end);
        String::from_utf8(bytes).map_err(|_| BAD)
    }
}

fn path_parts(path: &Path) -> Result<Vec<CString>, i32> {
    let bytes = path.as_os_str().as_bytes();
    if !path.is_absolute() || bytes.len() > 4096 {
        return Err(PATH);
    }
    let normalized = if bytes.starts_with(b"/var/") || bytes.starts_with(b"/tmp/") {
        let mut normalized = b"/private".to_vec();
        normalized.extend_from_slice(bytes);
        PathBuf::from(std::ffi::OsStr::from_bytes(&normalized))
    } else {
        path.to_owned()
    };
    let mut parts = Vec::new();
    for component in normalized.components() {
        match component {
            Component::RootDir => {}
            Component::Normal(name) => parts.push(CString::new(name.as_bytes()).map_err(|_| PATH)?),
            _ => return Err(PATH),
        }
    }
    if parts.is_empty() {
        return Err(PATH);
    }
    Ok(parts)
}

pub(crate) fn parent(path: &Path) -> Result<(File, CString), i32> {
    let mut parts = path_parts(path)?;
    let name = parts.pop().ok_or(PATH)?;
    let mut directory_path = Vec::new();
    for component in parts {
        directory_path.push(b'/');
        directory_path.extend_from_slice(component.as_bytes());
    }
    if directory_path.is_empty() {
        directory_path.push(b'/');
    }
    let directory_path = CString::new(directory_path).map_err(|_| PATH)?;
    let fd = unsafe {
        libc::open(
            directory_path.as_ptr(),
            libc::O_SEARCH | libc::O_NOFOLLOW_ANY | libc::O_CLOEXEC,
        )
    };
    if fd < 0 {
        return Err(PATH);
    }
    Ok((unsafe { File::from_raw_fd(fd) }, name))
}

pub(crate) fn open_regular(path: &Path) -> Result<(File, Metadata), i32> {
    let (directory, name) = parent(path)?;
    let fd = unsafe {
        libc::openat(
            directory.as_raw_fd(),
            name.as_ptr(),
            libc::O_RDONLY | libc::O_NOFOLLOW | libc::O_NONBLOCK | libc::O_CLOEXEC,
        )
    };
    if fd < 0 {
        return Err(PATH);
    }
    let file = unsafe { File::from_raw_fd(fd) };
    let metadata = file.metadata().map_err(|_| DISK)?;
    if !metadata.is_file() {
        return Err(PATH);
    }
    Ok((file, metadata))
}

pub(crate) fn same_file(a: &Metadata, b: &Metadata) -> bool {
    (
        a.dev(),
        a.ino(),
        a.len(),
        a.mtime(),
        a.mtime_nsec(),
        a.ctime(),
        a.ctime_nsec(),
    ) == (
        b.dev(),
        b.ino(),
        b.len(),
        b.mtime(),
        b.mtime_nsec(),
        b.ctime(),
        b.ctime_nsec(),
    )
}

fn bundle_id(value: &str) -> bool {
    let parts: Vec<_> = value.split('.').collect();
    value.len() <= 255
        && parts.len() >= 2
        && parts.iter().all(|p| {
            !p.is_empty()
                && !p.starts_with('-')
                && !p.ends_with('-')
                && p.bytes().all(|c| c.is_ascii_alphanumeric() || c == b'-')
        })
}

fn archive_owner(path: &str) -> Result<&str, i32> {
    let parts: Vec<_> = path.split('/').collect();
    if path.len() > 1536
        || parts.len() > 34
        || parts.len() < 4
        || parts[0] != "Application"
        || !bundle_id(parts[1])
        || parts.iter().any(|p| {
            p.is_empty()
                || p.starts_with('.')
                || *p == "__MACOSX"
                || p.len() > 255
                || p.contains('\\')
                || p.chars().any(char::is_control)
        })
    {
        return Err(PATH);
    }
    if !(parts[2] == "Documents"
        || (parts.len() >= 5 && parts[2] == "Library" && parts[3] == "Caches"))
    {
        return Err(PATH);
    }
    let destination = parts[2..].join("/");
    if destination.len() > 1024 || parts.len() - 2 > 32 {
        return Err(PATH);
    }
    Ok(parts[1])
}

struct Entry {
    archive: String,
    payload: Option<(PathBuf, Metadata)>,
}

struct Output {
    file: File,
    parent: File,
    name: CString,
    committed: bool,
}
impl Drop for Output {
    fn drop(&mut self) {
        if self.committed {
            return;
        }
        let mut found = std::mem::MaybeUninit::<libc::stat>::uninit();
        let result = unsafe {
            libc::fstatat(
                self.parent.as_raw_fd(),
                self.name.as_ptr(),
                found.as_mut_ptr(),
                libc::AT_SYMLINK_NOFOLLOW,
            )
        };
        if result == 0
            && let Ok(owned) = self.file.metadata()
        {
            let found = unsafe { found.assume_init() };
            if found.st_dev as u64 == owned.dev() && found.st_ino == owned.ino() {
                unsafe {
                    libc::unlinkat(self.parent.as_raw_fd(), self.name.as_ptr(), 0);
                }
            }
        }
    }
}

struct LimitedWriter<'a> {
    file: &'a mut File,
    position: u64,
    exceeded: &'a std::cell::Cell<bool>,
}
impl Write for LimitedWriter<'_> {
    fn write(&mut self, bytes: &[u8]) -> std::io::Result<usize> {
        if self
            .position
            .checked_add(bytes.len() as u64)
            .is_none_or(|n| n > ARCHIVE_MAX)
        {
            self.exceeded.set(true);
            return Err(std::io::Error::other("archive limit"));
        }
        let count = self.file.write(bytes)?;
        self.position += count as u64;
        Ok(count)
    }
    fn flush(&mut self) -> std::io::Result<()> {
        self.file.flush()
    }
}
impl Seek for LimitedWriter<'_> {
    fn seek(&mut self, position: SeekFrom) -> std::io::Result<u64> {
        self.position = self.file.seek(position)?;
        if self.position > ARCHIVE_MAX {
            self.exceeded.set(true);
            return Err(std::io::Error::other("archive limit"));
        }
        Ok(self.position)
    }
}

fn create(
    manifest_path: &Path,
    output_path: &Path,
    cancelled: impl Fn() -> bool,
) -> Result<(), i32> {
    create_with_policy(manifest_path, output_path, cancelled, true)
}

pub(crate) fn create_with_policy(
    manifest_path: &Path,
    output_path: &Path,
    cancelled: impl Fn() -> bool,
    patch: bool,
) -> Result<(), i32> {
    if cancelled() {
        return Err(CANCEL);
    }
    let (mut manifest, metadata) = open_regular(manifest_path)?;
    if metadata.len() > MANIFEST_MAX {
        return Err(LIMIT);
    }
    let mut data = Vec::new();
    (&mut manifest)
        .take(MANIFEST_MAX + 1)
        .read_to_end(&mut data)
        .map_err(|_| DISK)?;
    if data.len() as u64 > MANIFEST_MAX {
        return Err(LIMIT);
    }
    if !same_file(&metadata, &manifest.metadata().map_err(|_| DISK)?) {
        return Err(DISK);
    }
    let value: Value = serde_json::from_slice(&data).map_err(|_| BAD)?;
    let object = value.as_object().ok_or(BAD)?;
    if object.keys().any(|k| {
        ![
            "entries",
            "name",
            "author",
            "compression_level",
            "work_mode",
        ]
        .contains(&k.as_str())
    }) {
        return Err(BAD);
    }
    let options = crate::archive::ArchiveOptions::parse(object)?;
    let members = object.get("entries").and_then(Value::as_array).ok_or(BAD)?;
    if members.is_empty() {
        return Err(EMPTY);
    }
    if members.len() > if patch { 1024 } else { 4096 } {
        return Err(LIMIT);
    }
    let mut comment = serde_json::Map::new();
    for (key, limit) in [("name", 120), ("author", 160)] {
        if let Some(value) = object.get(key) {
            let text = value.as_str().ok_or(BAD)?;
            if text.len() > limit || text.chars().any(char::is_control) {
                return Err(BAD);
            }
            comment.insert(key.into(), value.clone());
        }
    }
    let mut entries = Vec::new();
    let mut owner = None;
    let mut nodes = HashSet::new();
    let mut seen = HashSet::new();
    let mut leaves = HashSet::new();
    let mut parents = HashSet::new();
    let mut total = 0u64;
    let mut file_count = 0;
    for member in members {
        if cancelled() {
            return Err(CANCEL);
        }
        let entry = member.as_object().ok_or(BAD)?;
        if entry.len() != 2 {
            return Err(BAD);
        }
        let archive = entry
            .get("archive_path")
            .and_then(Value::as_str)
            .ok_or(BAD)?;
        let directory = !patch && entry.get("kind").and_then(Value::as_str) == Some("directory");
        if patch {
            let bundle = archive_owner(archive)?;
            if owner.is_some_and(|previous| previous != bundle) {
                return Err(PATH);
            }
            owner = Some(bundle);
        } else {
            crate::archive::validate_name(archive)?;
        }
        let key = canonical_key(archive)?;
        if !patch {
            nodes.insert(key.clone());
            for (i, _) in key.match_indices('/') {
                nodes.insert(key[..i].to_owned());
            }
            if nodes.len() > 4096 {
                return Err(LIMIT);
            }
        }
        if !seen.insert(key.clone())
            || (!directory && parents.contains(&key))
            || leaves.contains(&key)
        {
            return Err(PATH);
        }
        for (i, _) in key.match_indices('/') {
            if leaves.contains(&key[..i]) {
                return Err(PATH);
            }
            parents.insert(key[..i].to_owned());
        }
        if directory {
            entries.push(Entry {
                archive: archive.to_owned(),
                payload: None,
            });
            continue;
        }
        leaves.insert(key);
        file_count += 1;
        if file_count > 1024 {
            return Err(LIMIT);
        }
        let source = entry.get("local_path").and_then(Value::as_str).ok_or(BAD)?;
        let (_, metadata) = open_regular(Path::new(source))?;
        if metadata.len() > FILE_MAX || metadata.len() > TOTAL - total {
            return Err(LIMIT);
        }
        total += metadata.len();
        entries.push(Entry {
            archive: archive.to_owned(),
            payload: Some((source.into(), metadata)),
        });
    }
    let (directory, name) = parent(output_path)?;
    let (manifest_directory, _) = parent(manifest_path)?;
    let dir = directory.metadata().map_err(|_| DISK)?;
    let other = manifest_directory.metadata().map_err(|_| DISK)?;
    if (dir.dev(), dir.ino()) != (other.dev(), other.ino())
        || dir.uid() != unsafe { libc::geteuid() }
        || dir.mode() & 0o022 != 0
    {
        return Err(PATH);
    }
    let fd = unsafe {
        libc::openat(
            directory.as_raw_fd(),
            name.as_ptr(),
            libc::O_CREAT | libc::O_EXCL | libc::O_WRONLY | libc::O_NOFOLLOW | libc::O_CLOEXEC,
            0o600,
        )
    };
    if fd < 0 {
        return Err(DISK);
    }
    let mut output = Output {
        file: unsafe { File::from_raw_fd(fd) },
        parent: directory,
        name,
        committed: false,
    };
    let exceeded = std::cell::Cell::new(false);
    let disk_error = || if exceeded.get() { LIMIT } else { DISK };
    let mut zip = ZipWriter::new(LimitedWriter {
        file: &mut output.file,
        position: 0,
        exceeded: &exceeded,
    });
    if !comment.is_empty() {
        zip.set_comment(Value::Object(comment).to_string())
            .map_err(|_| DISK)?;
    }
    let file_options = SimpleFileOptions::default()
        .compression_method(if options.level == 0 {
            CompressionMethod::Stored
        } else {
            CompressionMethod::Deflated
        })
        .compression_level(if options.level == 0 {
            None
        } else {
            Some(i64::from(options.level))
        })
        .unix_permissions(0o600);
    let mut buffer = vec![0u8; options.mode.buffer_size()];
    let mut pacing = crate::archive::Pacing::new(options.mode);
    let mut actual_total = 0u64;
    for entry in entries {
        if cancelled() {
            return Err(CANCEL);
        }
        let Some((source_path, metadata)) = entry.payload else {
            zip.add_directory(
                entry.archive + "/",
                SimpleFileOptions::default().unix_permissions(0o700),
            )
            .map_err(|_| disk_error())?;
            continue;
        };
        let (mut source, initial) = open_regular(&source_path)?;
        if !same_file(&metadata, &initial) {
            return Err(DISK);
        }
        zip.start_file(entry.archive, file_options)
            .map_err(|_| disk_error())?;
        let mut actual = 0u64;
        loop {
            if cancelled() {
                return Err(CANCEL);
            }
            let count = source.read(&mut buffer).map_err(|_| DISK)?;
            if count == 0 {
                break;
            }
            actual += count as u64;
            actual_total += count as u64;
            if actual > FILE_MAX || actual_total > TOTAL {
                return Err(LIMIT);
            }
            if actual > initial.len() {
                return Err(DISK);
            }
            zip.write_all(&buffer[..count]).map_err(|_| disk_error())?;
            pacing.processed(count);
        }
        if actual != initial.len() || !same_file(&initial, &source.metadata().map_err(|_| DISK)?) {
            return Err(DISK);
        }
    }
    zip.finish().map_err(|_| disk_error())?;
    if cancelled() {
        return Err(CANCEL);
    }
    output.file.sync_all().map_err(|_| DISK)?;
    if cancelled() {
        return Err(CANCEL);
    }
    let current_fd = unsafe {
        libc::openat(
            output.parent.as_raw_fd(),
            output.name.as_ptr(),
            libc::O_RDONLY | libc::O_NOFOLLOW | libc::O_NONBLOCK | libc::O_CLOEXEC,
        )
    };
    if current_fd < 0 {
        return Err(DISK);
    }
    let current = unsafe { File::from_raw_fd(current_fd) };
    if !same_file(
        &output.file.metadata().map_err(|_| DISK)?,
        &current.metadata().map_err(|_| DISK)?,
    ) {
        return Err(DISK);
    }
    output.committed = true;
    Ok(())
}

#[unsafe(no_mangle)]
pub unsafe extern "C" fn cc365_create_patch_zip(
    manifest: *const c_char,
    output: *const c_char,
    cancelled: Option<extern "C" fn() -> bool>,
) -> i32 {
    if manifest.is_null() || output.is_null() {
        return BAD;
    }
    std::panic::catch_unwind(|| {
        let manifest = Path::new(std::ffi::OsStr::from_bytes(
            unsafe { CStr::from_ptr(manifest) }.to_bytes(),
        ));
        let output = Path::new(std::ffi::OsStr::from_bytes(
            unsafe { CStr::from_ptr(output) }.to_bytes(),
        ));
        create(manifest, output, || cancelled.is_some_and(|f| f()))
            .err()
            .unwrap_or(0)
    })
    .unwrap_or(BAD)
}
