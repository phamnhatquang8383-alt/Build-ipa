use crate::patch_create::{canonical_key, open_regular, parent, same_file};
use serde_json::{Map, Value};
use std::{
    collections::HashSet,
    ffi::{CStr, CString, c_char},
    fs::{File, Metadata},
    io::{BufReader, Read, Write},
    os::{
        fd::{AsRawFd, FromRawFd},
        unix::{ffi::OsStrExt, fs::MetadataExt},
    },
    path::Path,
};
use zip::{read::ZipReadOptions, unstable::read::ZipIterable};
const BAD: i32 = 1;
const PATH: i32 = 2;
const LIMIT: i32 = 3;
const DISK: i32 = 5;
const CANCEL: i32 = 6;
const FILE_MAX: u64 = 128 << 20;
const TOTAL: u64 = 256 << 20;

#[derive(Clone, Copy, Debug, PartialEq)]
pub(crate) enum WorkMode {
    Eco,
    Balanced,
    Fast,
}
impl WorkMode {
    pub(crate) fn from_native(value: i32) -> Result<Self, i32> {
        match value {
            0 => Ok(Self::Eco),
            1 => Ok(Self::Balanced),
            2 => Ok(Self::Fast),
            _ => Err(BAD),
        }
    }
    pub(crate) fn buffer_size(self) -> usize {
        match self {
            Self::Eco => 32 << 10,
            Self::Balanced => 64 << 10,
            Self::Fast => 256 << 10,
        }
    }
}
pub(crate) struct ArchiveOptions {
    pub level: u8,
    pub mode: WorkMode,
}
impl ArchiveOptions {
    pub(crate) fn parse(object: &Map<String, Value>) -> Result<Self, i32> {
        let level = match object.get("compression_level") {
            None => 6,
            Some(v) => v.as_u64().filter(|v| *v <= 9).ok_or(BAD)? as u8,
        };
        let mode = match object.get("work_mode") {
            None => WorkMode::Balanced,
            Some(v) => match v.as_str() {
                Some("eco") => WorkMode::Eco,
                Some("balanced") => WorkMode::Balanced,
                Some("fast") => WorkMode::Fast,
                _ => return Err(BAD),
            },
        };
        Ok(Self { level, mode })
    }
}
pub(crate) struct Pacing {
    mode: WorkMode,
    bytes: usize,
}
impl Pacing {
    pub(crate) fn new(mode: WorkMode) -> Self {
        Self { mode, bytes: 0 }
    }
    pub(crate) fn processed(&mut self, bytes: usize) {
        if self.mode != WorkMode::Eco {
            return;
        }
        self.bytes += bytes;
        if self.bytes >= 1 << 20 {
            self.bytes %= 1 << 20;
            std::thread::sleep(std::time::Duration::from_millis(1));
        }
    }
}
pub(crate) fn validate_name(name: &str) -> Result<(), i32> {
    let parts: Vec<_> = name.split('/').collect();
    if name.len() > 1536
        || parts.len() > 34
        || parts.iter().any(|p| {
            p.is_empty()
                || *p == "."
                || *p == ".."
                || p.len() > 255
                || p.contains('\\')
                || p.chars().any(char::is_control)
        })
        || parts[0].as_bytes().get(1) == Some(&b':')
    {
        return Err(PATH);
    }
    Ok(())
}
fn cstr(value: &str) -> Result<CString, i32> {
    CString::new(value).map_err(|_| PATH)
}
fn stat_at(dir: &File, name: &CString) -> Result<libc::stat, i32> {
    let mut info = std::mem::MaybeUninit::uninit();
    if unsafe {
        libc::fstatat(
            dir.as_raw_fd(),
            name.as_ptr(),
            info.as_mut_ptr(),
            libc::AT_SYMLINK_NOFOLLOW,
        )
    } != 0
    {
        return Err(DISK);
    }
    Ok(unsafe { info.assume_init() })
}
fn matches(info: &libc::stat, meta: &Metadata) -> bool {
    info.st_dev as u64 == meta.dev() && info.st_ino == meta.ino()
}
fn directory_at(dir: &File, name: &CString) -> Result<File, i32> {
    let fd = unsafe {
        libc::openat(
            dir.as_raw_fd(),
            name.as_ptr(),
            libc::O_RDONLY | libc::O_DIRECTORY | libc::O_NOFOLLOW | libc::O_CLOEXEC,
        )
    };
    if fd < 0 {
        return Err(PATH);
    }
    Ok(unsafe { File::from_raw_fd(fd) })
}
fn empty_directory(dir: &File) -> Result<bool, i32> {
    let fd = unsafe { libc::dup(dir.as_raw_fd()) };
    if fd < 0 {
        return Err(DISK);
    }
    let stream = unsafe { libc::fdopendir(fd) };
    if stream.is_null() {
        unsafe {
            libc::close(fd);
        }
        return Err(DISK);
    }
    let mut empty = true;
    loop {
        unsafe {
            *libc::__error() = 0;
        }
        let item = unsafe { libc::readdir(stream) };
        if item.is_null() {
            let error = std::io::Error::last_os_error().raw_os_error().unwrap_or(0);
            unsafe {
                libc::closedir(stream);
            }
            return if error == 0 { Ok(empty) } else { Err(DISK) };
        }
        let name = unsafe { CStr::from_ptr((*item).d_name.as_ptr()) }.to_bytes();
        if name != b"." && name != b".." {
            empty = false;
            break;
        }
    }
    unsafe {
        libc::closedir(stream);
    }
    Ok(empty)
}
struct Created {
    parts: Vec<String>,
    metadata: Metadata,
    directory: bool,
}
struct Tree {
    parent: File,
    root: File,
    root_meta: Metadata,
    created: Vec<Created>,
    committed: bool,
}
impl Tree {
    fn new(scratch: &Path) -> Result<Self, i32> {
        let (base, name) = parent(&scratch.join("contents"))?;
        let base = directory_at(&base, &cstr(".")?)?;
        let meta = base.metadata().map_err(|_| DISK)?;
        if !meta.is_dir()
            || meta.uid() != unsafe { libc::geteuid() }
            || meta.mode() & 0o022 != 0
            || !empty_directory(&base)?
        {
            return Err(PATH);
        }
        if unsafe { libc::mkdirat(base.as_raw_fd(), name.as_ptr(), 0o700) } != 0 {
            return Err(DISK);
        }
        let root = match directory_at(&base, &name) {
            Ok(root) => root,
            Err(e) => {
                unsafe {
                    libc::unlinkat(base.as_raw_fd(), name.as_ptr(), libc::AT_REMOVEDIR);
                }
                return Err(e);
            }
        };
        let root_meta = root.metadata().map_err(|_| DISK)?;
        Ok(Self {
            parent: base,
            root,
            root_meta,
            created: Vec::new(),
            committed: false,
        })
    }
    fn parent_for(&mut self, parts: &[String], create: bool) -> Result<File, i32> {
        let mut dir = self.root.try_clone().map_err(|_| DISK)?;
        for (i, part) in parts.iter().enumerate() {
            let name = cstr(part)?;
            if create {
                if unsafe { libc::mkdirat(dir.as_raw_fd(), name.as_ptr(), 0o700) } == 0 {
                    let child = directory_at(&dir, &name)?;
                    self.created.push(Created {
                        parts: parts[..=i].to_vec(),
                        metadata: child.metadata().map_err(|_| DISK)?,
                        directory: true,
                    });
                    dir = child;
                    continue;
                }
                if std::io::Error::last_os_error().raw_os_error() != Some(libc::EEXIST) {
                    return Err(DISK);
                }
            }
            dir = directory_at(&dir, &name)?;
        }
        Ok(dir)
    }
    fn directory(&mut self, parts: &[String]) -> Result<(), i32> {
        self.parent_for(parts, true).map(|_| ())
    }
    fn file(&mut self, parts: &[String]) -> Result<File, i32> {
        let dir = self.parent_for(&parts[..parts.len() - 1], true)?;
        let name = cstr(parts.last().ok_or(PATH)?)?;
        let fd = unsafe {
            libc::openat(
                dir.as_raw_fd(),
                name.as_ptr(),
                libc::O_CREAT | libc::O_EXCL | libc::O_WRONLY | libc::O_NOFOLLOW | libc::O_CLOEXEC,
                0o600,
            )
        };
        if fd < 0 {
            return Err(DISK);
        }
        let file = unsafe { File::from_raw_fd(fd) };
        self.created.push(Created {
            parts: parts.to_vec(),
            metadata: file.metadata().map_err(|_| DISK)?,
            directory: false,
        });
        Ok(file)
    }
    fn commit(&mut self) -> Result<(), i32> {
        if !matches(&stat_at(&self.parent, &cstr("contents")?)?, &self.root_meta) {
            return Err(DISK);
        }
        self.committed = true;
        Ok(())
    }
}
impl Drop for Tree {
    fn drop(&mut self) {
        if self.committed {
            return;
        }
        while let Some(item) = self.created.pop() {
            let Ok(dir) = self.parent_for(&item.parts[..item.parts.len() - 1], false) else {
                continue;
            };
            let Ok(name) = cstr(item.parts.last().unwrap()) else {
                continue;
            };
            if stat_at(&dir, &name).is_ok_and(|s| matches(&s, &item.metadata)) {
                unsafe {
                    libc::unlinkat(
                        dir.as_raw_fd(),
                        name.as_ptr(),
                        if item.directory {
                            libc::AT_REMOVEDIR
                        } else {
                            0
                        },
                    );
                }
            }
        }
        let name = CString::new("contents").unwrap();
        if stat_at(&self.parent, &name).is_ok_and(|s| matches(&s, &self.root_meta)) {
            unsafe {
                libc::unlinkat(self.parent.as_raw_fd(), name.as_ptr(), libc::AT_REMOVEDIR);
            }
        }
    }
}

fn extract(
    source: &Path,
    scratch: &Path,
    mode: WorkMode,
    cancelled: impl Fn() -> bool,
) -> Result<(), i32> {
    if cancelled() {
        return Err(CANCEL);
    }
    let (first, metadata) = open_regular(source)?;
    if metadata.len() > TOTAL + (8 << 20) {
        return Err(LIMIT);
    }
    let (body, other) = open_regular(source)?;
    if !same_file(&metadata, &other) {
        return Err(DISK);
    }
    let body_check = body.try_clone().map_err(|_| DISK)?;
    let mut zip = ZipIterable::try_new(BufReader::new(first), Default::default())
        .map_err(|_| BAD)?
        .enforce_header_consistency(true);
    if zip.len() > 4096 {
        return Err(LIMIT);
    }
    let expected = zip.len();
    let mut files = zip
        .files_with_reader(
            BufReader::new(body),
            ZipReadOptions::new().enforce_header_consistency(true),
        )
        .map_err(|_| BAD)?;
    let mut tree = Tree::new(scratch)?;
    let mut nodes = HashSet::new();
    let mut seen = HashSet::new();
    let mut leaves = HashSet::new();
    let mut parents = HashSet::new();
    let mut total = 0;
    let mut count = 0;
    let mut file_count = 0;
    let mut buffer = vec![0u8; mode.buffer_size()];
    let mut pacing = Pacing::new(mode);
    while let Some(member) = files.next() {
        if cancelled() {
            return Err(CANCEL);
        }
        let mut member = member.map_err(|_| BAD)?;
        count += 1;
        let path = member.name().map_err(|_| PATH)?.into_owned();
        let directory = member.is_dir();
        let name = if directory {
            path.strip_suffix('/').ok_or(PATH)?
        } else {
            &path
        };
        validate_name(name)?;
        let kind = member.unix_mode().unwrap_or(0) & 0o170000;
        if member.is_symlink()
            || !matches!(kind, 0 | 0o100000 | 0o040000)
            || (kind == 0o040000 && !directory)
            || (kind == 0o100000 && directory)
        {
            return Err(PATH);
        }
        let key = canonical_key(name)?;
        nodes.insert(key.clone());
        for (i, _) in key.match_indices('/') {
            nodes.insert(key[..i].to_owned());
        }
        if nodes.len() > 4096 {
            return Err(LIMIT);
        }
        if !seen.insert(key.clone())
            || (!directory && parents.contains(&key))
            || leaves.contains(&key)
        {
            return Err(PATH);
        }
        for (i, _) in key.match_indices('/') {
            if leaves.contains(&key[..i]) {
                return Err(PATH);
            }
            parents.insert(key[..i].to_owned());
        }
        let parts: Vec<String> = name.split('/').map(str::to_owned).collect();
        if directory {
            if member.size() != 0 {
                return Err(PATH);
            }
            if member.read(&mut buffer[..1]).map_err(|_| BAD)? != 0 {
                return Err(PATH);
            }
            tree.directory(&parts)?;
            continue;
        }
        leaves.insert(key);
        file_count += 1;
        let size = member.size();
        if file_count > 1024 || size > FILE_MAX || size > TOTAL - total {
            return Err(LIMIT);
        }
        let mut out = tree.file(&parts)?;
        let mut actual = 0;
        loop {
            if cancelled() {
                return Err(CANCEL);
            }
            let n = member.read(&mut buffer).map_err(|_| BAD)?;
            if n == 0 {
                break;
            }
            actual += n as u64;
            if actual > size || actual > FILE_MAX || actual > TOTAL - total {
                return Err(LIMIT);
            }
            out.write_all(&buffer[..n]).map_err(|_| DISK)?;
            pacing.processed(n);
        }
        if actual != size {
            return Err(BAD);
        }
        total += actual;
    }
    if count != expected {
        return Err(BAD);
    }
    if cancelled() {
        return Err(CANCEL);
    }
    if !same_file(&metadata, &body_check.metadata().map_err(|_| DISK)?)
        || !same_file(&metadata, &open_regular(source)?.1)
    {
        return Err(DISK);
    }
    tree.commit()
}

#[unsafe(no_mangle)]
pub unsafe extern "C" fn cc365_create_zip(
    manifest: *const c_char,
    output: *const c_char,
    cancelled: Option<extern "C" fn() -> bool>,
) -> i32 {
    if manifest.is_null() || output.is_null() {
        return BAD;
    }
    std::panic::catch_unwind(|| {
        let manifest = Path::new(std::ffi::OsStr::from_bytes(
            unsafe { CStr::from_ptr(manifest) }.to_bytes(),
        ));
        let output = Path::new(std::ffi::OsStr::from_bytes(
            unsafe { CStr::from_ptr(output) }.to_bytes(),
        ));
        crate::patch_create::create_with_policy(
            manifest,
            output,
            || cancelled.is_some_and(|f| f()),
            false,
        )
        .err()
        .unwrap_or(0)
    })
    .unwrap_or(BAD)
}
#[unsafe(no_mangle)]
pub unsafe extern "C" fn cc365_extract_zip(
    source: *const c_char,
    scratch: *const c_char,
    work_mode: i32,
    cancelled: Option<extern "C" fn() -> bool>,
) -> i32 {
    if source.is_null() || scratch.is_null() {
        return BAD;
    }
    std::panic::catch_unwind(|| {
        let mode = WorkMode::from_native(work_mode)?;
        let source = Path::new(std::ffi::OsStr::from_bytes(
            unsafe { CStr::from_ptr(source) }.to_bytes(),
        ));
        let scratch = Path::new(std::ffi::OsStr::from_bytes(
            unsafe { CStr::from_ptr(scratch) }.to_bytes(),
        ));
        extract(source, scratch, mode, || cancelled.is_some_and(|f| f()))
    })
    .unwrap_or(Err(BAD))
    .err()
    .unwrap_or(0)
}

#[cfg(test)]
#[path = "archive_tests.rs"]
mod tests;
