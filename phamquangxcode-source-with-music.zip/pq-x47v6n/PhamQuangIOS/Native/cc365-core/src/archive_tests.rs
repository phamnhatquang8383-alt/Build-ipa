use super::*;
use std::{
    cell::Cell,
    fs,
    io::Cursor,
    os::unix::fs::{PermissionsExt, symlink},
    path::PathBuf,
};
use tempfile::{TempDir, tempdir};
use zip::{CompressionMethod, ZipWriter, write::SimpleFileOptions};

struct Fixture {
    root: TempDir,
    manifest: PathBuf,
    source: PathBuf,
    output: PathBuf,
    scratch: PathBuf,
}
impl Fixture {
    fn new() -> Self {
        let root = tempdir().unwrap();
        let source = root.path().join("source");
        fs::write(&source, b"exact\0bytes\xff").unwrap();
        let scratch = root.path().join("scratch");
        fs::create_dir(&scratch).unwrap();
        Self {
            manifest: root.path().join("manifest.json"),
            output: root.path().join("archive.zip"),
            source,
            scratch,
            root,
        }
    }
    fn manifest(&self, entries: Value, level: i32, mode: &str) {
        fs::write(
            &self.manifest,
            serde_json::json!({"entries":entries,"compression_level":level,"work_mode":mode})
                .to_string(),
        )
        .unwrap();
    }
    fn create(&self) -> Result<(), i32> {
        crate::patch_create::create_with_policy(&self.manifest, &self.output, || false, false)
    }
    fn extract(&self) -> Result<(), i32> {
        extract(&self.output, &self.scratch, WorkMode::Balanced, || false)
    }
    fn empty(&self) {
        assert_eq!(fs::read_dir(&self.scratch).unwrap().count(), 0);
    }
}
fn zip(entries: &[(&str, &[u8])], method: CompressionMethod) -> Vec<u8> {
    let mut out = ZipWriter::new(Cursor::new(Vec::new()));
    for (name, bytes) in entries {
        out.start_file(
            *name,
            SimpleFileOptions::default().compression_method(method),
        )
        .unwrap();
        out.write_all(bytes).unwrap();
    }
    out.finish().unwrap().into_inner()
}
fn check_bad(bytes: &[u8], code: i32) {
    let f = Fixture::new();
    fs::write(&f.output, bytes).unwrap();
    assert_eq!(f.extract(), Err(code));
    f.empty();
    assert_eq!(fs::read(&f.source).unwrap(), b"exact\0bytes\xff");
}
#[test]
fn general_zip_roundtrip_keeps_dotfiles_empty_directories_unicode_and_opaque_payloads() {
    let f = Fixture::new();
    fs::write(&f.source, b"OPAQUE\0binary\xff").unwrap();
    let empty = f.root.path().join("empty");
    fs::write(&empty, b"").unwrap();
    f.manifest(
        serde_json::json!([
        {"archive_path":"Đồ dùng/.private/file.blob","local_path":f.source},
        {"archive_path":"Đồ dùng/empty.bin","local_path":empty},
        {"archive_path":"Đồ dùng/empty folder","kind":"directory"},
        {"archive_path":"__MACOSX","kind":"directory"}]),
        6,
        "balanced",
    );
    assert_eq!(f.create(), Ok(()));
    assert_eq!(f.extract(), Ok(()));
    assert_eq!(
        fs::read(f.scratch.join("contents/Đồ dùng/.private/file.blob")).unwrap(),
        b"OPAQUE\0binary\xff"
    );
    assert_eq!(
        fs::metadata(f.scratch.join("contents/Đồ dùng/empty.bin"))
            .unwrap()
            .len(),
        0
    );
    assert!(f.scratch.join("contents/Đồ dùng/empty folder").is_dir());
    assert!(f.scratch.join("contents/__MACOSX").is_dir());
}
#[test]
fn compression_levels_and_resource_modes_roundtrip_using_the_library() {
    let payload = vec![b'x'; 2 << 20];
    let mut stored = 0;
    for level in 0..=9 {
        let f = Fixture::new();
        fs::write(&f.source, &payload).unwrap();
        let mode = ["eco", "balanced", "fast"][level as usize % 3];
        f.manifest(
            serde_json::json!([{"archive_path":"data","local_path":f.source}]),
            level,
            mode,
        );
        assert_eq!(f.create(), Ok(()));
        let encoded = fs::read(&f.output).unwrap();
        assert_eq!(
            u16::from_le_bytes([encoded[8], encoded[9]]),
            if level == 0 { 0 } else { 8 }
        );
        if level == 0 {
            stored = encoded.len();
        } else {
            assert!(encoded.len() < stored / 10);
        }
        assert_eq!(
            extract(
                &f.output,
                &f.scratch,
                WorkMode::from_native(level % 3).unwrap(),
                || false
            ),
            Ok(())
        );
        assert_eq!(fs::read(f.scratch.join("contents/data")).unwrap(), payload);
    }
    let defaults = ArchiveOptions::parse(&Map::new()).unwrap();
    assert_eq!(defaults.level, 6);
    assert_eq!(defaults.mode, WorkMode::Balanced);
    assert_eq!(
        [
            WorkMode::Eco.buffer_size(),
            WorkMode::Balanced.buffer_size(),
            WorkMode::Fast.buffer_size()
        ],
        [32768, 65536, 262144]
    );
}
#[test]
fn strict_settings_and_bridge_arguments_reject_invalid_values_without_output() {
    for (key, value) in [
        ("compression_level", serde_json::json!(-1)),
        ("compression_level", serde_json::json!(10)),
        ("compression_level", serde_json::json!(6.5)),
        ("compression_level", serde_json::json!(true)),
        ("work_mode", serde_json::json!("turbo")),
        ("work_mode", Value::Null),
    ] {
        let mut options = Map::new();
        options.insert(key.into(), value);
        assert!(matches!(ArchiveOptions::parse(&options), Err(BAD)));
    }
    assert_eq!(
        unsafe { cc365_create_zip(std::ptr::null(), std::ptr::null(), None) },
        BAD
    );
    assert_eq!(
        unsafe { cc365_extract_zip(std::ptr::null(), std::ptr::null(), 1, None) },
        BAD
    );
    let f = Fixture::new();
    fs::write(&f.output, zip(&[], CompressionMethod::Stored)).unwrap();
    let source = CString::new(f.output.as_os_str().as_bytes()).unwrap();
    let scratch = CString::new(f.scratch.as_os_str().as_bytes()).unwrap();
    assert_eq!(
        unsafe { cc365_extract_zip(source.as_ptr(), scratch.as_ptr(), 99, None) },
        BAD
    );
    f.empty();
    assert_eq!(
        unsafe {
            crate::patch_zip::cc365_patch_extract_zip_with_mode(
                source.as_ptr(),
                scratch.as_ptr(),
                -1,
                None,
            )
        },
        BAD
    );
    f.empty();
}
#[test]
fn actual_c_bridge_create_and_extract_and_empty_zip_succeed() {
    let f = Fixture::new();
    f.manifest(
        serde_json::json!([{"archive_path":"data","local_path":f.source}]),
        1,
        "eco",
    );
    let m = CString::new(f.manifest.as_os_str().as_bytes()).unwrap();
    let o = CString::new(f.output.as_os_str().as_bytes()).unwrap();
    let s = CString::new(f.scratch.as_os_str().as_bytes()).unwrap();
    assert_eq!(unsafe { cc365_create_zip(m.as_ptr(), o.as_ptr(), None) }, 0);
    assert_eq!(
        unsafe { cc365_extract_zip(o.as_ptr(), s.as_ptr(), 2, None) },
        0
    );
    assert_eq!(
        fs::read(f.scratch.join("contents/data")).unwrap(),
        b"exact\0bytes\xff"
    );
    let f = Fixture::new();
    fs::write(&f.output, zip(&[], CompressionMethod::Stored)).unwrap();
    assert_eq!(f.extract(), Ok(()));
    assert_eq!(fs::read_dir(f.scratch.join("contents")).unwrap().count(), 0);
}
#[test]
fn unsafe_names_symlinks_specials_and_unicode_collisions_fail_with_cleanup() {
    for path in [
        "../outside",
        "/absolute",
        "C:/drive",
        "a\\b",
        "a//b",
        "./a",
        "a/../b",
        "a/\nb",
    ] {
        check_bad(
            &zip(
                &[("first", b"ok"), (path, b"bad")],
                CompressionMethod::Stored,
            ),
            PATH,
        );
        let f = Fixture::new();
        f.manifest(
            serde_json::json!([{"archive_path":path,"local_path":f.source}]),
            6,
            "balanced",
        );
        assert_eq!(f.create(), Err(PATH));
        assert!(!f.output.exists());
    }
    for (a, b) in [
        ("same", "SAME"),
        ("café", "cafe\u{301}"),
        ("x", "X/child"),
        ("X/child", "x"),
    ] {
        check_bad(
            &zip(&[(a, b"a"), (b, b"b")], CompressionMethod::Deflated),
            PATH,
        );
        let f = Fixture::new();
        f.manifest(serde_json::json!([{"archive_path":a,"local_path":f.source},{"archive_path":b,"local_path":f.source}]),6,"balanced");
        assert_eq!(f.create(), Err(PATH));
    }
    let mut archive = ZipWriter::new(Cursor::new(Vec::new()));
    archive
        .add_symlink("link", "../outside", SimpleFileOptions::default())
        .unwrap();
    check_bad(&archive.finish().unwrap().into_inner(), PATH);
    let mut bytes = zip(&[("node", b"x")], CompressionMethod::Stored);
    let central = bytes.windows(4).rposition(|v| v == b"PK\x01\x02").unwrap();
    bytes[central + 38..central + 42].copy_from_slice(&(0o020600u32 << 16).to_le_bytes());
    check_bad(&bytes, PATH);
}
#[test]
fn general_writer_preserves_no_clobber_private_staging_and_source_link_rejection() {
    let f = Fixture::new();
    f.manifest(
        serde_json::json!([{"archive_path":"data","local_path":f.source}]),
        0,
        "balanced",
    );
    fs::write(&f.output, b"existing").unwrap();
    assert_eq!(f.create(), Err(DISK));
    assert_eq!(fs::read(&f.output).unwrap(), b"existing");
    fs::remove_file(&f.output).unwrap();
    let link = f.root.path().join("link");
    symlink(&f.source, &link).unwrap();
    f.manifest(
        serde_json::json!([{"archive_path":"data","local_path":link}]),
        6,
        "balanced",
    );
    assert_eq!(f.create(), Err(PATH));
    let f = Fixture::new();
    f.manifest(
        serde_json::json!([{"archive_path":"data","local_path":f.source}]),
        6,
        "balanced",
    );
    fs::set_permissions(f.root.path(), fs::Permissions::from_mode(0o777)).unwrap();
    assert_eq!(f.create(), Err(PATH));
}
#[test]
fn extraction_refuses_existing_scratch_tree_and_symlink_ancestors() {
    let f = Fixture::new();
    fs::write(
        &f.output,
        zip(&[("data", b"new")], CompressionMethod::Stored),
    )
    .unwrap();
    fs::write(f.scratch.join("existing"), b"keep").unwrap();
    assert_eq!(f.extract(), Err(PATH));
    assert_eq!(fs::read(f.scratch.join("existing")).unwrap(), b"keep");
    fs::remove_file(f.scratch.join("existing")).unwrap();
    let alias = f.root.path().join("alias");
    symlink(&f.scratch, &alias).unwrap();
    assert_eq!(
        extract(&f.output, &alias, WorkMode::Balanced, || false),
        Err(PATH)
    );
    f.empty();
    let source_alias = f.root.path().join("input-link");
    symlink(&f.output, &source_alias).unwrap();
    assert_eq!(
        extract(&source_alias, &f.scratch, WorkMode::Balanced, || false),
        Err(PATH)
    );
    f.empty();
}
#[test]
fn cancellation_cleans_both_output_and_full_nested_tree() {
    let f = Fixture::new();
    fs::write(&f.source, vec![1u8; 2 << 20]).unwrap();
    f.manifest(
        serde_json::json!([{"archive_path":"a/b/data","local_path":f.source}]),
        6,
        "eco",
    );
    let calls = Cell::new(0);
    assert_eq!(
        crate::patch_create::create_with_policy(
            &f.manifest,
            &f.output,
            || {
                calls.set(calls.get() + 1);
                calls.get() > 8
            },
            false
        ),
        Err(CANCEL)
    );
    assert!(!f.output.exists());
    assert_eq!(f.create(), Ok(()));
    let calls = Cell::new(0);
    assert_eq!(
        extract(&f.output, &f.scratch, WorkMode::Eco, || {
            calls.set(calls.get() + 1);
            calls.get() > 10
        }),
        Err(CANCEL)
    );
    f.empty();
    assert_eq!(
        extract(&f.output, &f.scratch, WorkMode::Fast, || true),
        Err(CANCEL)
    );
    f.empty();
}
#[test]
fn extraction_detects_source_mutation_and_cleans_partial() {
    let f = Fixture::new();
    fs::write(
        &f.output,
        zip(
            &[("deep/a", &vec![2; 256 << 10])],
            CompressionMethod::Stored,
        ),
    )
    .unwrap();
    let calls = Cell::new(0);
    assert_eq!(
        extract(&f.output, &f.scratch, WorkMode::Balanced, || {
            calls.set(calls.get() + 1);
            if calls.get() == 4 {
                std::fs::OpenOptions::new()
                    .append(true)
                    .open(&f.output)
                    .unwrap()
                    .write_all(b"changed")
                    .unwrap();
            }
            false
        }),
        Err(DISK)
    );
    f.empty();
}
#[test]
fn crc_forged_size_zip_bomb_and_total_entry_limits_are_enforced() {
    let original = zip(
        &[("data", b"123456789payload")],
        CompressionMethod::Deflated,
    );
    let central = original
        .windows(4)
        .rposition(|v| v == b"PK\x01\x02")
        .unwrap();
    let mut crc = original.clone();
    crc[14..18].copy_from_slice(&1u32.to_le_bytes());
    crc[central + 16..central + 20].copy_from_slice(&1u32.to_le_bytes());
    check_bad(&crc, BAD);
    let mut large = original;
    large[22..26].copy_from_slice(&((FILE_MAX + 1) as u32).to_le_bytes());
    large[central + 24..central + 28].copy_from_slice(&((FILE_MAX + 1) as u32).to_le_bytes());
    check_bad(&large, LIMIT);
    let f = Fixture::new();
    File::create(&f.source)
        .unwrap()
        .set_len(FILE_MAX + 1)
        .unwrap();
    f.manifest(
        serde_json::json!([{"archive_path":"large","local_path":f.source}]),
        6,
        "balanced",
    );
    assert_eq!(f.create(), Err(LIMIT));
    let names: Vec<_> = (0..1025).map(|n| format!("f{n}")).collect();
    let entries: Vec<_> = names.iter().map(|n| (n.as_str(), b"".as_slice())).collect();
    check_bad(&zip(&entries, CompressionMethod::Stored), LIMIT);
    let f = Fixture::new();
    f.manifest(
        Value::Array(
            (0..4097)
                .map(|n| serde_json::json!({"archive_path":format!("d{n}"),"kind":"directory"}))
                .collect(),
        ),
        6,
        "balanced",
    );
    assert_eq!(f.create(), Err(LIMIT));
}
#[test]
fn directory_ancestor_collision_rejected_in_both_orders() {
    for reversed in [false, true] {
        let f = Fixture::new();
        let mut entries = vec![
            serde_json::json!({"archive_path":"a","kind":"directory"}),
            serde_json::json!({"archive_path":"A","local_path":f.source}),
        ];
        if reversed {
            entries.reverse();
        }
        f.manifest(Value::Array(entries), 6, "balanced");
        assert_eq!(f.create(), Err(PATH));
        assert!(!f.output.exists());
    }
}

#[test]
fn implicit_parent_directories_share_the_general_tree_budget() {
    let names: Vec<_> = (0..800).map(|n| format!("d{n}/a/b/c/d/e/file")).collect();
    let members: Vec<_> = names.iter().map(|n| (n.as_str(), b"".as_slice())).collect();
    check_bad(&zip(&members, CompressionMethod::Stored), LIMIT);
    let f = Fixture::new();
    f.manifest(
        Value::Array(
            names
                .iter()
                .map(|n| serde_json::json!({"archive_path":n,"local_path":f.source}))
                .collect(),
        ),
        6,
        "balanced",
    );
    assert_eq!(f.create(), Err(LIMIT));
    assert!(!f.output.exists());
}

#[test]
fn failure_cleanup_does_not_follow_a_replaced_parent_symlink() {
    let f = Fixture::new();
    fs::write(
        &f.output,
        zip(
            &[("nested/file", &vec![1; 256 << 10])],
            CompressionMethod::Stored,
        ),
    )
    .unwrap();
    let outside = f.root.path().join("outside");
    fs::create_dir(&outside).unwrap();
    fs::write(outside.join("file"), b"keep").unwrap();
    let moved = f.root.path().join("moved");
    let polls = Cell::new(0);
    assert_eq!(
        extract(&f.output, &f.scratch, WorkMode::Balanced, || {
            polls.set(polls.get() + 1);
            if polls.get() == 4 {
                fs::rename(f.scratch.join("contents/nested"), &moved).unwrap();
                symlink(&outside, f.scratch.join("contents/nested")).unwrap();
                return true;
            }
            false
        }),
        Err(CANCEL)
    );
    assert_eq!(fs::read(outside.join("file")).unwrap(), b"keep");
    assert!(
        fs::symlink_metadata(f.scratch.join("contents/nested"))
            .unwrap()
            .file_type()
            .is_symlink()
    );
}

#[test]
fn empty_directory_member_still_requires_a_valid_crc() {
    let mut archive = ZipWriter::new(Cursor::new(Vec::new()));
    archive
        .add_directory("empty/", SimpleFileOptions::default())
        .unwrap();
    let mut bytes = archive.finish().unwrap().into_inner();
    let central = bytes.windows(4).rposition(|v| v == b"PK\x01\x02").unwrap();
    bytes[14..18].copy_from_slice(&1u32.to_le_bytes());
    bytes[central + 16..central + 20].copy_from_slice(&1u32.to_le_bytes());
    check_bad(&bytes, BAD);
}
#[test]
fn writer_rejects_output_name_replacement_before_commit_without_deleting_replacement() {
    let f = Fixture::new();
    f.manifest(
        serde_json::json!([{"archive_path":"data","local_path":f.source}]),
        6,
        "balanced",
    );
    let moved = f.root.path().join("our-output");
    let changed = Cell::new(false);
    assert_eq!(
        crate::patch_create::create_with_policy(
            &f.manifest,
            &f.output,
            || {
                if !changed.get()
                    && fs::read(&f.output).is_ok_and(|b| b.windows(4).any(|v| v == b"PK\x05\x06"))
                {
                    fs::rename(&f.output, &moved).unwrap();
                    fs::write(&f.output, b"foreign replacement").unwrap();
                    changed.set(true);
                }
                false
            },
            false
        ),
        Err(DISK)
    );
    assert!(changed.get());
    assert_eq!(fs::read(&f.output).unwrap(), b"foreign replacement");
}
