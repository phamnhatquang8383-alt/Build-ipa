use std::{
    collections::HashSet,
    ffi::{CStr, c_char},
    fs::{self, File, OpenOptions},
    io::{BufReader, Read, Write},
    os::unix::{
        ffi::OsStrExt,
        fs::{MetadataExt, OpenOptionsExt},
    },
    path::Path,
};
use zip::{read::ZipReadOptions, unstable::read::ZipIterable};

const BAD: i32 = 1;
const PATH: i32 = 2;
const LIMIT: i32 = 3;
const DISK: i32 = 5;
const CANCEL: i32 = 6;
const EMPTY: i32 = 7;
const FILE_MAX: u64 = 128 << 20;
const TOTAL: u64 = 256 << 20;

#[cfg(test)]
#[path = "patch_zip_tests.rs"]
mod tests;

fn unpack(source: &Path, scratch: &Path, cancelled: impl Fn() -> bool) -> Result<(), i32> {
    unpack_mode(
        source,
        scratch,
        crate::archive::WorkMode::Balanced,
        cancelled,
    )
}

fn unpack_mode(
    source: &Path,
    scratch: &Path,
    mode: crate::archive::WorkMode,
    cancelled: impl Fn() -> bool,
) -> Result<(), i32> {
    let dir = fs::symlink_metadata(scratch).map_err(|_| DISK)?;
    if !dir.is_dir() || fs::read_dir(scratch).map_err(|_| DISK)?.next().is_some() {
        return Err(DISK);
    }
    let open = || {
        OpenOptions::new()
            .read(true)
            .custom_flags(libc::O_NOFOLLOW)
            .open(source)
            .map_err(|_| DISK)
    };
    let fd = open()?;
    let meta = fd.metadata().map_err(|_| DISK)?;
    if !meta.is_file() || meta.len() > TOTAL + (8 << 20) {
        return Err(LIMIT);
    }
    let body = open()?;
    let other = body.metadata().map_err(|_| DISK)?;
    if (other.dev(), other.ino(), other.len()) != (meta.dev(), meta.ino(), meta.len()) {
        return Err(DISK);
    }
    let mut signature = [0u8; 4];
    let mut first = BufReader::new(fd);
    let n = first.read(&mut signature).map_err(|_| BAD)?;
    if !signature[..n].starts_with(b"PK\x03\x04") && !signature[..n].starts_with(b"PK\x05\x06") {
        return Err(BAD);
    }
    let mut zip = ZipIterable::try_new(first, Default::default())
        .map_err(|_| BAD)?
        .enforce_header_consistency(true);
    if zip.len() > 4096 {
        return Err(LIMIT);
    }
    let expected = zip.len();
    let mut files = zip
        .files_with_reader(
            BufReader::new(body),
            ZipReadOptions::new().enforce_header_consistency(true),
        )
        .map_err(|_| BAD)?;
    let mut list = Vec::new();
    let mut seen = HashSet::new();
    let mut leaf_keys = HashSet::new();
    let mut parent_keys = HashSet::new();
    let mut emitted = 0u64;
    let mut count = 0;
    let mut buf = vec![0u8; mode.buffer_size()];
    let mut pacing = crate::archive::Pacing::new(mode);
    while let Some(member) = files.next() {
        if cancelled() {
            return Err(CANCEL);
        }
        let mut member = member.map_err(|_| BAD)?;
        count += 1;
        let path = member.name().map_err(|_| PATH)?.into_owned();
        let dir = member.is_dir();
        let name = if dir {
            path.strip_suffix('/').ok_or(PATH)?
        } else {
            &path
        };
        let parts: Vec<_> = name.split('/').collect();
        if name.len() > 1536
            || parts.len() > 34
            || parts.iter().any(|p| {
                p.is_empty()
                    || *p == "."
                    || *p == ".."
                    || p.len() > 255
                    || p.contains('\\')
                    || p.chars().any(char::is_control)
            })
            || parts[0].as_bytes().get(1) == Some(&b':')
        {
            return Err(PATH);
        }
        let kind = member.unix_mode().unwrap_or(0) & 0o170000;
        if member.is_symlink()
            || !matches!(kind, 0 | 0o100000 | 0o040000)
            || (kind == 0o040000 && !dir)
        {
            return Err(PATH);
        }
        if parts.iter().any(|c| c.starts_with('.') || *c == "__MACOSX") {
            continue;
        }
        let key = crate::patch_create::canonical_key(name)?;
        if !seen.insert(key.clone()) || (!dir && parent_keys.contains(&key)) {
            return Err(PATH);
        }
        for (i, _) in key.match_indices('/') {
            if leaf_keys.contains(&key[..i]) {
                return Err(PATH);
            }
            parent_keys.insert(key[..i].to_owned());
        }
        if dir {
            continue;
        }
        leaf_keys.insert(key);
        let size = member.size();
        if list.len() >= 1024 || size > FILE_MAX || size > TOTAL - emitted {
            return Err(LIMIT);
        }
        let mut out = OpenOptions::new()
            .create_new(true)
            .write(true)
            .mode(0o600)
            .open(scratch.join(list.len().to_string()))
            .map_err(|_| DISK)?;
        let mut actual = 0u64;
        loop {
            if cancelled() {
                return Err(CANCEL);
            }
            let n = member.read(&mut buf).map_err(|_| BAD)?;
            if n == 0 {
                break;
            }
            actual += n as u64;
            if actual > size {
                return Err(BAD);
            }
            out.write_all(&buf[..n]).map_err(|_| DISK)?;
            pacing.processed(n);
        }
        if actual != size {
            return Err(BAD);
        }
        emitted += size;
        list.push((path, size));
    }
    if count != expected {
        return Err(BAD);
    }
    if list.is_empty() {
        return Err(EMPTY);
    }
    let manifest = File::create_new(scratch.join("members.json")).map_err(|_| DISK)?;
    serde_json::to_writer(manifest, &list).map_err(|_| DISK)
}

#[unsafe(no_mangle)]
pub unsafe extern "C" fn cc365_patch_extract_zip(
    source: *const c_char,
    scratch: *const c_char,
    cancelled: Option<extern "C" fn() -> bool>,
) -> i32 {
    if source.is_null() || scratch.is_null() {
        return BAD;
    }
    std::panic::catch_unwind(|| {
        let src = Path::new(std::ffi::OsStr::from_bytes(
            unsafe { CStr::from_ptr(source) }.to_bytes(),
        ));
        let tmp = Path::new(std::ffi::OsStr::from_bytes(
            unsafe { CStr::from_ptr(scratch) }.to_bytes(),
        ));
        unpack(src, tmp, || cancelled.is_some_and(|f| f()))
            .err()
            .unwrap_or(0)
    })
    .unwrap_or(BAD)
}

#[unsafe(no_mangle)]
pub unsafe extern "C" fn cc365_patch_extract_zip_with_mode(
    source: *const c_char,
    scratch: *const c_char,
    work_mode: i32,
    cancelled: Option<extern "C" fn() -> bool>,
) -> i32 {
    if source.is_null() || scratch.is_null() {
        return BAD;
    }
    std::panic::catch_unwind(|| {
        let mode = crate::archive::WorkMode::from_native(work_mode)?;
        let src = Path::new(std::ffi::OsStr::from_bytes(
            unsafe { CStr::from_ptr(source) }.to_bytes(),
        ));
        let tmp = Path::new(std::ffi::OsStr::from_bytes(
            unsafe { CStr::from_ptr(scratch) }.to_bytes(),
        ));
        unpack_mode(src, tmp, mode, || cancelled.is_some_and(|f| f()))
    })
    .unwrap_or(Err(BAD))
    .err()
    .unwrap_or(0)
}
