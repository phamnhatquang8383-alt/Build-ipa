use super::*;
use std::{
    cell::Cell,
    fs,
    os::unix::fs::{PermissionsExt, symlink},
};
use tempfile::{TempDir, tempdir};

struct Fixture {
    root: TempDir,
    manifest: PathBuf,
    output: PathBuf,
    source: PathBuf,
}
impl Fixture {
    fn new() -> Self {
        let root = tempdir().unwrap();
        let manifest = root.path().join("manifest.json");
        let output = root.path().join("patch.vailon");
        let source = root.path().join("payload");
        fs::write(&source, b"original\0bytes\xff").unwrap();
        Self {
            root,
            manifest,
            output,
            source,
        }
    }
    fn entries(&self, paths: &[&str]) {
        self.write(serde_json::json!({"entries": paths.iter().map(|p| serde_json::json!({"archive_path":p,"local_path":self.source})).collect::<Vec<_>>() }));
    }
    fn write(&self, value: Value) {
        fs::write(&self.manifest, value.to_string()).unwrap();
    }
    fn run(&self) -> Result<(), i32> {
        create(&self.manifest, &self.output, || false)
    }
    fn fails(&self, expected: i32) {
        assert_eq!(self.run(), Err(expected));
        assert!(!self.output.exists());
        assert_eq!(fs::read(&self.source).unwrap(), b"original\0bytes\xff");
    }
}
const DOC: &str = "Application/com.example.app/Documents/data.bin";

#[test]
fn creator_roundtrips_exact_unicode_paths_bytes_empty_file_and_mixed_destinations() {
    let f = Fixture::new();
    let empty = f.root.path().join("empty");
    fs::write(&empty, b"").unwrap();
    let paths = [DOC, "Application/com.example.app/Library/Caches/ảnh/zero"];
    f.write(serde_json::json!({"entries":[
        {"archive_path":paths[0],"local_path":f.source},
        {"archive_path":paths[1],"local_path":empty}], "name":"Patch thử", "author":"Local author"}));
    assert_eq!(f.run(), Ok(()));
    let extracted = f.root.path().join("extracted");
    fs::create_dir(&extracted).unwrap();
    let input = CString::new(f.output.as_os_str().as_bytes()).unwrap();
    let output = CString::new(extracted.as_os_str().as_bytes()).unwrap();
    assert_eq!(
        unsafe { crate::patch_zip::cc365_patch_extract_zip(input.as_ptr(), output.as_ptr(), None) },
        0
    );
    let members: Vec<(String, u64)> =
        serde_json::from_slice(&fs::read(extracted.join("members.json")).unwrap()).unwrap();
    assert_eq!(members, vec![(paths[0].into(), 15), (paths[1].into(), 0)]);
    assert_eq!(
        fs::read(extracted.join("0")).unwrap(),
        fs::read(&f.source).unwrap()
    );
    assert!(fs::read(extracted.join("1")).unwrap().is_empty());
    let zip = fs::read(&f.output).unwrap();
    let footer = zip.windows(4).rposition(|p| p == b"PK\x05\x06").unwrap();
    let comment: Value = serde_json::from_slice(&zip[footer + 22..]).unwrap();
    assert_eq!(comment["name"], "Patch thử");
    assert_eq!(comment["author"], "Local author");
    assert_eq!(fs::metadata(&f.output).unwrap().mode() & 0o777, 0o600);
}

#[test]
fn rejects_bad_roots_owners_traversal_and_hidden_paths() {
    for path in [
        "/Application/com.example.app/Documents/a",
        "Application//Documents/a",
        "Application/UUID/Documents/a",
        "Application/com.-bad/Documents/a",
        "Application/com.example.app/Library/Preferences/a",
        "Application/com.example.app/Documents",
        "Application/com.example.app/Library/Caches",
        "Application/com.example.app/Documents/../a",
        "Application/com.example.app/Documents/.secret",
        "Application/com.example.app/Documents/__MACOSX/a",
        "Application/com.example.app/Documents/a\\b",
        "Application/com.example.app/Documents/a\nb",
        "Application/com.example.app/Documents//a",
    ] {
        let f = Fixture::new();
        f.entries(&[path]);
        f.fails(PATH);
    }
    let f = Fixture::new();
    f.entries(&[DOC, "Application/com.other.app/Documents/a"]);
    f.fails(PATH);
}

#[test]
fn rejects_duplicate_case_unicode_and_file_ancestor_conflicts_in_both_orders() {
    for (a, b) in [
        ("a", "a"),
        ("a", "A"),
        ("é", "e\u{301}"),
        ("é", "e\u{301}/child"),
        ("a", "a/child"),
    ] {
        let one = format!("Application/com.example.app/Documents/{a}");
        let two = format!("Application/com.example.app/Documents/{b}");
        for paths in [[one.as_str(), two.as_str()], [two.as_str(), one.as_str()]] {
            let f = Fixture::new();
            f.entries(&paths);
            f.fails(PATH);
        }
    }
}

#[test]
fn rejects_symbolic_link_sources_and_parent_components() {
    let f = Fixture::new();
    let link = f.root.path().join("link");
    symlink(&f.source, &link).unwrap();
    f.write(serde_json::json!({"entries":[{"archive_path":DOC,"local_path":link}]}));
    f.fails(PATH);
    let linked_dir = f.root.path().join("linked-dir");
    symlink(f.root.path(), &linked_dir).unwrap();
    f.write(serde_json::json!({"entries":[{"archive_path":DOC,"local_path":linked_dir.join("payload")}]}));
    f.fails(PATH);
    f.entries(&[DOC]);
    assert_eq!(
        create(
            &linked_dir.join("manifest.json"),
            &linked_dir.join("other.zip"),
            || false
        ),
        Err(PATH)
    );
    let manifest_link = f.root.path().join("manifest-link");
    symlink(&f.manifest, &manifest_link).unwrap();
    assert_eq!(create(&manifest_link, &f.output, || false), Err(PATH));
}

#[test]
fn rejects_nonregular_sources_without_blocking() {
    let f = Fixture::new();
    let fifo = f.root.path().join("fifo");
    let name = CString::new(fifo.as_os_str().as_bytes()).unwrap();
    assert_eq!(unsafe { libc::mkfifo(name.as_ptr(), 0o600) }, 0);
    for source in [fifo, f.root.path().to_owned()] {
        f.write(serde_json::json!({"entries":[{"archive_path":DOC,"local_path":source}]}));
        f.fails(PATH);
    }
}

#[test]
fn own_files_export_without_listing_ancestor_directories() {
    let f = Fixture::new();
    let ancestor = f.root.path().join("search-only");
    let staging = ancestor.join("private-staging");
    fs::create_dir_all(&staging).unwrap();
    fs::set_permissions(&staging, fs::Permissions::from_mode(0o700)).unwrap();
    let manifest = staging.join("manifest.json");
    fs::write(
        &manifest,
        serde_json::json!({"entries":[{"archive_path":DOC,"local_path":f.source}]}).to_string(),
    )
    .unwrap();
    fs::set_permissions(&ancestor, fs::Permissions::from_mode(0o100)).unwrap();
    let result = create(&manifest, &staging.join("export.zip"), || false);
    fs::set_permissions(&ancestor, fs::Permissions::from_mode(0o700)).unwrap();
    assert_eq!(result, Ok(()));
    assert!(staging.join("export.zip").is_file());
}

#[test]
fn output_is_no_clobber_and_stays_in_manifest_private_directory() {
    let f = Fixture::new();
    f.entries(&[DOC]);
    fs::write(&f.output, b"previous export").unwrap();
    assert_eq!(f.run(), Err(DISK));
    assert_eq!(fs::read(&f.output).unwrap(), b"previous export");
    fs::remove_file(&f.output).unwrap();
    symlink(&f.source, &f.output).unwrap();
    assert_eq!(f.run(), Err(DISK));
    assert_eq!(fs::read(&f.source).unwrap(), b"original\0bytes\xff");
    fs::remove_file(&f.output).unwrap();
    let other = tempdir().unwrap();
    assert_eq!(
        create(&f.manifest, &other.path().join("elsewhere.zip"), || false),
        Err(PATH)
    );
    fs::set_permissions(f.root.path(), fs::Permissions::from_mode(0o777)).unwrap();
    assert_eq!(f.run(), Err(PATH));
}

#[test]
fn enforces_file_total_manifest_and_count_limits_before_output() {
    let f = Fixture::new();
    f.entries(&[DOC]);
    File::create(&f.source)
        .unwrap()
        .set_len(FILE_MAX + 1)
        .unwrap();
    assert_eq!(f.run(), Err(LIMIT));
    assert!(!f.output.exists());
    File::create(&f.source).unwrap().set_len(FILE_MAX).unwrap();
    f.entries(&[
        DOC,
        "Application/com.example.app/Documents/two",
        "Application/com.example.app/Documents/three",
    ]);
    assert_eq!(f.run(), Err(LIMIT));
    assert!(!f.output.exists());
    File::create(&f.source).unwrap().set_len(0).unwrap();
    let names: Vec<_> = (0..1025)
        .map(|i| format!("Application/com.example.app/Documents/{i}"))
        .collect();
    f.entries(&names.iter().map(String::as_str).collect::<Vec<_>>());
    assert_eq!(f.run(), Err(LIMIT));
    assert!(!f.output.exists());
    f.entries(&names[..1024].iter().map(String::as_str).collect::<Vec<_>>());
    assert_eq!(f.run(), Ok(()));
    fs::remove_file(&f.output).unwrap();
    File::create(&f.manifest)
        .unwrap()
        .set_len(MANIFEST_MAX + 1)
        .unwrap();
    assert_eq!(f.run(), Err(LIMIT));
    assert!(!f.output.exists());
}

#[test]
fn malformed_manifest_and_empty_sources_fail_without_output() {
    for value in [
        serde_json::json!({}),
        serde_json::json!([]),
        serde_json::json!({"entries":"wrong"}),
        serde_json::json!({"entries":[],"extra":true}),
        serde_json::json!({"entries":[{"archive_path":DOC,"local_path":42}]}),
        serde_json::json!({"entries":[{"archive_path":DOC,"local_path":"relative"}]}),
    ] {
        let f = Fixture::new();
        f.write(value);
        assert!(matches!(f.run(), Err(BAD | PATH)));
        assert!(!f.output.exists());
    }
    let f = Fixture::new();
    f.entries(&[]);
    f.fails(EMPTY);
    f.write(serde_json::json!({"entries":[{"archive_path":DOC,"local_path":f.source}],"name":"x".repeat(121)}));
    f.fails(BAD);
    assert_eq!(
        unsafe { cc365_create_patch_zip(std::ptr::null(), std::ptr::null(), None) },
        BAD
    );
}

#[test]
fn cancellation_during_copy_removes_partial_and_preserves_inputs() {
    let f = Fixture::new();
    f.entries(&[DOC]);
    let bytes = vec![b'x'; 512 << 10];
    fs::write(&f.source, &bytes).unwrap();
    let polls = Cell::new(0);
    assert_eq!(
        create(&f.manifest, &f.output, || {
            polls.set(polls.get() + 1);
            polls.get() >= 6
        }),
        Err(CANCEL)
    );
    assert!(!f.output.exists());
    assert_eq!(fs::read(&f.source).unwrap(), bytes);
    assert_eq!(create(&f.manifest, &f.output, || true), Err(CANCEL));
    assert!(!f.output.exists());
}

#[test]
fn detects_growth_and_source_replacement_after_preflight() {
    let f = Fixture::new();
    f.entries(&[DOC]);
    let polls = Cell::new(0);
    assert_eq!(
        create(&f.manifest, &f.output, || {
            polls.set(polls.get() + 1);
            if polls.get() == 4 {
                fs::write(&f.source, vec![b'y'; 128 << 10]).unwrap();
            }
            false
        }),
        Err(DISK)
    );
    assert!(!f.output.exists());
    let polls = Cell::new(0);
    assert_eq!(
        create(&f.manifest, &f.output, || {
            polls.set(polls.get() + 1);
            if polls.get() == 3 {
                fs::remove_file(&f.source).unwrap();
                fs::write(&f.source, b"replacement").unwrap();
            }
            false
        }),
        Err(DISK)
    );
    assert!(!f.output.exists());
}

#[test]
fn opaque_payload_bytes_roundtrip_through_patch_writer() {
    let f = Fixture::new();
    f.entries(&["Application/com.example.app/Documents/payload.blob"]);
    let bytes = b"OPAQUE\0binary\xffpayload";
    fs::write(&f.source, bytes).unwrap();
    assert_eq!(f.run(), Ok(()));
    let scratch = f.root.path().join("decoded");
    fs::create_dir(&scratch).unwrap();
    let input = CString::new(f.output.as_os_str().as_bytes()).unwrap();
    let output = CString::new(scratch.as_os_str().as_bytes()).unwrap();
    assert_eq!(
        unsafe { crate::patch_zip::cc365_patch_extract_zip(input.as_ptr(), output.as_ptr(), None) },
        0
    );
    assert_eq!(fs::read(scratch.join("0")).unwrap(), bytes);
}

#[test]
fn archive_writer_enforces_actual_output_bound() {
    let f = Fixture::new();
    let mut file = File::create(&f.output).unwrap();
    let exceeded = Cell::new(false);
    let mut writer = LimitedWriter {
        file: &mut file,
        position: 0,
        exceeded: &exceeded,
    };
    writer.seek(SeekFrom::Start(ARCHIVE_MAX - 1)).unwrap();
    writer.write_all(b"x").unwrap();
    assert!(writer.write_all(b"y").is_err());
    assert!(exceeded.get());
    assert_eq!(fs::metadata(&f.output).unwrap().len(), ARCHIVE_MAX);
}
