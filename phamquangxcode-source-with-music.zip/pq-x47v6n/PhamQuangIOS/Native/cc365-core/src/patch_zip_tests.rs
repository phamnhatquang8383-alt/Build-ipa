use super::*;
use flate2::Crc;
use std::{cell::Cell, io::Cursor, os::unix::fs::symlink};
use tempfile::tempdir;
use zip::{CompressionMethod, ZipWriter, write::SimpleFileOptions};

fn archive(names: &[(&str, &[u8])], method: CompressionMethod) -> Vec<u8> {
    let mut zip = ZipWriter::new(Cursor::new(Vec::new()));
    for &(name, bytes) in names {
        zip.start_file(
            name,
            SimpleFileOptions::default().compression_method(method),
        )
        .unwrap();
        zip.write_all(bytes).unwrap();
    }
    zip.finish().unwrap().into_inner()
}

fn check(bytes: &[u8], expected: Result<(), i32>) {
    let root = tempdir().unwrap();
    let source = root.path().join("pack.zip");
    fs::write(&source, bytes).unwrap();
    let scratch = root.path().join("scratch");
    fs::create_dir(&scratch).unwrap();
    let outside = root.path().join("outside");
    fs::write(&outside, b"unchanged").unwrap();
    assert_eq!(unpack(&source, &scratch, || false), expected);
    assert_eq!(scratch.join("members.json").exists(), expected.is_ok());
    assert_eq!(fs::read(outside).unwrap(), b"unchanged");
}

#[test]
fn rejects_traversal_absolute_paths_and_special_files() {
    for name in [
        "../outside",
        "sub/../../outside",
        "./file",
        "/private/file",
        "a//b",
        "C:/file",
        "sub\\outside",
        "dir/bad\nname",
    ] {
        check(
            &archive(&[(name, b"changed")], CompressionMethod::Stored),
            Err(PATH),
        );
    }
    let mut zip = ZipWriter::new(Cursor::new(Vec::new()));
    zip.add_symlink("link", "../outside", SimpleFileOptions::default())
        .unwrap();
    check(&zip.finish().unwrap().into_inner(), Err(PATH));
    let mut device = archive(&[("node", b"data")], CompressionMethod::Stored);
    let central = central_header(&device);
    device[central + 38..central + 42].copy_from_slice(&((0o020600u32) << 16).to_le_bytes());
    check(&device, Err(PATH));
}

#[test]
fn rejects_duplicate_files_and_file_directory_collisions_in_any_order() {
    for (first, second) in [("f", "F"), ("f", "F/child"), ("F/child", "f")] {
        check(
            &archive(&[(first, b"a"), (second, b"b")], CompressionMethod::Stored),
            Err(PATH),
        );
    }
    let mut dup = archive(&[("111", b"a"), ("222", b"b")], CompressionMethod::Stored);
    let offsets: Vec<_> = dup
        .windows(3)
        .enumerate()
        .filter_map(|(i, block)| (block == b"222").then_some(i))
        .collect();
    assert_eq!(offsets.len(), 2);
    for offset in offsets {
        dup[offset..offset + 3].copy_from_slice(b"111");
    }
    check(&dup, Err(PATH));
}

fn central_header(bytes: &[u8]) -> usize {
    bytes
        .windows(4)
        .rposition(|block| block == b"PK\x01\x02")
        .unwrap()
}

fn set_declared_size(bytes: &mut [u8], size: u32) {
    let central = central_header(bytes);
    bytes[22..26].copy_from_slice(&size.to_le_bytes());
    bytes[central + 24..central + 28].copy_from_slice(&size.to_le_bytes());
}

fn set_crc(bytes: &mut [u8], crc: u32) {
    let central = central_header(bytes);
    bytes[14..18].copy_from_slice(&crc.to_le_bytes());
    bytes[central + 16..central + 20].copy_from_slice(&crc.to_le_bytes());
}

#[test]
fn validates_crc_and_rejects_output_beyond_declared_size_even_with_valid_prefix_crc() {
    let original = b"123456789 and concealed extra output";
    let mut prefix = Crc::new();
    prefix.update(&original[..9]);
    for method in [CompressionMethod::Deflated, CompressionMethod::Stored] {
        let archive = archive(&[("file", original)], method);
        let mut wrong_crc = archive.clone();
        set_crc(&mut wrong_crc, 1);
        check(&wrong_crc, Err(BAD));
        let mut forged = archive;
        set_declared_size(&mut forged, 9);
        set_crc(&mut forged, prefix.sum());
        check(&forged, Err(BAD));
    }
}

#[test]
fn nonzip_input_fails_but_opaque_payloads_remain_ordinary_members() {
    check(b"not a ZIP archive", Err(BAD));
    let entries = [
        (
            "Application/app/Documents/data.blob",
            b"OPAQUE\0payload\xff".as_slice(),
        ),
        (
            "Application/app/Documents/config.unknown",
            b"another binary\0payload".as_slice(),
        ),
    ];
    let root = tempdir().unwrap();
    let source = root.path().join("pack.zip");
    let scratch = root.path().join("scratch");
    fs::write(&source, archive(&entries, CompressionMethod::Deflated)).unwrap();
    fs::create_dir(&scratch).unwrap();
    assert_eq!(unpack(&source, &scratch, || false), Ok(()));
    for (index, (_, bytes)) in entries.iter().enumerate() {
        assert_eq!(fs::read(scratch.join(index.to_string())).unwrap(), *bytes);
    }
}

#[test]
fn enforces_member_size_input_size_and_file_count_without_allocating_large_fixtures() {
    let mut forged = archive(&[("file", b"x")], CompressionMethod::Deflated);
    set_declared_size(&mut forged, (FILE_MAX + 1) as u32);
    check(&forged, Err(LIMIT));

    let root = tempdir().unwrap();
    let sparse = root.path().join("sparse.zip");
    let scratch = root.path().join("scratch");
    fs::create_dir(&scratch).unwrap();
    File::create(&sparse)
        .unwrap()
        .set_len(TOTAL + (8 << 20) + 1)
        .unwrap();
    assert_eq!(unpack(&sparse, &scratch, || false), Err(LIMIT));
    assert_eq!(fs::read_dir(&scratch).unwrap().count(), 0);

    let names: Vec<_> = (0..1025).map(|i| format!("member-{i}")).collect();
    let entries: Vec<_> = names.iter().map(|s| (s.as_str(), b"".as_slice())).collect();
    check(
        &archive(&entries[..1024], CompressionMethod::Stored),
        Ok(()),
    );
    check(&archive(&entries, CompressionMethod::Stored), Err(LIMIT));
}

#[test]
fn cancellation_has_no_committed_manifest_and_owned_scratch_is_disposable() {
    let root = tempdir().unwrap();
    let tmp = tempfile::tempdir_in(&root).unwrap();
    let scratch = tmp.path().to_owned();
    let source = root.path().join("pack.zip");
    let data = vec![b'x'; 512 << 10];
    let bytes = archive(
        &[("first", &data), ("second", b"small")],
        CompressionMethod::Deflated,
    );
    fs::write(&source, &bytes).unwrap();
    let polls = Cell::new(0);
    let cancelled = || {
        polls.set(polls.get() + 1);
        polls.get() == 4
    };
    assert_eq!(unpack(&source, &scratch, cancelled), Err(CANCEL));
    assert!(!scratch.join("members.json").exists());
    assert_eq!(fs::read(&source).unwrap(), bytes);
    drop(tmp);
    assert!(!scratch.exists());

    let elsewhere = root.path().join("real");
    fs::create_dir(&elsewhere).unwrap();
    let link = root.path().join("as-scratch");
    symlink(&elsewhere, &link).unwrap();
    assert_eq!(unpack(&source, &link, || false), Err(DISK));
    assert_eq!(fs::read_dir(&elsewhere).unwrap().count(), 0);
    fs::write(elsewhere.join("0"), b"existing").unwrap();
    assert_eq!(unpack(&source, &elsewhere, || false), Err(DISK));
    assert_eq!(fs::read(elsewhere.join("0")).unwrap(), b"existing");
}
