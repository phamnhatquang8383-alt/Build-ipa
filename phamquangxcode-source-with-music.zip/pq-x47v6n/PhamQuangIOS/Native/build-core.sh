#!/bin/bash
set -euo pipefail
native_dir="$(cd "$(dirname "$0")" && pwd)"
project_dir="$(cd "$native_dir/.." && pwd)"
manifest="$native_dir/cc365-core/Cargo.toml"
build_root="${CC365_RUST_BUILD_DIR:-$project_dir/build/rust}"
cargo_bin="${CC365_CARGO:-cargo}"
export CARGO_BUILD_JOBS="${CARGO_BUILD_JOBS:-4}"
case "${1:-ios}" in
  --test) CARGO_TARGET_DIR="$build_root/host" "$cargo_bin" test --locked --manifest-path "$manifest" ;;
  --host) CARGO_TARGET_DIR="$build_root/host" "$cargo_bin" build --locked --manifest-path "$manifest" ;;
  ios)
    export IPHONEOS_DEPLOYMENT_TARGET=16.0
    CARGO_TARGET_DIR="$build_root/app-ios16" "$cargo_bin" build --locked --release --target aarch64-apple-ios --manifest-path "$manifest"
    archive="$build_root/app-ios16/aarch64-apple-ios/release/libcc365_core.a"
    xcrun lipo "$archive" -verify_arch arm64
    install -m 644 "$archive" "$project_dir/Vendor/cc365/libcc365_core.a.new"
    mv "$project_dir/Vendor/cc365/libcc365_core.a.new" "$project_dir/Vendor/cc365/libcc365_core.a"
    ;;
  *) echo 'Usage: Native/build-core.sh [--test|--host]' >&2; exit 2 ;;
esac
