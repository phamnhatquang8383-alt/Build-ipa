
mod airlift;
mod airlift_wire;
mod atc;
mod bounded_afc;
pub(crate) mod files;
pub(crate) mod patch;
use crate::{
    storage,
    sync::{SyncControl, SyncError},
};
pub use atc::NativeAtcChannel;
use idevice::{
    IdeviceError, RsdService,
    afc::{AfcClient, opcode::AfcFopenMode},
    lockdown::LockdownClient,
    remote_pairing::{
        RemotePairingClient, RpPairingFile, RpPairingSocket, connect_tls_psk_tunnel_native,
    },
    rsd::RsdHandshake,
    tcp::{adapter::Adapter, handle::AdapterHandle},
};

use std::{future::Future, net::IpAddr, path::Path, time::Duration};
use tokio::net::TcpStream;

const IO_TIMEOUT: Duration = Duration::from_secs(20);
const CONNECT_TIMEOUT: Duration = Duration::from_secs(60);
async fn native<T>(
    control: &SyncControl,
    timeout: Duration,
    operation: &'static str,
    future: impl Future<Output = Result<T, IdeviceError>>,
) -> Result<T, SyncError> {
    control.check()?;
    let future = tokio::time::timeout(timeout, future);
    tokio::pin!(future);
    loop {
        tokio::select! {
            result = &mut future => {
                let result = match result {
                    Ok(Ok(value)) => Ok(value),
                    Ok(Err(error)) => Err(SyncError::Native { operation, code: error.code() as u32 }),
                    Err(_) => Err(SyncError::TimedOut),
                };
                if let Err(error) = &result { control.log(&format!("{operation}: {error}")); }
                return result;
            }
            _ = tokio::time::sleep(Duration::from_millis(100)) => { control.check()?; }
        }
    }
}

async fn connect_stage<T>(
    control: &SyncControl,
    deadline: tokio::time::Instant,
    stage_timeout: Duration,
    stage: &'static str,
    operation: &'static str,
    future: impl Future<Output = Result<T, IdeviceError>>,
) -> Result<T, SyncError> {
    control.log(&format!("{operation}: starting."));
    let result = match deadline.checked_duration_since(tokio::time::Instant::now()) {
        Some(remaining) if !remaining.is_zero() => {
            native(control, stage_timeout.min(remaining), operation, future).await
        }
        _ => control.check().and(Err(SyncError::TimedOut)),
    };
    match &result {
        Ok(_) => control.log(&format!("{operation}: completed.")),
        Err(error) => control.log(&format!("{operation}: stopped ({error})")),
    }
    result.map_err(|cause| match cause {
        SyncError::Cancelled => SyncError::Cancelled,
        cause => SyncError::Connection {
            stage,
            cause: Box::new(cause),
        },
    })
}

fn invalid(message: &'static str) -> IdeviceError {
    IdeviceError::UnexpectedResponse(message.into())
}

pub struct DeviceSession {
    connection: Connection,
    control: SyncControl,
    pairing_file: Option<std::fs::File>,
    pairing_path: std::path::PathBuf,
}

impl DeviceSession {
    pub async fn connect(
        path: &Path,
        host: &str,
        port: u16,
        control: SyncControl,
    ) -> Result<Self, SyncError> {
        control.check()?;
        let address = crate::endpoint::numeric_host(host.trim())
            .and_then(|address| address.socket_address(port))
            .ok_or(SyncError::InvalidData(
                "numeric device address, scope or port",
            ))?;
        let (opened, original) = storage::open_pairing_session(path)
            .map_err(|_| SyncError::InvalidData("pairing file could not be read"))?;
        if storage::is_lockdown(&original) {
            return Self::connect_lockdown(path, opened, &original, control).await;
        }
        let mut pairing = RpPairingFile::from_bytes(&original)
            .map_err(|_| SyncError::InvalidData("pairing file could not be decoded"))?;
        control.log("Opening Remote Pairing tunnel…");
        let deadline = tokio::time::Instant::now() + CONNECT_TIMEOUT;
        let xpc = if port == 49152 {
            Some(remote_xpc_tunnel(address, &mut pairing, &control, deadline).await)
        } else {
            None
        };
        let result: Result<_, SyncError> = match xpc {
            Some(Ok(connected)) => Ok(connected),
            _ => {
                async {
                    let stream = connect_stage(
                        &control,
                        deadline,
                        Duration::from_secs(10),
                        "control_tcp",
                        "Remote Pairing control TCP",
                        async { Ok(TcpStream::connect(address).await?) },
                    )
                    .await?;
                    let mut rpc =
                        RemotePairingClient::new(RpPairingSocket::new(stream), "CC365-Apps");
                    connect_stage(
                        &control,
                        deadline,
                        Duration::from_secs(15),
                        "authentication",
                        "Remote Pairing authentication",
                        rpc.connect(&mut pairing, async || "000000".to_string()),
                    )
                    .await?;
                    let tunnel_port = connect_stage(
                        &control,
                        deadline,
                        Duration::from_secs(10),
                        "listener_request",
                        "Remote Pairing listener request",
                        rpc.create_tcp_listener(),
                    )
                    .await?;
                    let mut tunnel_address = address;
                    tunnel_address.set_port(tunnel_port);
                    let stream = connect_stage(
                        &control,
                        deadline,
                        Duration::from_secs(10),
                        "tunnel_tcp",
                        "Remote Pairing tunnel TCP",
                        async { Ok(TcpStream::connect(tunnel_address).await?) },
                    )
                    .await?;
                    let tunnel = connect_stage(
                        &control,
                        deadline,
                        Duration::from_secs(15),
                        "tls_handshake",
                        "Remote Pairing TLS handshake",
                        connect_tls_psk_tunnel_native(stream, rpc.encryption_key()),
                    )
                    .await?;
                    connect_stage(
                        &control,
                        deadline,
                        Duration::from_secs(15),
                        "rsd_handshake",
                        "Remote Pairing RSD handshake",
                        async {
                            let client_ip: IpAddr = tunnel.info.client_address.parse()?;
                            let server_ip: IpAddr = tunnel.info.server_address.parse()?;
                            let mtu = (tunnel.info.mtu as usize).min(8192);
                            if mtu <= 60 {
                                return Err(invalid("invalid tunnel MTU"));
                            }
                            let rsd_port = tunnel.info.server_rsd_port;
                            let mut adapter =
                                Adapter::new(Box::new(tunnel.into_inner()), client_ip, server_ip);
                            adapter.set_mss(mtu - 60);
                            let mut adapter = adapter.to_async_handle();
                            let handshake =
                                RsdHandshake::new(adapter.connect(rsd_port).await?).await?;
                            Ok((adapter, handshake))
                        },
                    )
                    .await
                }
                .await
            }
        };
        let mut warnings: Vec<String> = Vec::new();
        let updated = pairing.to_bytes();
        let pairing_file = match storage::finish_pairing_handshake(
            path, &opened, &original, &updated,
        ) {
            Ok(Some(file)) => Some(file),
            Ok(None) => {
                warnings.push("Pairing changed or was deleted during this session; the newer state was preserved.".into());
                None
            }
            Err(_) => {
                warnings.push("The active pairing record could not be confirmed.".into());
                None
            }
        };
        for warning in &warnings {
            control.log(warning);
        }
        let (mut adapter, handshake) = result?;
        control.check()?;
        if pairing_file.is_none() {
            let _ = tokio::time::timeout(Duration::from_secs(2), adapter.close()).await;
            return Err(SyncError::InvalidData(
                "pairing changed during authentication",
            ));
        }
        control.log("Remote Pairing + RSD connected.");
        Ok(Self {
            connection: Connection::Rsd { adapter, handshake },
            control,
            pairing_file,
            pairing_path: path.into(),
        })
    }

    pub async fn close(mut self) {
        if let Connection::Rsd { adapter, .. } = &mut self.connection {
            let _ = adapter.close().await;
        }
    }
}

use idevice::{
    Idevice, IdeviceService, ReadWrite,
    pairing_file::PairingFile,
    provider::{IdeviceProvider, TcpProvider},
};
enum Connection {
    Rsd {
        adapter: AdapterHandle,
        handshake: RsdHandshake,
    },
    Lockdown {
        provider: TcpProvider,
    },
}
impl DeviceSession {
    async fn connect_lockdown(
        path: &Path,
        opened: std::fs::File,
        bytes: &[u8],
        control: SyncControl,
    ) -> Result<Self, SyncError> {
        let pairing = PairingFile::from_bytes(bytes)
            .map_err(|_| SyncError::InvalidData("Lockdown certificates or keys"))?;
        let provider = TcpProvider {
            addr: "10.7.0.1".parse().unwrap(),
            scope_id: None,
            pairing_file: pairing,
            label: "Viet99".into(),
        };
        let mut client = native(
            &control,
            Duration::from_secs(10),
            "Lockdown TCP",
            LockdownClient::connect(&provider),
        )
        .await?;
        native(
            &control,
            Duration::from_secs(20),
            "Lockdown authentication",
            client.start_session(&provider.pairing_file),
        )
        .await?;
        if let Some(expected) = provider.pairing_file.udid.as_deref() {
            let observed = native(
                &control,
                IO_TIMEOUT,
                "Lockdown identity",
                client.get_value(Some("UniqueDeviceID"), None),
            )
            .await?;
            if observed.as_string() != Some(expected) {
                return Err(SyncError::InvalidData("pairing device identity mismatch"));
            }
        }
        let _ = tokio::time::timeout(Duration::from_secs(2), client.shutdown()).await;
        let pairing_file = storage::finish_pairing_handshake(path, &opened, bytes, bytes)
            .map_err(|_| SyncError::InvalidData("pairing changed during authentication"))?
            .ok_or(SyncError::InvalidData(
                "pairing changed during authentication",
            ))?;
        control.check()?;
        Ok(Self {
            connection: Connection::Lockdown { provider },
            control,
            pairing_file: Some(pairing_file),
            pairing_path: path.into(),
        })
    }
    async fn service(&mut self, name: &'static str) -> Result<Box<dyn ReadWrite>, IdeviceError> {
        match &mut self.connection {
            Connection::Rsd { adapter, handshake } => {
                let shim = format!("{name}.shim.remote");
                let service = handshake
                    .services
                    .get(&shim)
                    .filter(|s| s.port != 0 && !s.uses_remote_xpc)
                    .ok_or_else(|| invalid("Required RSD service unavailable"))?;
                let mut stream: Box<dyn ReadWrite> = Box::new(adapter.connect(service.port).await?);
                atc::checkin(&mut *stream).await?;
                Ok(stream)
            }
            Connection::Lockdown { provider } => {
                let mut client = LockdownClient::connect(provider).await?;
                let legacy = client.start_session(&provider.pairing_file).await?;
                let (port, ssl) = client.start_service(name).await?;
                if port == 0 {
                    return Err(invalid("Invalid service port"));
                }
                let mut stream = provider.connect(port).await?;
                if ssl {
                    stream.start_session(&provider.pairing_file, legacy).await?;
                }
                client.shutdown().await?;
                stream
                    .get_socket()
                    .ok_or_else(|| invalid("Service socket unavailable"))
            }
        }
    }
    async fn afc(&mut self) -> Result<AfcClient, IdeviceError> {
        Ok(AfcClient::new(Idevice::new(
            bounded_afc::BoundedAfc::wrap(self.service("com.apple.afc").await?),
            "Viet99",
        )))
    }
    async fn lockdown(&mut self) -> Result<LockdownClient, IdeviceError> {
        match &mut self.connection {
            Connection::Rsd { adapter, handshake } => {
                LockdownClient::connect_rsd(adapter, handshake).await
            }
            Connection::Lockdown { provider } => {
                let mut client = LockdownClient::connect(provider).await?;
                client.start_session(&provider.pairing_file).await?;
                Ok(client)
            }
        }
    }
    async fn atc(&mut self) -> Result<NativeAtcChannel, SyncError> {
        let ctl = self.control.clone();
        let stream = native(
            &ctl,
            IO_TIMEOUT,
            "AirTraffic service",
            self.service("com.apple.atc"),
        )
        .await?;
        Ok(NativeAtcChannel::from_stream(stream, ctl))
    }
    pub(crate) async fn probe(&mut self, expected_os: &str) -> Result<serde_json::Value, String> {
        let ctl = self.control.clone();
        let mut ld = native(&ctl, IO_TIMEOUT, "Device identity", self.lockdown())
            .await
            .map_err(|e| e.to_string())?;
        let version = native(
            &ctl,
            IO_TIMEOUT,
            "Device version",
            ld.get_value(Some("ProductVersion"), None),
        )
        .await
        .map_err(|e| e.to_string())?;
        let build = native(
            &ctl,
            IO_TIMEOUT,
            "Device build",
            ld.get_value(Some("BuildVersion"), None),
        )
        .await
        .map_err(|e| e.to_string())?;
        let udid = native(
            &ctl,
            IO_TIMEOUT,
            "Device identity",
            ld.get_value(Some("UniqueDeviceID"), None),
        )
        .await
        .map_err(|e| e.to_string())?;
        let version = version
            .as_string()
            .ok_or("Không xác định được phiên bản iPhone.")?;
        let build = build
            .as_string()
            .ok_or("Không xác định được bản dựng iPhone.")?;
        let id = udid
            .as_string()
            .filter(|s| {
                (8..=64).contains(&s.len())
                    && s.bytes().all(|c| c.is_ascii_alphanumeric() || c == b'-')
            })
            .ok_or("Không xác định được iPhone.")?;
        if version != expected_os {
            return Err("Phiên bản thiết bị ghép nối không khớp iPhone này. Hãy kiểm tra pairing và VPN nội bộ.".into());
        }
        if !supported_os(version, build) {
            return Err("AirLift chỉ được bật cho iOS 18.7.2–18.8.x trong nhánh này.".into());
        }
        Ok(
            serde_json::json!({"connected":true,"experimental":true,"udid":id,"os_version":version,"build":build,
            "message":"Đã xác thực pairing và đọc được danh sách ứng dụng. AirLift thử nghiệm; mỗi patch vẫn phải xác nhận sao lưu, ghi và dọn dẹp."}),
        )
    }
}
fn supported_os(version: &str, _build: &str) -> bool {
    let values: Option<Vec<u32>> = version
        .split('.')
        .map(|s| {
            if s.is_empty() {
                None
            } else {
                s.parse::<u32>().ok()
            }
        })
        .collect();
    match values.as_deref() {
        Some([18, 7, patch]) if *patch >= 2 => true,
        Some([18, 8]) | Some([18, 8, _]) => true,
        _ => false,
    }
}

impl DeviceSession {
    pub(crate) async fn selected_app(&mut self, bundle: &str) -> Result<serde_json::Value, String> {
        if !crate::identity::valid_bundle(bundle) {
            return Err("Bundle ID không hợp lệ.".into());
        }
        let mut rows = self.lookup_patch_apps(Some(bundle)).await?;
        if rows.len() != 1 {
            return Err("Không xác nhận được đúng ứng dụng từ iPhone.".into());
        }
        let mut row =
            serde_json::to_value(rows.remove(0)).map_err(|_| "Không đọc được ứng dụng.")?;
        if let Some(path) = row["data_path"].as_str() {
            row["target_id"] = serde_json::json!(format!("path:{path}"));
        }
        Ok(row)
    }
    pub(crate) async fn verify_own_app(&mut self, bundle: &str, home: &str) -> Result<(), String> {
        let app = self.selected_app(bundle).await?;
        let canonical = |s: &str| {
            s.strip_prefix("/private")
                .unwrap_or(s)
                .trim_end_matches('/')
                .to_owned()
        };
        if app["data_path"].as_str().map(canonical) != Some(canonical(home)) {
            return Err("Pairing/VPN không trỏ tới bản Viet99 đang chạy trên iPhone này.".into());
        }
        Ok(())
    }
    pub(crate) async fn browse(
        &mut self,
        action: &str,
        path: &str,
        offset: usize,
        local: Option<&Path>,
        options: &files::ListOptions,
    ) -> Result<serde_json::Value, String> {
        use serde_json::json;
        if !matches!(action, "list" | "download" | "details") {
            return Err("Nhánh AirLift chỉ duyệt và xuất qua AFC/HouseArrest; hãy dùng Patch để ghi có sao lưu. Vùng làm việc Viet99 vẫn dùng bộ nhớ cục bộ.".into());
        }
        if !path.starts_with('/')
            || path.len() > 4096
            || path.split('/').skip(1).any(|p| {
                p == "." || p == ".." || p.contains('\\') || p.chars().any(char::is_control)
            })
        {
            return Err("Đường dẫn không hợp lệ.".into());
        }
        let apps = self.patch_apps().await?;
        if action == "list" && matches!(path, "/" | "/var/mobile/Containers/Data/Application") {
            let mut entries = Vec::new();
            if path == "/" {
                entries.push(json!({"name":"Media","display_name":"Media · AFC","kind":"directory","path":"/var/mobile/Media"}));
            }
            for app in apps {
                if let Some(p) = app.data_path {
                    entries.push(json!({"name":p.rsplit('/').next().unwrap_or(""),"display_name":app.name,"subtitle":app.bundle_id,"kind":"directory","path":p}));
                }
            }
            let mut page = files::page(entries, offset, options)?;
            page["notice"] = json!(
                "AirLift chỉ mở được các thư mục được AFC/HouseArrest cho phép; danh sách ứng dụng không có nghĩa mọi tệp đều đọc được."
            );
            return Ok(page);
        }
        let ctl = self.control.clone();
        let (mut afc, relative, base) = if path == "/var/mobile/Media"
            || path.starts_with("/var/mobile/Media/")
        {
            (
                native(&ctl, IO_TIMEOUT, "AFC", self.afc())
                    .await
                    .map_err(|_| "Không mở được Media qua AFC.")?,
                path.strip_prefix("/var/mobile/Media")
                    .filter(|s| !s.is_empty())
                    .unwrap_or("/")
                    .to_string(),
                "/var/mobile/Media".to_string(),
            )
        } else {
            let app=apps.into_iter().find(|a|a.data_path.as_deref().is_some_and(|root|path==root||path.strip_prefix(root).is_some_and(|r|r.starts_with('/')))).ok_or("Đường dẫn này không thuộc container đã được iPhone xác nhận; AirLift không duyệt root tùy ý.")?;
            let root = app.data_path.as_deref().unwrap();
            let relative = path
                .strip_prefix(root)
                .filter(|s| !s.is_empty())
                .unwrap_or("/");
            if let Some(afc) = self
                .patch_house_arrest_reader(&app.bundle_id, "VendContainer")
                .await?
            {
                (afc, relative.to_owned(), root.to_owned())
            } else if relative == "/Documents" || relative.starts_with("/Documents/") {
                let afc = self
                    .patch_house_arrest_reader(&app.bundle_id, "VendDocuments")
                    .await?
                    .ok_or("iOS không cho đọc Documents của ứng dụng này qua HouseArrest.")?;
                (
                    afc,
                    relative
                        .strip_prefix("/Documents")
                        .filter(|s| !s.is_empty())
                        .unwrap_or("/")
                        .to_owned(),
                    format!("{root}/Documents"),
                )
            } else {
                return Err("iOS không cho duyệt container này qua HouseArrest; khả năng ghi patch được kiểm tra riêng khi áp dụng.".into());
            }
        };
        if action == "download" {
            return files::export(
                &mut afc,
                &ctl,
                &relative,
                local.ok_or("Thiếu nơi lưu tệp.")?,
            )
            .await;
        }
        if action == "details" {
            return files::details(&mut afc, &ctl, &relative, path).await;
        }
        let mut result = files::browse_list(&mut afc, &ctl, &relative, offset, options).await?;
        if let Some(entries) = result["entries"].as_array_mut() {
            for entry in entries {
                if let Some(name) = entry["name"].as_str() {
                    entry["path"] = json!(format!(
                        "{}{}/{}",
                        base,
                        relative.trim_end_matches('/'),
                        name
                    ));
                }
            }
        }
        Ok(result)
    }
}

#[cfg(test)]
mod legacy_policy_tests {
    use super::*;
    #[test]
    fn compatibility_is_explicit_and_does_not_claim_every_ios18_build() {
        for v in ["18.7.2", "18.7.3", "18.8", "18.8.0", "18.8.5"] {
            assert!(supported_os(v, "fixture"), "{v}")
        }
        for v in [
            "16.7", "18.7.1", "18.7", "18.9", "19.0", "18.8.bad", "18.8.1.1", "",
        ] {
            assert!(!supported_os(v, "fixture"), "{v}")
        }
        assert!(!supported_os("27.0", "24A437"));
        assert!(!supported_os("27.0", "other"));
    }
}

async fn remote_xpc_tunnel(
    address: std::net::SocketAddr,
    pairing: &mut RpPairingFile,
    control: &SyncControl,
    deadline: tokio::time::Instant,
) -> Result<(AdapterHandle, RsdHandshake), SyncError> {
    use idevice::RemoteXpcClient;
    let xpc = connect_stage(
        control,
        deadline,
        Duration::from_secs(12),
        "rsd_discovery",
        "Remote Pairing RSD discovery",
        async {
            let handshake = RsdHandshake::new(TcpStream::connect(address).await?).await?;
            let service = handshake
                .services
                .get("com.apple.internal.dt.coredevice.untrusted.tunnelservice")
                .filter(|s| s.port != 0)
                .ok_or_else(|| invalid("Remote Pairing tunnel service missing"))?;
            let endpoint = std::net::SocketAddr::new(address.ip(), service.port);
            let mut xpc = RemoteXpcClient::new(TcpStream::connect(endpoint).await?).await?;
            xpc.do_handshake().await?;
            let _ = xpc.recv_root().await?;
            Ok(xpc)
        },
    )
    .await?;
    let mut rpc = RemotePairingClient::new(xpc, "Viet99");
    connect_stage(
        control,
        deadline,
        Duration::from_secs(15),
        "authentication",
        "Remote Pairing authentication",
        rpc.connect(pairing, async || "000000".into()),
    )
    .await?;
    let port = connect_stage(
        control,
        deadline,
        Duration::from_secs(10),
        "listener_request",
        "Remote Pairing listener request",
        rpc.create_tcp_listener(),
    )
    .await?;
    let stream = connect_stage(
        control,
        deadline,
        Duration::from_secs(10),
        "tunnel_tcp",
        "Remote Pairing tunnel TCP",
        async { Ok(TcpStream::connect(std::net::SocketAddr::new(address.ip(), port)).await?) },
    )
    .await?;
    let tunnel = connect_stage(
        control,
        deadline,
        Duration::from_secs(15),
        "tls_handshake",
        "Remote Pairing TLS handshake",
        connect_tls_psk_tunnel_native(stream, rpc.encryption_key()),
    )
    .await?;
    connect_stage(
        control,
        deadline,
        Duration::from_secs(15),
        "rsd_handshake",
        "Remote Pairing RSD handshake",
        async {
            let client: IpAddr = tunnel.info.client_address.parse()?;
            let server: IpAddr = tunnel.info.server_address.parse()?;
            let mtu = (tunnel.info.mtu as usize).min(8192);
            if mtu <= 60 {
                return Err(invalid("Invalid tunnel MTU"));
            }
            let port = tunnel.info.server_rsd_port;
            let mut adapter = Adapter::new(Box::new(tunnel.into_inner()), client, server);
            adapter.set_mss(mtu - 60);
            let mut adapter = adapter.to_async_handle();
            let handshake = RsdHandshake::new(adapter.connect(port).await?).await?;
            Ok((adapter, handshake))
        },
    )
    .await
}
