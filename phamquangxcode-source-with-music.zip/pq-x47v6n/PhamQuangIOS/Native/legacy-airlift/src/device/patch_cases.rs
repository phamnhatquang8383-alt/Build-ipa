use super::*;
use idevice::{
    Idevice,
    afc::{
        AfcClient, MAGIC,
        opcode::{AfcFopenMode, AfcOpcode},
    },
};
use std::{
    os::unix::fs::MetadataExt,
    sync::{Arc, atomic::AtomicBool},
};
use tempfile::TempDir;
use tokio::io::{AsyncReadExt, AsyncWriteExt};

#[test]
fn patch_job_blocks_other_receipt_access_until_the_job_ends() {
    let active = begin_patch_job().unwrap();
    assert_eq!(begin_patch_job().unwrap_err(), PATCH_BUSY);
    drop(active);
    assert!(begin_patch_job().is_ok());
}

pub(super) fn afc(root: PathBuf) -> AfcClient {
    afc_timed(root, Duration::ZERO, None)
}
pub(super) fn afc_timed(
    root: PathBuf,
    latency: Duration,
    mut first_request: Option<Arc<tokio::sync::Barrier>>,
) -> AfcClient {
    let (client, mut socket) = tokio::io::duplex(256 * 1024);
    tokio::spawn(async move {
        let mut open: Option<File> = None;
        while let Ok(magic) = socket.read_u64_le().await {
            assert_eq!(magic, MAGIC);
            if let Some(gate) = first_request.take() {
                gate.wait().await;
            }
            if !latency.is_zero() {
                tokio::time::sleep(latency).await;
            }
            let len = socket.read_u64_le().await.unwrap();
            let _header = socket.read_u64_le().await.unwrap();
            let sequence = socket.read_u64_le().await.unwrap();
            let op = AfcOpcode::try_from(socket.read_u64_le().await.unwrap()).unwrap();
            let mut b = vec![0; len as usize - 40];
            socket.read_exact(&mut b).await.unwrap();
            let path = |input: &[u8]| {
                let absolute = std::str::from_utf8(input).unwrap().trim_end_matches('\0');
                assert!(absolute.starts_with('/') && !absolute.split('/').any(|s| s == ".."));
                root.join(absolute.trim_start_matches('/'))
            };
            let mut hdr = Vec::new();
            let mut data = Vec::new();
            let mut answer = AfcOpcode::Status;
            let mut code = 0u64;
            match op {
                AfcOpcode::GetFileInfo => {
                    let name = path(&b);
                    if let Ok(meta) = fs::symlink_metadata(&name) {
                        answer = AfcOpcode::Data;
                        let anchor = name == root.join("link");
                        let kind = if anchor || meta.file_type().is_symlink() {
                            "S_IFLNK"
                        } else if meta.is_file() {
                            "S_IFREG"
                        } else {
                            "S_IFDIR"
                        };
                        data=format!("st_ifmt\0{kind}\0st_size\0{}\0st_nlink\0{}\0st_ino\042\0st_birthtime\01\0",meta.len(),meta.nlink()).into_bytes();
                        if anchor {
                            data.extend_from_slice(b"LinkTarget\0/fixture\0");
                        }
                    } else {
                        code = 8
                    }
                }
                AfcOpcode::FileOpen if path(&b[8..]).ends_with("preflight-offline.bin") => {
                    code = idevice::afc::errors::AfcError::ServiceNotConnected as u64;
                }
                AfcOpcode::FileOpen if path(&b[8..]).ends_with("denied.bin") => {
                    code = idevice::afc::errors::AfcError::PermDenied as u64;
                }
                AfcOpcode::FileOpen => {
                    let mode = u64::from_le_bytes(b[..8].try_into().unwrap());
                    open = Some(if mode == AfcFopenMode::RdOnly as u64 {
                        File::open(path(&b[8..])).unwrap()
                    } else {
                        File::create_new(path(&b[8..])).unwrap()
                    });
                    answer = AfcOpcode::FileOpenRes;
                    hdr.extend(1u64.to_le_bytes());
                }
                AfcOpcode::FileClose => {
                    open.take();
                }
                AfcOpcode::Read => {
                    let requested = u64::from_le_bytes(b[8..].try_into().unwrap());
                    assert!(requested <= 16 * 1024);
                    data.resize(requested as usize, 0);
                    let n = open.as_mut().unwrap().read(&mut data).unwrap();
                    data.truncate(n);
                    answer = AfcOpcode::Data;
                }
                AfcOpcode::Write => {
                    assert!(b.len() <= 64 * 1024 + 8);
                    open.as_mut().unwrap().write_all(&b[8..]).unwrap();
                }
                AfcOpcode::RenamePath => {
                    let mut parts = b.split(|c| *c == 0);
                    fs::rename(path(parts.next().unwrap()), path(parts.next().unwrap())).unwrap();
                }
                AfcOpcode::RemovePath => fs::remove_file(path(&b)).unwrap(),
                AfcOpcode::GetFileHash if path(&b).ends_with("stage-hash-denied.bin") => {
                    code = idevice::afc::errors::AfcError::PermDenied as u64;
                }
                AfcOpcode::GetFileHash if path(&b).ends_with("stage-changed.bin") => {
                    fs::write(path(&b), b"foreign").unwrap();
                    code = idevice::afc::errors::AfcError::PermDenied as u64;
                }
                AfcOpcode::GetFileHash if path(&b).ends_with("stage-offline.bin") => {
                    code = idevice::afc::errors::AfcError::ServiceNotConnected as u64;
                }
                AfcOpcode::GetFileHash => {
                    use sha1::Sha1;
                    answer = AfcOpcode::Data;
                    data = Sha1::digest(fs::read(path(&b)).unwrap()).to_vec();
                }
                _ => panic!("Unexpected fixture opcode {op:?}"),
            }
            if answer == AfcOpcode::Status {
                hdr.extend(code.to_le_bytes());
            }
            for u in [
                MAGIC,
                (40 + hdr.len() + data.len()) as u64,
                (40 + hdr.len()) as u64,
                sequence,
                answer as u64,
            ] {
                socket.write_u64_le(u).await.unwrap();
            }
            socket.write_all(&hdr).await.unwrap();
            socket.write_all(&data).await.unwrap();
        }
    });
    AfcClient::new(Idevice::new(Box::new(client), "patch fixture"))
}
pub(super) fn control() -> SyncControl {
    SyncControl::new(Arc::new(AtomicBool::new(false)), Arc::new(|_| {}))
}
fn stamp(b: &[u8]) -> Stamp {
    io::local_copy(b, std::io::sink()).unwrap()
}

#[test]
fn rejects_absolute_traversal_and_signed_code_paths() {
    for s in [
        "../a",
        "/a",
        "a//b",
        "a/../b",
        "a/",
        "_a/./b",
        ".cc365-patch-id",
        "x\\y",
        "a\u{0000}b",
    ] {
        assert!(!relative_ok(s), "{s}")
    }
    for s in [
        "_CodeSignature/CodeResources",
        "Info.plist",
        "Frameworks/Kit.framework/res",
        "PlugIns/Extension.appex/asset",
        "Example",
        "other.dylib",
    ] {
        assert!(!bundle_resource(s, Some("Example")), "{s}");
    }
    assert!(relative_ok("Documents/Tiếng Việt.txt"));
}

#[tokio::test]
async fn recovery_after_publish_before_ack_preserves_edits_and_is_idempotent() {
    let device = TempDir::new().unwrap();
    let local = TempDir::new().unwrap();
    fs::create_dir_all(device.path().join("link/Example.app")).unwrap();
    let target = device.path().join("link/Example.app/artwork.png");
    let old = vec![0x2a; 21_000];
    let new = vec![0x88; 91_034];
    fs::write(&target, &old).unwrap();
    let slot = local.path().join("transaction");
    directory(&slot).unwrap();
    fs::write(artifact(&slot, 0, true), &old).unwrap();
    fs::write(artifact(&slot, 0, false), &new).unwrap();
    let mut link = PatchLink::fixture(afc(device.path().into())).await;
    let ctl = control();
    let j = Journal {
        identity: link.identity.clone(),
        token: token(),
        state: "pending".into(),
        armed: 1,
        skipped: 0,
        omitted_items: vec![],
        entries: vec![Entry {
            rel: "artwork.png".into(),
            original: Some(stamp(&old)),
            replacement: stamp(&new),
        }],
    };
    save(&slot, &j).unwrap();
    fs::write(&target, &new).unwrap();
    let mut recovered = load(&slot).unwrap().unwrap();
    fs::write(&target, b"external edit").unwrap();
    assert!(
        restore(&mut link, &ctl, &slot, &mut recovered)
            .await
            .is_err()
    );
    assert_eq!(fs::read(&target).unwrap(), b"external edit");
    assert_eq!(fs::read(artifact(&slot, 0, true)).unwrap(), old);
    fs::write(&target, &new).unwrap();
    let receipt = restore(&mut link, &ctl, &slot, &mut recovered)
        .await
        .unwrap();
    assert_eq!(receipt["state"], "restored");
    assert_eq!(fs::read(&target).unwrap(), old);
    assert!(load(&slot).unwrap().is_none());
}

#[tokio::test]
async fn atomic_publish_and_restore_read_actual_target_and_match_bytes() {
    let device = TempDir::new().unwrap();
    let local = TempDir::new().unwrap();
    fs::create_dir_all(device.path().join("link/Example.app")).unwrap();
    let target = device.path().join("link/Example.app/photo");
    let before = vec![10; 15];
    let after = vec![22; 95_001];
    fs::write(&target, &before).unwrap();
    let mut link = PatchLink::fixture(afc(device.path().into())).await;
    let events = Arc::new(std::sync::Mutex::new(Vec::new()));
    let record = events.clone();
    let ctl = control().with_patch_progress(Arc::new(move |phase, done, total, path| {
        record
            .lock()
            .unwrap()
            .push((phase.to_owned(), done, total, path.to_owned()));
    }));
    let slot = local.path().join("slot");
    directory(&slot).unwrap();
    fs::write(artifact(&slot, 0, true), &before).unwrap();
    fs::write(artifact(&slot, 0, false), &after).unwrap();
    let mut j = Journal {
        identity: link.identity.clone(),
        token: token(),
        state: "pending".into(),
        armed: 0,
        skipped: 1,
        omitted_items: vec![],
        entries: vec![Entry {
            rel: "photo".into(),
            original: Some(stamp(&before)),
            replacement: stamp(&after),
        }],
    };
    save(&slot, &j).unwrap();
    let done = publish(&mut link, &ctl, &slot, &mut j, false)
        .await
        .unwrap();
    assert_eq!(done["state"], "applied");
    assert_eq!(done["restore_paths"], json!(["photo"]));
    assert_eq!(done["skipped"], 1);
    assert_eq!(fs::read(&target).unwrap(), after);
    assert_eq!(fs::read_dir(target.parent().unwrap()).unwrap().count(), 1);
    let mut pending = load(&slot).unwrap().unwrap();
    restore(&mut link, &ctl, &slot, &mut pending).await.unwrap();
    assert_eq!(fs::read(&target).unwrap(), before);
    let events = events.lock().unwrap();
    assert_eq!(
        events
            .iter()
            .map(|event| event.0.as_str())
            .collect::<Vec<_>>(),
        ["applying", "applied", "restoring", "restored"]
    );
    assert!(
        events
            .iter()
            .all(|(_, done, total, path)| *done < *total && path == "photo")
    );
}

#[tokio::test]
async fn bundle_publish_requires_exact_delivered_stage_and_original() {
    let device = TempDir::new().unwrap();
    let local = TempDir::new().unwrap();
    let app = device.path().join("link/Example.app");
    fs::create_dir_all(app.join("Images")).unwrap();
    let relative = "Images/background.png";
    let target = app.join(relative);
    fs::write(&target, b"old").unwrap();
    let slot = local.path().join("transaction");
    directory(&slot).unwrap();
    let mut link = PatchLink::fixture(afc(device.path().into())).await;
    let mut journal = Journal {
        identity: link.identity.clone(),
        token: token(),
        state: "pending".into(),
        armed: 1,
        skipped: 0,
        omitted_items: vec![],
        entries: vec![Entry {
            rel: relative.into(),
            original: Some(stamp(b"old")),
            replacement: stamp(b"new"),
        }],
    };
    fs::write(artifact(&slot, 0, true), b"old").unwrap();
    fs::write(artifact(&slot, 0, false), b"new").unwrap();
    save(&slot, &journal).unwrap();
    let sibling = stage_path(&link.alias, relative, &journal.token, 0, false);
    let sibling = device.path().join(sibling.trim_start_matches('/'));
    fs::write(&sibling, b"bad").unwrap();
    let ctl = control();
    assert!(
        publish(&mut link, &ctl, &slot, &mut journal, true)
            .await
            .is_err()
    );
    assert_eq!(fs::read(&target).unwrap(), b"old");
    fs::write(&sibling, b"new").unwrap();
    fs::write(&target, b"external").unwrap();
    assert!(
        publish(&mut link, &ctl, &slot, &mut journal, true)
            .await
            .is_err()
    );
    assert_eq!(fs::read(&target).unwrap(), b"external");
    fs::write(&target, b"old").unwrap();
    let receipt = publish(&mut link, &ctl, &slot, &mut journal, true)
        .await
        .unwrap();
    assert_eq!(receipt["state"], "applied");
    assert_eq!(fs::read(&target).unwrap(), b"new");
    assert!(!sibling.exists());
    restore(&mut link, &ctl, &slot, &mut journal).await.unwrap();
    assert_eq!(fs::read(&target).unwrap(), b"old");
}

#[tokio::test]
async fn interrupted_batch_restores_first_file_and_cleans_only_its_partial_second_stage() {
    let device = TempDir::new().unwrap();
    let local = TempDir::new().unwrap();
    let app = device.path().join("link/Example.app");
    fs::create_dir_all(&app).unwrap();
    let slot = local.path().join("batch");
    directory(&slot).unwrap();
    let id = token();
    let data = [
        ("first", b"first-old".as_slice(), b"first-new".as_slice()),
        ("second", b"second-old".as_slice(), b"second-new".as_slice()),
    ];
    let entries = data
        .iter()
        .enumerate()
        .map(|(i, (name, before, after))| {
            fs::write(artifact(&slot, i, true), before).unwrap();
            fs::write(artifact(&slot, i, false), after).unwrap();
            fs::write(app.join(name), before).unwrap();
            Entry {
                rel: name.to_string(),
                original: Some(stamp(before)),
                replacement: stamp(after),
            }
        })
        .collect();
    let mut link = PatchLink::fixture(afc(device.path().into())).await;
    let mut j = Journal {
        state: "pending".into(),
        identity: link.identity.clone(),
        token: id,
        armed: 2,
        skipped: 0,
        omitted_items: vec![],
        entries,
    };
    save(&slot, &j).unwrap();
    fs::write(app.join("first"), data[0].2).unwrap();
    let stage = stage_path("/link/Example.app", "second", &j.token, 1, false);
    let staged = device.path().join(stage.trim_start_matches('/'));
    fs::write(&staged, &data[1].2[..4]).unwrap();
    let unrelated = app.join(".sibling-user-data");
    fs::write(&unrelated, b"keep").unwrap();

    restore(&mut link, &control(), &slot, &mut j).await.unwrap();
    assert!(!staged.exists());
    for (name, before, _) in data {
        assert_eq!(fs::read(app.join(name)).unwrap(), before);
    }
    assert_eq!(fs::read(unrelated).unwrap(), b"keep");
    assert!(load(&slot).unwrap().is_none());
}

#[tokio::test]
async fn prepared_but_unarmed_journal_leaves_untouched_target_including_external_edit() {
    let device = TempDir::new().unwrap();
    let local = TempDir::new().unwrap();
    let app = device.path().join("link/Example.app");
    fs::create_dir_all(&app).unwrap();
    let slot = local.path().join("transaction");
    directory(&slot).unwrap();
    fs::write(app.join("photo"), b"new user content").unwrap();
    fs::write(artifact(&slot, 0, true), b"original").unwrap();
    fs::write(artifact(&slot, 0, false), b"replacement").unwrap();
    let mut link = PatchLink::fixture(afc(device.path().into())).await;
    let mut j = Journal {
        identity: link.identity.clone(),
        token: token(),
        state: "pending".into(),
        armed: 0,
        skipped: 0,
        omitted_items: vec![],
        entries: vec![Entry {
            rel: "photo".into(),
            original: Some(stamp(b"original")),
            replacement: stamp(b"replacement"),
        }],
    };
    save(&slot, &j).unwrap();
    restore(&mut link, &control(), &slot, &mut j).await.unwrap();
    assert_eq!(fs::read(app.join("photo")).unwrap(), b"new user content");
    assert!(load(&slot).unwrap().is_none());
}

fn import_folder() -> TempDir {
    let transfers = std::env::temp_dir().join("CC365-Files");
    fs::create_dir_all(&transfers).unwrap();
    let id = token();
    let uuid = format!(
        "{}-{}-{}-{}-{}",
        &id[..8],
        &id[8..12],
        &id[12..16],
        &id[16..20],
        &id[20..]
    );
    tempfile::Builder::new()
        .prefix(&uuid)
        .rand_bytes(0)
        .tempdir_in(transfers)
        .unwrap()
}

#[tokio::test]
async fn denied_bundle_preimage_does_not_stage_large_replacement() {
    let device = TempDir::new().unwrap();
    let local = TempDir::new().unwrap();
    let slot = local.path().join("transaction");
    directory(&slot).unwrap();
    let app = device.path().join("link/Example.app");
    fs::create_dir_all(&app).unwrap();
    fs::write(app.join("denied.bin"), b"signed original").unwrap();
    let imports = import_folder();
    let source = imports.path().join("blob");
    File::create_new(&source)
        .unwrap()
        .set_len(100_000_000)
        .unwrap();
    let mut link = PatchLink::fixture(afc(device.path().into())).await;
    let item = PatchItem {
        relative_path: "denied.bin".into(),
        local_path: source,
    };
    let prepared = prepare(&mut link, &control(), &slot, "bundle", &[item])
        .await
        .unwrap();
    assert!(prepared.entries.is_empty());
    assert_eq!(prepared.omitted_items[0].reason, io::PERMISSION_DENIED);
    assert_eq!(prepared.omitted_items[0].path, "denied.bin");
    assert!(!artifact(&slot, 0, true).exists());
    assert!(!artifact(&slot, 0, false).exists());
    assert!(load(&slot).unwrap().is_none());
    assert_eq!(
        fs::read(app.join("denied.bin")).unwrap(),
        b"signed original"
    );
}

#[tokio::test]
async fn missing_shared_document_is_omitted_while_eligible_existing_file_is_prepared() {
    let device = TempDir::new().unwrap();
    let local = TempDir::new().unwrap();
    let app = device.path().join("link/Example.app");
    fs::create_dir_all(&app).unwrap();
    fs::write(app.join("present"), b"original").unwrap();
    let slot = local.path().join("slot");
    directory(&slot).unwrap();
    let imports = import_folder();
    let source = imports.path().join("blob");
    fs::write(&source, b"replacement").unwrap();
    let items = ["present", "missing"].map(|name| PatchItem {
        relative_path: format!("Documents/{name}"),
        local_path: source.clone(),
    });
    let mut link = PatchLink::fixture(afc(device.path().into())).await;
    link.io_prefix = Some("Documents/".into());
    let prepared = prepare(&mut link, &control(), &slot, "data", &items)
        .await
        .unwrap();
    assert_eq!(prepared.entries.len(), 1);
    assert_eq!(prepared.omitted_items[0].path, "Documents/missing");
    assert!(
        prepared.omitted_items[0]
            .reason
            .contains("chỉ hỗ trợ thay tệp đã có")
    );
    assert_eq!(fs::read(app.join("present")).unwrap(), b"original");
    assert_eq!(fs::read_dir(&app).unwrap().count(), 1);
    assert!(load(&slot).unwrap().is_none());
}

#[tokio::test]
async fn private_cache_batch_rejects_absent_files_and_linked_parents_before_delivery() {
    let device = TempDir::new().unwrap();
    let app = device.path().join("link/Example.app");
    let cache = app.join("Library/Caches");
    let other = device.path().join("another-app");
    fs::create_dir_all(&cache).unwrap();
    fs::create_dir(&other).unwrap();
    fs::write(cache.join("present"), b"original").unwrap();
    fs::write(other.join("foreign"), b"another application").unwrap();
    std::os::unix::fs::symlink(&other, cache.join("alias")).unwrap();

    let imports = import_folder();
    let source = imports.path().join("payload");
    fs::write(&source, b"replacement").unwrap();
    for (leaf, expected) in [("absent", "tệp có sẵn"), ("alias/foreign", "liên kết")] {
        let local = TempDir::new().unwrap();
        let slot = local.path().join("slot");
        directory(&slot).unwrap();
        let mut link = PatchLink::fixture(afc(device.path().into())).await;
        link.transport = "airlift_cache_container";
        let items = ["present", leaf].map(|name| PatchItem {
            relative_path: format!("Library/Caches/{name}"),
            local_path: source.clone(),
        });
        let prepared = prepare(&mut link, &control(), &slot, "data", &items)
            .await
            .unwrap();
        assert_eq!(prepared.entries.len(), 1);
        assert_eq!(
            prepared.omitted_items[0].path,
            format!("Library/Caches/{leaf}")
        );
        assert!(prepared.omitted_items[0].reason.contains(expected));
        assert!(load(&slot).unwrap().is_none());
        assert_eq!(fs::read(cache.join("present")).unwrap(), b"original");
        assert_eq!(
            fs::read(other.join("foreign")).unwrap(),
            b"another application"
        );
        assert!(!cache.join("absent").exists());
    }
}

#[tokio::test]
async fn mixed_legacy_cache_reports_only_verified_writes_and_restores_in_reverse_order() {
    let device = TempDir::new().unwrap();
    let cache = device.path().join("link/Example.app/Library/Caches");
    fs::create_dir_all(&cache).unwrap();
    for name in ["a", "b", "denied.bin"] {
        fs::write(cache.join(name), name).unwrap();
    }
    fs::write(cache.join("same"), b"replacement").unwrap();
    let local = TempDir::new().unwrap();
    let slot = local.path().join("slot");
    directory(&slot).unwrap();
    let imports = import_folder();
    let source = imports.path().join("blob");
    fs::write(&source, b"replacement").unwrap();
    let items = ["absent", "a", "same", "denied.bin", "b"].map(|name| PatchItem {
        relative_path: format!("Library/Caches/{name}"),
        local_path: source.clone(),
    });
    let events = Arc::new(std::sync::Mutex::new(Vec::new()));
    let collect = events.clone();
    let ctl = control().with_patch_progress(Arc::new(move |phase, done, total, path| {
        collect
            .lock()
            .unwrap()
            .push((phase.to_owned(), done, total, path.to_owned()));
    }));
    let mut link = PatchLink::fixture(afc(device.path().into())).await;
    link.transport = "airlift_cache_container";
    let mut rows = prepare(&mut link, &ctl, &slot, "data", &items)
        .await
        .unwrap();
    let checking: Vec<_> = events
        .lock()
        .unwrap()
        .iter()
        .filter(|e| e.0 == "checking")
        .map(|e| e.1)
        .collect();
    assert_eq!(checking, [0, 1, 2, 3, 4]);
    let applied = publish(&mut link, &ctl, &slot, &mut rows, false)
        .await
        .unwrap();
    assert_eq!(applied["changed"], 2);
    assert_eq!(applied["skipped"], 1);
    assert_eq!(applied["omitted"], 2);
    assert_eq!(applied["omitted_items"][0]["path"], "Library/Caches/absent");
    assert_eq!(applied["omitted_items"][1]["reason"], io::PERMISSION_DENIED);
    assert_eq!(
        applied["restore_paths"],
        json!(["Library/Caches/b", "Library/Caches/a"])
    );
    let mut saved = load(&slot).unwrap().unwrap();
    assert_eq!(
        receipt(Some(&saved), "applied", "")["omitted_items"],
        applied["omitted_items"]
    );
    for name in ["a", "b", "same"] {
        assert_eq!(fs::read(cache.join(name)).unwrap(), b"replacement");
    }
    restore(&mut link, &ctl, &slot, &mut saved).await.unwrap();
    for name in ["a", "b", "denied.bin"] {
        assert_eq!(fs::read(cache.join(name)).unwrap(), name.as_bytes());
    }
    assert!(!cache.join("absent").exists());
    assert_eq!(fs::read(cache.join("same")).unwrap(), b"replacement");
    assert!(!slot.exists());
}

#[tokio::test]
async fn legacy_preflight_transport_failure_is_not_a_row_omission() {
    let device = TempDir::new().unwrap();
    let app = device.path().join("link/Example.app");
    fs::create_dir_all(&app).unwrap();
    fs::write(app.join("preflight-offline.bin"), b"original").unwrap();
    let local = TempDir::new().unwrap();
    let slot = local.path().join("slot");
    directory(&slot).unwrap();
    let imports = import_folder();
    let source = imports.path().join("blob");
    fs::write(&source, b"replacement").unwrap();
    let inputs = [PatchItem {
        relative_path: "preflight-offline.bin".into(),
        local_path: source,
    }];
    let mut link = PatchLink::fixture(afc(device.path().into())).await;
    assert!(
        prepare(&mut link, &control(), &slot, "bundle", &inputs)
            .await
            .is_err()
    );
    assert_eq!(
        fs::read(app.join("preflight-offline.bin")).unwrap(),
        b"original"
    );
    assert!(load(&slot).unwrap().is_none());
}

#[test]
fn bulk_request_and_recovery_accept_all_1024_slots_with_long_paths() {
    let imports = import_folder();
    let temp = std::env::temp_dir();
    let long_part = "\"".repeat(240);
    let target = |i| format!("Documents/{long_part}/{long_part}/{long_part}/{long_part}/{i}.bytes");
    let source = imports.path().join("selected.bin");
    let mut items: Vec<_> = (0..MAX_ITEMS)
        .map(|i| PatchItem {
            relative_path: target(i),
            local_path: source.clone(),
        })
        .collect();
    assert!(valid_request(
        "apply",
        "com.example.game",
        "data",
        None,
        &items,
        &temp
    ));
    items.push(PatchItem {
        relative_path: target(MAX_ITEMS),
        local_path: source,
    });
    assert!(!valid_request(
        "apply",
        "com.example.game",
        "data",
        None,
        &items,
        &temp
    ));

    let root = TempDir::new().unwrap();
    let slot = root.path().join("app");
    directory(&slot).unwrap();
    let journal = Journal {
        identity: "this-installation".into(),
        token: token(),
        state: "pending".into(),
        skipped: 0,
        omitted_items: vec![],
        armed: MAX_ITEMS,
        entries: (0..MAX_ITEMS)
            .map(|i| Entry {
                rel: target(i),
                original: Some(stamp(b"before")),
                replacement: stamp(b"after"),
            })
            .collect(),
    };
    save(&slot, &journal).unwrap();
    assert!(fs::metadata(slot.join("journal.json")).unwrap().len() > 1024 * 1024);
    let recovered = load(&slot).unwrap().unwrap();
    assert_eq!(recovered.entries.len(), MAX_ITEMS);
    assert_eq!(recovered.entries.last().unwrap().rel, target(MAX_ITEMS - 1));
    fs::write(artifact(&slot, MAX_ITEMS - 1, true), b"before").unwrap();
    remove_slot(&slot).unwrap();
    assert!(!slot.exists());
}

#[tokio::test]
async fn denied_document_reports_backup_failure_before_writing_any_payload() {
    let device = TempDir::new().unwrap();
    let local = TempDir::new().unwrap();
    let slot = local.path().join("transaction");
    directory(&slot).unwrap();
    let app = device.path().join("link/Example.app/Documents");
    fs::create_dir_all(&app).unwrap();
    fs::write(app.join("first.bin"), b"first original").unwrap();
    fs::write(app.join("denied.bin"), b"game original").unwrap();
    let imports = import_folder();
    let source = imports.path().join("replacement");
    fs::write(&source, b"game replacement").unwrap();
    let mut link = PatchLink::fixture(afc(device.path().into())).await;
    let items = ["denied.bin", "first.bin"].map(|name| PatchItem {
        relative_path: format!("Documents/{name}"),
        local_path: source.clone(),
    });
    let prepared = prepare(&mut link, &control(), &slot, "data", &items)
        .await
        .unwrap();
    assert_eq!(prepared.entries.len(), 1);
    assert_eq!(prepared.omitted_items[0].path, "Documents/denied.bin");
    assert_eq!(prepared.omitted_items[0].reason, io::PERMISSION_DENIED);
    assert!(artifact(&slot, 0, false).exists());
    assert_eq!(
        fs::read(artifact(&slot, 0, true)).unwrap(),
        b"first original"
    );
    assert_eq!(prepared.entries[0].rel, "Documents/first.bin");
    assert!(!artifact(&slot, 1, false).exists());
    assert!(load(&slot).unwrap().is_none());
    assert_eq!(fs::read_dir(&app).unwrap().count(), 2);
    assert_eq!(fs::read(app.join("first.bin")).unwrap(), b"first original");
    assert_eq!(fs::read(app.join("denied.bin")).unwrap(), b"game original");
}
