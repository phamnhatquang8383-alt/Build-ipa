use super::*;
use checkpoint::persist_rows;
use compare::confirmed_prefix;
use idevice::afc::AfcClient;

struct ChangedFile {
    index: usize,
    stage: String,
    held: String,
    backup_object: String,
    witness: String,
    stamp: Stamp,
}
type ReturnMove = (String, String, String, String);

fn indices(jobs: &[ChangedFile]) -> Vec<usize> {
    jobs.iter().map(|job| job.index).collect()
}
fn tickets(b: &Batch, jobs: &[ChangedFile], objects: &[String]) -> Result<Vec<ReturnMove>> {
    if jobs.len() != objects.len() {
        return Err(UNCERTAIN.into());
    }
    Ok(jobs
        .iter()
        .zip(objects)
        .map(|(job, object)| {
            let row = &b.items[job.index];
            (
                row.rel.clone(),
                row.key.clone(),
                object.clone(),
                job.witness.clone(),
            )
        })
        .collect())
}

async fn verify_changed(
    client: &mut AfcClient,
    ctl: &SyncControl,
    job: &ChangedFile,
) -> Result<String> {
    let object = PatchLink::reverse_cargo_witness_on(client, &job.stage)
        .await?
        .ok_or(UNCERTAIN)?;
    let observed = io::snapshot(client, ctl, &job.stage, std::io::sink(), MAX_FILE)
        .await?
        .ok_or(UNCERTAIN)?;
    if observed != job.stamp
        || job.witness != observed.sha1_witness()
        || PatchLink::reverse_cargo_witness_on(client, &job.stage)
            .await?
            .as_deref()
            != Some(&object)
    {
        return Err(CONFLICT.into());
    }
    Ok(object)
}

impl DeviceSession {
    pub(super) async fn publish_changed_group(
        &mut self,
        link: &mut PatchLink,
        slot: &Path,
        b: &mut Batch,
        group: &[usize],
        extra: &mut [AfcClient],
    ) -> Result<()> {
        let mut possible = vec![];
        for &i in group {
            let row = &b.items[i];
            if row.phase != Phase::Comparing || row.handoff != Some(Handoff::StageDifferent) {
                continue;
            }
            let witness = row.replacement_witness.as_ref().ok_or(UNCERTAIN)?;
            if !witness.starts_with("sha1:") {
                continue;
            }
            if row
                .original
                .as_ref()
                .is_none_or(|old| old == &row.replacement)
                || witness != &row.replacement.sha1_witness()
            {
                return Err(UNCERTAIN.into());
            }
            link.select_reverse_doc(&row.rel, &row.key)?;
            possible.push(ChangedFile {
                index: i,
                stage: link.reverse_stage_path()?,
                held: link.reverse_media_path()?,
                backup_object: row.cargo.clone().ok_or(UNCERTAIN)?,
                witness: witness.clone(),
                stamp: row.replacement.clone(),
            });
        }
        if possible.len() < 2 {
            return Ok(());
        }
        let mut eligible = vec![];
        let mut objects = vec![];
        let mut first = possible.into_iter();
        loop {
            let wave: Vec<_> = first.by_ref().take(1 + extra.len()).collect();
            if wave.is_empty() {
                break;
            }
            let clients = std::iter::once(link.reverse_media_afc()?).chain(extra.iter_mut());
            let inspected = futures_util::future::join_all(clients.zip(&wave).map(
                |(client, job)| async move {
                    if PatchLink::reverse_cargo_witness_on(client, &job.held)
                        .await?
                        .as_deref()
                        != Some(&job.backup_object)
                    {
                        return Ok(None);
                    }
                    PatchLink::reverse_cargo_witness_on(client, &job.stage).await
                },
            ))
            .await;
            for (job, result) in wave.into_iter().zip(inspected) {
                match result {
                    Ok(Some(object)) => {
                        eligible.push(job);
                        objects.push(object);
                    }
                    Ok(None) => (),
                    Err(error) if PatchLink::is_local_patch_refusal(&error) => (),
                    Err(error) => return Err(error),
                }
            }
        }
        if eligible.len() < 2 {
            return Ok(());
        }
        let selected = indices(&eligible);
        for &i in &selected {
            b.items[i].phase = Phase::Moving;
            b.items[i].handoff = Some(Handoff::InstallNew);
        }
        persist_rows(slot, b, &selected)?;
        for &i in &selected {
            report_progress(&self.control, "applying", b, true, i);
        }
        let published = confirmed_prefix(
            self.return_changed_group(link, &tickets(b, &eligible, &objects)?)
                .await?,
            eligible.len(),
        )?;
        for &i in &selected[published..] {
            b.items[i].phase = Phase::Comparing;
            b.items[i].handoff = Some(Handoff::StageDifferent);
        }
        persist_rows(slot, b, &selected[published..])?;
        eligible.truncate(published);
        if eligible.is_empty() {
            return Ok(());
        }
        self.recall_changed(link, slot, b, eligible, extra).await
    }

    async fn recall_changed(
        &mut self,
        link: &mut PatchLink,
        slot: &Path,
        b: &mut Batch,
        installed: Vec<ChangedFile>,
        extra: &mut [AfcClient],
    ) -> Result<()> {
        let selected = indices(&installed);
        let mut tickets_out = vec![];
        for &i in &selected {
            b.items[i].handoff = Some(Handoff::VerifyNewOut);
            tickets_out.push((b.items[i].rel.clone(), b.items[i].key.clone()));
        }
        persist_rows(slot, b, &selected)?;
        let n = confirmed_prefix(
            self.export_changed_group(link, &tickets_out).await?,
            installed.len(),
        )?;
        let mut returned = vec![];
        for (position, job) in installed.into_iter().enumerate() {
            let i = job.index;
            if position >= n {
                let row = &b.items[i];
                link.select_reverse_doc(&row.rel, &row.key)?;
                let result = self.reverse_opaque_export(link, true).await;
                self.handle_apply_result(link, slot, b, i, result).await?;
                if b.items[i].phase == Phase::Omitted {
                    report_progress(&self.control, "omitted", b, true, i);
                    continue;
                }
            }
            returned.push(job);
        }

        let mut verified = vec![];
        let mut identities = vec![];
        let mut remaining = returned.into_iter();
        loop {
            let wave: Vec<_> = remaining.by_ref().take(1 + extra.len()).collect();
            if wave.is_empty() {
                break;
            }
            let clients = std::iter::once(link.reverse_media_afc()?).chain(extra.iter_mut());
            let proofs = futures_util::future::join_all(
                clients
                    .zip(&wave)
                    .map(|(client, job)| verify_changed(client, &self.control, job)),
            )
            .await;
            for (job, result) in wave.into_iter().zip(proofs) {
                let i = job.index;
                match result {
                    Ok(object) => {
                        verified.push(job);
                        identities.push(object);
                    }
                    Err(reason) => {
                        let row = &b.items[i];
                        link.select_reverse_doc(&row.rel, &row.key)?;
                        self.put_back_foreign(link, slot, b, i).await?;
                        self.handle_apply_result(link, slot, b, i, Err(reason))
                            .await?;
                        report_progress(&self.control, "omitted", b, true, i);
                    }
                }
            }
        }
        if verified.is_empty() {
            return Ok(());
        }
        self.deliver_verified_changed(link, slot, b, verified, identities)
            .await
    }

    async fn deliver_verified_changed(
        &mut self,
        link: &mut PatchLink,
        slot: &Path,
        b: &mut Batch,
        jobs: Vec<ChangedFile>,
        identities: Vec<String>,
    ) -> Result<()> {
        let selected = indices(&jobs);
        for &i in &selected {
            b.items[i].handoff = Some(Handoff::ReturnVerifiedNew);
        }
        persist_rows(slot, b, &selected)?;
        let n = confirmed_prefix(
            self.return_changed_group(link, &tickets(b, &jobs, &identities)?)
                .await?,
            jobs.len(),
        )?;
        let before = b
            .items
            .iter()
            .filter(|r| matches!(r.phase, Phase::Installed | Phase::Skipped | Phase::Omitted))
            .count();
        for &i in &selected[..n] {
            b.items[i].phase = Phase::Installed;
        }
        persist_rows(slot, b, &selected[..n])?;
        for (index, &i) in selected[..n].iter().enumerate() {
            self.control.patch_progress(
                "applied",
                (before + index + 1).min(b.items.len() - 1),
                b.items.len(),
                &b.items[i].rel,
            );
        }
        for (job, object) in jobs[n..].iter().zip(&identities[n..]) {
            let i = job.index;
            let row = &b.items[i];
            link.select_reverse_doc(&row.rel, &row.key)?;
            if link.reverse_opaque_cargo_witness(false).await?.as_ref() != Some(object) {
                return Err(UNCERTAIN.into());
            }
            let result = self.reverse_opaque_return(link, true, &job.witness).await;
            self.handle_apply_result(link, slot, b, i, result).await?;
            if b.items[i].phase == Phase::Omitted {
                report_progress(&self.control, "omitted", b, true, i);
            } else {
                b.items[i].phase = Phase::Installed;
                persist_row(slot, b, i)?;
                report_progress(&self.control, "applied", b, true, i);
            }
        }
        Ok(())
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    use crate::device::patch::tests::{afc, control};
    #[tokio::test]
    async fn grouped_changed_readback_accepts_only_the_actual_recalled_bytes() {
        let root = tempfile::tempdir().unwrap();
        let ctl = control();
        let mut client = afc(root.path().into());
        let expected = io::local_copy(&b"expected"[..], std::io::sink()).unwrap();
        let path = root.path().join("recall");
        let job = ChangedFile {
            index: 0,
            stage: "/recall".into(),
            held: "/held".into(),
            backup_object: "unused".into(),
            witness: expected.sha1_witness(),
            stamp: expected,
        };
        fs::write(&path, b"expected").unwrap();
        let object = verify_changed(&mut client, &ctl, &job).await.unwrap();
        assert!(object.starts_with("object:"));
        fs::write(&path, b"new-edit").unwrap();
        assert_eq!(
            verify_changed(&mut client, &ctl, &job).await.unwrap_err(),
            CONFLICT
        );
        assert_eq!(fs::read(&path).unwrap(), b"new-edit");
        fs::remove_file(&path).unwrap();
        assert_eq!(
            verify_changed(&mut client, &ctl, &job).await.unwrap_err(),
            UNCERTAIN
        );
    }
}
