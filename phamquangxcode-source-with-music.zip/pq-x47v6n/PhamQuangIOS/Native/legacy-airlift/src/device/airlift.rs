#[path = "airlift_books.rs"]
mod airlift_books;
#[path = "airlift_patch_link.rs"]
mod patch_link;
pub(crate) use patch_link::{
    GroupDelivery, MAX_GROUP_HANDOFFS, MAX_REVERSE_PLAN_ITEMS, PatchLink, ReversePreflight,
    ScanFailure, reverse_plan_fits,
};

use super::files::{close_handle, open_handle};
use super::patch::MAX_ITEMS;
use super::{AfcClient, AfcFopenMode, DeviceSession, IdeviceError, airlift_wire};
use idevice::afc::{errors::AfcError, opcode::AfcOpcode};
use plist::{Dictionary, Value as Plist};
use rand::{RngCore, rngs::OsRng};
use serde::{Deserialize, Serialize};
use serde_json::{Value, json};
use std::{
    collections::HashMap,
    fs,
    future::Future,
    io::{Read, Write},
    os::unix::fs::OpenOptionsExt,
    path::Path,
    time::{Duration, SystemTime, UNIX_EPOCH},
};

const ARCHIVE: &[u8; 1090] = include_bytes!("airlift-template.zip");
const PAYLOAD_DATA: std::ops::Range<usize> = 482..514;
const LOCAL_PAYLOAD_HEADER: usize = 439;
const CENTRAL_PAYLOAD_HEADER: usize = 1009;
const JUMP: &str = "../../../var/tmp";
const BOOKS: &str = "/Books";
const SYNC: &str = "/Books/Sync";
const MANIFEST: &str = "/Books/Sync/Books.plist";
const CONFLICT: &str =
    "Một đường dẫn của phép thử đã thay đổi hoặc không đúng loại tệp. CC365 đã dừng phiên này.";
const JOURNAL_ERROR: &str = "Không đọc hoặc lưu được thông tin khôi phục của phép thử.";
const AFC_ERROR: &str = "Không xác nhận được trạng thái tệp trên iPhone. Hãy kiểm tra kết nối.";
static AIRLIFT_LOCK: tokio::sync::Mutex<()> = tokio::sync::Mutex::const_new(());
const BUSY: &str = "Một phiên AirLift khác đang chạy.";
type Info = HashMap<String, String>;
type Result<T> = std::result::Result<T, String>;

fn now() -> u64 {
    SystemTime::now()
        .duration_since(UNIX_EPOCH)
        .unwrap_or_default()
        .as_secs()
}
fn archive(payload: &[u8; 32]) -> Vec<u8> {
    let mut zip = ARCHIVE.to_vec();
    let mut crc = flate2::Crc::new();
    crc.update(payload);
    zip[LOCAL_PAYLOAD_HEADER + 14..LOCAL_PAYLOAD_HEADER + 18]
        .copy_from_slice(&crc.sum().to_le_bytes());
    zip[CENTRAL_PAYLOAD_HEADER + 16..CENTRAL_PAYLOAD_HEADER + 20]
        .copy_from_slice(&crc.sum().to_le_bytes());
    zip[PAYLOAD_DATA].copy_from_slice(payload);
    zip
}
#[derive(Serialize, Deserialize)]
struct Trial {
    token: String,
    challenge: [u8; 32],
    had_books: bool,
    archive_in_flight: Option<u64>,
    publish_attempted: bool,
    sync_started: Option<u64>,
    matched: bool,
    #[serde(default)]
    books_snapshot: bool,
    #[serde(default)]
    books_verified: bool,
    #[serde(default)]
    books_atc_started: bool,
    #[serde(default, skip_serializing_if = "Option::is_none")]
    patch_parent: Option<String>,
    #[serde(default)]
    patch_slots: usize,
    #[serde(default, skip_serializing_if = "Vec::is_empty")]
    reverse_docs: Vec<(String, String)>,
    #[serde(default)]
    reverse_redelivery: bool,
    #[serde(default)]
    reverse_namespaced: bool,
}
impl Trial {
    fn new(had_books: bool) -> Self {
        let mut id = [0u8; 10];
        let mut challenge = [0u8; 32];
        OsRng.fill_bytes(&mut id);
        OsRng.fill_bytes(&mut challenge);
        Self {
            token: format!(
                "n{}",
                id.iter().map(|v| format!("{v:02x}")).collect::<String>()
            ),
            challenge,
            had_books,
            archive_in_flight: None,
            publish_attempted: false,
            sync_started: None,
            matched: false,
            books_snapshot: true,
            books_verified: false,
            books_atc_started: false,
            patch_parent: None,
            patch_slots: 0,
            reverse_docs: Vec::new(),
            reverse_redelivery: false,
            reverse_namespaced: true,
        }
    }
    fn source(&self) -> String {
        format!("cl-src-{}", self.token)
    }
    fn link(&self) -> String {
        format!("cl-link-{}", self.token)
    }
    fn readback(&self) -> String {
        format!("/cl-read-{}", self.token)
    }
    fn leaf(&self) -> String {
        format!("cl-canary-{}.bin", self.token)
    }
    fn marker(&self) -> String {
        format!(".cc365-owner-{}", self.token)
    }
    fn moves(&self) -> Vec<(String, String)> {
        let src = self.source();
        let link = self.link();
        let leaf = self.leaf();
        if self.patch_parent.is_some() {
            return vec![(format!("../../{src}/a/b/c/jump"), link)];
        }
        vec![
            (format!("../../{src}/a/b/c/jump"), link.clone()),
            (format!("../../{src}/payload"), format!("{link}/{leaf}")),
            (
                format!("../../../../tmp/{leaf}"),
                format!("cl-read-{}", self.token),
            ),
        ]
    }
    fn manifest_moves(&self) -> Vec<(String, String)> {
        let mut moves = self.moves();
        for i in 0..self.patch_slots {
            moves.push((
                format!("../../{}/patch-{i}-a", self.source()),
                String::new(),
            ));
        }
        if let Some(root) = self.patch_parent.as_deref() {
            for (rel, key) in &self.reverse_docs {
                for direction in airlift_wire::ReverseMove::ALL {
                    if let Some([first, second]) = direction.assets_for_lease(
                        &self.token,
                        root,
                        rel,
                        key,
                        self.reverse_namespaced,
                    ) {
                        moves.push(first);
                        if self.reverse_redelivery {
                            moves.push(second);
                        }
                    }
                }
            }
        }
        moves
    }
    fn manifest(&self) -> Result<Vec<u8>> {
        let books = self
            .manifest_moves()
            .into_iter()
            .enumerate()
            .map(|(i, (source, _))| {
                let mut d = Dictionary::new();
                d.insert("Persistent ID".into(), source.into());
                d.insert("Item ID".into(), (i + 1).to_string().into());
                d.insert("DSID".into(), "1".into());
                Plist::Dictionary(d)
            })
            .collect();
        let mut d = Dictionary::new();
        d.insert("Books".into(), Plist::Array(books));
        let mut data = Vec::new();
        Plist::Dictionary(d)
            .to_writer_binary(&mut data)
            .map_err(|_| JOURNAL_ERROR)?;
        Ok(data)
    }
    fn load(path: &Path) -> Result<Option<Self>> {
        let mut options = fs::OpenOptions::new();
        options.read(true).custom_flags(libc::O_NOFOLLOW);
        let f = match options.open(path) {
            Ok(f) => f,
            Err(e) if e.kind() == std::io::ErrorKind::NotFound => return Ok(None),
            Err(_) => return Err(JOURNAL_ERROR.into()),
        };
        if !f
            .metadata()
            .is_ok_and(|m| m.is_file() && m.len() < 32 * 1024)
        {
            return Err(JOURNAL_ERROR.into());
        }
        let mut bytes = Vec::new();
        f.take(32 * 1024)
            .read_to_end(&mut bytes)
            .map_err(|_| JOURNAL_ERROR)?;
        let trial: Self = serde_json::from_slice(&bytes).map_err(|_| JOURNAL_ERROR)?;
        if (!trial.reverse_docs.is_empty()
            && (trial.patch_slots != 0
                || !trial
                    .patch_parent
                    .as_deref()
                    .is_some_and(|root| patch_link::valid_reverse_plan(root, &trial.reverse_docs))))
            || trial.patch_slots > MAX_ITEMS
            || (trial.patch_parent.is_none() && trial.patch_slots != 0)
            || trial
                .patch_parent
                .as_deref()
                .is_some_and(|p| !patch_link::valid_parent(p))
            || !airlift_wire::valid_token(&trial.token)
            || trial.reverse_namespaced != trial.token.starts_with('n')
        {
            return Err(JOURNAL_ERROR.into());
        }
        Ok(Some(trial))
    }
    fn save(&self, path: &Path) -> Result<()> {
        save_private_json(path, self)
    }
}
fn save_private_json(path: &Path, record: &impl Serialize) -> Result<()> {
    let tmp = path.with_extension(format!("{:032x}.tmp", rand::random::<u128>()));
    let f = fs::OpenOptions::new()
        .write(true)
        .create_new(true)
        .mode(0o600)
        .open(&tmp)
        .map_err(|_| JOURNAL_ERROR)?;
    let result = (|| {
        let mut output = std::io::BufWriter::new(&f);
        serde_json::to_writer(&mut output, record).map_err(|_| JOURNAL_ERROR)?;
        output
            .flush()
            .and_then(|_| f.sync_all())
            .and_then(|_| fs::rename(&tmp, path))
            .and_then(|_| fs::File::open(path.parent().unwrap_or(Path::new(".")))?.sync_all())
            .map_err(|_| JOURNAL_ERROR.to_owned())
    })();
    if result.is_err() {
        let _ = fs::remove_file(&tmp);
    }
    result
}
fn session_manifest(t: &Trial, prior: Option<&[u8]>) -> Result<Vec<u8>> {
    use std::collections::HashSet;
    let Some(data) = prior else {
        return t.manifest();
    };
    let Some(mut document) = Plist::from_reader(std::io::Cursor::new(data))
        .ok()
        .and_then(Plist::into_dictionary)
    else {
        return t.manifest();
    };
    let Some(rows) = document.get_mut("Books").and_then(Plist::as_array_mut) else {
        return t.manifest();
    };
    let moves = t.manifest_moves();
    let requested: HashSet<_> = moves.iter().map(|(source, _)| source.as_str()).collect();
    let mut used = HashSet::new();
    for row in rows.iter().filter_map(Plist::as_dictionary) {
        if row
            .get("Persistent ID")
            .and_then(Plist::as_string)
            .is_some_and(|id| requested.contains(id))
        {
            return Err("Mã của tệp thử đã tồn tại trong danh sách Sách. Hãy thử lại.".into());
        }
        if let Some(number) = row.get("Item ID").and_then(|id| {
            id.as_unsigned_integer()
                .or_else(|| id.as_string()?.parse::<u64>().ok())
        }) {
            used.insert(number);
        }
    }
    let mut next = 1u64;
    for (source, _) in moves {
        while used.contains(&next) {
            next += 1;
        }
        let mut row = Dictionary::new();
        row.insert("Item ID".into(), next.to_string().into());
        row.insert("Persistent ID".into(), source.into());
        row.insert("DSID".into(), "1".into());
        rows.push(Plist::Dictionary(row));
        next += 1;
    }
    let mut result = Vec::new();
    Plist::Dictionary(document)
        .to_writer_binary(&mut result)
        .map_err(|_| JOURNAL_ERROR)?;
    Ok(result)
}

async fn io<T>(f: impl Future<Output = std::result::Result<T, IdeviceError>>) -> Result<T> {
    tokio::time::timeout(Duration::from_secs(8), f)
        .await
        .map_err(|_| AFC_ERROR)?
        .map_err(|_| AFC_ERROR.into())
}
async fn stat(c: &mut AfcClient, p: &str) -> Result<Option<Info>> {
    io(async {
        match c.get_file_info_raw(p).await {
            Ok(m) => Ok(Some(m)),
            Err(IdeviceError::Afc(AfcError::ObjectNotFound)) => Ok(None),
            Err(e) => Err(e),
        }
    })
    .await
}
fn kind(m: &Info) -> &str {
    if m.contains_key("LinkTarget") || m.contains_key("st_link_target") {
        "S_IFLNK"
    } else {
        m.get("st_ifmt").map(String::as_str).unwrap_or("")
    }
}
fn is_jump(m: &Info) -> bool {
    is_link_to(m, JUMP)
}
fn is_link_to(m: &Info, target: &str) -> bool {
    kind(m) == "S_IFLNK"
        && m.get("LinkTarget")
            .or(m.get("st_link_target"))
            .is_some_and(|v| v == target)
}
async fn dir(c: &mut AfcClient, p: &str) -> Result<bool> {
    match stat(c, p).await? {
        None => Ok(false),
        Some(m) if kind(&m) == "S_IFDIR" => Ok(true),
        _ => Err(CONFLICT.into()),
    }
}
async fn empty(c: &mut AfcClient, p: &str) -> Result<bool> {
    Ok(io(c.list_dir(p))
        .await?
        .iter()
        .all(|n| n == "." || n == ".."))
}
async fn read(c: &mut AfcClient, p: &str) -> Result<Option<Vec<u8>>> {
    let Some(m) = stat(c, p).await? else {
        return Ok(None);
    };
    let n: usize = m
        .get("st_size")
        .and_then(|n| n.parse().ok())
        .filter(|n| *n <= 8192)
        .ok_or(AFC_ERROR)?;
    if kind(&m) != "S_IFREG" {
        return Err(AFC_ERROR.into());
    }
    let handle = io(open_handle(c, p, AfcFopenMode::RdOnly)).await?;
    let bytes = if n > 0 {
        let args = [handle.to_le_bytes(), (n as u64).to_le_bytes()].concat();
        io(c.send_op(AfcOpcode::Read, args, vec![])).await?.payload
    } else {
        vec![]
    };
    io(close_handle(c, handle)).await?;
    if bytes.len() != n {
        return Err(AFC_ERROR.into());
    }
    Ok(Some(bytes))
}
async fn preflight(c: &mut AfcClient) -> Result<bool> {
    dir(c, BOOKS).await
}
async fn known_parents(c: &mut AfcClient, path: &str) -> Result<bool> {
    let mut current = String::new();
    let (parent, _) = path.rsplit_once('/').ok_or(AFC_ERROR)?;
    for part in parent.split('/').filter(|s| !s.is_empty()) {
        current.push('/');
        current.push_str(part);
        if !dir(c, &current).await? {
            return Ok(false);
        }
    }
    Ok(true)
}
async fn remove_file(c: &mut AfcClient, p: &str, expected: &[u8]) -> Result<()> {
    match read(c, p).await? {
        None => Ok(()),
        Some(data) if data == expected => io(c.remove(p)).await,
        _ => Err(AFC_ERROR.into()),
    }
}
async fn remove_dir(c: &mut AfcClient, p: &str) -> Result<()> {
    if dir(c, p).await? {
        if !empty(c, p).await? {
            return Err(AFC_ERROR.into());
        }
        io(c.remove(p)).await?;
    }
    Ok(())
}
async fn stage(
    session: &mut DeviceSession,
    c: &mut AfcClient,
    t: &mut Trial,
    journal: &Path,
) -> Result<Option<airlift_wire::BooksSession>> {
    airlift_books::snapshot(c, journal, t).await?;
    prepare_archive(session, c, t, journal).await?;
    start_books(session, c, t, journal).await
}

async fn prepare_archive(
    session: &mut DeviceSession,
    c: &mut AfcClient,
    t: &mut Trial,
    journal: &Path,
) -> Result<()> {
    session.control.check().map_err(|_| "Đã dừng phép thử.")?;
    let src = t.source();
    t.archive_in_flight = Some(now());
    t.save(journal)?;
    let target = t.patch_parent.as_deref().map(|p| format!("../../..{p}"));
    let bytes = match t.patch_parent.as_deref() {
        Some(p) => patch_link::link_archive(p, &t.challenge)?,
        None => archive(&t.challenge),
    };
    airlift_wire::transfer(session, &src, &bytes).await?;
    let base = format!("/{src}");
    let jump = format!("{base}/a/b/c/jump");
    if !known_parents(c, &jump).await?
        || !stat(c, &jump)
            .await?
            .as_ref()
            .is_some_and(|m| is_link_to(m, target.as_deref().unwrap_or(JUMP)))
        || read(c, &format!("{base}/payload")).await?.as_deref() != Some(&t.challenge)
    {
        return Err("iOS chưa giải nén đúng tệp thử.".into());
    }
    t.archive_in_flight = None;
    t.save(journal)
}

async fn start_books(
    session: &mut DeviceSession,
    c: &mut AfcClient,
    t: &mut Trial,
    journal: &Path,
) -> Result<Option<airlift_wire::BooksSession>> {
    let target = t.patch_parent.as_deref().map(|p| format!("../../..{p}"));
    session.control.check().map_err(|_| "Đã dừng phép thử.")?;
    t.publish_attempted = true;
    t.save(journal)?;
    airlift_books::publish(c, journal, t).await?;
    session.control.check().map_err(|_| "Đã dừng phép thử.")?;
    t.books_atc_started = true;
    t.save(journal)?;
    let channel = airlift_wire::books(session, &t.moves(), t.reverse_namespaced, || {
        t.sync_started = Some(now());
        t.save(journal)
    })
    .await?;
    if let Some(target) = target {
        let link_path = format!("/{}", t.link());
        for attempt in 0..35 {
            if stat(c, &link_path)
                .await?
                .as_ref()
                .is_some_and(|m| is_link_to(m, &target))
            {
                t.matched = true;
                t.save(journal)?;
                return Ok(Some(channel));
            }
            session
                .control
                .check()
                .map_err(|_| "Đã dừng mở thư mục ứng dụng.")?;
            tokio::time::sleep(Duration::from_millis(if attempt < 2 { 35 } else { 250 })).await;
        }
        return Err("iOS chưa cung cấp liên kết đến thư mục ứng dụng.".into());
    }
    for _ in 0..60 {
        if read(c, &t.readback()).await?.as_deref() == Some(&t.challenge) {
            t.matched = true;
            t.save(journal)?;
            return Ok(None);
        }
        session.control.check().map_err(|_| "Đã dừng phép thử.")?;
        tokio::time::sleep(Duration::from_millis(250)).await;
    }
    Err("iOS chưa trả lại đủ 32 byte của tệp thử.".into())
}
async fn cleanup(c: &mut AfcClient, t: &Trial) -> Result<bool> {
    let mut clean = true;
    let link = format!("/{}", t.link());
    let moved_link = stat(c, &link).await?;
    let target = t.patch_parent.as_deref().map(|p| format!("../../..{p}"));
    let expected = target.as_deref().unwrap_or(JUMP);
    let own_link = moved_link.as_ref().is_some_and(|m| is_link_to(m, expected));
    if own_link && t.patch_parent.is_none() {
        remove_file(c, &format!("{link}/{}", t.leaf()), &t.challenge).await?;
    } else if moved_link.is_some() && !own_link {
        return Ok(false);
    } else if t.patch_parent.is_none() && t.sync_started.is_some() && !t.matched {
        let root = format!("/{}", t.source());
        let jump = format!("{root}/a/b/c/jump");
        if !known_parents(c, &jump).await?
            || !stat(c, &jump).await?.as_ref().is_some_and(is_jump)
            || read(c, &format!("{root}/payload")).await?.as_deref() != Some(&t.challenge)
        {
            return Ok(false);
        }
    }
    if t.patch_parent.is_none() {
        remove_file(c, &t.readback(), &t.challenge).await?;
    }
    let base = format!("/{}", t.source());
    if dir(c, &base).await? {
        if t.patch_slots > 0 {
            let owned = read(c, &format!("{base}/payload")).await?.as_deref() == Some(&t.challenge);
            let mut slots = Vec::new();
            for name in io(c.list_dir(&base)).await? {
                if matches!(
                    name.as_str(),
                    "." | ".." | "a" | "var" | "META-INF" | "cc365-books" | "payload"
                ) {
                    continue;
                }
                let Some(index) = name
                    .strip_prefix("patch-")
                    .and_then(|p| p.strip_suffix("-a"))
                    .and_then(|n| n.parse::<usize>().ok())
                else {
                    return Ok(false);
                };
                if !owned || index >= t.patch_slots || name != format!("patch-{index}-a") {
                    return Ok(false);
                }
                slots.push(format!("{base}/{name}"));
            }
            for p in slots {
                if !stat(c, &p).await?.is_some_and(|m| kind(&m) == "S_IFREG") {
                    return Ok(false);
                }
                io(c.remove(p)).await?;
            }
        }
        let staged_marker = format!("cc365-books/Sync/{}", t.marker());
        for part in [
            "payload",
            "a/b/c/jump",
            "a/b/c",
            "a/b",
            "a",
            "var/tmp",
            "var",
            "META-INF/com.apple.ZipMetadata.plist",
            "META-INF",
            "cc365-books/Sync/Books.plist",
            staged_marker.as_str(),
            "cc365-books/Sync",
            "cc365-books",
        ] {
            if t.patch_parent.is_some() && matches!(part, "var/tmp" | "var") {
                continue;
            }
            let p = format!("{base}/{part}");
            if !known_parents(c, &p).await? {
                continue;
            }
            let Some(m) = stat(c, &p).await? else {
                continue;
            };
            match part {
                "payload" => remove_file(c, &p, &t.challenge).await?,
                "a/b/c/jump" if is_link_to(&m, expected) => io(c.remove(&p)).await?,
                "a/b/c/jump" => clean = false,
                "META-INF/com.apple.ZipMetadata.plist" => {
                    let expected = Plist::from_reader(std::io::Cursor::new(
                        read(c, &p).await?.ok_or(AFC_ERROR)?,
                    ))
                    .ok();
                    if expected.and_then(Plist::into_dictionary).is_some_and(|d| {
                        d.len() == 1
                            && d.get("Version").and_then(Plist::as_unsigned_integer) == Some(2)
                    }) {
                        io(c.remove(&p)).await?
                    } else {
                        clean = false
                    }
                }
                "cc365-books/Sync/Books.plist" => remove_file(c, &p, &t.manifest()?).await?,
                marker if marker == staged_marker => remove_file(c, &p, &t.challenge).await?,
                _ => remove_dir(c, &p).await?,
            }
        }
        if let Some(p) = &t.patch_parent {
            let mut tail = p.as_str();
            while !tail.is_empty() {
                let mirror = format!("{base}{tail}");
                if known_parents(c, &mirror).await? {
                    remove_dir(c, &mirror).await?;
                }
                tail = tail.rsplit_once('/').map(|v| v.0).unwrap_or("");
            }
        }
        remove_dir(c, &base).await?;
    }
    if !t.books_snapshot && t.publish_attempted && known_parents(c, MANIFEST).await? {
        let marker = format!("{SYNC}/{}", t.marker());
        let marker_bytes = read(c, &marker).await?;
        let own_marker = marker_bytes.as_deref() == Some(&t.challenge);
        if marker_bytes.is_some() && !own_marker {
            return Ok(false);
        }
        let manifest = read(c, MANIFEST).await?;
        let own_manifest = manifest.as_deref() == Some(&t.manifest()?);
        if own_manifest {
            remove_file(c, MANIFEST, &t.manifest()?).await?;
        }
        if own_marker {
            if stat(c, MANIFEST).await?.is_some() && !own_manifest {
                return Ok(false);
            }
            remove_file(c, &marker, &t.challenge).await?;
            if empty(c, SYNC).await? {
                remove_dir(c, SYNC).await?;
                if !t.had_books && empty(c, BOOKS).await? {
                    remove_dir(c, BOOKS).await?;
                }
            }
        }
    }
    if clean && own_link {
        io(c.remove(&link)).await?;
    }
    Ok(clean)
}

impl DeviceSession {
    async fn airlift_device(&mut self) -> Result<(String, bool)> {
        let mut ld = io(self.lockdown()).await?;
        let build = io(ld.get_value(Some("BuildVersion"), None)).await?;
        let version = io(ld.get_value(Some("ProductVersion"), None)).await?;
        let id = io(ld.get_value(Some("UniqueDeviceID"), None))
            .await?
            .into_string()
            .filter(|s| {
                (8..=64).contains(&s.len())
                    && s.bytes().all(|c| c.is_ascii_alphanumeric() || c == b'-')
            })
            .ok_or(JOURNAL_ERROR)?;
        Ok((
            id,
            super::supported_os(
                version.as_string().unwrap_or(""),
                build.as_string().unwrap_or(""),
            ),
        ))
    }
    pub(crate) async fn airlift_check(&mut self) -> Result<Value> {
        let _lock = AIRLIFT_LOCK.try_lock().map_err(|_| BUSY)?;
        self.run_airlift_check(false).await
    }
    async fn run_airlift_check(&mut self, recovery_only: bool) -> Result<Value> {
        let (id, supported) = self.airlift_device().await?;
        let journal = self
            .pairing_path
            .with_file_name(format!(".cc365-airlift-{id}.json"));
        let pending = Trial::load(&journal)?;
        let recovery = pending.is_some();
        if recovery_only && !recovery {
            return Err(JOURNAL_ERROR.into());
        }
        if !recovery && !supported {
            return Err("Phiên bản iOS này không nằm trong phạm vi AirLift đã bật.".into());
        }
        let mut c = io(self.afc()).await?;
        let mut t = if let Some(t) = pending {
            t
        } else {
            let t = Trial::new(preflight(&mut c).await?);
            for p in [
                format!("/{}", t.source()),
                format!("/{}", t.link()),
                t.readback(),
            ] {
                if stat(&mut c, &p).await?.is_some() {
                    return Err(CONFLICT.into());
                }
            }
            t.save(&journal)?;
            t
        };
        let attempt = if recovery {
            Ok(())
        } else {
            stage(self, &mut c, &mut t, &journal).await.map(|_| ())
        };
        drop(c);
        let mut message = attempt.err().unwrap_or_default();
        let mut clean = false;
        let mut books_restored =
            (t.books_snapshot && t.publish_attempted).then_some(t.books_verified);
        if let Ok(mut c) = io(self.afc()).await {
            if t.patch_parent.is_none()
                && t.sync_started.is_some()
                && !t.matched
                && read(&mut c, &t.readback()).await.ok().flatten().as_deref() == Some(&t.challenge)
            {
                t.matched = true;
                t.save(&journal)?;
            }
            if t.matched
                || t.sync_started
                    .or(t.archive_in_flight)
                    .is_none_or(|ts| now().saturating_sub(ts) >= 120)
            {
                let cleanup_timeout = Duration::from_secs(40 + t.patch_slots as u64 / 2);
                clean = tokio::time::timeout(cleanup_timeout, cleanup(&mut c, &t))
                    .await
                    .ok()
                    .and_then(|r| r.ok())
                    .unwrap_or(false);
            }
        }
        if books_restored == Some(false)
            && (t.matched
                || t.sync_started
                    .is_none_or(|ts| now().saturating_sub(ts) >= 120))
        {
            if t.books_atc_started && !t.matched && t.sync_started.is_none() {
                tokio::time::sleep(Duration::from_secs(2)).await;
            }
            if let Ok(mut c) = io(self.afc()).await {
                match airlift_books::restore(&mut c, &journal, &t).await {
                    Ok(true) => {
                        drop(c);
                        if t.books_atc_started {
                            tokio::time::sleep(Duration::from_secs(4)).await;
                        }
                        if let Ok(mut confirm) = io(self.afc()).await {
                            if airlift_books::verify(&mut confirm, &journal, &t).await == Ok(true) {
                                t.books_verified = true;
                                t.save(&journal)?;
                                books_restored = Some(true);
                            }
                        }
                    }
                    Ok(false) => {}
                    Err(error) => {
                        if !message.is_empty() {
                            message.push(' ');
                        }
                        message.push_str(&error);
                    }
                }
            }
        }
        clean &= books_restored != Some(false);
        if clean {
            if t.books_snapshot {
                airlift_books::discard(&journal, &t)?;
            }
            fs::remove_file(&journal).map_err(|_| JOURNAL_ERROR)?;
        }
        if message.is_empty() {
            message = if t.patch_parent.is_some() {
                "Đã kiểm tra lại phiên AirLift dùng cho patch."
            } else if t.matched {
                "Đã đọc lại đúng 32 byte của tệp thử qua luồng AirLift."
            } else if recovery {
                "Đã kiểm tra lại các tệp của lần thử trước."
            } else {
                "Chưa xác nhận được nội dung tệp thử."
            }
            .into();
        }
        if !clean {
            message.push_str(" CC365 đã lưu phiên này. Sau hai phút, mở lại Kiểm tra AirLift để tiếp tục khôi phục và dọn tệp.");
        }
        Ok(
            json!({"exactBytesRecovered":t.patch_parent.is_none() && t.matched,"cleanupComplete":clean,"recoveryOnly":recovery,
                  "booksRestored":books_restored,"message":message}),
        )
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    #[test]
    fn patch_reserves_only_requested_media_slots_and_dispatches_only_link_at_start() {
        let mut trial = Trial::new(true);
        trial.patch_parent = Some(
            "/var/mobile/Containers/Data/Application/12345678-1234-1234-1234-123456789ABC".into(),
        );
        trial.patch_slots = 2;
        let dispatch = trial.moves();
        assert_eq!(dispatch.len(), 1);
        let declared = trial.manifest_moves();
        assert_eq!(declared[0], dispatch[0]);
        assert_eq!(declared[1].0, format!("../../{}/patch-0-a", trial.source()));
        assert_eq!(declared[2].0, format!("../../{}/patch-1-a", trial.source()));
        let decoded: Dictionary = plist::from_bytes(&trial.manifest().unwrap()).unwrap();
        assert_eq!(decoded["Books"].as_array().unwrap().len(), 3);
    }

    #[test]
    fn template_contains_the_stored_payload_and_both_crc_headers() {
        assert_eq!(&ARCHIVE[439..443], b"PK\x03\x04");
        assert_eq!(&ARCHIVE[1009..1013], b"PK\x01\x02");
        assert_eq!(&ARCHIVE[469..476], b"payload");
        assert_eq!(&ARCHIVE[1055..1062], b"payload");
        assert_eq!(archive(&[b'0'; 32]).as_slice(), ARCHIVE);
        let b = archive(&[77; 32]);
        assert_eq!(&b[482..514], &[77; 32]);
        assert_eq!(&b[453..457], &b[1025..1029]);
    }
    #[test]
    fn populated_manifest_retains_existing_rows_and_allocates_unused_ids() {
        let t = Trial::new(true);
        let mut document = Dictionary::new();
        let mut original = Vec::new();
        for id in [Plist::Integer(1u64.into()), Plist::String("3".into())] {
            let mut r = Dictionary::new();
            r.insert("Item ID".into(), id);
            r.insert("Title".into(), "My book".into());
            original.push(Plist::Dictionary(r));
        }
        document.insert("LibraryVersion".into(), 8u64.into());
        document.insert("Books".into(), Plist::Array(original.clone()));
        let mut prior = Vec::new();
        Plist::Dictionary(document)
            .to_writer_xml(&mut prior)
            .unwrap();
        let output = session_manifest(&t, Some(&prior)).unwrap();
        let parsed = Plist::from_reader(std::io::Cursor::new(output))
            .unwrap()
            .into_dictionary()
            .unwrap();
        assert_eq!(parsed["LibraryVersion"].as_unsigned_integer(), Some(8));
        let rows = parsed["Books"].as_array().unwrap();
        assert_eq!(&rows[..2], &original);
        for ((from, _), (id, row)) in t
            .moves()
            .iter()
            .zip(["2", "4", "5"].into_iter().zip(&rows[2..]))
        {
            let row = row.as_dictionary().unwrap();
            assert_eq!(row["Item ID"].as_string(), Some(id));
            assert_eq!(row["Persistent ID"].as_string(), Some(from.as_str()));
        }
        assert_eq!(
            session_manifest(&t, Some(b"invalid")).unwrap(),
            t.manifest().unwrap()
        );
    }

    #[test]
    fn repeated_336_file_runs_keep_prior_rows_and_do_not_collide_at_the_144_boundary() {
        use std::collections::HashSet;
        let root = "/var/mobile/Containers/Data/Application/12345678-1234-1234-1234-123456789ABC";
        let plans: Vec<_> = (0..336)
            .map(|i| {
                (
                    format!("Documents/pack/row-{i:03}.bytes"),
                    format!("{i:032x}"),
                )
            })
            .collect();
        let collision = airlift_wire::ReverseMove::Evict
            .assets("00000000000000000001", root, &plans[144].0, &plans[144].1)
            .unwrap()[0]
            .0
            .clone();
        let rows = vec![
            Plist::Dictionary(
                [
                    ("Persistent ID".to_owned(), Plist::String(collision)),
                    ("Item ID".to_owned(), Plist::Integer(1u64.into())),
                    (
                        "Title".to_owned(),
                        Plist::String("Retained earlier library entry".into()),
                    ),
                ]
                .into_iter()
                .collect(),
            ),
            Plist::Dictionary(
                [
                    (
                        "Persistent ID".to_owned(),
                        Plist::String("a-real-book.epub".into()),
                    ),
                    ("Item ID".to_owned(), Plist::String("3".into())),
                    ("CustomMetadata".to_owned(), Plist::Data(vec![9u8, 8, 7])),
                ]
                .into_iter()
                .collect(),
            ),
        ];
        let prior_doc = Plist::Dictionary(
            [
                ("Books".to_owned(), Plist::Array(rows.clone())),
                ("LibraryVersion".to_owned(), 42u64.into()),
            ]
            .into_iter()
            .collect(),
        );
        let mut prior = vec![];
        prior_doc.to_writer_xml(&mut prior).unwrap();
        let mut all_ids = HashSet::new();
        for run in 0..2 {
            for (batch, items) in plans.chunks(16).enumerate() {
                let mut t = Trial::new(true);
                t.token = format!("n{:020x}", 1000 + run * 100 + batch);
                t.patch_parent = Some(root.into());
                t.reverse_docs = items.to_vec();
                t.reverse_redelivery = true;
                if run == 0 {
                    t.reverse_namespaced = false;
                    assert_eq!(
                        session_manifest(&t, Some(&prior)).is_err(),
                        batch == 9,
                        "the legacy static eviction ID reproduces the 144/336 boundary"
                    );
                    t.reverse_namespaced = true;
                }
                let manifest = session_manifest(&t, Some(&prior)).unwrap();
                let parsed: Dictionary = plist::from_bytes(&manifest).unwrap();
                assert_eq!(
                    parsed["LibraryVersion"],
                    prior_doc.as_dictionary().unwrap()["LibraryVersion"]
                );
                let combined = parsed["Books"].as_array().unwrap();
                assert_eq!(&combined[..rows.len()], rows.as_slice());
                assert_eq!(combined.len(), rows.len() + 1 + 12 * items.len());
                for row in &combined[rows.len()..] {
                    let id = row.as_dictionary().unwrap()["Persistent ID"]
                        .as_string()
                        .unwrap();
                    assert!(
                        all_ids.insert(id.to_owned()),
                        "new leases cannot reuse an earlier literal ID"
                    );
                }
                assert!(session_manifest(&t, Some(&manifest)).is_err());
            }
        }
        assert_eq!(all_ids.len(), 2 * (336 * 12 + 21));
    }

    #[test]
    fn old_journals_reconstruct_legacy_ids_while_new_journals_preserve_the_namespace() {
        let root = "/var/mobile/Containers/Data/Application/12345678-1234-1234-1234-123456789ABC";
        let mut t = Trial::new(true);
        t.patch_parent = Some(root.into());
        t.reverse_docs = vec![("Documents/fixture.bytes".into(), "a".repeat(32))];
        t.reverse_redelivery = true;
        let namespaced = t.manifest().unwrap();
        let new_token = t.token.clone();
        t.token = "00000000000000000001".into();
        t.reverse_namespaced = false;
        let legacy_manifest = t.manifest().unwrap();
        let mut legacy_json = serde_json::to_value(&t).unwrap();
        legacy_json
            .as_object_mut()
            .unwrap()
            .remove("reverse_namespaced");
        let temporary = tempfile::tempdir().unwrap();
        let journal = temporary.path().join("trial.json");
        fs::write(&journal, serde_json::to_vec(&legacy_json).unwrap()).unwrap();
        let old = Trial::load(&journal).unwrap().unwrap();
        assert!(!old.reverse_namespaced);
        assert_eq!(old.manifest().unwrap(), legacy_manifest);
        assert_ne!(old.manifest().unwrap(), namespaced);
        t.reverse_namespaced = true;
        t.token = new_token;
        t.save(&journal).unwrap();
        let current = Trial::load(&journal).unwrap().unwrap();
        assert!(current.reverse_namespaced);
        assert_eq!(current.manifest().unwrap(), namespaced);
        assert!(
            !(current.token.len() == 20
                && current
                    .token
                    .bytes()
                    .all(|b| b.is_ascii_digit() || (b'a'..=b'f').contains(&b)))
        );
        for (token, flag) in [
            ("00000000000000000001", true),
            ("n00000000000000000001", false),
        ] {
            t.token = token.into();
            t.reverse_namespaced = flag;
            t.save(&journal).unwrap();
            assert!(
                Trial::load(&journal).is_err(),
                "mismatched namespace generation must fail closed"
            );
        }
    }
    #[test]
    fn private_journal_roundtrip_rejects_path_injection() {
        let d = tempfile::tempdir().unwrap();
        let p = d.path().join("journal");
        let mut t = Trial::new(false);
        t.save(&p).unwrap();
        let loaded = Trial::load(&p).unwrap().unwrap();
        assert_eq!(t.challenge, loaded.challenge);
        assert_eq!(loaded.moves()[2].0, format!("../../../../tmp/{}", t.leaf()));
        let plist = Plist::from_reader(std::io::Cursor::new(t.manifest().unwrap())).unwrap();
        assert_eq!(
            plist.as_dictionary().unwrap()["Books"]
                .as_array()
                .unwrap()
                .len(),
            3
        );
        t.token = "../foreign".into();
        t.save(&p).unwrap();
        assert!(Trial::load(&p).is_err());
    }
}

#[cfg(test)]
#[path = "airlift_cases.rs"]
mod airlift_cases;
