use super::*;
use crate::sync::SyncControl;

const SEND_WINDOW: Duration = Duration::from_secs(45);
const ARRIVAL_WINDOW: Duration = Duration::from_secs(15);

struct Member<'a> {
    rel: &'a str,
    key: &'a str,
    held: Option<(&'a str, &'a str)>,
}

trait WaveIo {
    fn arm(&mut self) -> Result<()>;
    fn disarm(&mut self) -> Result<()>;
    fn check(&self) -> Result<()>;
    async fn ready(&mut self, index: usize) -> Result<bool>;
    async fn send(&mut self, index: usize) -> Result<()>;
    async fn arrived(&mut self, index: usize) -> Result<bool>;
    fn finish(&mut self) -> Result<()>;
}

async fn run_wave(io: &mut impl WaveIo, count: usize) -> Result<GroupDelivery> {
    if !(1..=MAX_GROUP_HANDOFFS).contains(&count) {
        return Err(CONFLICT.into());
    }
    io.check()?;
    io.arm()?;
    let mut attempted = false;
    let dispatch = tokio::time::timeout(SEND_WINDOW, async {
        for index in 0..count {
            io.check()?;
            if !io.ready(index).await? {
                return Ok(index);
            }
            attempted = true;
            io.send(index).await?;
        }
        Ok(count)
    })
    .await
    .unwrap_or_else(|_| Err(WAIT.into()));
    let sent = match dispatch {
        Ok(0) => {
            io.disarm()?;
            return Ok(GroupDelivery::Individual);
        }
        Ok(sent) => sent,
        Err(error) => {
            if !attempted {
                io.disarm()?;
            }
            return Err(error);
        }
    };
    let mut ended = tokio::time::Instant::now() + ARRIVAL_WINDOW;
    let mut complete = [false; MAX_GROUP_HANDOFFS];
    while complete[..sent].iter().any(|seen| !seen) {
        for (index, seen) in complete[..sent].iter_mut().enumerate() {
            if *seen {
                continue;
            }
            io.check()?;
            *seen = tokio::time::timeout_at(ended, io.arrived(index))
                .await
                .map_err(|_| WAIT)??;
            if *seen {
                ended = tokio::time::Instant::now() + ARRIVAL_WINDOW;
            }
        }
        if complete[..sent].iter().any(|seen| !seen) {
            wait_poll(ended).await?;
        }
    }
    io.finish()?;
    Ok(if sent == count {
        GroupDelivery::Complete
    } else {
        GroupDelivery::Prefix(sent)
    })
}

struct LiveWave<'a, 'names> {
    link: &'a mut PatchLink,
    members: &'a [Member<'names>],
    ctl: &'a SyncControl,
    trial: Trial,
    prior_sync: Option<u64>,
    direction: ReverseMove,
}
impl LiveWave<'_, '_> {
    fn cargo_place(&self) -> Place {
        match self.direction {
            ReverseMove::Export | ReverseMove::Return => Place::Held,
            ReverseMove::Evict | ReverseMove::Install => Place::Stage,
            _ => unreachable!("only validated file moves enter a wave"),
        }
    }
}

impl WaveIo for LiveWave<'_, '_> {
    fn arm(&mut self) -> Result<()> {
        self.trial.matched = false;
        self.trial.sync_started = Some(now().saturating_add(SEND_WINDOW.as_secs()));
        self.trial.save(&self.link.journal)
    }
    fn disarm(&mut self) -> Result<()> {
        self.trial.matched = true;
        self.trial.sync_started = self.prior_sync;
        self.trial.save(&self.link.journal)
    }
    fn check(&self) -> Result<()> {
        self.ctl.check().map_err(|_| WAIT.to_owned())
    }
    async fn ready(&mut self, index: usize) -> Result<bool> {
        let item = &self.members[index];
        self.link.select_reverse_doc(item.rel, item.key)?;
        let place = self.cargo_place();
        let Some((cargo, witness)) = item.held else {
            return self.link.reverse_transfer_out_ready(place).await;
        };
        self.link.verify().await?;
        let target = self.link.reverse_target_path()?;
        self.link.check_document_parents(&target).await?;
        if self.link.witness_at(place, Some(witness)).await?.as_deref() != Some(witness)
            || self
                .link
                .reverse_opaque_cargo_witness(matches!(place, Place::Held))
                .await?
                .as_deref()
                != Some(cargo)
        {
            return Ok(false);
        }
        Ok(observe(&mut self.link.afc, &target).await? == Observation::Absent)
    }
    async fn send(&mut self, index: usize) -> Result<()> {
        let item = &self.members[index];
        self.link
            .channel
            .as_mut()
            .ok_or(ACCESS)?
            .reverse_move(
                self.direction,
                &self.link.token,
                &self.link.absolute_root,
                item.rel,
                item.key,
            )
            .await?;
        self.ctl.log(match self.direction {
            ReverseMove::Export => "AirLift group: export frame sent.",
            ReverseMove::Return => "AirLift group: return frame sent.",
            ReverseMove::Install => "AirLift group: install frame sent.",
            ReverseMove::Evict => "AirLift group: verify-out frame sent.",
            _ => unreachable!("only validated file moves enter a wave"),
        });
        Ok(())
    }
    async fn arrived(&mut self, index: usize) -> Result<bool> {
        let item = &self.members[index];
        self.link.select_reverse_doc(item.rel, item.key)?;
        let returning = item.held.is_some();
        let (afc, path) = self.link.client_path(self.cargo_place())?;
        let state = observe(afc, &path).await?;
        if state
            != if returning {
                Observation::Absent
            } else {
                Observation::Visible
            }
        {
            return Ok(false);
        }
        Ok(self.link.target_present(Target::Protected).await? == returning)
    }
    fn finish(&mut self) -> Result<()> {
        observed(self.link, &mut self.trial)
    }
}

impl DeviceSession {
    pub(crate) async fn export_compared_group(
        &mut self,
        link: &mut PatchLink,
        rows: &[(String, String)],
    ) -> Result<GroupDelivery> {
        let members: Vec<_> = rows
            .iter()
            .map(|(rel, key)| Member {
                rel,
                key,
                held: None,
            })
            .collect();
        self.deliver_protected_group(link, ReverseMove::Export, &members)
            .await
    }
    pub(crate) async fn return_equal_group(
        &mut self,
        link: &mut PatchLink,
        rows: &[(String, String, String, String)],
    ) -> Result<GroupDelivery> {
        let members: Vec<_> = rows
            .iter()
            .map(|(rel, key, cargo, witness)| Member {
                rel,
                key,
                held: Some((cargo, witness)),
            })
            .collect();
        self.deliver_protected_group(link, ReverseMove::Return, &members)
            .await
    }

    pub(crate) async fn export_changed_group(
        &mut self,
        link: &mut PatchLink,
        rows: &[(String, String)],
    ) -> Result<GroupDelivery> {
        let members: Vec<_> = rows
            .iter()
            .map(|(rel, key)| Member {
                rel,
                key,
                held: None,
            })
            .collect();
        self.deliver_protected_group(link, ReverseMove::Evict, &members)
            .await
    }
    pub(crate) async fn return_changed_group(
        &mut self,
        link: &mut PatchLink,
        rows: &[(String, String, String, String)],
    ) -> Result<GroupDelivery> {
        let members: Vec<_> = rows
            .iter()
            .map(|(rel, key, cargo, witness)| Member {
                rel,
                key,
                held: Some((cargo, witness)),
            })
            .collect();
        self.deliver_protected_group(link, ReverseMove::Install, &members)
            .await
    }

    async fn deliver_protected_group(
        &mut self,
        link: &mut PatchLink,
        direction: ReverseMove,
        members: &[Member<'_>],
    ) -> Result<GroupDelivery> {
        if !(1..=MAX_GROUP_HANDOFFS).contains(&members.len()) {
            return Err(CONFLICT.into());
        }
        let mut names = Vec::with_capacity(members.len());
        let mut keys = HashSet::new();
        for item in members {
            link.select_reverse_doc(item.rel, item.key)?;
            if !keys.insert(item.key) {
                return Err(CONFLICT.into());
            }
            if !item.rel.is_ascii() {
                return Ok(GroupDelivery::Individual);
            }
            let name = item.rel.to_ascii_lowercase();
            if names.iter().any(|other: &String| {
                name == *other
                    || name
                        .strip_prefix(other)
                        .is_some_and(|rest| rest.starts_with('/'))
                    || other
                        .strip_prefix(&name)
                        .is_some_and(|rest| rest.starts_with('/'))
            }) {
                return Ok(GroupDelivery::Individual);
            }
            names.push(name);
            if let Some((cargo, witness)) = item.held {
                if !witness.starts_with("sha1:") || !cargo.starts_with("object:") {
                    return Ok(GroupDelivery::Individual);
                }
            }
            link.channel.as_ref().ok_or(ACCESS)?.next_reverse_frame(
                direction,
                &link.token,
                &link.absolute_root,
                item.rel,
                item.key,
            )?;
        }
        let trial = Trial::load(&link.journal)?.ok_or(JOURNAL_ERROR)?;
        if trial.token != link.token
            || trial.patch_parent.as_deref() != Some(&link.absolute_root)
            || trial.reverse_docs != link.reverse_docs
            || !trial.matched
        {
            return Err(WAIT.into());
        }
        link.verify().await?;
        let prior_sync = trial.sync_started;
        let mut wave = LiveWave {
            link,
            members,
            ctl: &self.control,
            trial,
            prior_sync,
            direction,
        };
        run_wave(&mut wave, members.len()).await
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[tokio::test]
    async fn live_guard_binds_generated_cargo_hash_route_and_exact_vacancy_for_each_frame() {
        use crate::device::airlift::airlift_cases::{Node, Tree, memory};
        use sha1::Digest;
        use std::sync::{Arc, atomic::AtomicBool};
        let key = "1".repeat(32);
        let rel = "Documents/pack/first";
        let held = format!("/cc365-held-{key}");
        let stage = format!("/cc365-put-{key}");
        let mut base = Tree::from([
            ("/link".into(), Node::Link("/fixture")),
            ("/link/Documents".into(), Node::Dir),
            ("/link/Documents/pack".into(), Node::Dir),
        ]);
        let correct = format!("sha1:{:x}:4", sha1::Sha1::digest(b"okay"));
        let other = format!("sha1:{:x}:4", sha1::Sha1::digest(b"oops"));
        let control = SyncControl::new(Arc::new(AtomicBool::new(false)), Arc::new(|_| {}));
        for (direction, cargo_path) in
            [(ReverseMove::Return, &held), (ReverseMove::Install, &stage)]
        {
            for (wrong_hash, wrong_cargo, occupied) in [
                (false, false, false),
                (true, false, false),
                (false, true, false),
                (false, false, true),
            ] {
                let mut tree = base.clone();
                tree.insert(cargo_path.clone(), Node::IdentifiedFile(b"okay".to_vec()));
                if occupied {
                    tree.insert(
                        format!("/link/{rel}"),
                        Node::Status(AfcError::PermDenied as u64),
                    );
                }
                let (afc, _server) = memory(tree);
                let mut link = PatchLink::fixture_documents(afc, rel).await;
                let cargo = PatchLink::reverse_cargo_witness_on(&mut link.afc, cargo_path)
                    .await
                    .unwrap()
                    .unwrap();
                if cargo_path == &held {
                    assert_eq!(
                        PatchLink::reverse_verified_held_witness(&mut link.afc, cargo_path, None)
                            .await
                            .unwrap()
                            .as_deref(),
                        Some(correct.as_str())
                    );
                    assert!(
                        PatchLink::reverse_verified_stage_witness(&mut link.afc, cargo_path, None)
                            .await
                            .is_err()
                    );
                } else {
                    assert!(
                        PatchLink::reverse_verified_held_witness(&mut link.afc, cargo_path, None)
                            .await
                            .is_err()
                    );
                }
                let members = [Member {
                    rel,
                    key: &key,
                    held: Some((
                        if wrong_cargo { "object:wrong" } else { &cargo },
                        if wrong_hash { &other } else { &correct },
                    )),
                }];
                let mut wave = LiveWave {
                    link: &mut link,
                    members: &members,
                    ctl: &control,
                    trial: Trial::new(false),
                    prior_sync: None,
                    direction,
                };
                assert_eq!(
                    wave.ready(0).await.unwrap(),
                    !(wrong_hash || wrong_cargo || occupied)
                );
            }
        }
        base.insert(
            format!("/link/{rel}"),
            Node::Status(AfcError::PermDenied as u64),
        );
        base.insert(held.clone(), Node::IdentifiedFile(b"foreign".to_vec()));
        let (afc, _server) = memory(base);
        let mut link = PatchLink::fixture_documents(afc, rel).await;
        let members = [Member {
            rel,
            key: &key,
            held: None,
        }];
        let mut wave = LiveWave {
            link: &mut link,
            members: &members,
            ctl: &control,
            trial: Trial::new(false),
            prior_sync: None,
            direction: ReverseMove::Export,
        };
        assert!(!wave.ready(0).await.unwrap());
        wave.direction = ReverseMove::Evict;
        assert!(wave.ready(0).await.unwrap());
    }

    #[derive(Default)]
    struct Mock {
        armed: bool,
        synced: bool,
        refuse_at: Option<usize>,
        write_error: Option<usize>,
        ack_error: Option<usize>,
        failure_before_frame: Option<usize>,
        first_ack_deferred: bool,
        frames: Vec<usize>,
        checked: Vec<usize>,
        observed: Vec<usize>,
    }
    impl WaveIo for Mock {
        fn arm(&mut self) -> Result<()> {
            assert!(!self.armed);
            self.armed = true;
            Ok(())
        }
        fn disarm(&mut self) -> Result<()> {
            assert!(self.frames.is_empty());
            self.armed = false;
            Ok(())
        }
        fn check(&self) -> Result<()> {
            Ok(())
        }
        async fn ready(&mut self, index: usize) -> Result<bool> {
            assert!(self.armed);
            self.checked.push(index);
            if self.failure_before_frame == Some(index) {
                return Err("AFC disconnected".into());
            }
            Ok(self.refuse_at != Some(index))
        }
        async fn send(&mut self, index: usize) -> Result<()> {
            assert_eq!(self.checked.last(), Some(&index));
            self.frames.push(index);
            if self.write_error == Some(index) {
                return Err("frame write interrupted".into());
            }
            Ok(())
        }
        async fn arrived(&mut self, index: usize) -> Result<bool> {
            assert!(self.armed && self.frames.contains(&index));
            if self.ack_error == Some(index) {
                return Err("AFC disconnected".into());
            }
            if self.first_ack_deferred && index == 0 && self.observed.is_empty() {
                self.first_ack_deferred = false;
                return Ok(false);
            }
            self.observed.push(index);
            Ok(true)
        }
        fn finish(&mut self) -> Result<()> {
            let mut acked = self.observed.clone();
            acked.sort();
            assert_eq!(self.frames, acked);
            self.synced = true;
            self.armed = false;
            Ok(())
        }
    }

    #[tokio::test]
    async fn guarded_group_settles_exactly_confirmed_prefix_and_keeps_partial_writes_pending() {
        for index in 0..=MAX_GROUP_HANDOFFS {
            let mut io = Mock {
                refuse_at: Some(index),
                first_ack_deferred: true,
                ..Default::default()
            };
            let result = run_wave(&mut io, MAX_GROUP_HANDOFFS).await.unwrap();
            let expected = if index == 0 {
                GroupDelivery::Individual
            } else if index == MAX_GROUP_HANDOFFS {
                GroupDelivery::Complete
            } else {
                GroupDelivery::Prefix(index)
            };
            assert_eq!(result, expected);
            assert_eq!(io.frames, (0..index).collect::<Vec<_>>());
            assert!(!io.armed);
            assert_eq!(io.synced, index > 0);
        }
        for index in 0..MAX_GROUP_HANDOFFS {
            let mut io = Mock {
                write_error: Some(index),
                ..Default::default()
            };
            assert!(run_wave(&mut io, MAX_GROUP_HANDOFFS).await.is_err());
            assert!(io.armed && !io.synced);
            assert_eq!(io.frames, (0..=index).collect::<Vec<_>>());
            let mut io = Mock {
                ack_error: Some(index),
                ..Default::default()
            };
            assert!(run_wave(&mut io, MAX_GROUP_HANDOFFS).await.is_err());
            assert!(io.armed && !io.synced);
            let mut io = Mock {
                failure_before_frame: Some(index),
                ..Default::default()
            };
            assert!(run_wave(&mut io, MAX_GROUP_HANDOFFS).await.is_err());
            assert_eq!(io.armed, index > 0);
        }
        let mut io = Mock::default();
        assert!(run_wave(&mut io, MAX_GROUP_HANDOFFS + 1).await.is_err());
        assert!(!io.armed && io.frames.is_empty());
    }
}
