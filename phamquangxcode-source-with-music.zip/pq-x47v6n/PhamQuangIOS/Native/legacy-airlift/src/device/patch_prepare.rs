use super::*;
use std::{
    os::unix::fs::MetadataExt,
    sync::{
        Arc,
        atomic::{AtomicBool, AtomicUsize, Ordering},
    },
};
use tokio::task::JoinSet;

pub(super) const WORKERS: usize = 3;
const SOURCE_MISSING: &str = "Tệp nguồn đã di chuyển, không đọc được hoặc không phải tệp thường.";
const SOURCE_CHANGED: &str = "Tệp nguồn đã thay đổi trong lúc chuẩn bị.";
const SOURCE_LARGE: &str = "Tệp nguồn vượt giới hạn 128 MiB.";
const STOPPED: &str = "Đã dừng chuẩn bị patch.";

#[derive(PartialEq, Eq)]
struct Identity {
    dev: u64,
    ino: u64,
    len: u64,
    mtime: (i64, i64),
    ctime: (i64, i64),
}

impl From<fs::Metadata> for Identity {
    fn from(m: fs::Metadata) -> Self {
        Self {
            dev: m.dev(),
            ino: m.ino(),
            len: m.len(),
            mtime: (m.mtime(), m.mtime_nsec()),
            ctime: (m.ctime(), m.ctime_nsec()),
        }
    }
}

struct Source {
    path: PathBuf,
    identity: Identity,
}

#[derive(Clone, Debug, PartialEq, Eq)]
pub(super) enum Prepared {
    Ready(Stamp),
    Unavailable(&'static str),
}

pub(super) struct Sources {
    files: Vec<std::result::Result<Source, &'static str>>,
    pub(super) bytes: u64,
}

impl Sources {
    pub(super) async fn inspect(
        items: &[PatchItem],
        available: u64,
        ctl: &SyncControl,
    ) -> Result<Self> {
        let paths = items.iter().map(|item| item.local_path.clone()).collect();
        let control = ctl.clone();
        tokio::task::spawn_blocking(move || {
            Self::inventory(paths, available, &std::env::temp_dir(), &control)
        })
        .await
        .map_err(|_| DISK)?
    }

    fn inventory(
        paths: Vec<PathBuf>,
        available: u64,
        temp: &Path,
        ctl: &SyncControl,
    ) -> Result<Self> {
        let mut files = Vec::with_capacity(paths.len());
        let mut bytes = 0;
        for path in paths {
            ctl.check().map_err(|_| STOPPED)?;
            if !crate::bridge::valid_transfer_path(&path, temp) {
                return Err(INVALID.into());
            }
            let input = match Source::open(&path) {
                Ok(file) => file,
                Err(reason) if reason == SOURCE_MISSING => {
                    files.push(Err(SOURCE_MISSING));
                    continue;
                }
                Err(error) => return Err(error),
            };
            let identity = Identity::from(input.metadata().map_err(|_| DISK)?);
            if identity.len > MAX_FILE {
                files.push(Err(SOURCE_LARGE));
                continue;
            }
            if identity.len > MAX_TOTAL - bytes {
                return Err(LIMIT.into());
            }
            bytes += identity.len;
            if bytes > available {
                return Err(DISK.into());
            }
            files.push(Ok(Source { path, identity }));
        }
        Ok(Self { files, bytes })
    }

    pub(super) async fn stage(
        self,
        slot: &Path,
        control: &SyncControl,
        stop: Arc<AtomicBool>,
        workers: usize,
    ) -> Result<Vec<Prepared>> {
        let files = Arc::new(self.files);
        let next = Arc::new(AtomicUsize::new(0));
        let mut jobs = JoinSet::new();
        for _ in 0..files.len().min(workers.clamp(1, WORKERS)) {
            let (files, next, stop) = (files.clone(), next.clone(), stop.clone());
            let (slot, ctl) = (slot.to_owned(), control.clone());
            jobs.spawn_blocking(move || -> Result<Vec<(usize, Prepared)>> {
                let mut ready = vec![];
                while !stop.load(Ordering::Acquire) {
                    let index = next.fetch_add(1, Ordering::Relaxed);
                    let Some(source) = files.get(index) else {
                        break;
                    };
                    ctl.check().map_err(|_| STOPPED)?;
                    let source = match source {
                        Ok(source) => source,
                        Err(reason) => {
                            ready.push((index, Prepared::Unavailable(reason)));
                            continue;
                        }
                    };
                    match source.copy(&artifact(&slot, index, false)) {
                        Ok(stamp) => ready.push((index, Prepared::Ready(stamp))),
                        Err(reason) if reason == SOURCE_MISSING => {
                            ready.push((index, Prepared::Unavailable(SOURCE_MISSING)))
                        }
                        Err(reason) if reason == SOURCE_CHANGED => {
                            ready.push((index, Prepared::Unavailable(SOURCE_CHANGED)))
                        }
                        Err(error) => {
                            stop.store(true, Ordering::Release);
                            return Err(error);
                        }
                    }
                }
                Ok(ready)
            });
        }
        let mut stamps = vec![None; files.len()];
        let mut failure = None;
        while let Some(joined) = jobs.join_next().await {
            match joined.unwrap_or_else(|_| Err(DISK.into())) {
                Ok(done) => {
                    for (index, stamp) in done {
                        stamps[index] = Some(stamp);
                    }
                }
                Err(error) => {
                    stop.store(true, Ordering::Release);
                    failure.get_or_insert(error);
                }
            }
        }
        if let Some(error) = failure {
            return Err(error);
        }
        stamps
            .into_iter()
            .collect::<Option<_>>()
            .ok_or_else(|| STOPPED.into())
    }
}

impl Source {
    fn open(path: &Path) -> Result<File> {
        let file = OpenOptions::new()
            .read(true)
            .custom_flags(libc::O_NOFOLLOW | libc::O_NONBLOCK)
            .open(path)
            .map_err(|error| match error.kind() {
                std::io::ErrorKind::NotFound | std::io::ErrorKind::PermissionDenied => {
                    SOURCE_MISSING
                }
                _ if error.raw_os_error() == Some(libc::ELOOP) => SOURCE_MISSING,
                _ => DISK,
            })?;
        if !file.metadata().map_err(|_| DISK)?.is_file() {
            return Err(SOURCE_MISSING.into());
        }
        Ok(file)
    }

    fn copy(&self, destination: &Path) -> Result<Stamp> {
        let source = Self::open(&self.path)?;
        let identity = || source.metadata().map(Identity::from).map_err(|_| DISK);
        if identity()? != self.identity {
            return Err(SOURCE_CHANGED.into());
        }
        let mut out = new_file(destination)?;
        let stamp = io::local_copy((&source).take(self.identity.len + 1), &mut out)?;
        if stamp.len != self.identity.len || identity()? != self.identity {
            drop(out);
            fs::remove_file(destination).map_err(|_| DISK)?;
            return Err(SOURCE_CHANGED.into());
        }
        out.sync_all().map_err(|_| DISK)?;
        Ok(stamp)
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    use std::time::Instant;

    fn control() -> SyncControl {
        SyncControl::new(Arc::new(AtomicBool::new(false)), Arc::new(|_| {}))
    }

    fn import_dir(temp: &Path) -> PathBuf {
        let dir = temp.join("CC365-Files/01234567-89ab-cdef-0123-456789abcdef");
        fs::create_dir_all(&dir).unwrap();
        dir
    }

    #[tokio::test]
    async fn parallel_stamps_and_copies_follow_input_indices() {
        let temp = tempfile::tempdir().unwrap();
        let imports = import_dir(temp.path());
        let slot = tempfile::tempdir().unwrap();
        let payloads: Vec<_> = [64_001, 1, 131_073, 0, 2048, 17_011, 61]
            .iter()
            .enumerate()
            .map(|(i, &len)| vec![i as u8; len])
            .collect();
        let paths = payloads
            .iter()
            .enumerate()
            .map(|(i, data)| {
                let path = imports.join(i.to_string());
                fs::write(&path, data).unwrap();
                path
            })
            .collect();
        let source = Sources::inventory(paths, MAX_TOTAL, temp.path(), &control()).unwrap();
        let ready = source
            .stage(
                slot.path(),
                &control(),
                Arc::new(AtomicBool::new(false)),
                WORKERS,
            )
            .await
            .unwrap();
        for (index, bytes) in payloads.iter().enumerate() {
            assert_eq!(
                ready[index],
                Prepared::Ready(io::local_copy(&bytes[..], std::io::sink()).unwrap())
            );
            assert_eq!(
                fs::read(artifact(slot.path(), index, false)).unwrap(),
                *bytes
            );
        }
    }

    #[tokio::test]
    async fn disk_exhaustion_stops_but_missing_and_replaced_inputs_spare_valid_siblings() {
        let temp = tempfile::tempdir().unwrap();
        let imports = import_dir(temp.path());
        let slot = tempfile::tempdir().unwrap();
        let path = imports.join("first");
        fs::write(&path, b"original").unwrap();
        let second = imports.join("second");
        fs::write(&second, b"123").unwrap();
        assert!(
            matches!(Sources::inventory(vec![path.clone(), second], 10, temp.path(), &control()), Err(e) if e == DISK)
        );
        let valid = imports.join("valid");
        fs::write(&valid, b"sibling").unwrap();
        let source = Sources::inventory(
            vec![path.clone(), imports.join("absent"), valid],
            MAX_TOTAL,
            temp.path(),
            &control(),
        )
        .unwrap();
        let other = imports.join("other");
        fs::write(&other, b"replaced").unwrap();
        fs::rename(&other, &path).unwrap();
        let result = source
            .stage(
                slot.path(),
                &control(),
                Arc::new(AtomicBool::new(false)),
                WORKERS,
            )
            .await;
        let mut result = result.unwrap().into_iter();
        assert_eq!(result.next(), Some(Prepared::Unavailable(SOURCE_CHANGED)));
        assert_eq!(result.next(), Some(Prepared::Unavailable(SOURCE_MISSING)));
        assert!(matches!(result.next(), Some(Prepared::Ready(_))));
        assert_eq!(fs::read_dir(slot.path()).unwrap().count(), 1);
    }

    #[tokio::test]
    #[ignore = "release benchmark for 1 versus 3 local prepare workers on the host"]
    async fn local_preparation_benchmark() {
        let temp = tempfile::tempdir().unwrap();
        let imports = import_dir(temp.path());
        let block: Vec<u8> = (0..65536).map(|i| (i % 251) as u8).collect();
        for (files, bytes) in [(64, 1_572_864), (12, 8_388_608)] {
            let paths: Vec<_> = (0..files)
                .map(|i| {
                    let path = imports.join(i.to_string());
                    let mut output = File::create(&path).unwrap();
                    for _ in 0..bytes / block.len() {
                        output.write_all(&block).unwrap();
                    }
                    output.sync_all().unwrap();
                    path
                })
                .collect();
            let mut samples = [Vec::new(), Vec::new()];
            let mut expected = None;
            for round in 0..6 {
                let order = if round % 2 == 0 {
                    [1, WORKERS]
                } else {
                    [WORKERS, 1]
                };
                for workers in order {
                    let slot = tempfile::tempdir().unwrap();
                    let start = Instant::now();
                    let sources =
                        Sources::inventory(paths.clone(), MAX_TOTAL, temp.path(), &control())
                            .unwrap();
                    let stamps = sources
                        .stage(
                            slot.path(),
                            &control(),
                            Arc::new(AtomicBool::new(false)),
                            workers,
                        )
                        .await
                        .unwrap();
                    let elapsed = start.elapsed();
                    assert_eq!(fs::read_dir(slot.path()).unwrap().count(), files);
                    assert_eq!(stamps, *expected.get_or_insert_with(|| stamps.clone()));
                    if round > 0 {
                        samples[usize::from(workers != 1)].push(elapsed.as_secs_f64() * 1000.0);
                    }
                }
            }
            for s in &mut samples {
                s.sort_by(|a, b| a.total_cmp(b));
            }
            println!(
                "local prep {files} files × {bytes} bytes: 1 worker {:?} ms; {WORKERS} workers {:?} ms; median speedup {:.2}x",
                samples[0],
                samples[1],
                samples[0][2] / samples[1][2]
            );
        }
    }
}
