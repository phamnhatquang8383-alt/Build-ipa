use super::{
    AFC_ERROR, AfcClient, AfcFopenMode, AfcOpcode, JOURNAL_ERROR, Result, Trial, close_handle, dir,
    empty, io, kind, known_parents, open_handle, stat,
};
use serde::{Deserialize, Serialize};
use sha2::{Digest, Sha256};
use std::{
    fs,
    io::{Read, Write},
    os::unix::fs::{DirBuilderExt, OpenOptionsExt},
    path::{Path, PathBuf},
};

const DIRS: [&str; 3] = ["/Books", "/Books/Sync", "/Books/Sync/Database"];
const PATHS: [&str; 6] = [
    "/Books/Books.plist",
    "/Books/Sync/Books.plist",
    "/Books/Sync/Upload.plist",
    "/Books/Sync/Database/OutstandingAssets_4.sqlite",
    "/Books/Sync/Database/OutstandingAssets_4.sqlite-shm",
    "/Books/Sync/Database/OutstandingAssets_4.sqlite-wal",
];
const MANIFEST: usize = 1;
const READ_BLOCK: usize = 16 * 1024;
const BLOCK: usize = 64 * 1024;
const MAX_FILE: u64 = 128 * 1024 * 1024;
const MAX_TOTAL: u64 = 256 * 1024 * 1024;
const CHANGED: &str = "Dữ liệu Sách đang thay đổi. Hãy đóng Sách và thử lại.";
const LARGE: &str = "Dữ liệu đồng bộ Sách vượt dung lượng sao lưu cho phép.";
const UNEXPECTED: &str = "Loại tệp đồng bộ Sách không hợp lệ.";

#[derive(Clone, PartialEq, Eq, Debug, Serialize, Deserialize)]
struct Stamp {
    len: u64,
    hash: [u8; 32],
}
impl Stamp {
    fn bytes(data: &[u8]) -> Self {
        Self {
            len: data.len() as u64,
            hash: Sha256::digest(data).into(),
        }
    }
}
#[derive(Serialize, Deserialize)]
struct Snapshot {
    owner: [u8; 32],
    dirs: [bool; 3],
    files: [Option<Stamp>; 6],
}

fn local_root(journal: &Path, t: &Trial) -> PathBuf {
    journal.with_file_name(format!(".cc365-books-{}", t.token))
}
fn original(root: &Path, i: usize) -> PathBuf {
    root.join(format!("original-{i}"))
}
fn temporary(t: &Trial, i: usize) -> String {
    let (parent, _) = PATHS[i].rsplit_once('/').unwrap();
    format!("{parent}/.cc365-airlift-{}-{i}.tmp", t.token)
}
fn local<T>(r: std::io::Result<T>) -> Result<T> {
    r.map_err(|_| JOURNAL_ERROR.to_owned())
}
fn checked_root(root: &Path) -> Result<bool> {
    match fs::symlink_metadata(root) {
        Ok(m) if m.is_dir() => Ok(true),
        Err(e) if e.kind() == std::io::ErrorKind::NotFound => Ok(false),
        _ => Err(JOURNAL_ERROR.into()),
    }
}
fn private_file(path: &Path, new: bool) -> Result<fs::File> {
    let mut opt = fs::OpenOptions::new();
    opt.custom_flags(libc::O_NOFOLLOW | libc::O_NONBLOCK)
        .mode(0o600);
    if new {
        opt.create_new(true).write(true);
    } else {
        opt.read(true);
    }
    let f = local(opt.open(path))?;
    if !local(f.metadata())?.is_file() {
        return Err(JOURNAL_ERROR.into());
    }
    Ok(f)
}
fn sync_dir(path: &Path) -> Result<()> {
    local(fs::File::open(path).and_then(|f| f.sync_all()))
}
fn load(root: &Path, t: &Trial) -> Result<Snapshot> {
    if !checked_root(root)? {
        return Err(JOURNAL_ERROR.into());
    }
    let mut f = private_file(&root.join("snapshot.json"), false)?;
    if local(f.metadata())?.len() > 8192 {
        return Err(JOURNAL_ERROR.into());
    }
    let data: Snapshot = serde_json::from_reader(&mut f).map_err(|_| JOURNAL_ERROR)?;
    if data.owner != t.challenge {
        return Err(JOURNAL_ERROR.into());
    }
    Ok(data)
}
fn manifest(root: &Path, t: &Trial, state: &Snapshot) -> Result<Vec<u8>> {
    let prior = match &state.files[MANIFEST] {
        Some(s) if s.len <= 8 * 1024 * 1024 => {
            let mut f = private_file(&original(root, MANIFEST), false)?;
            let mut bytes = Vec::new();
            local(
                std::io::Read::by_ref(&mut f)
                    .take(s.len + 1)
                    .read_to_end(&mut bytes),
            )?;
            if Stamp::bytes(&bytes) != *s {
                return Err(JOURNAL_ERROR.into());
            }
            Some(bytes)
        }
        _ => None,
    };
    super::session_manifest(t, prior.as_deref())
}
fn digest(reader: &mut impl Read) -> Result<Stamp> {
    let mut h = Sha256::new();
    let mut block = vec![0; BLOCK];
    let mut len = 0;
    loop {
        let n = local(reader.read(&mut block))?;
        if n == 0 {
            break;
        }
        len += n as u64;
        if len > MAX_FILE {
            return Err(LARGE.into());
        }
        h.update(&block[..n]);
    }
    Ok(Stamp {
        len,
        hash: h.finalize().into(),
    })
}
async fn remote(
    c: &mut AfcClient,
    path: &str,
    out: Option<&mut fs::File>,
) -> Result<Option<Stamp>> {
    remote_limited(c, path, out, MAX_FILE).await
}
async fn remote_limited(
    c: &mut AfcClient,
    path: &str,
    mut out: Option<&mut fs::File>,
    remaining_budget: u64,
) -> Result<Option<Stamp>> {
    if !known_parents(c, path).await? {
        return Ok(None);
    }
    let Some(info) = stat(c, path).await? else {
        return Ok(None);
    };
    if kind(&info) != "S_IFREG" {
        return Err(UNEXPECTED.into());
    }
    let len = info
        .get("st_size")
        .and_then(|n| n.parse::<u64>().ok())
        .ok_or(AFC_ERROR)?;
    if len > MAX_FILE || len > remaining_budget {
        return Err(LARGE.into());
    }
    let handle = io(open_handle(c, path, AfcFopenMode::RdOnly)).await?;
    let mut h = Sha256::new();
    let mut left = len;
    while left != 0 {
        let count = left.min(READ_BLOCK as u64);
        let args = [handle.to_le_bytes(), count.to_le_bytes()].concat();
        let bytes = io(c.send_op(AfcOpcode::Read, args, vec![])).await?.payload;
        if bytes.is_empty() || bytes.len() as u64 > count {
            return Err(CHANGED.into());
        }
        if let Some(f) = out.as_mut() {
            local(f.write_all(&bytes))?;
        }
        h.update(&bytes);
        left -= bytes.len() as u64;
    }
    io(close_handle(c, handle)).await?;
    let after = stat(c, path).await?.ok_or(CHANGED)?;
    if kind(&after) != "S_IFREG"
        || after.get("st_size") != info.get("st_size")
        || after.get("st_mtime") != info.get("st_mtime")
    {
        return Err(CHANGED.into());
    }
    Ok(Some(Stamp {
        len,
        hash: h.finalize().into(),
    }))
}

pub(super) async fn snapshot(c: &mut AfcClient, journal: &Path, t: &Trial) -> Result<()> {
    let root = local_root(journal, t);
    local(fs::DirBuilder::new().mode(0o700).create(&root))?;
    sync_dir(root.parent().ok_or(JOURNAL_ERROR)?)?;
    let _ = reserve_history(&root, 0);
    let mut data = Snapshot {
        owner: t.challenge,
        dirs: [false; 3],
        files: Default::default(),
    };
    let mut total = 0;
    for (i, path) in DIRS.iter().enumerate() {
        if i == 0 || data.dirs[i - 1] {
            data.dirs[i] = dir(c, path).await?;
        }
    }
    for (i, path) in PATHS.iter().enumerate() {
        let p = original(&root, i);
        let mut f = private_file(&p, true)?;
        data.files[i] = remote_limited(c, path, Some(&mut f), MAX_TOTAL - total).await?;
        if let Some(stamp) = &data.files[i] {
            total += stamp.len;
            local(f.sync_all())?;
        } else {
            drop(f);
            local(fs::remove_file(p))?;
        }
    }
    let mut f = private_file(&root.join("snapshot.json"), true)?;
    serde_json::to_writer(&mut f, &data).map_err(|_| JOURNAL_ERROR)?;
    local(f.sync_all())?;
    sync_dir(&root)
}

async fn ensure_parents(c: &mut AfcClient, path: &str) -> Result<()> {
    for p in DIRS {
        if path.starts_with(&format!("{p}/")) && !dir(c, p).await? {
            io(c.mk_dir(p)).await?;
            if !dir(c, p).await? {
                return Err(AFC_ERROR.into());
            }
        }
    }
    Ok(())
}

async fn replace(
    c: &mut AfcClient,
    t: &Trial,
    i: usize,
    mut input: impl Read,
    target: &Stamp,
    previous: Option<&Stamp>,
) -> Result<()> {
    let path = PATHS[i];
    let tmp = temporary(t, i);
    ensure_parents(c, path).await?;
    if stat(c, &tmp).await?.is_some() {
        return Err(CHANGED.into());
    }
    let handle = io(open_handle(c, &tmp, AfcFopenMode::WrOnly)).await?;
    let mut block = vec![0; BLOCK];
    let mut len = 0;
    loop {
        let n = local(input.read(&mut block))?;
        if n == 0 {
            break;
        }
        len += n as u64;
        if len > target.len {
            return Err(JOURNAL_ERROR.into());
        }
        io(c.send_op(
            AfcOpcode::Write,
            handle.to_le_bytes().to_vec(),
            block[..n].to_vec(),
        ))
        .await?;
    }
    io(close_handle(c, handle)).await?;
    if len != target.len
        || remote(c, &tmp, None).await?.as_ref() != Some(target)
        || remote(c, path, None).await?.as_ref() != previous
    {
        return Err(CHANGED.into());
    }
    io(c.rename(&tmp, path)).await?;
    if remote(c, path, None).await?.as_ref() != Some(target) {
        return Err(CHANGED.into());
    }
    Ok(())
}

pub(super) async fn publish(c: &mut AfcClient, journal: &Path, t: &Trial) -> Result<()> {
    let root = local_root(journal, t);
    let original_state = load(&root, t)?;
    for (i, path) in DIRS.iter().enumerate() {
        let exists = known_parents(c, path).await? && dir(c, path).await?;
        if exists != original_state.dirs[i] {
            return Err(CHANGED.into());
        }
    }
    for (i, path) in PATHS.iter().enumerate() {
        if let Some(stamp) = &original_state.files[i] {
            if digest(&mut private_file(&original(&root, i), false)?)? != *stamp {
                return Err(JOURNAL_ERROR.into());
            }
        }
        if remote(c, path, None).await? != original_state.files[i] {
            return Err(CHANGED.into());
        }
        if known_parents(c, path).await? && stat(c, &temporary(t, i)).await?.is_some() {
            return Err(CHANGED.into());
        }
    }
    let bytes = manifest(&root, t, &original_state)?;
    let f = private_file(&root.join("intent"), true)?;
    local(f.sync_all())?;
    sync_dir(&root)?;
    replace(
        c,
        t,
        MANIFEST,
        bytes.as_slice(),
        &Stamp::bytes(&bytes),
        original_state.files[MANIFEST].as_ref(),
    )
    .await
}

fn changed_name(s: &str) -> bool {
    s.strip_prefix("changed-")
        .and_then(|rest| rest.split_once('-'))
        .is_some_and(|(index, hash)| {
            index.len() == 1
                && matches!(index.as_bytes()[0], b'0'..=b'5')
                && hash.len() == 64
                && hash
                    .bytes()
                    .all(|b| b.is_ascii_digit() || (b'a'..=b'f').contains(&b))
        })
}

fn reserve_history(root: &Path, additional: u64) -> Result<()> {
    let mut bytes = additional;
    let mut count = 1usize;
    let mut completed = Vec::new();
    let parent = root.parent().ok_or(JOURNAL_ERROR)?;
    for item in local(fs::read_dir(parent))? {
        let item = local(item)?;
        if !item
            .file_name()
            .to_str()
            .and_then(|n| n.strip_prefix(".cc365-books-"))
            .is_some_and(super::airlift_wire::valid_token)
        {
            continue;
        }
        if !local(item.file_type())?.is_dir() {
            continue;
        }
        let folder = item.path();
        let mut history = Vec::new();
        let mut completion = None;
        let mut other = false;
        for file in local(fs::read_dir(&folder))? {
            let file = local(file)?;
            if !local(file.file_type())?.is_file() {
                other = true;
                continue;
            }
            let m = local(file.metadata())?;
            let name = file.file_name();
            if name.to_str().is_some_and(changed_name) {
                bytes = bytes.saturating_add(m.len());
                count = count.saturating_add(1);
                history.push((file.path(), m.len()));
            } else if name == "complete" && m.len() == 0 {
                completion = Some(local(m.modified())?);
            } else {
                other = true;
            }
        }
        if let Some(stamp) = completion {
            if !other && folder != root {
                completed.push((stamp, folder, history));
            }
        }
    }
    completed.sort_unstable_by_key(|(stamp, _, _)| *stamp);
    for (stamp, dir, files) in completed {
        if bytes <= MAX_TOTAL
            && count <= 96
            && stamp.elapsed().unwrap_or_default().as_secs() < 7 * 86400
        {
            break;
        }
        for (file, size) in files {
            local(fs::remove_file(file))?;
            bytes -= size;
            count -= 1;
        }
        local(fs::remove_file(dir.join("complete")))?;
        local(fs::remove_dir(dir))?;
    }
    if bytes > MAX_TOTAL || count > 96 {
        return Err("Chưa đủ chỗ để bảo toàn bản sao dữ liệu Sách.".into());
    }
    Ok(())
}

async fn retain(c: &mut AfcClient, root: &Path, i: usize, stamp: &Stamp) -> Result<()> {
    let hash: String = stamp.hash.iter().map(|b| format!("{b:02x}")).collect();
    let name = root.join(format!("changed-{i}-{hash}"));
    if fs::symlink_metadata(&name).is_ok() {
        if digest(&mut private_file(&name, false)?)? != *stamp {
            return Err(JOURNAL_ERROR.into());
        }
        return Ok(());
    }
    reserve_history(root, stamp.len)?;
    let tmp = root.join(format!("holding-{i}"));
    match fs::remove_file(&tmp) {
        Ok(()) => (),
        Err(e) if e.kind() == std::io::ErrorKind::NotFound => (),
        Err(_) => return Err(JOURNAL_ERROR.into()),
    }
    let mut f = private_file(&tmp, true)?;
    if remote(c, PATHS[i], Some(&mut f)).await?.as_ref() != Some(stamp) {
        return Err(CHANGED.into());
    }
    local(f.sync_all())?;
    drop(f);
    local(fs::rename(tmp, name))?;
    sync_dir(root)
}

async fn clear_interrupted_stage(
    c: &mut AfcClient,
    root: &Path,
    t: &Trial,
    saved: &Snapshot,
    i: usize,
) -> Result<()> {
    let path = temporary(t, i);
    let Some(bytes) = remote(c, &path, None).await? else {
        return Ok(());
    };
    let mine = if i == MANIFEST {
        let payload = manifest(root, t, saved)?;
        usize::try_from(bytes.len)
            .ok()
            .and_then(|n| payload.get(..n))
            .is_some_and(|part| Stamp::bytes(part) == bytes)
    } else {
        false
    };
    let original_prefix = if !mine && saved.files[i].as_ref().is_some_and(|s| bytes.len <= s.len) {
        digest(&mut private_file(&original(root, i), false)?.take(bytes.len))? == bytes
    } else {
        false
    };
    if !mine && !original_prefix {
        return Err(CHANGED.into());
    }
    io(c.remove(path)).await
}

fn intended_snapshot(root: &Path, t: &Trial) -> Result<Option<Snapshot>> {
    if !checked_root(root)? {
        return if t.publish_attempted {
            Err(JOURNAL_ERROR.into())
        } else {
            Ok(None)
        };
    }
    match fs::symlink_metadata(root.join("intent")) {
        Err(e) if e.kind() == std::io::ErrorKind::NotFound => Ok(None),
        Ok(meta) if meta.is_file() && meta.len() == 0 => load(root, t).map(Some),
        _ => Err(JOURNAL_ERROR.into()),
    }
}

pub(super) async fn verify(c: &mut AfcClient, journal: &Path, t: &Trial) -> Result<bool> {
    let Some(saved) = intended_snapshot(&local_root(journal, t), t)? else {
        return Ok(true);
    };
    for (i, path) in DIRS.iter().enumerate() {
        let exists = known_parents(c, path).await? && dir(c, path).await?;
        if exists != saved.dirs[i] {
            return Ok(false);
        }
    }
    for (i, path) in PATHS.iter().enumerate() {
        if remote(c, path, None).await? != saved.files[i] {
            return Ok(false);
        }
    }
    Ok(true)
}

pub(super) async fn restore(c: &mut AfcClient, journal: &Path, t: &Trial) -> Result<bool> {
    let root = local_root(journal, t);
    let Some(saved) = intended_snapshot(&root, t)? else {
        return Ok(true);
    };
    let our_manifest = Stamp::bytes(&manifest(&root, t, &saved)?);
    for (i, s) in saved.files.iter().enumerate() {
        if let Some(stamp) = s {
            if digest(&mut private_file(&original(&root, i), false)?)? != *stamp {
                return Err(JOURNAL_ERROR.into());
            }
        }
    }
    for i in 0..PATHS.len() {
        clear_interrupted_stage(c, &root, t, &saved, i).await?;
    }
    for (i, path) in PATHS.iter().enumerate() {
        if !t.books_atc_started && i != MANIFEST {
            continue;
        }
        let current = remote(c, path, None).await?;
        if current == saved.files[i] {
            continue;
        }
        let owned = i == MANIFEST && current.as_ref() == Some(&our_manifest);
        if !owned && !t.books_atc_started {
            continue;
        }
        if !owned {
            if let Some(ref stamp) = current {
                retain(c, &root, i, stamp).await?;
            }
        }
        match &saved.files[i] {
            Some(stamp) => {
                let source = private_file(&original(&root, i), false)?;
                replace(c, t, i, source, stamp, current.as_ref()).await?;
            }
            None => {
                if remote(c, path, None).await? != current {
                    return Err(CHANGED.into());
                }
                io(c.remove(*path)).await?;
            }
        }
    }
    for (i, path) in PATHS.iter().enumerate() {
        if remote(c, path, None).await? != saved.files[i] {
            return Err(CHANGED.into());
        }
    }
    for (i, path) in DIRS.iter().enumerate() {
        if saved.dirs[i] && !dir(c, path).await? {
            io(c.mk_dir(*path)).await?;
            if !dir(c, path).await? {
                return Err(AFC_ERROR.into());
            }
        }
    }
    let mut exact = true;
    for (i, path) in DIRS.iter().enumerate().rev() {
        if !saved.dirs[i] && known_parents(c, path).await? && dir(c, path).await? {
            if empty(c, path).await? {
                io(c.remove(*path)).await?;
            } else {
                exact = false;
            }
        }
    }
    Ok(exact)
}

pub(super) fn discard(journal: &Path, t: &Trial) -> Result<()> {
    let root = local_root(journal, t);
    if !checked_root(&root)? {
        return Ok(());
    }
    let mut names = vec!["snapshot.json".to_string(), "intent".to_string()];
    for i in 0..PATHS.len() {
        names.push(format!("original-{i}"));
        names.push(format!("holding-{i}"));
    }
    for name in names {
        let p = root.join(name);
        match fs::symlink_metadata(&p) {
            Ok(m) if m.is_file() => local(fs::remove_file(p))?,
            Err(e) if e.kind() == std::io::ErrorKind::NotFound => (),
            _ => return Err(JOURNAL_ERROR.into()),
        }
    }
    let mut retained = false;
    for entry in local(fs::read_dir(&root))? {
        let e = local(entry)?;
        if e.file_name().to_str().is_some_and(changed_name) && local(e.file_type())?.is_file() {
            retained = true;
        }
    }
    let marker = root.join("complete");
    if retained {
        if !fs::symlink_metadata(&marker).is_ok_and(|m| m.is_file() && m.len() == 0) {
            local(private_file(&marker, true)?.sync_all())?;
        }
        sync_dir(&root)?;
    } else if local(fs::read_dir(&root))?.next().is_none() {
        local(fs::remove_dir(&root))?;
    }
    Ok(())
}

#[cfg(test)]
mod tests {
    use super::*;
    use idevice::{
        Idevice,
        afc::{MAGIC, opcode::AfcOpcode as Op},
    };
    use tokio::io::{AsyncReadExt, AsyncWriteExt};

    fn afc(root: PathBuf) -> AfcClient {
        afc_mode(root, false)
    }
    fn afc_mode(root: PathBuf, read_only: bool) -> AfcClient {
        let (host, mut peer) = tokio::io::duplex(256 * 1024);
        tokio::spawn(async move {
            let mut handle: Option<fs::File> = None;
            while let Ok(magic) = peer.read_u64_le().await {
                assert_eq!(magic, MAGIC);
                let len = peer.read_u64_le().await.unwrap();
                let _ = peer.read_u64_le().await.unwrap();
                let seq = peer.read_u64_le().await.unwrap();
                let op = Op::try_from(peer.read_u64_le().await.unwrap()).unwrap();
                let mut body = vec![0; len as usize - 40];
                peer.read_exact(&mut body).await.unwrap();
                let at = |p: &[u8]| {
                    let s = std::str::from_utf8(p)
                        .unwrap()
                        .trim_end_matches('\0')
                        .trim_start_matches('/');
                    assert!(!s.split('/').any(|n| n == ".."));
                    root.join(s)
                };
                let mut out = Vec::new();
                let mut hdr = Vec::new();
                let mut answer = Op::Status;
                let mut status = 0u64;
                if read_only {
                    assert!(matches!(
                        op,
                        Op::GetFileInfo | Op::FileOpen | Op::Read | Op::FileClose
                    ));
                    if op == Op::FileOpen {
                        assert_eq!(body[..8], (AfcFopenMode::RdOnly as u64).to_le_bytes());
                    }
                }
                match op {
                    Op::GetFileInfo => match fs::symlink_metadata(at(&body)) {
                        Ok(m) => {
                            answer = Op::Data;
                            let typ = if m.is_file() {
                                "S_IFREG"
                            } else if m.is_dir() {
                                "S_IFDIR"
                            } else {
                                "S_IFLNK"
                            };
                            out = format!("st_ifmt\0{typ}\0st_size\0{}\0", m.len()).into_bytes();
                        }
                        Err(_) => status = 8,
                    },
                    Op::ReadDir => {
                        answer = Op::Data;
                        for entry in fs::read_dir(at(&body)).unwrap() {
                            out.extend(entry.unwrap().file_name().to_str().unwrap().as_bytes());
                            out.push(0);
                        }
                    }
                    Op::FileOpen => {
                        let mode = u64::from_le_bytes(body[..8].try_into().unwrap());
                        let path = at(&body[8..]);
                        handle = Some(if mode == AfcFopenMode::RdOnly as u64 {
                            fs::File::open(path).unwrap()
                        } else {
                            fs::File::create_new(path).unwrap()
                        });
                        answer = Op::FileOpenRes;
                        hdr.extend(1u64.to_le_bytes());
                    }
                    Op::Read => {
                        let n = u64::from_le_bytes(body[8..].try_into().unwrap()) as usize;
                        out.resize(n, 0);
                        let got = handle.as_mut().unwrap().read(&mut out).unwrap();
                        out.truncate(got);
                        answer = Op::Data;
                    }
                    Op::Write => handle.as_mut().unwrap().write_all(&body[8..]).unwrap(),
                    Op::FileClose => {
                        handle.take();
                    }
                    Op::MakeDir => fs::create_dir(at(&body)).unwrap(),
                    Op::RemovePath => {
                        let p = at(&body);
                        if p.is_dir() {
                            fs::remove_dir(p).unwrap()
                        } else {
                            fs::remove_file(p).unwrap()
                        }
                    }
                    Op::RenamePath => {
                        let mut paths = body.split(|b| *b == 0);
                        fs::rename(at(paths.next().unwrap()), at(paths.next().unwrap())).unwrap();
                    }
                    _ => panic!("Unexpected AFC opcode {op:?}"),
                }
                if answer == Op::Status {
                    hdr.extend(status.to_le_bytes());
                }
                for word in [
                    MAGIC,
                    40 + (hdr.len() + out.len()) as u64,
                    40 + hdr.len() as u64,
                    seq,
                    answer as u64,
                ] {
                    peer.write_u64_le(word).await.unwrap();
                }
                peer.write_all(&hdr).await.unwrap();
                peer.write_all(&out).await.unwrap();
            }
        });
        AfcClient::new(Idevice::new(Box::new(host), "books-fixture"))
    }

    #[tokio::test]
    async fn interrupted_patch_upload_reclaims_only_owned_slots_and_retains_conflicts_for_retry() {
        let phone = tempfile::tempdir().unwrap();
        let mut trial = Trial::new(false);
        trial.patch_parent = Some(
            "/var/mobile/Containers/Data/Application/11111111-2222-3333-4444-555555555555".into(),
        );
        trial.patch_slots = 3;
        let base = phone.path().join(trial.source());
        fs::create_dir(&base).unwrap();
        fs::write(base.join("patch-1-a"), b"partially uploaded").unwrap();
        fs::write(base.join("payload"), b"unknown owner").unwrap();
        let mut c = afc(phone.path().into());
        assert!(!super::super::cleanup(&mut c, &trial).await.unwrap());
        assert!(base.join("patch-1-a").exists());
        fs::write(base.join("payload"), trial.challenge).unwrap();
        fs::write(base.join("foreign.txt"), b"external file").unwrap();
        assert!(!super::super::cleanup(&mut c, &trial).await.unwrap());
        assert_eq!(
            fs::read(base.join("foreign.txt")).unwrap(),
            b"external file"
        );
        assert!(base.join("patch-1-a").exists() && base.join("payload").exists());
        fs::remove_file(base.join("foreign.txt")).unwrap();
        for _ in 0..2 {
            assert!(super::super::cleanup(&mut c, &trial).await.unwrap());
        }
        assert!(!base.exists());
    }

    #[tokio::test]
    async fn existing_books_are_preserved_and_generated_changes_retained_across_retry() {
        let phone = tempfile::tempdir().unwrap();
        let local = tempfile::tempdir().unwrap();
        let j = local.path().join("journal");
        let p = |path: &str| phone.path().join(path.trim_start_matches('/'));
        fs::create_dir_all(p(DIRS[2])).unwrap();
        let database: Vec<_> = (0..BLOCK + 71).map(|n| n as u8).collect();
        fs::write(p(PATHS[MANIFEST]), b"old manifest").unwrap();
        fs::write(p(PATHS[3]), &database).unwrap();
        fs::write(p("/Books/reader.epub"), b"real book").unwrap();
        let mut t = Trial::new(true);
        let mut c = afc(phone.path().into());
        snapshot(&mut c, &j, &t).await.unwrap();
        t.publish_attempted = true;
        publish(&mut c, &j, &t).await.unwrap();
        assert_eq!(fs::read(p(PATHS[MANIFEST])).unwrap(), t.manifest().unwrap());
        assert_eq!(fs::read(p(PATHS[3])).unwrap(), database);
        t.books_atc_started = true;
        t.sync_started = Some(123);
        fs::write(p(PATHS[3]), b"generated database").unwrap();
        fs::write(p(PATHS[5]), b"generated wal").unwrap();
        fs::write(p(&temporary(&t, 3)), &database[..17]).unwrap();
        for _ in 0..2 {
            assert!(restore(&mut c, &j, &t).await.unwrap());
        }
        assert_eq!(fs::read(p(PATHS[3])).unwrap(), database);
        assert_eq!(fs::read(p(PATHS[MANIFEST])).unwrap(), b"old manifest");
        assert_eq!(fs::read(p("/Books/reader.epub")).unwrap(), b"real book");
        assert!(!p(PATHS[5]).exists());
        discard(&j, &t).unwrap();
        let mut copies: Vec<_> = fs::read_dir(local_root(&j, &t))
            .unwrap()
            .filter_map(|e| {
                let e = e.unwrap();
                e.file_name()
                    .to_str()
                    .is_some_and(changed_name)
                    .then(|| fs::read(e.path()).unwrap())
            })
            .collect();
        copies.sort();
        assert_eq!(copies, [b"generated database".as_slice(), b"generated wal"]);
    }

    #[tokio::test]
    async fn old_collision_before_publication_recovers_without_rebuilding_or_removing_prior_entries()
     {
        let phone = tempfile::tempdir().unwrap();
        let local = tempfile::tempdir().unwrap();
        let journal = local.path().join("journal");
        let path = |p: &str| phone.path().join(p.trim_start_matches('/'));
        fs::create_dir_all(path(DIRS[2])).unwrap();
        let mut t = Trial::new(true);
        t.reverse_namespaced = false;
        t.token = "00000000000000000001".into();
        t.patch_parent = Some(
            "/var/mobile/Containers/Data/Application/12345678-1234-1234-1234-123456789ABC".into(),
        );
        t.reverse_docs = vec![("Documents/old.bytes".into(), "a".repeat(32))];
        t.reverse_redelivery = true;
        let prior = t.manifest().unwrap();
        fs::write(path(PATHS[MANIFEST]), &prior).unwrap();
        fs::write(path(PATHS[3]), b"original sqlite fixture").unwrap();
        fs::write(path("/Books/real.epub"), b"real library file").unwrap();
        let mut c = afc(phone.path().into());
        snapshot(&mut c, &journal, &t).await.unwrap();
        t.publish_attempted = true;
        t.save(&journal).unwrap();
        assert!(
            publish(&mut c, &journal, &t)
                .await
                .unwrap_err()
                .contains("đã tồn tại")
        );
        assert!(!local_root(&journal, &t).join("intent").exists());
        let recovered = Trial::load(&journal).unwrap().unwrap();
        for _ in 0..2 {
            assert!(restore(&mut c, &journal, &recovered).await.unwrap());
            assert!(verify(&mut c, &journal, &recovered).await.unwrap());
        }
        assert_eq!(fs::read(path(PATHS[MANIFEST])).unwrap(), prior);
        assert_eq!(
            fs::read(path(PATHS[3])).unwrap(),
            b"original sqlite fixture"
        );
        assert_eq!(
            fs::read(path("/Books/real.epub")).unwrap(),
            b"real library file"
        );
        discard(&journal, &recovered).unwrap();
        assert_eq!(fs::read(path(PATHS[MANIFEST])).unwrap(), prior);
    }

    #[test]
    fn retention_can_reclaim_completed_copies_but_never_pending_or_foreign_files() {
        for prefix in ["", "n"] {
            let parent = tempfile::tempdir().unwrap();
            let live = parent
                .path()
                .join(format!(".cc365-books-{prefix}11111111111111111111"));
            let done = parent
                .path()
                .join(format!(".cc365-books-{prefix}22222222222222222222"));
            fs::create_dir(&live).unwrap();
            fs::create_dir(&done).unwrap();
            let name = format!("changed-0-{}", "0".repeat(64));
            private_file(&done.join("complete"), true).unwrap();
            private_file(&done.join(&name), true)
                .unwrap()
                .set_len(MAX_TOTAL)
                .unwrap();
            reserve_history(&live, 1).unwrap();
            assert!(!done.exists());
            private_file(&live.join(&name), true)
                .unwrap()
                .set_len(MAX_TOTAL)
                .unwrap();
            assert!(reserve_history(&live, 1).is_err());
            assert!(live.join(&name).exists());
        }
    }

    #[tokio::test]
    async fn disconnected_before_atc_preserves_a_foreign_edit_after_publication() {
        let phone = tempfile::tempdir().unwrap();
        let local = tempfile::tempdir().unwrap();
        let j = local.path().join("journal");
        let books = phone.path().join("Books");
        fs::create_dir_all(books.join("Sync")).unwrap();
        fs::write(books.join("Sync/Books.plist"), b"preimage").unwrap();
        let mut t = Trial::new(true);
        let mut c = afc(phone.path().into());
        snapshot(&mut c, &j, &t).await.unwrap();
        t.publish_attempted = true;
        publish(&mut c, &j, &t).await.unwrap();
        fs::write(books.join("Books.plist"), b"other writer").unwrap();
        assert_eq!(restore(&mut c, &j, &t).await.unwrap_err(), CHANGED);
        assert_eq!(
            fs::read(books.join("Books.plist")).unwrap(),
            b"other writer"
        );
        assert_eq!(
            fs::read(books.join("Sync/Books.plist")).unwrap(),
            b"preimage"
        );
    }

    #[tokio::test]
    async fn recovers_original_empty_directories_in_parent_first_order() {
        let phone = tempfile::tempdir().unwrap();
        let local = tempfile::tempdir().unwrap();
        let j = local.path().join("journal");
        let books = phone.path().join("Books");
        fs::create_dir_all(books.join("Sync/Database")).unwrap();
        let mut c = afc(phone.path().into());
        let mut t = Trial::new(true);
        snapshot(&mut c, &j, &t).await.unwrap();
        t.publish_attempted = true;
        publish(&mut c, &j, &t).await.unwrap();
        t.books_atc_started = true;
        fs::remove_dir_all(&books).unwrap();
        assert!(restore(&mut c, &j, &t).await.unwrap());
        assert!(books.join("Sync/Database").is_dir());
    }

    #[tokio::test]
    async fn delayed_verification_detects_late_same_size_writes_and_new_dirs_without_mutation() {
        let phone = tempfile::tempdir().unwrap();
        let local = tempfile::tempdir().unwrap();
        let journal = local.path().join("journal");
        let books = phone.path().join("Books");
        fs::create_dir_all(books.join("Sync")).unwrap();
        let plist = books.join("Books.plist");
        fs::write(&plist, b"old").unwrap();
        let mut t = Trial::new(true);
        let mut c = afc(phone.path().into());
        snapshot(&mut c, &journal, &t).await.unwrap();
        let mut check = afc_mode(phone.path().into(), true);
        fs::write(&plist, b"new").unwrap();
        assert!(verify(&mut check, &journal, &t).await.unwrap());
        fs::write(&plist, b"old").unwrap();
        t.publish_attempted = true;
        publish(&mut c, &journal, &t).await.unwrap();
        assert!(restore(&mut c, &journal, &t).await.unwrap());
        assert!(verify(&mut check, &journal, &t).await.unwrap());
        fs::write(&plist, b"new").unwrap();
        assert!(!verify(&mut check, &journal, &t).await.unwrap());
        assert_eq!(fs::read(&plist).unwrap(), b"new");
        fs::write(&plist, b"old").unwrap();
        fs::create_dir(books.join("Sync/Database")).unwrap();
        assert!(!verify(&mut check, &journal, &t).await.unwrap());
        assert!(books.join("Sync/Database").is_dir());
    }

    #[tokio::test]
    async fn preflight_conflict_does_not_roll_back_a_concurrent_edit_or_follow_links() {
        let phone = tempfile::tempdir().unwrap();
        let local = tempfile::tempdir().unwrap();
        let j = local.path().join("journal");
        let books = phone.path().join("Books");
        fs::create_dir(&books).unwrap();
        let mut c = afc(phone.path().into());
        let mut t = Trial::new(true);
        snapshot(&mut c, &j, &t).await.unwrap();
        fs::write(books.join("Books.plist"), b"concurrent edit").unwrap();
        t.publish_attempted = true;
        assert_eq!(publish(&mut c, &j, &t).await.unwrap_err(), CHANGED);
        assert!(restore(&mut c, &j, &t).await.unwrap());
        assert_eq!(
            fs::read(books.join("Books.plist")).unwrap(),
            b"concurrent edit"
        );
        discard(&j, &t).unwrap();

        let outsider = tempfile::tempdir().unwrap();
        std::os::unix::fs::symlink(outsider.path(), books.join("Sync")).unwrap();
        assert!(snapshot(&mut c, &j, &Trial::new(true)).await.is_err());
        assert_eq!(fs::read_dir(outsider.path()).unwrap().count(), 0);
    }
}
