use super::checkpoint::persist_rows;
use super::*;
use crate::device::airlift::{GroupDelivery, MAX_GROUP_HANDOFFS};
use idevice::afc::AfcClient;

const LANES: usize = 6;
const WINDOW_BYTES: u64 = 16 << 20;
const SMALL_ORIGINAL: u64 = 64 << 10;

pub(super) fn eligible(row: &Item) -> bool {
    row.original_witness == "opaque" && row.phase == Phase::Waiting
}

pub(super) fn valid(row: &Item) -> bool {
    if row.phase != Phase::Comparing {
        return row.handoff != Some(Handoff::StageDifferent);
    }
    row.original_witness == "opaque"
        && (row.replacement_witness.is_none() || row.handoff == Some(Handoff::StageDifferent))
        && matches!(
            row.handoff,
            Some(
                Handoff::ExportOld
                    | Handoff::StageDifferent
                    | Handoff::ReturnOld
                    | Handoff::VerifyOldOut
                    | Handoff::ReturnVerifiedOld
                    | Handoff::ReturnForeignOld
            )
        )
        && (row.handoff != Some(Handoff::StageDifferent)
            || row.original.is_some() && row.cargo.is_some() && row.return_witness.is_some())
}

pub(super) fn window(batch: &Batch, indices: &[usize], limit: usize) -> usize {
    let mut paths: Vec<String> = vec![];
    let mut bytes = 0;
    for &i in indices.iter().take(limit.min(MAX_GROUP_HANDOFFS)) {
        let row = &batch.items[i];
        if !eligible(row) || !row.rel.is_ascii() {
            break;
        }
        if bytes + row.replacement.len > WINDOW_BYTES {
            break;
        }
        let rel = row.rel.to_ascii_lowercase();
        let overlaps = |a: &str, b: &str| {
            a.strip_prefix(b)
                .is_some_and(|tail| tail.is_empty() || tail.starts_with('/'))
        };
        if paths
            .iter()
            .any(|other| overlaps(&rel, other) || overlaps(other, &rel))
        {
            break;
        }
        paths.push(rel);
        bytes += row.replacement.len;
    }
    paths.len().max(1)
}

#[derive(Default)]
pub(super) struct ReadPool {
    clients: Vec<AfcClient>,
    limited: bool,
    pub(super) upgraded: bool,
}

impl ReadPool {
    async fn revalidate(&mut self, ctl: &SyncControl) -> Result<usize> {
        ctl.check().map_err(|_| "Đã dừng phiên AirLift.")?;
        self.upgraded = false;
        let desired = self.clients.len();
        let idle = std::mem::take(&mut self.clients);
        let checked = futures_util::future::join_all(idle.into_iter().map(|mut client| async {
            let response = ctl
                .wait(Duration::from_secs(3), async {
                    Ok(client.get_file_info_raw("/").await)
                })
                .await;
            let healthy = matches!(response, Ok(Ok(info))
                if info.get("st_ifmt").map(String::as_str) == Some("S_IFDIR"));
            healthy.then_some(client)
        }))
        .await;
        ctl.check().map_err(|_| "Đã dừng phiên AirLift.")?;
        self.clients = checked.into_iter().flatten().collect();
        Ok(desired - self.clients.len())
    }
}

struct Exported {
    index: usize,
    path: String,
}
struct HeldObservation {
    cargo: String,
    witness: Result<String>,
}

struct Original {
    replacement: Stamp,
    cargo: String,
    index: usize,
    path: String,
    witness: String,
    size: u64,
}

struct Replacement {
    index: usize,
    stage: String,
    local: PathBuf,
    stamp: Stamp,
}

async fn upload_wave<'a>(
    clients: impl Iterator<Item = &'a mut AfcClient>,
    ctl: &SyncControl,
    jobs: &[Replacement],
) -> Vec<Result<String>> {
    futures_util::future::join_all(clients.zip(jobs).map(|(client, job)| {
        staging::upload_compared_file(client, ctl, &job.stage, &job.local, &job.stamp)
    }))
    .await
}

fn store_small_backup(
    replacement: &Path,
    original: &Path,
    bytes: &[u8],
    equal: bool,
) -> Result<()> {
    if equal && fs::hard_link(replacement, original).is_ok() {
        let check = || -> Result<bool> {
            let file = read_file(original)?;
            if file.metadata().map_err(|_| DISK)?.len() != bytes.len() as u64 {
                return Ok(false);
            }
            let mut observed = Vec::with_capacity(bytes.len());
            file.take(bytes.len() as u64 + 1)
                .read_to_end(&mut observed)
                .map_err(|_| DISK)?;
            Ok(observed == bytes)
        };
        if check() == Ok(true) {
            return Ok(());
        }
        fs::remove_file(original).map_err(|_| DISK)?;
    }
    let mut backup = new_file(original)?;
    backup.write_all(bytes).map_err(|_| DISK)?;
    backup.sync_all().map_err(|_| DISK.into())
}

async fn measured_original(
    client: &mut AfcClient,
    ctl: &SyncControl,
    job: &Original,
    out: impl Write,
) -> Result<Stamp> {
    let stamp = io::snapshot(client, ctl, &job.path, out, job.size)
        .await?
        .ok_or(UNCERTAIN)?;
    if stamp.len != job.size
        || job.witness.starts_with("sha1:") && stamp.sha1_witness() != job.witness
    {
        return Err(CONFLICT.into());
    }
    if PatchLink::reverse_cargo_witness_on(client, &job.path)
        .await?
        .as_deref()
        != Some(job.cargo.as_str())
    {
        return Err(CONFLICT.into());
    }
    Ok(stamp)
}

async fn read_original(
    client: &mut AfcClient,
    ctl: &SyncControl,
    slot: &Path,
    job: &Original,
) -> Result<Stamp> {
    let original = artifact(slot, job.index, true);
    if job.size <= SMALL_ORIGINAL {
        let mut bytes = Vec::with_capacity(job.size as usize);
        let stamp = measured_original(client, ctl, job, &mut bytes).await?;
        let replacement = artifact(slot, job.index, false);
        let equal = stamp == job.replacement;
        tokio::task::spawn_blocking(move || {
            store_small_backup(&replacement, &original, &bytes, equal)
        })
        .await
        .map_err(|_| DISK)??;
        Ok(stamp)
    } else {
        let mut backup = new_file(&original)?;
        let stamp = measured_original(client, ctl, job, &mut backup).await?;
        tokio::task::spawn_blocking(move || backup.sync_all())
            .await
            .map_err(|_| DISK)?
            .map_err(|_| DISK)?;
        Ok(stamp)
    }
}

async fn read_wave<'a>(
    clients: impl Iterator<Item = &'a mut AfcClient>,
    ctl: &SyncControl,
    slot: &Path,
    jobs: &[Original],
) -> Vec<Result<Stamp>> {
    futures_util::future::join_all(
        clients
            .zip(jobs)
            .map(|(client, job)| read_original(client, ctl, slot, job)),
    )
    .await
}

pub(super) fn confirmed_prefix(delivery: GroupDelivery, len: usize) -> Result<usize> {
    match delivery {
        GroupDelivery::Complete => Ok(len),
        GroupDelivery::Individual => Ok(0),
        GroupDelivery::Prefix(n) if n > 0 && n < len => Ok(n),
        _ => Err(UNCERTAIN.into()),
    }
}
impl DeviceSession {
    pub(super) async fn refresh_compare_pool(&mut self, pool: &mut ReadPool) -> Result<()> {
        let missing = pool.revalidate(&self.control).await?;
        if missing > 0 {
            let replacements = self.reverse_media_workers(missing).await?;
            pool.limited |= replacements.len() < missing;
            pool.clients.extend(replacements);
        }
        Ok(())
    }

    async fn export_compare_members(
        &mut self,
        link: &mut PatchLink,
        slot: &Path,
        b: &mut Batch,
        group: &[usize],
    ) -> Result<(Vec<Exported>, bool)> {
        let mut members = Vec::with_capacity(group.len());
        let mut exports = Vec::with_capacity(group.len());
        for &i in group {
            let row = &b.items[i];
            if !eligible(row) {
                return Err(UNCERTAIN.into());
            }
            link.select_reverse_doc(&row.rel, &row.key)?;
            members.push((row.rel.clone(), row.key.clone()));
            exports.push(Exported {
                index: i,
                path: link.reverse_media_path()?,
            });
            report_progress(&self.control, "comparing", b, true, i);
        }
        let mut ready = vec![];
        if group.len() > 1 {
            for &i in group {
                b.items[i].phase = Phase::Comparing;
                b.items[i].handoff = Some(Handoff::ExportOld);
            }
            persist_rows(slot, b, group)?;
            let confirmed = confirmed_prefix(
                self.export_compared_group(link, &members).await?,
                group.len(),
            )?;
            if confirmed == group.len() {
                return Ok((exports, group.len() >= LANES));
            }
            let unsent = &group[confirmed..];
            for &i in unsent {
                b.items[i].phase = Phase::Waiting;
                b.items[i].handoff = None;
            }
            persist_rows(slot, b, unsent)?;
            ready.extend(exports.drain(..confirmed));
        }
        for export in exports {
            let i = export.index;
            let row = &b.items[i];
            link.select_reverse_doc(&row.rel, &row.key)?;
            let result = async {
                self.control.check().map_err(|_| "Đã dừng phiên AirLift.")?;
                if !link.reverse_compare_export_ready().await? {
                    return Err(CONFLICT.into());
                }
                b.items[i].phase = Phase::Comparing;
                b.items[i].handoff = Some(Handoff::ExportOld);
                persist_row(slot, b, i)?;
                self.reverse_opaque_export(link, false).await?;
                self.control.log("AirLift compare: original exported.");
                Ok(())
            }
            .await;
            self.handle_apply_result(link, slot, b, i, result)
                .await
                .map_err(|e| format!("{}\n{e}", b.items[i].rel))?;
            if b.items[i].phase == Phase::Omitted {
                report_progress(&self.control, "omitted", b, true, i);
            } else {
                ready.push(export);
            }
        }
        Ok((ready, false))
    }

    async fn return_equal_members(
        &mut self,
        link: &mut PatchLink,
        slot: &Path,
        b: &mut Batch,
        indices: &[usize],
    ) -> Result<()> {
        let mut grouped = vec![];
        let mut members = vec![];
        let mut serial = vec![];
        for &i in indices {
            let row = &b.items[i];
            if row.phase != Phase::Comparing
                || row.handoff != Some(Handoff::ExportOld)
                || row.original.as_ref() != Some(&row.replacement)
            {
                return Err(UNCERTAIN.into());
            }
            let witness = row.return_witness.as_ref().ok_or(UNCERTAIN)?;
            if !witness.starts_with("sha1:") {
                serial.push(i);
                continue;
            }
            if witness != &row.replacement.sha1_witness() {
                return Err(UNCERTAIN.into());
            }
            grouped.push(i);
            members.push((
                row.rel.clone(),
                row.key.clone(),
                row.cargo.clone().ok_or(UNCERTAIN)?,
                witness.clone(),
            ));
        }
        if grouped.len() > 1 {
            for &i in &grouped {
                b.items[i].handoff = Some(Handoff::ReturnVerifiedOld);
            }
            persist_rows(slot, b, &grouped)?;
            let n = confirmed_prefix(
                self.return_equal_group(link, &members).await?,
                grouped.len(),
            )?;
            let (done, unsent) = grouped.split_at(n);
            let before = b
                .items
                .iter()
                .filter(|r| matches!(r.phase, Phase::Installed | Phase::Skipped | Phase::Omitted))
                .count();
            for &i in done {
                b.items[i].phase = Phase::Skipped;
            }
            for &i in unsent {
                b.items[i].handoff = Some(Handoff::ExportOld);
            }
            persist_rows(slot, b, &grouped)?;
            for (n, &i) in done.iter().enumerate() {
                self.control.patch_progress(
                    "unchanged",
                    (before + n + 1).min(b.items.len() - 1),
                    b.items.len(),
                    &b.items[i].rel,
                );
            }
            serial.extend_from_slice(unsent);
        } else {
            serial.extend(grouped);
        }
        for i in serial {
            let row = &b.items[i];
            link.select_reverse_doc(&row.rel, &row.key)?;
            let result = self.install_opaque(link, slot, b, i).await;
            self.handle_apply_result(link, slot, b, i, result)
                .await
                .map_err(|e| format!("{}\n{e}", b.items[i].rel))?;
            report_progress(
                &self.control,
                if b.items[i].phase == Phase::Skipped {
                    "unchanged"
                } else {
                    "omitted"
                },
                b,
                true,
                i,
            );
        }
        Ok(())
    }

    pub(super) async fn compare_originals(
        &mut self,
        link: &mut PatchLink,
        slot: &Path,
        b: &mut Batch,
        group: &[usize],
        pool: &mut ReadPool,
    ) -> Result<()> {
        let accounted = b
            .items
            .iter()
            .filter(|row| row.phase != Phase::Omitted)
            .map(|row| match &row.original {
                Some(stamp) => Ok(stamp.len),
                None if matches!(row.original_witness.as_str(), "opaque" | "missing") => Ok(0),
                None => witness_size(&row.original_witness),
            })
            .sum::<Result<u64>>()?;
        let planned: u64 = b.items.iter().map(|row| row.replacement.len).sum();
        let mut budget = MAX_TOTAL
            .saturating_sub(accounted)
            .min(available_storage(slot)?.saturating_sub(accounted + planned));
        let (exported, proven) = self.export_compare_members(link, slot, b, group).await?;
        pool.upgraded |= proven;
        if exported.is_empty() {
            return Ok(());
        }
        let lane_limit = if pool.upgraded {
            MAX_GROUP_HANDOFFS
        } else {
            LANES
        };
        let wanted = (exported.len() - 1).min(lane_limit - 1);
        if wanted > pool.clients.len() && !pool.limited {
            let additional = wanted - pool.clients.len();
            let extra = self.reverse_media_workers(additional).await?;
            pool.limited = extra.len() < additional;
            pool.clients.extend(extra);
        }
        let extra = &mut pool.clients;
        let mut jobs = Vec::with_capacity(exported.len());
        for wave in exported.chunks(1 + extra.len()) {
            let clients = std::iter::once(link.reverse_media_afc()?).chain(extra.iter_mut());
            let observations = futures_util::future::join_all(clients.zip(wave).map(
                |(client, member)| async move {
                    let cargo = PatchLink::reverse_cargo_witness_on(client, &member.path)
                        .await?
                        .ok_or(UNCERTAIN)?;
                    let witness =
                        PatchLink::reverse_verified_held_witness(client, &member.path, None)
                            .await
                            .and_then(|w| w.ok_or_else(|| UNCERTAIN.to_owned()));
                    Ok(HeldObservation { cargo, witness })
                },
            ))
            .await;
            let mut identified = vec![];
            for (member, seen) in wave.iter().zip(&observations) {
                if let Ok(seen) = seen {
                    b.items[member.index].cargo = Some(seen.cargo.clone());
                    identified.push(member.index);
                }
            }
            persist_rows(slot, b, &identified)?;
            for (member, seen) in wave.iter().zip(observations) {
                let i = member.index;
                let result = seen.and_then(|seen| {
                    let witness = seen.witness?;
                    let size = witness_size(&witness)?;
                    if size > MAX_FILE || size > budget {
                        return Err(LIMIT.into());
                    }
                    budget -= size;
                    jobs.push(Original {
                        replacement: b.items[i].replacement.clone(),
                        index: i,
                        path: member.path.clone(),
                        cargo: seen.cargo,
                        size,
                        witness,
                    });
                    Ok(())
                });
                if let Err(reason) = result {
                    let row = &b.items[i];
                    link.select_reverse_doc(&row.rel, &row.key)?;
                    self.handle_apply_result(link, slot, b, i, Err(reason))
                        .await
                        .map_err(|e| format!("{}\n{e}", b.items[i].rel))?;
                    report_progress(&self.control, "omitted", b, true, i);
                }
            }
        }
        let mut remaining = jobs.as_slice();
        let mut equal = vec![];
        while !remaining.is_empty() {
            let mut size = 0;
            let count = remaining
                .iter()
                .take(1 + extra.len())
                .take_while(|job| {
                    size += job.size;
                    size <= WINDOW_BYTES
                })
                .count()
                .max(1);
            let (wave, rest) = remaining.split_at(count);
            remaining = rest;
            let clients = std::iter::once(link.reverse_media_afc()?).chain(extra.iter_mut());
            self.control.log(&format!(
                "AirLift compare: {} original read(s) in flight.",
                wave.len()
            ));
            let reads = read_wave(clients, &self.control, slot, wave).await;
            let mut captured = vec![];
            let mut refused = vec![];
            for (job, result) in wave.iter().zip(reads) {
                let i = job.index;
                match result {
                    Ok(stamp) => {
                        if stamp == b.items[i].replacement {
                            equal.push(i);
                        }
                        b.items[i].original = Some(stamp);
                        b.items[i].return_witness = Some(job.witness.clone());
                        captured.push(i);
                    }
                    Err(error) => refused.push((i, error)),
                }
            }
            persist_rows(slot, b, &captured)?;
            if !captured.is_empty() {
                self.control
                    .log("AirLift reverse: original backup persisted.");
            }
            for (i, error) in refused {
                let row = &b.items[i];
                link.select_reverse_doc(&row.rel, &row.key)?;
                self.handle_apply_result(link, slot, b, i, Err(error))
                    .await
                    .map_err(|e| format!("{}\n{e}", b.items[i].rel))?;
                report_progress(&self.control, "omitted", b, true, i);
            }
        }
        self.return_equal_members(link, slot, b, &equal).await?;
        self.stage_different_group(link, slot, b, group, extra)
            .await?;
        self.publish_changed_group(link, slot, b, group, extra)
            .await
    }

    async fn stage_different_group(
        &mut self,
        link: &mut PatchLink,
        slot: &Path,
        b: &mut Batch,
        group: &[usize],
        extra: &mut [AfcClient],
    ) -> Result<()> {
        let mut uploads = vec![];
        for &i in group {
            let row = &b.items[i];
            if matches!(row.phase, Phase::Skipped | Phase::Omitted) {
                continue;
            }
            if row.phase != Phase::Comparing
                || row
                    .original
                    .as_ref()
                    .is_none_or(|old| old == &row.replacement)
            {
                return Err(UNCERTAIN.into());
            }
            link.select_reverse_doc(&row.rel, &row.key)?;
            let stage = link.reverse_stage_path()?;
            if !io::missing(link.reverse_media_afc()?, &self.control, &stage).await? {
                self.handle_apply_result(link, slot, b, i, Err(CONFLICT.into()))
                    .await?;
                report_progress(&self.control, "omitted", b, true, i);
                continue;
            }
            uploads.push(Replacement {
                index: i,
                stage,
                local: artifact(slot, i, false),
                stamp: row.replacement.clone(),
            });
            b.items[i].handoff = Some(Handoff::StageDifferent);
        }
        let armed: Vec<_> = uploads.iter().map(|job| job.index).collect();
        persist_rows(slot, b, &armed)?;
        for wave in uploads.chunks(1 + extra.len()) {
            for job in wave {
                report_progress(&self.control, "staging", b, true, job.index);
            }
            self.control.log(&format!(
                "AirLift compare: {} changed upload(s) in flight.",
                wave.len()
            ));
            let clients = std::iter::once(link.reverse_media_afc()?).chain(extra.iter_mut());
            let results = upload_wave(clients, &self.control, wave).await;
            for (job, result) in wave.iter().zip(results) {
                let i = job.index;
                match result {
                    Ok(witness) => {
                        b.items[i].replacement_witness = Some(witness);
                    }
                    Err(error) => {
                        let row = &b.items[i];
                        link.select_reverse_doc(&row.rel, &row.key)?;
                        self.handle_apply_result(link, slot, b, i, Err(error))
                            .await
                            .map_err(|e| format!("{}\n{e}", b.items[i].rel))?;
                        report_progress(&self.control, "omitted", b, true, i);
                    }
                }
            }
        }
        Ok(())
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    use crate::device::patch::tests::{afc_timed, control};
    use std::time::Instant;

    #[tokio::test]
    async fn media_pool_keeps_healthy_streams_across_leases_and_discards_stale_ones() {
        use idevice::Idevice;
        let left = tempfile::tempdir().unwrap();
        let right = tempfile::tempdir().unwrap();
        fs::write(left.path().join("identity"), b"left-reader").unwrap();
        fs::write(right.path().join("identity"), b"right-reader").unwrap();
        let wrong_root = left.path().join("not-a-directory");
        fs::write(&wrong_root, b"not Media").unwrap();
        let (closed, peer) = tokio::io::duplex(1024);
        drop(peer);
        let gate = Arc::new(tokio::sync::Barrier::new(2));
        let mut pool = ReadPool {
            clients: vec![
                afc_timed(left.path().into(), Duration::ZERO, Some(gate.clone())),
                AfcClient::new(Idevice::new(Box::new(closed), "closed Media fixture")),
                afc_timed(right.path().into(), Duration::ZERO, Some(gate)),
                afc_timed(wrong_root, Duration::ZERO, None),
            ],
            limited: true,
            upgraded: true,
        };
        let ctl = control();
        let missing = tokio::time::timeout(Duration::from_secs(2), pool.revalidate(&ctl))
            .await
            .unwrap()
            .unwrap();
        assert_eq!(missing, 2);
        assert_eq!(pool.clients.len(), 2);
        assert!(!pool.upgraded);
        assert!(pool.limited);
        for _lease in 0..3 {
            pool.upgraded = true;
            assert_eq!(pool.revalidate(&ctl).await.unwrap(), 0);
            assert!(!pool.upgraded);
            for (client, expected) in pool
                .clients
                .iter_mut()
                .zip([&b"left-reader"[..], &b"right-reader"[..]])
            {
                let observed = io::snapshot(client, &ctl, "/identity", std::io::sink(), MAX_FILE)
                    .await
                    .unwrap()
                    .unwrap();
                assert_eq!(observed, io::local_copy(expected, std::io::sink()).unwrap());
            }
        }
        assert_eq!(
            fs::read(left.path().join("identity")).unwrap(),
            b"left-reader"
        );
        assert_eq!(
            fs::read(right.path().join("identity")).unwrap(),
            b"right-reader"
        );
    }

    #[tokio::test]
    async fn media_pool_cancellation_and_stalled_probe_do_not_leave_uncertain_streams() {
        use idevice::Idevice;
        let (socket, _peer) = tokio::io::duplex(1024);
        let mut pool = ReadPool {
            clients: vec![AfcClient::new(Idevice::new(
                Box::new(socket),
                "stalled Media fixture",
            ))],
            ..Default::default()
        };
        let cancelled = control();
        cancelled.cancelled.store(true, Ordering::Release);
        assert!(pool.revalidate(&cancelled).await.is_err());
        assert_eq!(pool.clients.len(), 1);
        let expired = control().with_timeout(Duration::from_millis(5));
        assert!(
            tokio::time::timeout(Duration::from_secs(1), pool.revalidate(&expired))
                .await
                .unwrap()
                .is_err()
        );
        assert!(pool.clients.is_empty());
    }

    fn batch(count: usize) -> Batch {
        let mut b = super::super::tests::plan();
        b.items.clear();
        for i in 0..count {
            let mut row = super::super::tests::plan().items.pop().unwrap();
            row.rel = format!("Documents/dir/f{i}");
            row.original_witness = "opaque".into();
            b.items.push(row);
        }
        b
    }

    #[test]
    fn equal_small_backup_reuses_only_exact_current_local_bytes_and_never_overwrites_an_existing_backup()
     {
        use std::os::unix::fs::MetadataExt;
        let dir = tempfile::tempdir().unwrap();
        let source = dir.path().join("source");
        let backup = dir.path().join("equal");
        fs::write(&source, b"original").unwrap();
        store_small_backup(&source, &backup, b"original", true).unwrap();
        assert_eq!(
            fs::metadata(&source).unwrap().ino(),
            fs::metadata(&backup).unwrap().ino()
        );
        let stale = dir.path().join("different inode");
        fs::write(&stale, b"same len").unwrap();
        let recovered = dir.path().join("recover");
        store_small_backup(&stale, &recovered, b"original", true).unwrap();
        assert_eq!(fs::read(&recovered).unwrap(), b"original");
        assert_ne!(
            fs::metadata(&stale).unwrap().ino(),
            fs::metadata(&recovered).unwrap().ino()
        );
        assert!(store_small_backup(&source, &recovered, b"other", true).is_err());
        assert_eq!(fs::read(&recovered).unwrap(), b"original");
    }

    #[test]
    fn confirmed_prefix_never_replays_an_acknowledged_file_or_accepts_an_impossible_boundary() {
        assert_eq!(confirmed_prefix(GroupDelivery::Individual, 4).unwrap(), 0);
        assert_eq!(confirmed_prefix(GroupDelivery::Complete, 4).unwrap(), 4);
        let submitted = ["first", "second", "refused", "last"];
        let n = confirmed_prefix(GroupDelivery::Prefix(2), submitted.len()).unwrap();
        assert_eq!(&submitted[..n], ["first", "second"]);
        assert_eq!(&submitted[n..], ["refused", "last"]);
        for wrong in [0, 4, 5] {
            assert!(confirmed_prefix(GroupDelivery::Prefix(wrong), submitted.len()).is_err());
        }
    }

    #[test]
    fn compare_window_limits_independent_paths_bytes_and_unknown_aliases() {
        let mut b = batch(8);
        let order: Vec<_> = (0..8).collect();
        assert_eq!(window(&b, &order, LANES), 6);
        assert_eq!(window(&b, &order, MAX_GROUP_HANDOFFS), 8);
        b.items[4].rel = "Documents/dir/F0/sub".into();
        assert_eq!(window(&b, &order, LANES), 4);
        b.items[3].rel = "Documents/dir/Đỏ".into();
        assert_eq!(window(&b, &order, LANES), 3);
        assert_eq!(window(&b, &order[3..], LANES), 1);
        b.items[1].replacement.len = WINDOW_BYTES;
        assert_eq!(window(&b, &order, LANES), 1);
        b.items[0].replacement.len = WINDOW_BYTES + 1;
        assert_eq!(window(&b, &order, LANES), 1);
    }

    #[test]
    fn compare_and_deferred_upload_recover_including_partial_window_and_old_receipts() {
        for count in [3, 40] {
            let dir = tempfile::tempdir().unwrap();
            let mut b = batch(count);
            persist(dir.path(), &mut b).unwrap();
            for i in 0..3 {
                b.items[i].phase = Phase::Comparing;
                b.items[i].handoff = Some(Handoff::ExportOld);
                persist_row(dir.path(), &mut b, i).unwrap();
            }
            let mut b = load_receipt(dir.path()).unwrap().unwrap();
            for i in 0..2 {
                let row = &mut b.items[i];
                row.cargo = Some(format!("object:{}", "f".repeat(64)));
                row.original = Some(row.replacement.clone());
                row.return_witness = Some(row.replacement.sha1_witness());
                row.handoff = Some(Handoff::StageDifferent);
                if i == 1 {
                    row.replacement_witness = Some(row.replacement.sha1_witness());
                }
                persist_row(dir.path(), &mut b, i).unwrap();
            }
            let mut b = load_receipt(dir.path()).unwrap().unwrap();
            assert_eq!(report(&b)["restore_paths"].as_array().unwrap().len(), 3);
            b.items[1].phase = Phase::Moving;
            b.items[1].handoff = Some(Handoff::InstallNew);
            persist_row(dir.path(), &mut b, 1).unwrap();
            let mut b = load_receipt(dir.path()).unwrap().unwrap();
            assert!(valid(&b.items[1]));
            b.items[2].handoff = Some(Handoff::StageDifferent);
            assert!(validate(&b).is_err());
        }
    }

    #[tokio::test]
    async fn concurrent_changed_uploads_are_all_read_back_and_never_written_to_other_slots() {
        let local = tempfile::tempdir().unwrap();
        let serial = tempfile::tempdir().unwrap();
        let concurrent = tempfile::tempdir().unwrap();
        let jobs: Vec<_> = (0..LANES)
            .map(|i| {
                let data = vec![i as u8; 48 * 1024 + i];
                let source = local.path().join(format!("source-{i}"));
                fs::write(&source, &data).unwrap();
                Replacement {
                    index: i,
                    stage: format!("/stage-{i}"),
                    local: source,
                    stamp: io::local_copy(data.as_slice(), std::io::sink()).unwrap(),
                }
            })
            .collect();
        let ctl = control();
        let mut client = afc_timed(serial.path().into(), Duration::from_millis(2), None);
        let before = Instant::now();
        let mut expected = vec![];
        for job in &jobs {
            expected.push(
                staging::upload_compared_file(
                    &mut client,
                    &ctl,
                    &job.stage,
                    &job.local,
                    &job.stamp,
                )
                .await
                .unwrap(),
            );
        }
        let serial_time = before.elapsed();
        let gate = Arc::new(tokio::sync::Barrier::new(LANES));
        let mut clients: Vec<_> = (0..LANES)
            .map(|_| {
                afc_timed(
                    concurrent.path().into(),
                    Duration::from_millis(2),
                    Some(gate.clone()),
                )
            })
            .collect();
        let before = Instant::now();
        let actual = tokio::time::timeout(
            Duration::from_secs(10),
            upload_wave(clients.iter_mut(), &ctl, &jobs),
        )
        .await
        .unwrap()
        .into_iter()
        .collect::<Result<Vec<_>>>()
        .unwrap();
        println!(
            "{} independent verified AFC uploads, 2ms per request: serial {:?}, concurrent {:?}",
            LANES,
            serial_time,
            before.elapsed()
        );
        assert_eq!(actual, expected);
        for job in &jobs {
            assert_eq!(
                fs::read(concurrent.path().join(&job.stage[1..])).unwrap(),
                fs::read(&job.local).unwrap()
            );
        }
    }

    #[tokio::test]
    async fn simultaneous_real_afc_reads_have_identical_digests_to_serial_and_distinct_backups() {
        let device = tempfile::tempdir().unwrap();
        let mut jobs: Vec<_> = (0..LANES)
            .map(|i| {
                let data = vec![i as u8; 48 * 1024 + i];
                fs::write(device.path().join(format!("held-{i}")), &data).unwrap();
                let stamp = io::local_copy(data.as_slice(), std::io::sink()).unwrap();
                Original {
                    cargo: String::new(),
                    replacement: stamp.clone(),
                    index: i,
                    path: format!("/held-{i}"),
                    size: stamp.len,
                    witness: stamp.sha1_witness(),
                }
            })
            .collect();
        let ctl = control();
        let mut validator = afc_timed(device.path().into(), Duration::ZERO, None);
        for job in &mut jobs {
            job.cargo = PatchLink::reverse_cargo_witness_on(&mut validator, &job.path)
                .await
                .unwrap()
                .unwrap();
        }
        let serial = tempfile::tempdir().unwrap();
        let mut client = afc_timed(device.path().into(), Duration::from_millis(2), None);
        let before = Instant::now();
        let mut expected = vec![];
        for job in &jobs {
            expected.push(
                read_original(&mut client, &ctl, serial.path(), job)
                    .await
                    .unwrap(),
            );
        }
        let elapsed_serial = before.elapsed();
        let parallel = tempfile::tempdir().unwrap();
        let gate = Arc::new(tokio::sync::Barrier::new(LANES));
        let mut clients: Vec<_> = (0..LANES)
            .map(|_| {
                afc_timed(
                    device.path().into(),
                    Duration::from_millis(2),
                    Some(gate.clone()),
                )
            })
            .collect();
        let before = Instant::now();
        let observed = tokio::time::timeout(
            Duration::from_secs(10),
            read_wave(clients.iter_mut(), &ctl, parallel.path(), &jobs),
        )
        .await
        .unwrap();
        let elapsed_parallel = before.elapsed();
        println!(
            "{} independent AFC snapshots, 2ms per request: serial {:?}, concurrent {:?}",
            LANES, elapsed_serial, elapsed_parallel
        );
        assert_eq!(
            observed.into_iter().collect::<Result<Vec<_>>>().unwrap(),
            expected
        );
        for i in 0..LANES {
            assert_eq!(
                fs::read(artifact(parallel.path(), i, true)).unwrap(),
                fs::read(artifact(serial.path(), i, true)).unwrap()
            );
        }
        let wrong = Original {
            replacement: jobs[0].replacement.clone(),
            cargo: jobs[0].cargo.clone(),
            index: LANES,
            path: jobs[0].path.clone(),
            size: jobs[0].size,
            witness: format!("sha1:{}:{}", "0".repeat(40), jobs[0].size),
        };
        assert_eq!(
            read_original(&mut client, &ctl, parallel.path(), &wrong)
                .await
                .unwrap_err(),
            CONFLICT
        );
    }
}
