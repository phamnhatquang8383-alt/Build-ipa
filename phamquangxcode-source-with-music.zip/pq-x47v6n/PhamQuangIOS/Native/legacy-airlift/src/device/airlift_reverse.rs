use super::*;
use airlift_wire::{ReverseMove, valid_reverse_key, valid_reverse_relative};
use std::collections::HashSet;

#[path = "airlift_opaque.rs"]
mod opaque;
#[path = "airlift_scan.rs"]
mod scan;

pub(crate) const MAX_REVERSE_PLAN_ITEMS: usize = 32;
const MAX_PLAN_JSON_BYTES: usize = 24 * 1024;
const MAX_BYTES: u64 = 128 << 20;
const FILE_TOO_LARGE: &str = "Tệp gốc vượt giới hạn 128 MiB cho mỗi tệp.";
const NO_WITNESS: &str =
    "Chưa xác định được loại hoặc nội dung của tệp hiện có để sao lưu và khôi phục an toàn.";
const WAIT: &str =
    "Chưa xác nhận được kết quả di chuyển tệp qua AirLift. CC365 đã giữ phiên để khôi phục.";
const CHANGED: &str = "Tệp tại đích đã thay đổi. CC365 đã giữ dữ liệu khôi phục.";

pub(in super::super) fn valid_reverse_plan(root: &str, items: &[(String, String)]) -> bool {
    if !reverse_plan_fits(items) || !root.starts_with(DATA_PARENT) || !valid_parent(root) {
        return false;
    }
    let mut keys = HashSet::new();
    let mut targets = HashSet::new();
    items.iter().all(|(rel, key)| {
        valid_reverse_relative(rel)
            && valid_reverse_key(key)
            && keys.insert(key)
            && targets.insert(rel.to_lowercase())
    })
}

pub(crate) fn reverse_plan_fits(items: &[(String, String)]) -> bool {
    (1..=MAX_REVERSE_PLAN_ITEMS).contains(&items.len())
        && serde_json::to_vec(items).is_ok_and(|bytes| bytes.len() <= MAX_PLAN_JSON_BYTES)
}

#[derive(Clone, Copy)]
enum Place {
    Target,
    Held,
    Stage,
}

fn extra_connection_refused(error: &IdeviceError) -> bool {
    matches!(error, IdeviceError::Socket(socket) if socket.kind() == std::io::ErrorKind::ConnectionRefused)
        || matches!(
            error,
            IdeviceError::Afc(
                AfcError::NoResources | AfcError::ObjectBusy | AfcError::OpWouldBlock
            )
        )
}

impl DeviceSession {
    pub(crate) async fn reverse_media_workers(&mut self, count: usize) -> Result<Vec<AfcClient>> {
        if !(1..MAX_GROUP_HANDOFFS).contains(&count) {
            return Err(CONFLICT.into());
        }
        let mut clients = Vec::with_capacity(count);
        for _ in 0..count {
            self.control.check().map_err(|_| WAIT)?;
            let opened = tokio::time::timeout(Duration::from_secs(8), self.afc())
                .await
                .map_err(|_| AFC_ERROR)?;
            self.control.check().map_err(|_| WAIT)?;
            match opened {
                Ok(client) => clients.push(client),
                Err(error) if extra_connection_refused(&error) => break,
                Err(_) => return Err(AFC_ERROR.into()),
            }
        }
        Ok(clients)
    }

    pub(crate) async fn open_reverse_batch(
        &mut self,
        bundle: &str,
        plans: &[(String, String)],
    ) -> Result<PatchLink> {
        if !reverse_plan_fits(plans) {
            return Err(CONFLICT.into());
        }
        self.open_scoped_patch_link(bundle, "data", 0, true, None, plans)
            .await
    }
    pub(crate) async fn reverse_move_original(
        &mut self,
        link: &mut PatchLink,
        returning: bool,
        witness: &str,
    ) -> Result<()> {
        self.transfer_reverse_leaf(
            link,
            if returning {
                ReverseMove::Return
            } else {
                ReverseMove::Export
            },
            witness,
        )
        .await
    }
    pub(crate) async fn reverse_install_stage(
        &mut self,
        link: &mut PatchLink,
        witness: &str,
    ) -> Result<()> {
        self.transfer_reverse_leaf(link, ReverseMove::Install, witness)
            .await
    }
    pub(crate) async fn reverse_evict_stage(
        &mut self,
        link: &mut PatchLink,
        witness: &str,
    ) -> Result<()> {
        self.transfer_reverse_leaf(link, ReverseMove::Evict, witness)
            .await
    }

    async fn transfer_reverse_leaf(
        &mut self,
        link: &mut PatchLink,
        direction: ReverseMove,
        witness: &str,
    ) -> Result<()> {
        let (src, dst) = match direction {
            ReverseMove::Export => (Place::Target, Place::Held),
            ReverseMove::Return => (Place::Held, Place::Target),
            ReverseMove::Install => (Place::Stage, Place::Target),
            ReverseMove::Evict => (Place::Target, Place::Stage),
            ReverseMove::ProbePlace | ReverseMove::ProbeRecall => return Err(CONFLICT.into()),
        };
        let (rel, key) = link.selected_reverse()?.clone();
        let mut saved = Trial::load(&link.journal)?.ok_or(JOURNAL_ERROR)?;
        if saved.token != link.token
            || saved.patch_parent.as_deref() != Some(&link.absolute_root)
            || saved.reverse_docs != link.reverse_docs
            || !saved.matched
        {
            return Err(WAIT.into());
        }
        link.verify().await?;
        let target = link.document_path(&rel)?;
        link.check_document_parents(&target).await?;
        if link.witness_at(src, Some(witness)).await?.as_deref() != Some(witness) {
            return Err(CHANGED.into());
        }
        if !link.is_absent(dst).await? {
            return Err(CHANGED.into());
        }

        self.control.check().map_err(|_| WAIT)?;
        let channel = link.channel.as_mut().ok_or(ACCESS)?;
        saved.matched = false;
        saved.sync_started = Some(now().saturating_add(12));
        saved.save(&link.journal)?;
        tokio::time::timeout(
            Duration::from_secs(12),
            channel.reverse_move(direction, &link.token, &link.absolute_root, &rel, &key),
        )
        .await
        .map_err(|_| WAIT)??;

        let deadline = tokio::time::Instant::now() + Duration::from_secs(15);
        loop {
            self.control.check().map_err(|_| WAIT)?;
            if link.is_absent(src).await? {
                if let Some(observed) = link.witness_at(dst, Some(witness)).await? {
                    if observed != witness {
                        return Err(CHANGED.into());
                    }
                    link.verify().await?;
                    saved.matched = true;
                    saved.sync_started = Some(now());
                    return saved.save(&link.journal);
                }
            }
            opaque::wait_poll(deadline).await?;
        }
    }
}

impl PatchLink {
    pub(super) fn check_reverse_manifest(&self) -> Result<()> {
        if self.reverse_docs.is_empty() {
            return Ok(());
        }
        let channel = self.channel.as_ref().ok_or(ACCESS)?;
        let mut assets = vec![];
        for (rel, key) in &self.reverse_docs {
            for direction in ReverseMove::ALL {
                assets.extend(
                    channel
                        .reverse_assets(direction, &self.token, &self.absolute_root, rel, key)
                        .ok_or(CONFLICT)?,
                );
            }
        }
        if !self
            .channel
            .as_ref()
            .ok_or(ACCESS)?
            .has_reverse_assets(&assets)
        {
            return Err("iOS chưa xác nhận đủ hai chiều sao lưu và khôi phục tệp.".into());
        }
        Ok(())
    }
    pub(crate) fn select_reverse_doc(&mut self, rel: &str, key: &str) -> Result<()> {
        self.reverse_active = self
            .reverse_docs
            .iter()
            .position(|(r, k)| r == rel && k == key)
            .ok_or(CONFLICT)?;
        Ok(())
    }
    pub(crate) fn declares_reverse_plan(&self, plan: &[(String, String)]) -> bool {
        self.reverse_docs == plan
    }
    fn selected_reverse(&self) -> Result<&(String, String)> {
        self.reverse_docs
            .get(self.reverse_active)
            .ok_or_else(|| CONFLICT.into())
    }
    fn document_path(&self, rel: &str) -> Result<String> {
        if !valid_reverse_relative(rel)
            || self.executable.is_some()
            || !self.absolute_root.starts_with(DATA_PARENT)
        {
            return Err(CONFLICT.into());
        }
        match self.io_prefix.as_deref() {
            Some("Documents/") => Ok(format!("/{rel}")),
            None if self.media.is_none() => Ok(format!("{}/{rel}", self.alias)),
            _ => Err(CONFLICT.into()),
        }
    }
    async fn check_document_parents(&mut self, path: &str) -> Result<()> {
        let prefix = if self.io_prefix.is_some() {
            ""
        } else {
            &self.alias
        };
        match walk_parents(&mut self.afc, path, prefix, None).await? {
            Some(reason) => Err(reason),
            None => Ok(()),
        }
    }
    pub(crate) async fn reverse_review_parent(&mut self) -> Result<Option<String>> {
        self.verify().await?;
        let path = self.reverse_target_path()?;
        let prefix = if self.io_prefix.is_some() {
            ""
        } else {
            &self.alias
        };
        walk_parents(&mut self.afc, &path, prefix, None).await
    }
    pub(crate) fn is_local_patch_refusal(reason: &str) -> bool {
        reason == NO_WITNESS || reason == FILE_TOO_LARGE
    }
    #[cfg(test)]
    pub(crate) async fn reverse_preflight_witness(
        &mut self,
        rel: &str,
    ) -> Result<ReversePreflight> {
        self.verify().await?;
        let path = self.document_path(rel)?;
        let prefix = if self.io_prefix.is_some() {
            ""
        } else {
            &self.alias
        };
        inspect_leaf(
            &mut self.afc,
            &path,
            prefix,
            &mut HashSet::new(),
            &mut HashSet::new(),
        )
        .await
    }
    pub(crate) fn reverse_target_path(&self) -> Result<String> {
        self.document_path(&self.selected_reverse()?.0)
    }
    pub(crate) fn reverse_media_path(&self) -> Result<String> {
        Ok(format!("/cc365-held-{}", self.selected_reverse()?.1))
    }
    pub(crate) fn reverse_stage_path(&self) -> Result<String> {
        Ok(format!("/cc365-put-{}", self.selected_reverse()?.1))
    }
    pub(crate) async fn reverse_verified_stage_witness(
        client: &mut AfcClient,
        path: &str,
        expected: Option<&str>,
    ) -> Result<Option<String>> {
        if !path
            .strip_prefix("/cc365-put-")
            .is_some_and(valid_reverse_key)
        {
            return Err(CONFLICT.into());
        }
        file_witness(client, path, expected).await
    }
    pub(crate) async fn reverse_verified_held_witness(
        client: &mut AfcClient,
        path: &str,
        expected: Option<&str>,
    ) -> Result<Option<String>> {
        if !path
            .strip_prefix("/cc365-held-")
            .is_some_and(valid_reverse_key)
        {
            return Err(CONFLICT.into());
        }
        file_witness(client, path, expected).await
    }
    pub(crate) fn reverse_media_afc(&mut self) -> Result<&mut AfcClient> {
        self.selected_reverse()?;
        Ok(self.media.as_mut().unwrap_or(&mut self.afc))
    }
    fn client_path(&mut self, place: Place) -> Result<(&mut AfcClient, String)> {
        match place {
            Place::Target => {
                let path = self.reverse_target_path()?;
                Ok((&mut self.afc, path))
            }
            Place::Held => {
                let path = self.reverse_media_path()?;
                Ok((self.reverse_media_afc()?, path))
            }
            Place::Stage => {
                let path = self.reverse_stage_path()?;
                Ok((self.reverse_media_afc()?, path))
            }
        }
    }
    async fn is_absent(&mut self, place: Place) -> Result<bool> {
        let (client, path) = self.client_path(place)?;
        Ok(stat(client, &path).await?.is_none())
    }
    async fn witness_at(&mut self, place: Place, expected: Option<&str>) -> Result<Option<String>> {
        let (client, path) = self.client_path(place)?;
        file_witness(client, &path, expected).await
    }
    pub(crate) async fn reverse_leaf_inode(&mut self, held: bool) -> Result<Option<String>> {
        if !held {
            let path = self.reverse_target_path()?;
            if matches!(
                opaque::observe(&mut self.afc, &path).await?,
                opaque::Observation::Denied
            ) {
                return Ok(Some("opaque".into()));
            }
        }
        self.witness_at(if held { Place::Held } else { Place::Target }, None)
            .await
    }
    pub(crate) async fn reverse_held_witness_as(
        &mut self,
        target_witness: &str,
    ) -> Result<Option<String>> {
        self.witness_at(Place::Held, Some(target_witness)).await
    }
    pub(crate) async fn reverse_stage_witness(&mut self) -> Result<Option<String>> {
        self.witness_at(Place::Stage, None).await
    }
    pub(crate) async fn reverse_matches(&mut self, held: bool, witness: &str) -> Result<bool> {
        Ok(self
            .witness_at(
                if held { Place::Held } else { Place::Target },
                Some(witness),
            )
            .await?
            .as_deref()
            == Some(witness))
    }
    pub(crate) async fn stage_matches(&mut self, witness: &str) -> Result<bool> {
        Ok(self
            .witness_at(Place::Stage, Some(witness))
            .await?
            .as_deref()
            == Some(witness))
    }
}

async fn walk_parents(
    afc: &mut AfcClient,
    path: &str,
    prefix: &str,
    mut cache: Option<&mut HashSet<String>>,
) -> Result<Option<String>> {
    let relative = path
        .strip_prefix(prefix)
        .and_then(|p| p.strip_prefix('/'))
        .ok_or(CONFLICT)?;
    for (slash, _) in relative.match_indices('/') {
        let label = &relative[..slash];
        let folder = &path[..path.len() - relative.len() + slash];
        if cache
            .as_ref()
            .is_some_and(|parents| parents.contains(folder))
        {
            continue;
        }
        let reply = tokio::time::timeout(Duration::from_secs(8), afc.get_file_info_raw(folder))
            .await
            .map_err(|_| AFC_ERROR)?;
        match reply {
            Ok(info) if kind(&info) == "S_IFDIR" => (),
            Ok(info) if kind(&info).is_empty() => return Err(AFC_ERROR.into()),
            Ok(_) => {
                return Ok(Some(format!(
                    "Đường dẫn cha phải là thư mục thật trong ứng dụng.\n{label}"
                )));
            }
            Err(IdeviceError::Afc(AfcError::ObjectNotFound)) => {
                return Ok(Some(format!("Thiếu thư mục cha trong ứng dụng.\n{label}")));
            }
            Err(IdeviceError::Afc(AfcError::PermDenied)) => {
                return Ok(Some(format!("iOS từ chối xác minh thư mục cha.\n{label}")));
            }
            Err(_) => return Err(AFC_ERROR.into()),
        }
        if let Some(parents) = cache.as_deref_mut() {
            parents.insert(folder.to_owned());
        }
    }
    Ok(None)
}

async fn inspect_leaf(
    afc: &mut AfcClient,
    path: &str,
    prefix: &str,
    parents: &mut HashSet<String>,
    distinct: &mut HashSet<String>,
) -> Result<ReversePreflight> {
    if let Some(reason) = walk_parents(afc, path, prefix, Some(parents)).await? {
        return Ok(ReversePreflight::Unavailable(reason));
    }
    match opaque::inspect(afc, path).await? {
        opaque::Leaf::Visible(before) => match witnessed_file(afc, path, None, before).await {
            Ok(Some(w)) => Ok(ReversePreflight::Ready(w)),
            Ok(None) => Err(CHANGED.into()),
            Err(e) if PatchLink::is_local_patch_refusal(&e) => Ok(ReversePreflight::Unavailable(e)),
            Err(e) => Err(e),
        },
        opaque::Leaf::Absent => Ok(ReversePreflight::Ready("missing".into())),
        opaque::Leaf::Denied => {
            let parent = path.rsplit_once('/').ok_or(CONFLICT)?.0;
            if !distinct.contains(parent) {
                opaque::check_denied_sibling(afc, parent).await?;
                distinct.insert(parent.to_owned());
            }
            Ok(ReversePreflight::Ready("opaque".into()))
        }
    }
}

async fn file_witness(
    client: &mut AfcClient,
    path: &str,
    expected: Option<&str>,
) -> Result<Option<String>> {
    let Some(before) = stat(client, path).await? else {
        return Ok(None);
    };
    witnessed_file(client, path, expected, before).await
}

async fn witnessed_file(
    client: &mut AfcClient,
    path: &str,
    expected: Option<&str>,
    before: Info,
) -> Result<Option<String>> {
    if kind(&before).is_empty() {
        return Err(AFC_ERROR.into());
    }
    if kind(&before) != "S_IFREG" || before.get("st_nlink").is_some_and(|n| n != "1") {
        return Err(NO_WITNESS.into());
    }
    let len = before
        .get("st_size")
        .and_then(|s| s.parse::<u64>().ok())
        .ok_or(AFC_ERROR)?;
    if len > MAX_BYTES {
        return Err(FILE_TOO_LARGE.into());
    }
    let mut witness = None;
    if expected.is_none_or(|s| s.starts_with("sha1:")) {
        let result = tokio::time::timeout(Duration::from_secs(45), client.get_file_hash(path))
            .await
            .map_err(|_| WAIT)?;
        match result {
            Ok(hash) if hash.len() == 20 => {
                let hex: String = hash.iter().map(|b| format!("{b:02x}")).collect();
                witness = Some(format!("sha1:{hex}:{len}"));
            }
            Err(IdeviceError::Afc(AfcError::OpNotSupported | AfcError::UnknownPacketType))
                if expected.is_some()
                    || before
                        .get("st_ino")
                        .and_then(|n| n.parse::<u64>().ok())
                        .unwrap_or(0)
                        == 0 =>
            {
                let mut sha = sha1::Sha1::new();
                let open = tokio::time::timeout(
                    Duration::from_secs(8),
                    open_handle(client, path, AfcFopenMode::RdOnly),
                )
                .await
                .map_err(|_| WAIT)?;
                let handle = match open {
                    Ok(handle) => handle,
                    Err(IdeviceError::Afc(AfcError::PermDenied | AfcError::OpNotSupported)) => {
                        return Err(NO_WITNESS.into());
                    }
                    Err(_) => return Err(AFC_ERROR.into()),
                };
                let result = async {
                    let mut remaining = len;
                    while remaining > 0 {
                        let block = remaining.min(16 * 1024);
                        let args = [handle.to_le_bytes(), block.to_le_bytes()].concat();
                        let bytes = io(client.send_op(AfcOpcode::Read, args, vec![]))
                            .await?
                            .payload;
                        if bytes.is_empty() || bytes.len() as u64 > block {
                            return Err(CHANGED.to_owned());
                        }
                        sha.update(&bytes);
                        remaining -= bytes.len() as u64;
                    }
                    Ok(())
                }
                .await;
                let close = io(close_handle(client, handle)).await;
                result?;
                close?;
                witness = Some(format!("sha1:{:x}:{len}", sha.finalize()));
            }
            Err(IdeviceError::Afc(
                AfcError::PermDenied | AfcError::OpNotSupported | AfcError::UnknownPacketType,
            )) if expected.is_none() => {}
            Err(IdeviceError::Afc(AfcError::PermDenied)) => return Err(NO_WITNESS.into()),
            _ => return Err(AFC_ERROR.into()),
        }
    }
    if witness.is_none() && expected.is_none_or(|s| s.starts_with("ino:")) {
        let positive = |k: &str| before.get(k)?.parse::<u64>().ok().filter(|n| *n > 0);
        if let (Some(inode), Some(mtime)) = (positive("st_ino"), positive("st_mtime")) {
            witness = Some(format!("ino:{inode}:{mtime}:{len}"));
        }
    }
    let after = stat(client, path).await?.ok_or(CHANGED)?;
    for field in [
        "st_ifmt",
        "st_size",
        "st_ino",
        "st_mtime",
        "st_birthtime",
        "st_nlink",
    ] {
        if after.get(field) != before.get(field) || kind(&after) != "S_IFREG" {
            return Err(CHANGED.into());
        }
    }
    Ok(Some(witness.ok_or(NO_WITNESS)?))
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn reverse_plan_only_accepts_unique_descendants_and_install_roots() {
        let root = "/var/mobile/Containers/Data/Application/12345678-1234-1234-1234-123456789ABC";
        let row = ("Documents/Game/Actor105".to_owned(), "a".repeat(32));
        assert!(valid_reverse_plan(root, std::slice::from_ref(&row)));
        for bad in [
            "Library/Caches/x",
            "Documents/x/../y",
            "Documents/.hidden/z",
            "Documents//x",
            "Documents/a/",
            "Documents",
            "/Documents/a",
        ] {
            assert!(!valid_reverse_plan(root, &[(bad.into(), row.1.clone())]));
        }
        assert!(!valid_reverse_plan(
            root,
            &[row.clone(), ("Documents/Other".into(), row.1.clone())]
        ));
        assert!(!valid_reverse_plan(
            root,
            &[
                row.clone(),
                (
                    row.0.to_lowercase().replacen("documents", "Documents", 1),
                    "b".repeat(32)
                )
            ]
        ));
        assert!(!valid_reverse_plan(
            "/var/containers/Bundle/Application/12345678-1234-1234-1234-123456789ABC",
            &[row]
        ));
    }

    #[test]
    fn bounded_32_file_plan_keeps_journal_and_books_frames_below_their_limits() {
        let root = "/var/mobile/Containers/Data/Application/12345678-1234-1234-1234-123456789ABC";
        let plans: Vec<_> = (0..MAX_REVERSE_PLAN_ITEMS)
            .map(|i| {
                (
                    format!(
                        "Documents/{}/{}/{}/{i:02}",
                        "a".repeat(255),
                        "b".repeat(255),
                        "c".repeat(190)
                    ),
                    format!("{i:032x}"),
                )
            })
            .collect();
        assert!(valid_reverse_plan(root, &plans));
        assert!(serde_json::to_vec(&plans).unwrap().len() <= 24 * 1024);
        let oversized: Vec<_> = plans
            .iter()
            .map(|(name, key)| {
                (
                    name.replace(&"c".repeat(190), &"c".repeat(224)),
                    key.clone(),
                )
            })
            .collect();
        assert!(!reverse_plan_fits(&oversized));
        assert!(!valid_reverse_plan(root, &oversized));
        let mut excess = plans.clone();
        excess.push(("Documents/extra".into(), "f".repeat(32)));
        assert!(!reverse_plan_fits(&excess));

        let mut trial = Trial::new(true);
        trial.patch_parent = Some(root.into());
        trial.reverse_docs = plans;
        trial.reverse_redelivery = true;
        assert!(serde_json::to_vec(&trial).unwrap().len() < 32 * 1024);
        assert!(trial.manifest().unwrap().len() < 1024 * 1024);
        let sandbox = tempfile::tempdir().unwrap();
        let journal = sandbox.path().join("trial.json");
        trial.save(&journal).unwrap();
        assert_eq!(
            Trial::load(&journal).unwrap().unwrap().manifest().unwrap(),
            trial.manifest().unwrap()
        );
        let rows: Vec<_> = trial
            .manifest_moves()
            .into_iter()
            .map(|(id, _)| {
                let mut row = Dictionary::new();
                row.insert("AssetID".into(), id.into());
                row.insert("IsDownload".into(), true.into());
                Plist::Dictionary(row)
            })
            .collect();
        let mut reply = Dictionary::new();
        reply.insert("Assets".into(), Plist::Array(rows));
        let mut encoded = vec![];
        Plist::Dictionary(reply)
            .to_writer_binary(&mut encoded)
            .unwrap();
        assert!(encoded.len() < 1024 * 1024);
    }

    #[test]
    fn old_trial_defaults_to_no_reverse_assets_and_batched_recovery_data_round_trips() {
        let mut trial = Trial::new(true);
        let root = "/var/mobile/Containers/Data/Application/12345678-1234-1234-1234-123456789ABC";
        trial.patch_parent = Some(root.into());
        let sandbox = tempfile::tempdir().unwrap();
        let path = sandbox.path().join("trial");
        trial.save(&path).unwrap();
        let old = Trial::load(&path).unwrap().unwrap();
        assert!(old.reverse_docs.is_empty());
        for i in 0..16 {
            let prefix = "A".repeat(200);
            let name = format!("Documents/{prefix}/{prefix}/{prefix}/{i}.dat");
            trial.reverse_docs.push((name, format!("{i:032x}")));
        }
        trial.save(&path).unwrap();
        let restored = Trial::load(&path).unwrap().unwrap();
        assert_eq!(restored.reverse_docs, trial.reverse_docs);
        assert_eq!(restored.moves().len(), 1);
        assert_eq!(restored.manifest_moves().len(), 97);
        let mut old_json = serde_json::to_value(&trial).unwrap();
        old_json
            .as_object_mut()
            .unwrap()
            .remove("reverse_redelivery");
        let legacy: Trial = serde_json::from_value(old_json).unwrap();
        assert_eq!(legacy.manifest().unwrap(), restored.manifest().unwrap());
        trial.reverse_redelivery = true;
        assert_eq!(trial.manifest_moves().len(), 193);
    }
}
