use idevice::ReadWrite;
use std::{
    io,
    pin::Pin,
    task::{Context, Poll},
};
use tokio::io::{AsyncRead, AsyncWrite, ReadBuf};
#[derive(Debug)]
pub(super) struct BoundedAfc {
    stream: Box<dyn ReadWrite>,
    header: [u8; 40],
    read: usize,
    sent: usize,
    body: u64,
    failed: bool,
}
impl BoundedAfc {
    pub(super) fn wrap(stream: Box<dyn ReadWrite>) -> Box<dyn ReadWrite> {
        Box::new(Self {
            stream,
            header: [0; 40],
            read: 0,
            sent: 0,
            body: 0,
            failed: false,
        })
    }
    fn reject(&mut self) -> Poll<io::Result<()>> {
        self.failed = true;
        Poll::Ready(Err(io::Error::new(
            io::ErrorKind::InvalidData,
            "Invalid bounded AFC response",
        )))
    }
}
impl AsyncRead for BoundedAfc {
    fn poll_read(
        self: Pin<&mut Self>,
        cx: &mut Context<'_>,
        buf: &mut ReadBuf<'_>,
    ) -> Poll<io::Result<()>> {
        let this = self.get_mut();
        if this.failed {
            return this.reject();
        }
        if buf.remaining() == 0 {
            return Poll::Ready(Ok(()));
        }
        if this.sent < 40 {
            while this.read < 40 {
                let mut part = ReadBuf::new(&mut this.header[this.read..]);
                match Pin::new(&mut *this.stream).poll_read(cx, &mut part) {
                    Poll::Pending => return Poll::Pending,
                    Poll::Ready(Err(e)) => {
                        this.failed = true;
                        return Poll::Ready(Err(e));
                    }
                    Poll::Ready(Ok(())) => {
                        let n = part.filled().len();
                        if n == 0 {
                            return this.reject();
                        }
                        this.read += n;
                    }
                }
            }
            if this.sent == 0 {
                let word = |i| u64::from_le_bytes(this.header[i..i + 8].try_into().unwrap());
                let total = word(8);
                let header = word(16);
                if word(0) != idevice::afc::MAGIC
                    || header < 40
                    || header > total
                    || total > 8 * 1024 * 1024 + 40
                {
                    return this.reject();
                }
                this.body = total - 40;
            }
            let n = buf.remaining().min(40 - this.sent);
            buf.put_slice(&this.header[this.sent..this.sent + n]);
            this.sent += n;
            if this.sent == 40 && this.body == 0 {
                this.read = 0;
                this.sent = 0;
            }
            return Poll::Ready(Ok(()));
        }
        let n = buf.remaining().min(this.body as usize);
        let mut part = ReadBuf::new(buf.initialize_unfilled_to(n));
        match Pin::new(&mut *this.stream).poll_read(cx, &mut part) {
            Poll::Pending => Poll::Pending,
            Poll::Ready(Err(e)) => {
                this.failed = true;
                Poll::Ready(Err(e))
            }
            Poll::Ready(Ok(())) => {
                let n = part.filled().len();
                if n == 0 {
                    return this.reject();
                }
                buf.advance(n);
                this.body -= n as u64;
                if this.body == 0 {
                    this.read = 0;
                    this.sent = 0;
                }
                Poll::Ready(Ok(()))
            }
        }
    }
}
impl AsyncWrite for BoundedAfc {
    fn poll_write(self: Pin<&mut Self>, cx: &mut Context<'_>, b: &[u8]) -> Poll<io::Result<usize>> {
        Pin::new(&mut *self.get_mut().stream).poll_write(cx, b)
    }
    fn poll_flush(self: Pin<&mut Self>, cx: &mut Context<'_>) -> Poll<io::Result<()>> {
        Pin::new(&mut *self.get_mut().stream).poll_flush(cx)
    }
    fn poll_shutdown(self: Pin<&mut Self>, cx: &mut Context<'_>) -> Poll<io::Result<()>> {
        Pin::new(&mut *self.get_mut().stream).poll_shutdown(cx)
    }
}
#[cfg(test)]
mod tests {
    use super::*;
    use tokio::io::{AsyncReadExt, AsyncWriteExt};
    fn frame(total: u64, head: u64) -> Vec<u8> {
        [idevice::afc::MAGIC, total, head, 0, 2]
            .into_iter()
            .flat_map(u64::to_le_bytes)
            .collect()
    }
    #[tokio::test]
    async fn rejects_oversized_or_underflowing_header_before_dependency_can_allocate() {
        for (total, head) in [
            (u64::MAX, 40),
            (39, 40),
            (40, 0),
            (40, 41),
            (8 * 1024 * 1024 + 41, 40),
        ] {
            let (a, mut b) = tokio::io::duplex(128);
            b.write_all(&frame(total, head)).await.unwrap();
            let mut s = BoundedAfc::wrap(Box::new(a));
            let mut first = [0; 40];
            assert!(s.read_exact(&mut first).await.is_err());
        }
    }
    #[tokio::test]
    async fn preserves_multiple_valid_frames_and_fragmented_read_sizes() {
        let mut data = frame(43, 40);
        data.extend(b"abc");
        data.extend(frame(40, 40));
        let expected = data.clone();
        let (a, mut b) = tokio::io::duplex(128);
        b.write_all(&data).await.unwrap();
        let mut s = BoundedAfc::wrap(Box::new(a));
        let mut actual = vec![0; expected.len()];
        for chunk in actual.chunks_mut(7) {
            s.read_exact(chunk).await.unwrap();
        }
        assert_eq!(actual, expected);
    }
}
