use super::{IO_TIMEOUT, invalid, native};
use crate::sync::{AtcChannel, SyncControl, SyncError};
use idevice::{IdeviceError, ReadWrite, rsd::RsdHandshake, tcp::handle::AdapterHandle};
use std::time::Duration;
use tokio::io::{AsyncRead, AsyncReadExt, AsyncWrite, AsyncWriteExt};

const MAX_FRAME: usize = 1024 * 1024;
#[derive(Clone, Copy)]
enum Framing {
    RsdBigEndian,
    AtcLittleEndian,
}

pub struct NativeAtcChannel {
    stream: Option<Box<dyn ReadWrite>>,
    control: SyncControl,
    timeout: Duration,
}

impl NativeAtcChannel {
    pub(super) fn from_stream(stream: Box<dyn ReadWrite>, control: SyncControl) -> Self {
        Self {
            stream: Some(stream),
            control,
            timeout: IO_TIMEOUT,
        }
    }
    pub async fn connect(
        adapter: &mut AdapterHandle,
        handshake: &RsdHandshake,
        control: SyncControl,
    ) -> Result<Self, SyncError> {
        let service = handshake
            .services
            .get("com.apple.atc.shim.remote")
            .ok_or(SyncError::InvalidData("ATC shim is not advertised by RSD"))?;
        if service.port == 0 || service.uses_remote_xpc {
            return Err(SyncError::InvalidData(
                "ATC service is not a non-RemoteXPC plist shim",
            ));
        }
        let stream = native(&control, IO_TIMEOUT, "ATC RSD check-in", async {
            let mut stream: Box<dyn ReadWrite> = Box::new(adapter.connect(service.port).await?);
            checkin(&mut *stream).await?;
            Ok(stream)
        })
        .await?;
        control.log("ATC: RSDCheckin + StartService replies received; channel open.");
        Ok(Self {
            stream: Some(stream),
            control,
            timeout: IO_TIMEOUT,
        })
    }
}

impl AtcChannel for NativeAtcChannel {
    async fn send(&mut self, plist: &plist::Dictionary) -> Result<(), SyncError> {
        self.control.check()?;
        let stream = self
            .stream
            .as_mut()
            .ok_or(SyncError::Transport("ATC stream is closed"))?;
        let mut body = Vec::new();
        plist::Value::Dictionary(plist.clone())
            .to_writer_binary(&mut body)
            .map_err(|_| SyncError::InvalidData("outgoing ATC plist could not be encoded"))?;
        if body.is_empty() || body.len() > MAX_FRAME {
            return Err(SyncError::InvalidData("outgoing ATC frame exceeds 1 MiB"));
        }
        let result = native(
            &self.control,
            self.timeout,
            "ATC send",
            write_frame(&mut **stream, &body, Framing::AtcLittleEndian),
        )
        .await;
        if result.is_err() {
            self.stream.take();
        }
        if result.is_ok() {
            match plist.get("Command").and_then(plist::Value::as_string) {
                Some(command @ ("RequestingSync" | "FinishedSyncingMetadata")) => {
                    self.control.log(&format!("ATC sent {command}."))
                }
                _ => {}
            }
        }
        result
    }

    async fn receive(&mut self) -> Result<plist::Dictionary, SyncError> {
        self.control.check()?;
        let stream = self
            .stream
            .as_mut()
            .ok_or(SyncError::Transport("ATC stream is closed"))?;
        let result = native(&self.control, self.timeout, "ATC receive", async {
            let body = read_frame(&mut **stream, Framing::AtcLittleEndian).await?;
            let dictionary = dictionary(&body)?;
            Ok((dictionary, body.len()))
        })
        .await;
        if result.is_err() {
            self.stream.take();
        }
        let (dictionary, length) = result?;
        let command = match dictionary.get("Command").and_then(plist::Value::as_string) {
            Some(
                command @ ("SyncAllowed"
                | "ReadyForSync"
                | "SyncFailed"
                | "SyncFinished"
                | "FinishedSyncing"
                | "FinishedSyncingMetadata"
                | "SyncDidFinish"
                | "SyncComplete"),
            ) => command,
            _ => "other event",
        };
        self.control
            .log(&format!("ATC received {command} ({length} bytes)."));
        Ok(dictionary)
    }
}

fn dictionary(body: &[u8]) -> Result<plist::Dictionary, IdeviceError> {
    let value: plist::Value = plist::from_bytes(body)?;
    value
        .into_dictionary()
        .ok_or_else(|| invalid("ATC plist is not a dictionary"))
}

async fn write_frame<S: AsyncWrite + Unpin + ?Sized>(
    stream: &mut S,
    body: &[u8],
    framing: Framing,
) -> Result<(), IdeviceError> {
    if body.is_empty() || body.len() > MAX_FRAME {
        return Err(invalid("invalid ATC frame size"));
    }
    let prefix = match framing {
        Framing::RsdBigEndian => (body.len() as u32).to_be_bytes(),
        Framing::AtcLittleEndian => (body.len() as u32).to_le_bytes(),
    };
    stream.write_all(&prefix).await?;
    stream.write_all(body).await?;
    stream.flush().await?;
    Ok(())
}

async fn read_frame<S: AsyncRead + Unpin + ?Sized>(
    stream: &mut S,
    framing: Framing,
) -> Result<Vec<u8>, IdeviceError> {
    let mut prefix = [0; 4];
    stream.read_exact(&mut prefix).await?;
    let length = match framing {
        Framing::RsdBigEndian => u32::from_be_bytes(prefix),
        Framing::AtcLittleEndian => u32::from_le_bytes(prefix),
    } as usize;
    if length == 0 || length > MAX_FRAME {
        return Err(invalid("ATC frame outside 1..=1048576 bytes"));
    }
    let mut body = vec![0; length];
    stream.read_exact(&mut body).await?;
    Ok(body)
}

pub(super) async fn checkin<S: AsyncRead + AsyncWrite + Unpin + ?Sized>(
    stream: &mut S,
) -> Result<(), IdeviceError> {
    let mut request = plist::Dictionary::new();
    request.insert("Request".into(), "RSDCheckin".into());
    request.insert("Label".into(), "CC365-Apps".into());
    request.insert("ProtocolVersion".into(), "2".into());
    let mut body = Vec::new();
    plist::Value::Dictionary(request).to_writer_xml(&mut body)?;
    write_frame(stream, &body, Framing::RsdBigEndian).await?;
    for expected in ["RSDCheckin", "StartService"] {
        let reply = dictionary(&read_frame(stream, Framing::RsdBigEndian).await?)?;
        if reply.contains_key("Error") {
            return Err(invalid("RSD check-in response contains Error"));
        }
        if reply.get("Request").and_then(plist::Value::as_string) != Some(expected) {
            return Err(invalid("unexpected RSD check-in response order"));
        }
    }
    Ok(())
}

#[cfg(test)]
mod tests {
    use super::*;
    use std::sync::{Arc, atomic::AtomicBool};
    fn control() -> SyncControl {
        SyncControl::new(Arc::new(AtomicBool::new(false)), Arc::new(|_| {}))
    }
    fn encoded(key: &str, value: &str, binary: bool) -> Vec<u8> {
        let mut dict = plist::Dictionary::new();
        dict.insert(key.into(), value.into());
        let value = plist::Value::Dictionary(dict);
        let mut bytes = Vec::new();
        if binary {
            value.to_writer_binary(&mut bytes).unwrap();
        } else {
            value.to_writer_xml(&mut bytes).unwrap();
        }
        bytes
    }
    #[tokio::test]
    async fn checkin_then_atc_switches_endianness() {
        let (mut client, mut peer) = tokio::io::duplex(4096);
        let server = tokio::spawn(async move {
            let request =
                dictionary(&read_frame(&mut peer, Framing::RsdBigEndian).await.unwrap()).unwrap();
            assert_eq!(
                request.get("Request").and_then(plist::Value::as_string),
                Some("RSDCheckin")
            );
            assert_eq!(
                request
                    .get("ProtocolVersion")
                    .and_then(plist::Value::as_string),
                Some("2")
            );
            write_frame(
                &mut peer,
                &encoded("Request", "RSDCheckin", false),
                Framing::RsdBigEndian,
            )
            .await
            .unwrap();
            write_frame(
                &mut peer,
                &encoded("Request", "StartService", true),
                Framing::RsdBigEndian,
            )
            .await
            .unwrap();
            let body = encoded("Command", "SyncAllowed", true);
            peer.write_all(&(body.len() as u32).to_le_bytes())
                .await
                .unwrap();
            peer.write_all(&body).await.unwrap();
            let mut prefix = [0; 4];
            peer.read_exact(&mut prefix).await.unwrap();
            let length = u32::from_le_bytes(prefix) as usize;
            assert!(length < 4096);
            let mut body = vec![0; length];
            peer.read_exact(&mut body).await.unwrap();
            assert!(body.starts_with(b"bplist00"));
            assert_eq!(
                dictionary(&body)
                    .unwrap()
                    .get("Command")
                    .and_then(plist::Value::as_string),
                Some("RequestingSync")
            );
        });
        checkin(&mut client).await.unwrap();
        let mut channel = NativeAtcChannel {
            stream: Some(Box::new(client)),
            control: control(),
            timeout: Duration::from_secs(2),
        };
        assert_eq!(
            channel
                .receive()
                .await
                .unwrap()
                .get("Command")
                .and_then(plist::Value::as_string),
            Some("SyncAllowed")
        );
        let mut request = plist::Dictionary::new();
        request.insert("Command".into(), "RequestingSync".into());
        channel.send(&request).await.unwrap();
        server.await.unwrap();
    }
    #[tokio::test]
    async fn invalid_length_is_rejected_without_body_and_poisons_stream() {
        for length in [0u32, MAX_FRAME as u32 + 1] {
            let (client, mut peer) = tokio::io::duplex(64);
            peer.write_all(&length.to_le_bytes()).await.unwrap();
            let mut channel = NativeAtcChannel {
                stream: Some(Box::new(client)),
                control: control(),
                timeout: Duration::from_secs(1),
            };
            assert!(matches!(
                channel.receive().await,
                Err(SyncError::Native { code: 13, .. })
            ));
            assert!(channel.stream.is_none());
            assert!(matches!(
                channel.receive().await,
                Err(SyncError::Transport(_))
            ));
        }
    }
    #[tokio::test]
    async fn partial_frame_timeout_poisons_stream() {
        let (client, mut peer) = tokio::io::duplex(64);
        peer.write_all(&32u32.to_le_bytes()).await.unwrap();
        peer.write_all(b"bplist").await.unwrap();
        let mut channel = NativeAtcChannel {
            stream: Some(Box::new(client)),
            control: control(),
            timeout: Duration::from_millis(10),
        };
        assert!(matches!(channel.receive().await, Err(SyncError::TimedOut)));
        assert!(channel.stream.is_none());
    }
    #[tokio::test]
    async fn cancelling_partial_read_drops_the_connection() {
        let (client, mut peer) = tokio::io::duplex(64);
        peer.write_all(&32u32.to_le_bytes()).await.unwrap();
        let control = control();
        let cancel = control.cancelled.clone();
        let trigger = tokio::spawn(async move {
            tokio::time::sleep(Duration::from_millis(10)).await;
            cancel.store(true, std::sync::atomic::Ordering::Release);
        });
        let mut channel = NativeAtcChannel {
            stream: Some(Box::new(client)),
            control,
            timeout: Duration::from_secs(2),
        };
        assert!(matches!(channel.receive().await, Err(SyncError::Cancelled)));
        assert!(channel.stream.is_none());
        trigger.await.unwrap();
    }
    #[tokio::test]
    async fn checkin_rejects_wrong_order_and_error() {
        for body in [
            encoded("Request", "StartService", true),
            encoded("Error", "synthetic-private-value", false),
        ] {
            let (mut client, mut peer) = tokio::io::duplex(2048);
            let server = tokio::spawn(async move {
                read_frame(&mut peer, Framing::RsdBigEndian).await.unwrap();
                write_frame(&mut peer, &body, Framing::RsdBigEndian)
                    .await
                    .unwrap();
            });
            assert_eq!(checkin(&mut client).await.unwrap_err().code(), 13);
            server.await.unwrap();
        }
    }
}
