use super::{DeviceSession, IO_TIMEOUT};
use crate::sync::{SyncControl, SyncError};
use idevice::{
    IdeviceError,
    afc::{
        AfcClient,
        errors::AfcError,
        opcode::{AfcFopenMode, AfcOpcode, LinkType},
    },
};
use rand::seq::IteratorRandom;
use serde_json::{Value, json};
use std::{
    collections::HashMap,
    future::Future,
    os::unix::fs::OpenOptionsExt,
    path::{Path, PathBuf},
};
use tokio::{
    fs::File,
    io::{AsyncReadExt, AsyncWriteExt},
};

const WORKSPACE: &str = "/CC365";
const PART_PREFIX: &str = ".cc365-part-";
const PUBLISH_CLAIM: &str = ".cc365-part-publish";
const STALE_AGE: u64 = 24 * 60 * 60;
const PAGE: usize = 100;
const MAX_TRANSFER: u64 = 256 * 1024 * 1024;
const READ_BUFFER: usize = 16 * 1024;
const WRITE_BUFFER: usize = 64 * 1024;
const INVALID_PATH: &str = "Tên hoặc đường dẫn tệp không hợp lệ.";
const OUTSIDE: &str = "Chỉ có thể ghi trong thư mục CC365.";
const NOT_FOLDER: &str = "Mục này không phải thư mục có thể mở.";
const NOT_FILE: &str = "Chỉ có thể xuất tệp thông thường.";
const EXISTS: &str = "Tên này đã tồn tại. Hãy chọn tên khác.";
const TOOBIG: &str = "Kích thước tối đa mỗi lần chuyển là 256 MiB.";
const CHANGED: &str = "Tệp đã thay đổi trong lúc chuyển. Hãy thử lại.";

fn name_ok(name: &str) -> bool {
    !name.is_empty()
        && name.len() <= 255
        && name != "."
        && name != ".."
        && !name
            .as_bytes()
            .get(..PART_PREFIX.len())
            .is_some_and(|s| s.eq_ignore_ascii_case(PART_PREFIX.as_bytes()))
        && !name.contains(['/', '\\'])
        && !name.chars().any(char::is_control)
}

fn validate(action: &str, path: &str, local: Option<&Path>) -> Result<(), String> {
    let relative = path.strip_prefix('/').ok_or(INVALID_PATH)?;
    if path.len() > 4096
        || (!relative.is_empty()
            && (relative.split('/').count() > 64 || !relative.split('/').all(name_ok)))
    {
        return Err(INVALID_PATH.into());
    }
    if matches!(action, "mkdir" | "import" | "delete")
        && !(path.starts_with("/CC365/") || (action == "mkdir" && path == WORKSPACE))
    {
        return Err(OUTSIDE.into());
    }
    match (action, local) {
        ("list" | "mkdir" | "delete", None) => Ok(()),
        ("export" | "import", Some(file))
            if path != "/" && file.is_absolute() && file.file_name().is_some() =>
        {
            Ok(())
        }
        _ => Err(INVALID_PATH.into()),
    }
}

fn child(parent: &str, name: &str) -> String {
    format!("{}/{name}", parent.trim_end_matches('/'))
}

fn split_path(path: &str) -> (&str, &str) {
    let (parent, name) = path.rsplit_once('/').expect("validated absolute AFC path");
    (if parent.is_empty() { "/" } else { parent }, name)
}

fn temp_name() -> String {
    format!("{PART_PREFIX}{:032x}", rand::random::<u128>())
}

fn io_error(error: IdeviceError) -> String {
    match error {
        IdeviceError::Afc(AfcError::ObjectExists) => EXISTS,
        IdeviceError::Afc(AfcError::ObjectNotFound) => "Tệp hoặc thư mục không còn ở vị trí này.",
        IdeviceError::Afc(AfcError::PermDenied) => "iOS không cho phép truy cập mục này.",
        IdeviceError::Afc(AfcError::DirNotEmpty) => "Chỉ có thể xoá thư mục trống.",
        IdeviceError::Afc(AfcError::NoSpaceLeft) => "Thiết bị đã hết dung lượng trống.",
        IdeviceError::Afc(AfcError::OpNotSupported) => {
            "iOS không hỗ trợ thao tác này qua kết nối hiện tại."
        }
        _ => "Không hoàn tất được thao tác tệp. Hãy kiểm tra kết nối rồi thử lại.",
    }
    .into()
}

async fn afc_io<T>(
    control: &SyncControl,
    operation: impl Future<Output = Result<T, IdeviceError>>,
) -> Result<T, String> {
    control
        .wait(IO_TIMEOUT, async { Ok(operation.await) })
        .await
        .map_err(|e| match e {
            SyncError::Cancelled => "Đã dừng thao tác tệp.",
            _ => "Thiết bị phản hồi chậm. Hãy thử lại.",
        })?
        .map_err(io_error)
}

#[derive(PartialEq, Debug)]
struct Info {
    kind: &'static str,
    size: Option<u64>,
    mtime_ns: Option<i64>,
}
impl Info {
    fn from(raw: HashMap<String, String>) -> Self {
        let kind = if raw.contains_key("LinkTarget") || raw.contains_key("st_link_target") {
            "symlink"
        } else {
            match raw.get("st_ifmt").map(String::as_str) {
                Some("S_IFREG") => "file",
                Some("S_IFDIR") => "directory",
                Some("S_IFLNK") => "symlink",
                _ => "other",
            }
        };
        Self {
            kind,
            size: raw.get("st_size").and_then(|v| v.parse().ok()),
            mtime_ns: raw.get("st_mtime").and_then(|v| v.parse().ok()),
        }
    }
    fn length(&self) -> Result<u64, String> {
        if self.kind != "file" {
            return Err(NOT_FILE.into());
        }
        let size = self.size.ok_or("Không đọc được kích thước tệp.")?;
        if size > MAX_TRANSFER {
            Err(TOOBIG.into())
        } else {
            Ok(size)
        }
    }
}

async fn read_info(afc: &mut AfcClient, path: &str) -> Result<Option<Info>, IdeviceError> {
    match afc.get_file_info_raw(path).await {
        Ok(raw) => Ok(Some(Info::from(raw))),
        Err(IdeviceError::Afc(AfcError::ObjectNotFound)) => Ok(None),
        Err(err) => Err(err),
    }
}

async fn stat(
    afc: &mut AfcClient,
    control: &SyncControl,
    path: &str,
) -> Result<Option<Info>, String> {
    afc_io(control, read_info(afc, path)).await
}

async fn directories(afc: &mut AfcClient, control: &SyncControl, path: &str) -> Result<(), String> {
    let mut prefix = String::new();
    for name in path.split('/').filter(|v| !v.is_empty()) {
        prefix.push('/');
        prefix.push_str(name);
        if !stat(afc, control, &prefix)
            .await?
            .is_some_and(|i| i.kind == "directory")
        {
            return Err(NOT_FOLDER.into());
        }
    }
    Ok(())
}

fn staging_token(name: &str) -> bool {
    name.strip_prefix(PART_PREFIX).is_some_and(|id| {
        id.len() == 32
            && id
                .bytes()
                .all(|b| b.is_ascii_digit() || (b'a'..=b'f').contains(&b))
    })
}

fn now_seconds() -> u64 {
    std::time::SystemTime::now()
        .duration_since(std::time::UNIX_EPOCH)
        .unwrap_or_default()
        .as_secs()
}

fn stale(info: &Info, now: u64) -> bool {
    info.mtime_ns
        .and_then(|ns| u64::try_from(ns).ok())
        .is_some_and(|ns| ns > 0 && now.saturating_sub(ns.div_ceil(1_000_000_000)) >= STALE_AGE)
}

async fn reclaim_stage(
    afc: &mut AfcClient,
    path: &str,
    now: u64,
    publishing: bool,
) -> Result<bool, IdeviceError> {
    let Some(directory) = read_info(afc, path).await? else {
        return Ok(true);
    };
    let expired = stale(&directory, now);
    if directory.kind != "directory" || (!publishing && !expired) {
        return Ok(false);
    }
    let names = afc.list_dir(path).await?;
    let mut children = names
        .iter()
        .filter(|s| s.as_str() != "." && s.as_str() != "..");
    let leaf = match (children.next(), children.next()) {
        (None, _) if !expired => return Ok(true),
        (None, _) => None,
        (Some(token), None) if expired && staging_token(token) => Some(child(path, token)),
        _ => return Ok(false),
    };
    if let Some(file) = leaf.as_ref() {
        if !read_info(afc, file)
            .await?
            .is_some_and(|i| i.kind == "file" && stale(&i, now))
        {
            return Ok(false);
        }
    }
    if read_info(afc, path).await?.as_ref() != Some(&directory) {
        return Ok(false);
    }
    if let Some(file) = leaf {
        afc.remove(file).await?;
    }
    afc.remove(path).await?;
    Ok(true)
}

async fn ensure_workspace(afc: &mut AfcClient, control: &SyncControl) -> Result<(), String> {
    if let Some(info) = stat(afc, control, WORKSPACE).await? {
        return if info.kind == "directory" {
            Ok(())
        } else {
            Err(NOT_FOLDER.into())
        };
    }
    afc_io(control, async {
        match afc.mk_dir(WORKSPACE).await {
            Err(IdeviceError::Afc(AfcError::ObjectExists)) => Ok(()),
            result => result,
        }
    })
    .await?;
    directories(afc, control, WORKSPACE).await
}

pub(super) async fn list(
    afc: &mut AfcClient,
    control: &SyncControl,
    path: &str,
    offset: usize,
) -> Result<Value, String> {
    directories(afc, control, path).await?;
    let mut names = afc_io(control, afc.list_dir(path)).await?;
    let candidates = if offset == 0 && (path == WORKSPACE || path.starts_with("/CC365/")) {
        names
            .iter()
            .filter(|n| n.as_str() == PUBLISH_CLAIM || staging_token(n))
            .choose_multiple(&mut rand::thread_rng(), 3)
            .into_iter()
            .cloned()
            .collect::<Vec<_>>()
    } else {
        Vec::new()
    };
    if names.len() > 100_000 {
        return Err("Thư mục có quá nhiều mục; AirLift chưa tải danh sách này.".into());
    }
    names.retain(|name| name_ok(name));
    names.sort_unstable();
    names.dedup();
    let end = offset.saturating_add(PAGE).min(names.len());
    let mut entries = Vec::new();
    for name in names.get(offset..end).unwrap_or_default() {
        let item = child(path, name);
        let Some(info) = afc_io(control, async {
            match read_info(afc, &item).await {
                Err(IdeviceError::Afc(AfcError::PermDenied)) => Ok(Some(Info {
                    kind: "other",
                    size: None,
                    mtime_ns: None,
                })),
                result => result,
            }
        })
        .await?
        else {
            continue;
        };
        entries.push(json!({"name":name,"kind":info.kind,
            "size":(info.kind=="file").then_some(info.size).flatten(),
            "modified":info.mtime_ns.map(|ns|ns.div_euclid(1_000_000_000))}));
    }
    if !candidates.is_empty() {
        let _ = control
            .wait(std::time::Duration::from_millis(350), async {
                let now = now_seconds();
                for name in candidates {
                    if let Err(error) = reclaim_stage(afc, &child(path, &name), now, false).await {
                        if !matches!(error, IdeviceError::Afc(_)) {
                            break;
                        }
                    }
                }
                Ok(())
            })
            .await;
    }
    Ok(json!({"entries":entries,"nextOffset":(end<names.len()).then_some(end),"total":names.len()}))
}

async fn mkdir(afc: &mut AfcClient, control: &SyncControl, path: &str) -> Result<Value, String> {
    ensure_workspace(afc, control).await?;
    if path != WORKSPACE {
        directories(afc, control, split_path(path).0).await?;
        if stat(afc, control, path).await?.is_some() {
            return Err(EXISTS.into());
        }
        afc_io(control, afc.mk_dir(path)).await?;
    }
    Ok(json!({"bytes":0}))
}

async fn delete(afc: &mut AfcClient, control: &SyncControl, path: &str) -> Result<Value, String> {
    directories(afc, control, split_path(path).0).await?;
    let info = stat(afc, control, path)
        .await?
        .ok_or("Mục đã được xoá hoặc di chuyển.")?;
    let bytes = match info.kind {
        "file" => info.size.unwrap_or(0),
        "directory" => 0,
        _ => return Err("Chỉ có thể xoá tệp thông thường hoặc thư mục trống.".into()),
    };
    control.check().map_err(|_| "Đã dừng thao tác tệp.")?;
    match tokio::time::timeout(IO_TIMEOUT, afc.remove(path)).await {
        Ok(Ok(())) => Ok(json!({"bytes": bytes})),
        Ok(Err(err @ IdeviceError::Afc(_))) => Err(io_error(err)),
        _ => Err("Chưa xác nhận được kết quả xoá. Hãy làm mới thư mục.".into()),
    }
}

pub(super) async fn open_handle(
    afc: &mut AfcClient,
    path: &str,
    mode: AfcFopenMode,
) -> Result<u64, IdeviceError> {
    let mut args = (mode as u64).to_le_bytes().to_vec();
    args.extend_from_slice(path.as_bytes());
    let reply = afc.send_op(AfcOpcode::FileOpen, args, vec![]).await?;
    if reply.header.operation != AfcOpcode::FileOpenRes {
        return Err(IdeviceError::UnexpectedResponse(
            "AFC file-open reply has an unexpected opcode".into(),
        ));
    }
    reply
        .header_payload
        .as_slice()
        .try_into()
        .map(u64::from_le_bytes)
        .map_err(|_| {
            IdeviceError::UnexpectedResponse("AFC file-open reply has an invalid handle".into())
        })
}

pub(super) async fn close_handle(afc: &mut AfcClient, handle: u64) -> Result<(), IdeviceError> {
    let reply = afc
        .send_op(AfcOpcode::FileClose, handle.to_le_bytes().to_vec(), vec![])
        .await?;
    if reply.header.operation != AfcOpcode::Status {
        return Err(IdeviceError::UnexpectedResponse(
            "AFC file-close reply has an unexpected opcode".into(),
        ));
    }
    Ok(())
}

struct LocalTemp(PathBuf);
impl Drop for LocalTemp {
    fn drop(&mut self) {
        let _ = std::fs::remove_file(&self.0);
    }
}
pub(super) async fn export(
    afc: &mut AfcClient,
    control: &SyncControl,
    path: &str,
    local: &Path,
) -> Result<Value, String> {
    directories(afc, control, split_path(path).0).await?;
    let initial = stat(afc, control, path).await?.ok_or(NOT_FILE)?;
    let size = initial.length()?;
    let temp = local.with_file_name(temp_name());
    let f = std::fs::OpenOptions::new()
        .write(true)
        .create_new(true)
        .mode(0o600)
        .open(&temp)
        .map_err(|_| "Không tạo được tệp xuất tạm.")?;
    let cleanup = LocalTemp(temp);
    let mut output = File::from_std(f);
    let handle = afc_io(control, open_handle(afc, path, AfcFopenMode::RdOnly)).await?;
    let mut remaining = size;
    while remaining > 0 {
        let count = remaining.min(READ_BUFFER as u64) as usize;
        let args = [handle.to_le_bytes(), (count as u64).to_le_bytes()].concat();
        let chunk = afc_io(control, afc.send_op(AfcOpcode::Read, args, vec![]))
            .await?
            .payload;
        if chunk.is_empty() || chunk.len() > count {
            return Err(CHANGED.into());
        }
        output
            .write_all(&chunk)
            .await
            .map_err(|_| "Không ghi được tệp xuất. Hãy kiểm tra dung lượng trống.")?;
        remaining -= chunk.len() as u64;
    }
    afc_io(control, close_handle(afc, handle)).await?;
    if stat(afc, control, path).await?.as_ref() != Some(&initial) {
        return Err(CHANGED.into());
    }
    output
        .flush()
        .await
        .map_err(|_| "Không lưu được tệp xuất.")?;
    drop(output);
    control.check().map_err(|_| "Đã dừng thao tác tệp.")?;
    std::fs::hard_link(&cleanup.0, local).map_err(|error| {
        if error.kind() == std::io::ErrorKind::AlreadyExists {
            EXISTS
        } else {
            "Không lưu được tệp xuất."
        }
    })?;
    Ok(json!({"bytes":size}))
}

struct Staging {
    directory: String,
    claim: String,
    token: String,
    attempted_claim: bool,
    claimed: bool,
}
impl Staging {
    fn new(parent: &str) -> Self {
        Self {
            directory: child(parent, &temp_name()),
            claim: child(parent, PUBLISH_CLAIM),
            token: temp_name(),
            attempted_claim: false,
            claimed: false,
        }
    }
    fn payload(&self) -> String {
        child(&self.directory, &self.token)
    }
    async fn publish(
        &mut self,
        afc: &mut AfcClient,
        control: &SyncControl,
        dest: &str,
    ) -> Result<(), String> {
        let stage = self.payload();
        let linked = afc_io(control, async {
            match afc.link(&stage, dest, LinkType::Hardlink).await {
                Err(IdeviceError::Afc(AfcError::OpNotSupported)) => Ok(false),
                result => result.map(|_| true),
            }
        })
        .await?;
        if linked {
            return Ok(());
        }
        if !afc_io(
            control,
            reclaim_stage(afc, &self.claim, now_seconds(), true),
        )
        .await?
        {
            return Err("Đang có thao tác nhập tệp tại thư mục này. Hãy thử lại.".into());
        }
        self.attempted_claim = true;
        afc_io(control, afc.rename(&self.directory, &self.claim)).await?;
        self.claimed = true;
        if stat(afc, control, dest).await?.is_some() {
            return Err(EXISTS.into());
        }
        afc_io(control, afc.rename(child(&self.claim, &self.token), dest)).await
    }
    async fn cleanup(&self, afc: &mut AfcClient) -> Result<(), IdeviceError> {
        async fn remove(afc: &mut AfcClient, path: &str) -> Result<bool, IdeviceError> {
            match afc.remove(path).await {
                Ok(()) => Ok(true),
                Err(IdeviceError::Afc(AfcError::ObjectNotFound)) => Ok(false),
                Err(e) => Err(e),
            }
        }
        async fn directory_present(afc: &mut AfcClient, path: &str) -> Result<bool, IdeviceError> {
            match afc.get_file_info_raw(path).await {
                Ok(raw) => (Info::from(raw).kind == "directory")
                    .then_some(true)
                    .ok_or(IdeviceError::Afc(AfcError::PermDenied)),
                Err(IdeviceError::Afc(AfcError::ObjectNotFound)) => Ok(false),
                Err(e) => Err(e),
            }
        }
        let mut ancestor = String::new();
        for part in split_path(&self.directory)
            .0
            .split('/')
            .filter(|name| !name.is_empty())
        {
            ancestor.push('/');
            ancestor.push_str(part);
            if !directory_present(afc, &ancestor).await? {
                return Ok(());
            }
        }
        if directory_present(afc, &self.directory).await? {
            remove(afc, &self.payload()).await?;
            remove(afc, &self.directory).await?;
        }
        if self.attempted_claim && directory_present(afc, &self.claim).await? {
            let owned = remove(afc, &child(&self.claim, &self.token)).await?;
            if owned || self.claimed {
                match remove(afc, &self.claim).await {
                    Err(IdeviceError::Afc(AfcError::DirNotEmpty)) => (),
                    r => {
                        r?;
                    }
                }
            }
        }
        Ok(())
    }
}
async fn upload(
    afc: &mut AfcClient,
    control: &SyncControl,
    source: &mut File,
    size: u64,
    stage: &str,
) -> Result<(), String> {
    let handle = afc_io(control, open_handle(afc, stage, AfcFopenMode::WrOnly)).await?;
    let mut buf = vec![0u8; WRITE_BUFFER];
    let mut copied = 0;
    loop {
        let count = source
            .read(&mut buf)
            .await
            .map_err(|_| "Không đọc được tệp đã chọn.")?;
        if count == 0 {
            break;
        }
        copied += count as u64;
        if copied > size {
            return Err(CHANGED.into());
        }
        afc_io(
            control,
            afc.send_op(
                AfcOpcode::Write,
                handle.to_le_bytes().to_vec(),
                buf[..count].to_vec(),
            ),
        )
        .await?;
    }
    afc_io(control, close_handle(afc, handle)).await?;
    if copied != size
        || !stat(afc, control, stage)
            .await?
            .is_some_and(|info| info.kind == "file" && info.size == Some(size))
    {
        return Err(CHANGED.into());
    }
    Ok(())
}

impl DeviceSession {
    pub(crate) async fn files(
        &mut self,
        action: &str,
        path: &str,
        local_path: Option<&Path>,
        offset: usize,
    ) -> Result<Value, String> {
        validate(action, path, local_path)?;
        let control = self.control.clone();
        let mut afc = afc_io(&control, self.afc()).await?;
        match action {
            "list" => list(&mut afc, &control, path, offset).await,
            "mkdir" => mkdir(&mut afc, &control, path).await,
            "delete" => delete(&mut afc, &control, path).await,
            "export" => export(&mut afc, &control, path, local_path.ok_or(INVALID_PATH)?).await,
            "import" => {
                self.import_file(afc, path, local_path.ok_or(INVALID_PATH)?)
                    .await
            }
            _ => Err(INVALID_PATH.into()),
        }
    }

    async fn import_file(
        &mut self,
        mut afc: AfcClient,
        path: &str,
        local: &Path,
    ) -> Result<Value, String> {
        let control = self.control.clone();
        let local_file = std::fs::OpenOptions::new()
            .read(true)
            .custom_flags(libc::O_NOFOLLOW | libc::O_NONBLOCK)
            .open(local)
            .map_err(|_| "Không mở được tệp đã chọn.")?;
        let meta = local_file
            .metadata()
            .map_err(|_| "Không đọc được thông tin tệp.")?;
        if !meta.is_file() {
            return Err(NOT_FILE.into());
        }
        if meta.len() > MAX_TRANSFER {
            return Err(TOOBIG.into());
        }
        ensure_workspace(&mut afc, &control).await?;
        let parent = split_path(path).0;
        directories(&mut afc, &control, parent).await?;
        if stat(&mut afc, &control, path).await?.is_some() {
            return Err(EXISTS.into());
        }
        let mut staging = Staging::new(parent);
        if stat(&mut afc, &control, &staging.directory)
            .await?
            .is_some()
        {
            return Err("Hãy thử nhập tệp lại.".into());
        }
        let res = async {
            afc_io(&control, afc.mk_dir(&staging.directory)).await?;
            upload(
                &mut afc,
                &control,
                &mut File::from_std(local_file),
                meta.len(),
                &staging.payload(),
            )
            .await?;
            directories(&mut afc, &control, parent).await?;
            staging.publish(&mut afc, &control, path).await
        }
        .await;
        let cleaned = if res.is_ok() {
            matches!(
                tokio::time::timeout(IO_TIMEOUT, staging.cleanup(&mut afc)).await,
                Ok(Ok(()))
            )
        } else {
            drop(afc);
            let cleanup = async {
                let mut client = self.afc().await?;
                staging.cleanup(&mut client).await
            };
            matches!(tokio::time::timeout(IO_TIMEOUT, cleanup).await, Ok(Ok(())))
        };
        let warning = "Chưa dọn được tệp tạm của lần nhập này.";
        match res {
            Ok(()) => Ok(json!({"bytes":meta.len(), "warning":(!cleaned).then_some(warning)})),
            Err(message) if !cleaned => Err(format!("{message} {warning}")),
            Err(message) => Err(message),
        }
    }
}
#[cfg(test)]
mod tests {
    use super::*;
    use idevice::{Idevice, afc::MAGIC};
    use std::sync::{Arc, atomic::AtomicBool};

    fn control() -> SyncControl {
        SyncControl::new(Arc::new(AtomicBool::new(false)), Arc::new(|_| {}))
    }

    #[test]
    fn remote_paths_and_writes_stay_within_the_selected_workspace() {
        let local = Some(Path::new("/private/tmp/file"));
        for path in [
            "/CC365/../AirFair/x",
            "/cc365/x",
            "/CC365-1/file",
            "//CC365/a",
            "/CC365//a",
            "/CC365/",
            "/CC365/.",
            "/CC365/dir\\file",
            "/CC365/a\0b",
            "/CC365/.cc365-part-42",
            "/CC365/.CC365-PART-publish/payload",
        ] {
            assert!(validate("import", path, local).is_err(), "{path}");
        }
        assert!(validate("import", "/CC365/Ảnh mùa hè.jpg", local).is_ok());
        assert!(validate("list", "/DCIM", None).is_ok());
        assert!(validate("mkdir", "/AirFair/sync/test", None).is_err());
        assert!(validate("export", "/DCIM/a", Some(Path::new("relative"))).is_err());
    }

    struct Reply(AfcOpcode, AfcOpcode, Vec<u8>, Vec<u8>);
    fn reply_to(op: AfcOpcode, data: &[u8]) -> Reply {
        Reply(op, AfcOpcode::Data, vec![], data.to_vec())
    }
    fn opened() -> Reply {
        Reply(
            AfcOpcode::FileOpen,
            AfcOpcode::FileOpenRes,
            1_u64.to_le_bytes().to_vec(),
            vec![],
        )
    }
    fn closed() -> Reply {
        Reply(
            AfcOpcode::FileClose,
            AfcOpcode::Status,
            0_u64.to_le_bytes().to_vec(),
            vec![],
        )
    }

    fn scripted(replies: Vec<Reply>) -> (AfcClient, tokio::task::JoinHandle<Vec<Vec<u8>>>) {
        scripted_with(replies, |_| {})
    }

    fn scripted_with(
        replies: Vec<Reply>,
        mut on_request: impl FnMut(AfcOpcode) + Send + 'static,
    ) -> (AfcClient, tokio::task::JoinHandle<Vec<Vec<u8>>>) {
        let (host, mut peer) = tokio::io::duplex(32 * 1024);
        let task = tokio::spawn(async move {
            let mut requests = vec![];
            for Reply(op, answer, header, data) in replies {
                assert_eq!(peer.read_u64_le().await.unwrap(), MAGIC);
                let length = peer.read_u64_le().await.unwrap();
                let _header = peer.read_u64_le().await.unwrap();
                let seq = peer.read_u64_le().await.unwrap();
                assert_eq!(peer.read_u64_le().await.unwrap(), op as u64);
                let mut request = vec![0; length as usize - 40];
                peer.read_exact(&mut request).await.unwrap();
                requests.push(request);
                on_request(op);
                for v in [
                    MAGIC,
                    40 + (header.len() + data.len()) as u64,
                    40 + header.len() as u64,
                    seq,
                    answer as u64,
                ] {
                    peer.write_u64_le(v).await.unwrap();
                }
                peer.write_all(&header).await.unwrap();
                peer.write_all(&data).await.unwrap();
            }
            requests
        });
        (
            AfcClient::new(Idevice::new(Box::new(host), "fixture")),
            task,
        )
    }
    const DIR: &[u8] = b"st_ifmt\0S_IFDIR\0";
    const FILE: &[u8] = b"st_ifmt\0S_IFREG\0st_size\03\0st_mtime\01000000000\0";

    #[tokio::test]
    async fn delete_is_scoped_and_never_follows_links_or_requests_recursive_removal() {
        for protected in [
            "/CC365",
            "/",
            "/AirFair/sync",
            "/CC365/../Books",
            "/CC365/.cc365-part-publish",
        ] {
            assert!(validate("delete", protected, None).is_err());
        }
        assert!(validate("delete", "/CC365/Report.pdf", None).is_ok());
        let (mut link, peer) = scripted(vec![
            reply_to(AfcOpcode::GetFileInfo, DIR),
            reply_to(AfcOpcode::GetFileInfo, b"st_ifmt\0S_IFLNK\0"),
        ]);
        assert!(delete(&mut link, &control(), "/CC365/link").await.is_err());
        peer.await.unwrap();

        for (kind, status_code) in [(FILE, 0), (DIR, 0), (DIR, 33)] {
            let (mut afc, peer) = scripted(vec![
                reply_to(AfcOpcode::GetFileInfo, DIR),
                reply_to(AfcOpcode::GetFileInfo, kind),
                status(AfcOpcode::RemovePath, status_code),
            ]);
            let result = delete(&mut afc, &control(), "/CC365/item").await;
            assert_eq!(peer.await.unwrap()[2], b"/CC365/item");
            if status_code == 0 {
                assert_eq!(result.unwrap()["bytes"], if kind == FILE { 3 } else { 0 });
            } else {
                assert_eq!(result.unwrap_err(), "Chỉ có thể xoá thư mục trống.");
            }
        }
    }

    const OLD_DIR: &[u8] = b"st_ifmt\0S_IFDIR\0st_mtime\01000000000\0";
    const OLD_FILE: &[u8] = b"st_ifmt\0S_IFREG\0st_mtime\01000000000\0";
    const LINK: &[u8] = b"st_ifmt\0S_IFLNK\0st_mtime\01000000000\0";

    #[tokio::test]
    async fn listing_reclaims_only_a_stale_generated_directory_and_its_single_regular_payload() {
        let stage = temp_name();
        let token = temp_name();
        let names = format!("{}\0.cc365-part-unknown\0", stage);
        let (mut afc, peer) = scripted(vec![
            reply_to(AfcOpcode::GetFileInfo, DIR),
            reply_to(AfcOpcode::ReadDir, names.as_bytes()),
            reply_to(AfcOpcode::GetFileInfo, OLD_DIR),
            reply_to(AfcOpcode::ReadDir, token.as_bytes()),
            reply_to(AfcOpcode::GetFileInfo, OLD_FILE),
            reply_to(AfcOpcode::GetFileInfo, OLD_DIR),
            status(AfcOpcode::RemovePath, 0),
            status(AfcOpcode::RemovePath, 0),
        ]);
        let page = list(&mut afc, &control(), WORKSPACE, 0).await.unwrap();
        assert_eq!(page["total"], 0);
        let requests = peer.await.unwrap();
        let dir = child(WORKSPACE, &stage);
        assert_eq!(requests[6], child(&dir, &token).as_bytes());
        assert_eq!(requests[7], dir.as_bytes());

        let (mut afc, peer) = scripted(vec![
            reply_to(AfcOpcode::GetFileInfo, DIR),
            reply_to(AfcOpcode::ReadDir, names.as_bytes()),
        ]);
        list(&mut afc, &control(), "/Books", 0).await.unwrap();
        assert_eq!(peer.await.unwrap().len(), 2);
    }

    #[tokio::test]
    async fn stale_recovery_keeps_links_fresh_files_and_foreign_contents() {
        let token = temp_name();
        let folder = child(WORKSPACE, PUBLISH_CLAIM);
        let now = STALE_AGE + 1;
        let recent = b"st_ifmt\0S_IFREG\0st_mtime\05000000000\0";
        for (directory, names, file) in [
            (LINK, None, None),
            (DIR, None, None),
            (OLD_DIR, Some("photo.heic"), None),
            (OLD_DIR, Some("a\0b"), None),
            (OLD_DIR, Some(token.as_str()), Some(LINK)),
            (OLD_DIR, Some(token.as_str()), Some(recent.as_slice())),
        ] {
            let mut replies = vec![reply_to(AfcOpcode::GetFileInfo, directory)];
            if let Some(children) = names {
                replies.push(reply_to(AfcOpcode::ReadDir, children.as_bytes()))
            }
            if let Some(info) = file {
                replies.push(reply_to(AfcOpcode::GetFileInfo, info))
            }
            let (mut afc, peer) = scripted(replies);
            assert!(!reclaim_stage(&mut afc, &folder, now, false).await.unwrap());
            peer.await.unwrap();
        }
        let (mut afc, peer) = scripted(vec![
            reply_to(AfcOpcode::GetFileInfo, OLD_DIR),
            reply_to(AfcOpcode::ReadDir, b".\0..\0"),
            reply_to(AfcOpcode::GetFileInfo, OLD_DIR),
            status(AfcOpcode::RemovePath, 0),
        ]);
        assert!(reclaim_stage(&mut afc, &folder, now, false).await.unwrap());
        assert_eq!(peer.await.unwrap().last().unwrap(), folder.as_bytes());
    }

    #[tokio::test]
    async fn inaccessible_child_does_not_hide_other_entries() {
        let (mut afc, peer) = scripted(vec![
            reply_to(AfcOpcode::ReadDir, b".\0..\0a\0b\0"),
            status(AfcOpcode::GetFileInfo, 10),
            reply_to(AfcOpcode::GetFileInfo, FILE),
        ]);
        let listing = list(&mut afc, &control(), "/", 0).await.unwrap();
        peer.await.unwrap();
        assert_eq!(listing["entries"][0]["kind"], "other");
        assert_eq!(listing["entries"][1]["size"], 3);
    }

    #[tokio::test]
    async fn upload_chunks_preserve_the_bytes_and_require_verified_size() {
        let dir = tempfile::tempdir().unwrap();
        let path = dir.path().join("source");
        let data: Vec<u8> = (0..WRITE_BUFFER + 13).map(|n| n as u8).collect();
        std::fs::write(&path, &data).unwrap();
        for verified_size in [data.len(), data.len() - 1] {
            let size_info = format!("st_ifmt\0S_IFREG\0st_size\0{verified_size}\0");
            let (mut afc, peer) = scripted(vec![
                opened(),
                status(AfcOpcode::Write, 0),
                status(AfcOpcode::Write, 0),
                closed(),
                reply_to(AfcOpcode::GetFileInfo, size_info.as_bytes()),
            ]);
            let mut source = File::open(&path).await.unwrap();
            let result = upload(
                &mut afc,
                &control(),
                &mut source,
                data.len() as u64,
                "/CC365/stage",
            )
            .await;
            let requests = peer.await.unwrap();
            assert_eq!(&requests[1][8..], &data[..WRITE_BUFFER]);
            assert_eq!(&requests[2][8..], &data[WRITE_BUFFER..]);
            if verified_size == data.len() {
                result.unwrap()
            } else {
                assert_eq!(result.unwrap_err(), CHANGED)
            }
        }
    }

    #[tokio::test]
    async fn nested_link_is_never_traversed() {
        let (mut afc, peer) = scripted(vec![
            reply_to(AfcOpcode::GetFileInfo, DIR),
            reply_to(
                AfcOpcode::GetFileInfo,
                b"st_ifmt\0S_IFLNK\0LinkTarget\0/var/mobile\0",
            ),
        ]);
        assert_eq!(
            list(&mut afc, &control(), "/CC365/link/Library", 0)
                .await
                .unwrap_err(),
            NOT_FOLDER
        );
        assert_eq!(
            peer.await.unwrap(),
            vec![b"/CC365".as_slice(), b"/CC365/link"]
        );
    }

    #[tokio::test]
    async fn a_short_transfer_never_publishes_a_partial_export() {
        let (mut afc, peer) = scripted(vec![
            reply_to(AfcOpcode::GetFileInfo, FILE),
            opened(),
            reply_to(AfcOpcode::Read, b"x"),
            reply_to(AfcOpcode::Read, b""),
        ]);
        let dir = tempfile::tempdir().unwrap();
        assert_eq!(
            export(&mut afc, &control(), "/a", &dir.path().join("out"))
                .await
                .unwrap_err(),
            CHANGED
        );
        peer.await.unwrap();
        assert_eq!(std::fs::read_dir(dir.path()).unwrap().count(), 0);
    }

    #[tokio::test]
    async fn cancelling_an_open_export_discards_its_local_staging_file() {
        let cancelled = Arc::new(AtomicBool::new(false));
        let control = SyncControl::new(cancelled.clone(), Arc::new(|_| {}));
        let (mut afc, peer) = scripted_with(
            vec![
                reply_to(AfcOpcode::GetFileInfo, FILE),
                opened(),
                reply_to(AfcOpcode::Read, b"x"),
            ],
            move |op| {
                if op == AfcOpcode::Read {
                    cancelled.store(true, std::sync::atomic::Ordering::SeqCst);
                }
            },
        );
        let dir = tempfile::tempdir().unwrap();
        assert_eq!(
            export(&mut afc, &control, "/a", &dir.path().join("out"))
                .await
                .unwrap_err(),
            "Đã dừng thao tác tệp."
        );
        peer.await.unwrap();
        assert_eq!(std::fs::read_dir(dir.path()).unwrap().count(), 0);
    }

    fn status(op: AfcOpcode, code: u64) -> Reply {
        Reply(op, AfcOpcode::Status, code.to_le_bytes().to_vec(), vec![])
    }

    #[tokio::test]
    async fn unsupported_hardlink_uses_a_nonempty_claim_and_rechecks_destination() {
        for collision in [false, true] {
            let mut replies = vec![
                status(AfcOpcode::MakeLink, 15),
                status(AfcOpcode::GetFileInfo, 8),
                status(AfcOpcode::RenamePath, 0),
            ];
            if collision {
                replies.push(reply_to(AfcOpcode::GetFileInfo, FILE));
            } else {
                replies.push(status(AfcOpcode::GetFileInfo, 8));
                replies.push(status(AfcOpcode::RenamePath, 0));
            }
            let (mut afc, peer) = scripted(replies);
            let mut staging = Staging::new("/CC365");
            let dest = "/CC365/Report.pdf";
            let published = staging.publish(&mut afc, &control(), dest).await;
            let requests = peer.await.unwrap();
            assert!(staging.claimed);
            assert_eq!(
                requests[2],
                format!("{}\0{}\0", staging.directory, staging.claim).as_bytes()
            );
            assert_eq!(requests[3], dest.as_bytes());
            if collision {
                assert_eq!(published.unwrap_err(), EXISTS);
            } else {
                published.unwrap();
                assert_eq!(
                    requests[4],
                    format!("{}/{}\0{}\0", staging.claim, staging.token, dest).as_bytes()
                );
            }
        }
    }

    #[tokio::test]
    async fn export_caps_read_requests_on_wireless_afc() {
        let dir = tempfile::tempdir().unwrap();
        let path = dir.path().join("export.bin");
        let first = vec![17; 16 * 1024];
        let size = first.len() + 1;
        let info = format!("st_ifmt\0S_IFREG\0st_size\0{size}\0");
        let (mut afc, peer) = scripted(vec![
            reply_to(AfcOpcode::GetFileInfo, info.as_bytes()),
            opened(),
            reply_to(AfcOpcode::Read, &first),
            reply_to(AfcOpcode::Read, &[91]),
            closed(),
            reply_to(AfcOpcode::GetFileInfo, info.as_bytes()),
        ]);
        export(&mut afc, &control(), "/file", &path).await.unwrap();
        let requests = peer.await.unwrap();
        assert_eq!(&requests[2][8..], &(16_384u64).to_le_bytes());
        assert_eq!(&requests[3][8..], &1u64.to_le_bytes());
        assert_eq!(std::fs::read(path).unwrap(), [first, vec![91]].concat());
    }

    #[tokio::test]
    async fn publish_an_export_only_if_the_target_is_new() {
        let dir = tempfile::tempdir().unwrap();
        let path = dir.path().join("out");
        for first in [true, false] {
            let (mut afc, peer) = scripted(vec![
                reply_to(AfcOpcode::GetFileInfo, FILE),
                opened(),
                reply_to(AfcOpcode::Read, b"abc"),
                closed(),
                reply_to(AfcOpcode::GetFileInfo, FILE),
            ]);
            let result = export(&mut afc, &control(), "/a", &path).await;
            peer.await.unwrap();
            if first {
                assert_eq!(result.unwrap()["bytes"], 3);
                assert_eq!(std::fs::read(&path).unwrap(), b"abc");
                std::fs::write(&path, b"changed by another operation").unwrap();
            } else {
                assert_eq!(result.unwrap_err(), EXISTS);
                assert_eq!(
                    std::fs::read(&path).unwrap(),
                    b"changed by another operation"
                );
            }
        }
        assert_eq!(std::fs::read_dir(dir.path()).unwrap().count(), 1);
    }
}

#[derive(serde::Deserialize)]
pub(crate) struct ListOptions {
    #[serde(default)]
    query: String,
    #[serde(default = "sort_name")]
    sort: String,
    #[serde(default = "yes")]
    ascending: bool,
    #[serde(default = "yes")]
    folders_first: bool,
    #[serde(default = "yes")]
    show_hidden: bool,
}
fn sort_name() -> String {
    "name".into()
}
fn yes() -> bool {
    true
}
impl ListOptions {
    pub(crate) fn valid(&self) -> bool {
        self.query.len() <= 1024
            && !self.query.chars().any(char::is_control)
            && matches!(self.sort.as_str(), "name" | "size" | "modified" | "created")
    }
    fn matches(&self, name: &str) -> bool {
        (self.show_hidden || !name.starts_with('.'))
            && name.to_lowercase().contains(&self.query.to_lowercase())
    }
}
pub(super) fn page(
    mut entries: Vec<Value>,
    offset: usize,
    options: &ListOptions,
) -> Result<Value, String> {
    if !options.valid() {
        return Err("Tùy chọn danh sách không hợp lệ.".into());
    }
    entries.retain(|e| {
        options.matches(
            e["display_name"]
                .as_str()
                .or(e["name"].as_str())
                .unwrap_or(""),
        )
    });
    entries.sort_by(|a, b| {
        let folder = if options.folders_first {
            (b["kind"] == "directory").cmp(&(a["kind"] == "directory"))
        } else {
            std::cmp::Ordering::Equal
        };
        if folder != std::cmp::Ordering::Equal {
            return folder;
        }
        let name = |v: &Value| {
            v["display_name"]
                .as_str()
                .or(v["name"].as_str())
                .unwrap_or("")
                .to_lowercase()
        };
        let primary = if options.sort == "name" {
            name(a).cmp(&name(b))
        } else {
            a[&options.sort].as_i64().cmp(&b[&options.sort].as_i64())
        };
        let order = primary
            .then_with(|| name(a).cmp(&name(b)))
            .then_with(|| a["name"].as_str().cmp(&b["name"].as_str()));
        if options.ascending {
            order
        } else {
            order.reverse()
        }
    });
    let total = entries.len();
    let end = offset.saturating_add(PAGE).min(total);
    let subset = entries.get(offset..end).unwrap_or_default();
    Ok(json!({"entries":subset,"nextOffset":(end<total).then_some(end),"total":total}))
}
pub(super) async fn browse_list(
    afc: &mut AfcClient,
    control: &SyncControl,
    path: &str,
    offset: usize,
    options: &ListOptions,
) -> Result<Value, String> {
    let control = control
        .clone()
        .with_timeout(std::time::Duration::from_secs(30));
    directories(afc, &control, path).await?;
    let mut names = afc_io(&control, afc.list_dir(path)).await?;
    if names.len() > 100_000 {
        return Err("Thư mục có quá nhiều mục để duyệt qua AirLift.".into());
    }
    names.retain(|name| name_ok(name) && options.matches(name));
    names.sort();
    names.dedup();
    if names.len() > 4096 {
        return Err("Có hơn 4.096 mục khớp. Nhập tên để thu hẹp danh sách.".into());
    }
    let mut entries = Vec::new();
    for name in names {
        let raw = match afc_io(&control, afc.get_file_info_raw(child(path, &name))).await {
            Ok(v) => v,
            Err(e) => return Err(e),
        };
        let info = Info::from(raw.clone());
        entries.push(json!({"name":name,"kind":info.kind,"size":info.size,"modified":info.mtime_ns.map(|v|v.div_euclid(1_000_000_000)),"created":raw.get("st_birthtime").and_then(|s|s.parse::<i64>().ok()).map(|v|v.div_euclid(1_000_000_000))}));
    }
    let mut result = page(entries, offset, options)?;
    if options.sort == "created"
        && result["entries"]
            .as_array()
            .is_some_and(|rows| rows.iter().any(|r| r["created"].is_null()))
    {
        result["notice"] =
            json!("AFC không cung cấp ngày tạo cho một số mục; các mục đó được xếp theo tên.");
    }
    Ok(result)
}
pub(super) async fn details(
    afc: &mut AfcClient,
    control: &SyncControl,
    relative: &str,
    logical: &str,
) -> Result<Value, String> {
    directories(afc, control, split_path(relative).0).await?;
    let raw = afc_io(control, afc.get_file_info_raw(relative)).await?;
    let info = Info::from(raw.clone());
    let required = |key: &str| {
        raw.get(key).and_then(|v|v.parse::<u64>().ok()).ok_or("AFC không cung cấp đủ thông tin quyền/chủ sở hữu cho mục này. Bạn vẫn có thể duyệt hoặc xuất tệp.")
    };
    let mode = required("st_mode")?;
    Ok(
        json!({"name":logical.rsplit('/').next().unwrap_or(""),"path":logical,"kind":info.kind,"size":required("st_size")?,"modified":required("st_mtime")?/1_000_000_000,"created":required("st_birthtime")?/1_000_000_000,"permissions":format!("{:o}",mode&0o7777),"owner":u32::try_from(required("st_uid")?).map_err(|_|"Chủ sở hữu ngoài phạm vi.")?,"group":u32::try_from(required("st_gid")?).map_err(|_|"Nhóm ngoài phạm vi.")?,"inode":required("st_ino")?}),
    )
}

#[cfg(test)]
mod browser_policy_tests {
    use super::*;
    fn options(v: Value) -> ListOptions {
        serde_json::from_value(v).unwrap()
    }
    #[test]
    fn filtering_and_sorting_precede_pagination_and_do_not_invent_metadata() {
        let mut entries = vec![
            json!({"name":".hidden","kind":"file","size":999}),
            json!({"name":"folder","kind":"directory"}),
        ];
        entries.extend(
            (0..105).map(|n| json!({"name":format!("file-{n:03}"),"kind":"file","size":n})),
        );
        let p = page(
            entries.clone(),
            0,
            &options(json!({"sort":"size","ascending":false,"show_hidden":false})),
        )
        .unwrap();
        assert_eq!(p["entries"][0]["name"], "folder");
        assert_eq!(p["entries"][1]["name"], "file-104");
        assert!(p["entries"][0]["size"].is_null());
        assert_eq!(p["total"], 106);
        assert_eq!(p["nextOffset"], 100);
        let p = page(
            entries,
            0,
            &options(json!({"query":"file-10","sort":"name"})),
        )
        .unwrap();
        assert_eq!(p["total"], 5);
        assert_eq!(p["entries"][0]["name"], "file-100");
        assert!(p["nextOffset"].is_null());
    }
}
