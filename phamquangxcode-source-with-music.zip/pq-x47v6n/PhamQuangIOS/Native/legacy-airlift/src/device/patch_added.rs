use super::*;

#[derive(Serialize, Deserialize)]
pub(super) struct Created {
    object: String,
    pub(super) placed: bool,
    pub(super) preserved: bool,
}

pub(super) fn valid(row: &Item) -> bool {
    if row.original_witness != "missing" {
        return row.added.is_none()
            && !matches!(
                row.handoff,
                Some(Handoff::RemoveNew | Handoff::ReturnUnverified)
            );
    }
    if row.original.is_some()
        || row.cargo.is_some()
        || row.rebuilding_held
        || row.return_witness.is_some()
        || row.phase == Phase::Skipped
    {
        return false;
    }
    let Some(file) = row.added.as_ref() else {
        return row.handoff.is_none()
            && row.foreign_cargo.is_none()
            && matches!(
                row.phase,
                Phase::Waiting
                    | Phase::Probing
                    | Phase::Staging
                    | Phase::Staged
                    | Phase::Settled
                    | Phase::Omitted
            );
    };
    let fingerprint = |value: &str| {
        value
            .strip_prefix("object:")
            .is_some_and(|value| value.len() == 64 && value.bytes().all(|c| c.is_ascii_hexdigit()))
    };
    fingerprint(&file.object)
        && (!file.preserved || row.phase == Phase::Settled)
        && matches!(
            row.phase,
            Phase::Moving | Phase::Installed | Phase::Restoring | Phase::Settled
        )
        && (row.phase != Phase::Installed
            || file.placed && row.handoff == Some(Handoff::ReturnVerifiedNew))
        && match row.handoff {
            Some(Handoff::ReturnForeign | Handoff::ReturnUnverified) => {
                row.foreign_cargo.as_deref().is_some_and(fingerprint)
            }
            Some(
                Handoff::InstallNew
                | Handoff::VerifyNewOut
                | Handoff::ReturnVerifiedNew
                | Handoff::EvictNew
                | Handoff::RemoveNew,
            ) => row.foreign_cargo.is_none(),
            _ => false,
        }
}

fn arm(slot: &Path, batch: &mut Batch, i: usize, step: Handoff) -> Result<()> {
    batch.items[i].handoff = Some(step);
    persist_row(slot, batch, i)
}

fn settle(slot: &Path, batch: &mut Batch, i: usize, preserved: bool) -> Result<()> {
    let row = &mut batch.items[i];
    row.added.as_mut().ok_or(UNCERTAIN)?.preserved = preserved;
    row.phase = Phase::Settled;
    persist_row(slot, batch, i)
}

#[derive(PartialEq, Eq, Debug)]
enum Cargo {
    Ours,
    Foreign,
    Unverified(String),
}

impl Cargo {
    fn refusal(&self) -> Option<String> {
        match self {
            Self::Ours => None,
            Self::Foreign => Some(CONFLICT.into()),
            Self::Unverified(error) => Some(error.clone()),
        }
    }
}

async fn identify(
    link: &mut PatchLink,
    ctl: &SyncControl,
    row: &Item,
    object: &str,
) -> Result<Cargo> {
    if row.added.as_ref().ok_or(UNCERTAIN)?.object != object {
        return Ok(Cargo::Foreign);
    }
    let stage = link.reverse_stage_path()?;
    let read = io::snapshot(
        link.reverse_media_afc()?,
        ctl,
        &stage,
        std::io::sink(),
        row.replacement.len,
    )
    .await;
    if link.reverse_opaque_cargo_witness(false).await?.as_deref() != Some(object) {
        return Err(CONFLICT.into());
    }
    match read {
        Ok(Some(stamp)) if stamp == row.replacement => Ok(Cargo::Ours),
        Ok(Some(_)) => Ok(Cargo::Foreign),
        Ok(None) => Ok(Cargo::Unverified(UNCERTAIN.into())),
        Err(error) => Ok(Cargo::Unverified(error)),
    }
}

impl DeviceSession {
    async fn return_added_cargo(
        &mut self,
        link: &mut PatchLink,
        slot: &Path,
        b: &mut Batch,
        i: usize,
        object: String,
        kind: Cargo,
    ) -> Result<()> {
        let step = match kind {
            Cargo::Foreign => Handoff::ReturnForeign,
            Cargo::Unverified(_) => Handoff::ReturnUnverified,
            Cargo::Ours => return Err(UNCERTAIN.into()),
        };
        b.items[i].foreign_cargo = Some(object.clone());
        arm(slot, b, i, step)?;
        self.reverse_new_install(link, &object).await
    }

    pub(super) async fn install_added(
        &mut self,
        link: &mut PatchLink,
        slot: &Path,
        b: &mut Batch,
        i: usize,
    ) -> Result<()> {
        let row = &b.items[i];
        let witness = row.replacement_witness.as_deref().ok_or(UNCERTAIN)?;
        if row.phase != Phase::Staged
            || link.reverse_new_present().await?
            || !link.stage_matches(witness).await?
        {
            return Err(CONFLICT.into());
        }
        let object = link
            .reverse_opaque_cargo_witness(false)
            .await?
            .ok_or(UNCERTAIN)?;
        let row = &mut b.items[i];
        row.phase = Phase::Moving;
        row.added = Some(Created {
            object: object.clone(),
            placed: false,
            preserved: false,
        });
        arm(slot, b, i, Handoff::InstallNew)?;
        self.reverse_new_install(link, &object).await?;
        self.control.log("AirLift added: published new file.");
        b.items[i].added.as_mut().ok_or(UNCERTAIN)?.placed = true;
        arm(slot, b, i, Handoff::VerifyNewOut)?;
        self.reverse_new_export(link).await?;
        let returned = link
            .reverse_opaque_cargo_witness(false)
            .await?
            .ok_or(UNCERTAIN)?;
        let kind = identify(link, &self.control, &b.items[i], &returned).await?;
        if let Some(reason) = kind.refusal() {
            self.return_added_cargo(link, slot, b, i, returned, kind)
                .await?;
            return Err(reason);
        }
        self.control.log("AirLift added: readback verified.");
        arm(slot, b, i, Handoff::ReturnVerifiedNew)?;
        self.reverse_new_install(link, &object).await?;
        b.items[i].phase = Phase::Installed;
        persist_row(slot, b, i)
    }

    pub(super) async fn restore_added(
        &mut self,
        link: &mut PatchLink,
        slot: &Path,
        b: &mut Batch,
        i: usize,
    ) -> Result<()> {
        if matches!(
            b.items[i].phase,
            Phase::Probing | Phase::Staging | Phase::Staged
        ) {
            return self.restore_opaque(link, slot, b, i).await;
        }
        let mut step = b.items[i].handoff.ok_or(UNCERTAIN)?;
        let mut occupied = link.reverse_new_present().await?;
        let mut staged = link.reverse_opaque_cargo_witness(false).await?;
        if matches!(step, Handoff::ReturnForeign | Handoff::ReturnUnverified) {
            let expected = b.items[i].foreign_cargo.as_deref().ok_or(UNCERTAIN)?;
            if let Some(object) = staged.as_deref() {
                if occupied || object != expected {
                    return Err(CONFLICT.into());
                }
                self.reverse_new_install(link, object).await?;
                occupied = true;
                staged = None;
            }
            if step == Handoff::ReturnForeign {
                return settle(slot, b, i, occupied);
            }
            b.items[i].foreign_cargo = None;
            step = Handoff::EvictNew;
            arm(slot, b, i, step)?;
        }
        if step == Handoff::RemoveNew && staged.is_none() {
            return settle(slot, b, i, occupied);
        }
        if occupied && staged.is_none() {
            b.items[i].phase = Phase::Restoring;
            step = Handoff::EvictNew;
            arm(slot, b, i, step)?;
            self.reverse_new_export(link).await?;
            staged = Some(
                link.reverse_opaque_cargo_witness(false)
                    .await?
                    .ok_or(UNCERTAIN)?,
            );
            occupied = false;
        }
        let Some(object) = staged else {
            return settle(slot, b, i, false);
        };
        let kind = identify(link, &self.control, &b.items[i], &object).await?;
        if let Some(reason) = kind.refusal() {
            if !occupied && matches!(step, Handoff::VerifyNewOut | Handoff::EvictNew) {
                let foreign = kind == Cargo::Foreign;
                self.return_added_cargo(link, slot, b, i, object, kind)
                    .await?;
                if foreign {
                    return settle(slot, b, i, true);
                }
            }
            return Err(reason);
        }
        let row = &mut b.items[i];
        if matches!(step, Handoff::EvictNew | Handoff::VerifyNewOut) {
            row.added.as_mut().ok_or(UNCERTAIN)?.placed = true;
        }
        row.phase = Phase::Restoring;
        arm(slot, b, i, Handoff::RemoveNew)?;
        if link.reverse_opaque_cargo_witness(false).await?.as_deref() != Some(object.as_str()) {
            return Err(CONFLICT.into());
        }
        let stage = link.reverse_stage_path()?;
        io::remove(link.reverse_media_afc()?, &self.control, &stage).await?;
        settle(slot, b, i, link.reverse_new_present().await?)
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn new_file_receipt_survives_first_publish_interruption_and_counts_creation() {
        let mut b = super::super::tests::plan();
        let row = &mut b.items[0];
        row.original_witness = "missing".into();
        let path = tempfile::tempdir().unwrap();
        persist(path.path(), &mut b).unwrap();
        let mut b = load_receipt(path.path()).unwrap().unwrap();
        assert!(b.items[0].original.is_none());
        let row = &mut b.items[0];
        row.phase = Phase::Moving;
        row.replacement_witness = Some(row.replacement.sha1_witness());
        row.added = Some(Created {
            object: format!("object:{}", "a".repeat(64)),
            placed: false,
            preserved: false,
        });
        arm(path.path(), &mut b, 0, Handoff::InstallNew).unwrap();
        let mut b = load_receipt(path.path()).unwrap().unwrap();
        assert_eq!(report(&b)["created"], 0);
        assert!(b.items[0].original.is_none());
        b.items[0].added.as_mut().unwrap().placed = true;
        b.items[0].handoff = Some(Handoff::ReturnVerifiedNew);
        b.items[0].phase = Phase::Installed;
        b.state = "applied".into();
        persist(path.path(), &mut b).unwrap();
        let mut b = load_receipt(path.path()).unwrap().unwrap();
        assert_eq!(report(&b)["created"], 1);
        assert_eq!(report(&b)["changed"], 1);
        assert_eq!(report(&b)["bytes"], 3);
        b.state = "pending".into();
        b.items[0].phase = Phase::Restoring;
        b.items[0].foreign_cargo = Some(format!("object:{}", "b".repeat(64)));
        arm(path.path(), &mut b, 0, Handoff::ReturnForeign).unwrap();
        let mut b = load_receipt(path.path()).unwrap().unwrap();
        settle(path.path(), &mut b, 0, true).unwrap();
        b.state = "restored".into();
        persist(path.path(), &mut b).unwrap();
        let b = load_receipt(path.path()).unwrap().unwrap();
        assert_eq!(report(&b)["preserved"], 1);
        assert_eq!(report(&b)["created"], 1);
        assert_eq!(report(&b)["changed"], 1);
    }

    #[test]
    fn missing_preimage_cannot_become_a_backup_or_an_unowned_install() {
        let mut b = super::super::tests::plan();
        let row = &mut b.items[0];
        row.original_witness = "missing".into();
        row.original = Some(row.replacement.clone());
        assert!(validate(&b).is_err());
        b.items[0].original = None;
        b.items[0].phase = Phase::Installed;
        b.items[0].replacement_witness = Some(b.items[0].replacement.sha1_witness());
        assert!(validate(&b).is_err());
        b.items[0].added = Some(Created {
            object: "arbitrary-filename".into(),
            placed: true,
            preserved: false,
        });
        b.items[0].handoff = Some(Handoff::ReturnVerifiedNew);
        assert!(validate(&b).is_err());
        b.items[0].added.as_mut().unwrap().object = format!("object:{}", "a".repeat(64));
        assert!(validate(&b).is_ok());
        b.items[0].original_witness = "opaque".into();
        assert!(validate(&b).is_err());
    }
}
