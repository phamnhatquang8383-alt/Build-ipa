use super::*;

#[derive(Debug, Clone, Copy, PartialEq, Eq, Serialize, Deserialize)]
#[serde(rename_all = "snake_case")]
pub(super) enum Handoff {
    ExportOld,
    StageDifferent,
    InstallNew,
    VerifyNewOut,
    ReturnVerifiedNew,
    EvictNew,
    ReturnForeign,
    ReturnUnverified,
    RemoveNew,
    ReturnForeignOld,
    ReturnOld,
    VerifyOldOut,
    ReturnVerifiedOld,
}

fn verify_snapshot(observed: Result<Option<Stamp>>, expected: &Stamp) -> Result<()> {
    match observed? {
        Some(stamp) if &stamp == expected => Ok(()),
        Some(_) => Err(CONFLICT.into()),
        None => Err(UNCERTAIN.into()),
    }
}

fn arm(slot: &Path, batch: &mut Batch, i: usize, step: Handoff) -> Result<()> {
    batch.items[i].handoff = Some(step);
    persist_row(slot, batch, i)
}

#[derive(Debug, PartialEq, Eq)]
enum ForeignDisposition {
    FinishReturn,
    RecheckOccupant,
}

fn foreign_disposition(
    occupied: bool,
    slot: Option<&str>,
    expected: &str,
) -> Result<ForeignDisposition> {
    match (occupied, slot) {
        (false, Some(observed)) if observed == expected => Ok(ForeignDisposition::FinishReturn),
        (_, None) => Ok(ForeignDisposition::RecheckOccupant),
        _ => Err(CONFLICT.into()),
    }
}

impl DeviceSession {
    pub(super) async fn install_opaque(
        &mut self,
        link: &mut PatchLink,
        slot: &Path,
        b: &mut Batch,
        i: usize,
    ) -> Result<()> {
        let ctl = self.control.clone();
        let row = &b.items[i];
        if row.phase != Phase::Comparing
            || !matches!(
                row.handoff,
                Some(Handoff::ExportOld | Handoff::StageDifferent)
            )
        {
            return Err(UNCERTAIN.into());
        }
        let old = row.original.as_ref().ok_or(UNCERTAIN)?;
        let stamp = row.replacement.clone();
        let witness = row.return_witness.clone().ok_or(UNCERTAIN)?;
        let cargo = row.cargo.clone().ok_or(UNCERTAIN)?;
        if link.reverse_opaque_cargo_witness(true).await?.as_deref() != Some(&cargo) {
            return Err(CONFLICT.into());
        }
        if old == &stamp {
            if row.handoff != Some(Handoff::ExportOld) {
                return Err(UNCERTAIN.into());
            }
            if !witness.starts_with("sha1:") {
                let held = link.reverse_media_path()?;
                verify_snapshot(
                    io::snapshot(
                        link.reverse_media_afc()?,
                        &ctl,
                        &held,
                        std::io::sink(),
                        stamp.len,
                    )
                    .await,
                    &stamp,
                )?;
            }
            arm(slot, b, i, Handoff::ReturnVerifiedOld)?;
            self.reverse_opaque_return(link, false, &witness).await?;
            ctl.log("AirLift compare: verified equal original returned.");
            b.items[i].phase = Phase::Skipped;
        } else {
            let stage = link.reverse_stage_path()?;
            if row.handoff != Some(Handoff::StageDifferent) {
                return Err(UNCERTAIN.into());
            }
            let new = row.replacement_witness.clone().ok_or(UNCERTAIN)?;
            if !link.stage_matches(&new).await? {
                return Err(CONFLICT.into());
            }
            b.items[i].phase = Phase::Moving;
            arm(slot, b, i, Handoff::InstallNew)?;
            self.reverse_opaque_return(link, true, &new).await?;
            arm(slot, b, i, Handoff::VerifyNewOut)?;
            self.reverse_opaque_export(link, true).await?;
            ctl.log("AirLift reverse: replacement returned for verification.");
            let returned = io::snapshot(
                link.reverse_media_afc()?,
                &ctl,
                &stage,
                std::io::sink(),
                MAX_FILE,
            )
            .await;
            if let Err(reason) = verify_snapshot(returned, &stamp) {
                self.put_back_foreign(link, slot, b, i).await?;
                return Err(reason);
            }
            let verified = if new.starts_with("sha1:") {
                stamp.sha1_witness()
            } else {
                link.reverse_stage_witness().await?.ok_or(UNCERTAIN)?
            };
            arm(slot, b, i, Handoff::ReturnVerifiedNew)?;
            self.reverse_opaque_return(link, true, &verified).await?;
            b.items[i].phase = Phase::Installed;
        }
        persist_row(slot, b, i)
    }

    pub(super) async fn put_back_foreign(
        &mut self,
        link: &mut PatchLink,
        slot: &Path,
        b: &mut Batch,
        i: usize,
    ) -> Result<()> {
        let observed = link
            .reverse_opaque_cargo_witness(false)
            .await?
            .ok_or(UNCERTAIN)?;
        b.items[i].foreign_cargo = Some(observed.clone());
        arm(slot, b, i, Handoff::ReturnForeign)?;
        self.reverse_opaque_return(link, true, &observed).await
    }

    async fn verify_exported_original(
        &mut self,
        link: &mut PatchLink,
        slot: &Path,
        b: &mut Batch,
        i: usize,
        expected: &Stamp,
    ) -> Result<()> {
        let held = link.reverse_media_path()?;
        let cargo = link
            .reverse_opaque_cargo_witness(true)
            .await?
            .ok_or(UNCERTAIN)?;
        let readback = io::snapshot(
            link.reverse_media_afc()?,
            &self.control,
            &held,
            std::io::sink(),
            expected.len,
        )
        .await;
        let Err(reason) = verify_snapshot(readback, expected) else {
            return Ok(());
        };
        if b.items[i].handoff == Some(Handoff::VerifyOldOut)
            && link.reverse_opaque_cargo_witness(true).await?.as_ref() == Some(&cargo)
        {
            b.items[i].foreign_cargo = Some(cargo.clone());
            arm(slot, b, i, Handoff::ReturnForeignOld)?;
            self.reverse_opaque_return(link, false, &cargo).await?;
        }
        Err(reason)
    }

    async fn opaque_return_and_verify_old(
        &mut self,
        link: &mut PatchLink,
        slot: &Path,
        b: &mut Batch,
        i: usize,
    ) -> Result<()> {
        let old = b.items[i].original.clone();
        let witness = b.items[i]
            .return_witness
            .as_ref()
            .or(b.items[i].cargo.as_ref())
            .ok_or(UNCERTAIN)?
            .clone();
        let mut stored = link.reverse_opaque_cargo_witness(true).await?.is_some();
        let verifying = matches!(
            b.items[i].handoff,
            Some(Handoff::VerifyOldOut | Handoff::ReturnVerifiedOld)
        );
        if stored && !verifying {
            if let Some(ref stamp) = old {
                self.verify_exported_original(link, slot, b, i, stamp)
                    .await?;
            }
            arm(slot, b, i, Handoff::ReturnOld)?;
            self.reverse_opaque_return(link, false, &witness).await?;
            stored = false;
        }
        let Some(stamp) = old else {
            return if !stored && link.reverse_opaque_present().await? {
                Ok(())
            } else {
                Err(UNCERTAIN.into())
            };
        };
        if !stored {
            if !link.reverse_opaque_present().await? {
                return Err(UNCERTAIN.into());
            }
            arm(slot, b, i, Handoff::VerifyOldOut)?;
            self.reverse_opaque_export(link, false).await?;
        }
        self.verify_exported_original(link, slot, b, i, &stamp)
            .await?;
        let verified = if witness.starts_with("sha1:") {
            stamp.sha1_witness()
        } else {
            link.reverse_leaf_inode(true).await?.ok_or(UNCERTAIN)?
        };
        arm(slot, b, i, Handoff::ReturnVerifiedOld)?;
        self.reverse_opaque_return(link, false, &verified).await
    }

    async fn restore_compared(
        &mut self,
        link: &mut PatchLink,
        slot: &Path,
        b: &mut Batch,
        i: usize,
    ) -> Result<()> {
        let mut step = b.items[i].handoff.ok_or(UNCERTAIN)?;
        if step == Handoff::StageDifferent {
            let stage = link.reverse_stage_path()?;
            if b.items[i].replacement_witness.is_some() {
                clear_verified_stage(link, &self.control, &b.items[i].replacement).await?;
            } else {
                io::remove_owned_stage(
                    link.reverse_media_afc()?,
                    &self.control,
                    &stage,
                    &artifact(slot, i, false),
                )
                .await?;
            }
            b.items[i].replacement_witness = None;
            step = Handoff::ExportOld;
            arm(slot, b, i, step)?;
        }
        let mut held = link.reverse_opaque_cargo_witness(true).await?;
        let occupied = link.reverse_opaque_present().await?;
        if step == Handoff::ReturnForeignOld {
            let foreign = b.items[i]
                .foreign_cargo
                .as_deref()
                .ok_or(UNCERTAIN)?
                .to_owned();
            if !occupied && held.as_deref() == Some(&foreign) {
                self.reverse_opaque_return(link, false, &foreign).await?;
                return Err(CONFLICT.into());
            }
            if occupied || held.is_some() {
                return Err(CONFLICT.into());
            }
            b.items[i].foreign_cargo = None;
            step = Handoff::ExportOld;
            arm(slot, b, i, step)?;
        }
        if !occupied && held.is_none() || b.items[i].rebuilding_held {
            let stamp = b.items[i].original.clone().ok_or(UNCERTAIN)?;
            let witness = b.items[i].return_witness.clone().ok_or(UNCERTAIN)?;
            if occupied {
                return Err(CONFLICT.into());
            }
            self.rebuild_owned_backup(link, slot, b, i, &stamp, &witness)
                .await?;
            held = link.reverse_opaque_cargo_witness(true).await?;
        }
        if let Some(object) = held {
            if occupied {
                return Err(CONFLICT.into());
            }
            if b.items[i].cargo.is_none() && step == Handoff::ExportOld {
                b.items[i].cargo = Some(object.clone());
                persist_row(slot, b, i)?;
            }
            if !matches!(step, Handoff::VerifyOldOut | Handoff::ReturnVerifiedOld)
                && b.items[i].cargo.as_ref() != Some(&object)
            {
                return Err(CONFLICT.into());
            }
            self.opaque_return_and_verify_old(link, slot, b, i).await?;
        } else if !occupied {
            return Err(UNCERTAIN.into());
        } else if step == Handoff::ExportOld {
            if b.items[i].cargo.is_some() {
                return Err(CONFLICT.into());
            }
        } else if b.items[i].original.is_some() {
            self.opaque_return_and_verify_old(link, slot, b, i).await?;
        } else if step != Handoff::ReturnOld {
            return Err(UNCERTAIN.into());
        }
        b.items[i].phase = Phase::Settled;
        persist_row(slot, b, i)
    }

    pub(super) async fn restore_opaque(
        &mut self,
        link: &mut PatchLink,
        slot: &Path,
        b: &mut Batch,
        i: usize,
    ) -> Result<()> {
        let ctl = self.control.clone();
        let stage = link.reverse_stage_path()?;
        let data = artifact(slot, i, false);
        if b.items[i].phase == Phase::Comparing {
            return self.restore_compared(link, slot, b, i).await;
        }
        let mut step = b.items[i].handoff;
        if b.items[i].phase == Phase::Staged {
            clear_verified_stage(link, &ctl, &b.items[i].replacement).await?;
            b.items[i].phase = Phase::Settled;
            return persist_row(slot, b, i);
        }
        if b.items[i].phase == Phase::Probing {
            self.reverse_parent_probe(link, true).await?;
        }
        if matches!(b.items[i].phase, Phase::Probing | Phase::Staging) {
            if b.items[i].phase == Phase::Staging {
                io::remove_owned_stage(link.reverse_media_afc()?, &ctl, &stage, &data).await?;
            }
            b.items[i].phase = Phase::Settled;
            return persist_row(slot, b, i);
        }
        let mut held = link.reverse_opaque_cargo_witness(true).await?;
        let mut staged = link.reverse_opaque_cargo_witness(false).await?;
        let mut occupied = link.reverse_opaque_present().await?;
        let stamp = b.items[i].replacement.clone();
        if matches!(
            step,
            Some(Handoff::ReturnForeign | Handoff::ReturnForeignOld)
        ) {
            let in_held = step == Some(Handoff::ReturnForeignOld);
            let foreign = b.items[i].foreign_cargo.as_ref().ok_or(UNCERTAIN)?;
            let slot_object = if in_held { &held } else { &staged };
            let disposition = foreign_disposition(occupied, slot_object.as_deref(), foreign)?;
            if disposition == ForeignDisposition::FinishReturn {
                self.reverse_opaque_return(link, !in_held, foreign).await?;
                return Err(CONFLICT.into());
            }
            if in_held && staged.is_some() {
                clear_verified_stage(link, &ctl, &stamp).await?;
                staged = None;
            }
            b.items[i].foreign_cargo = None;
            arm(slot, b, i, Handoff::EvictNew)?;
            step = Some(Handoff::EvictNew);
        }
        if step == Some(Handoff::ExportOld) && held.is_none() && occupied {
            clear_verified_stage(link, &ctl, &stamp).await?;
            b.items[i].phase = Phase::Settled;
            return persist_row(slot, b, i);
        }
        if held.is_some() && b.items[i].cargo.is_none() && step == Some(Handoff::ExportOld) {
            b.items[i].cargo = held.clone();
            persist_row(slot, b, i)?;
        }
        let returning = matches!(
            step,
            Some(Handoff::ReturnOld | Handoff::VerifyOldOut | Handoff::ReturnVerifiedOld)
        );
        if b.items[i].rebuilding_held || (held.is_none() && !(returning && occupied)) {
            if let Some(original) = b.items[i].original.clone() {
                let kind = b.items[i].return_witness.clone().ok_or(UNCERTAIN)?;
                self.rebuild_owned_backup(link, slot, b, i, &original, &kind)
                    .await?;
                held = link.reverse_opaque_cargo_witness(true).await?;
            }
        }
        if returning && occupied && held.is_some() {
            return Err(CONFLICT.into());
        }
        if !returning && occupied && held.is_some() {
            if staged.is_some() || b.items[i].original.is_none() {
                return Err(CONFLICT.into());
            }
            arm(slot, b, i, Handoff::EvictNew)?;
            self.reverse_opaque_export(link, true).await?;
            staged = link.reverse_opaque_cargo_witness(false).await?;
            occupied = false;
        }
        if !returning
            && !occupied
            && let Some(stage_object) = staged.as_ref()
        {
            let digest = io::snapshot(
                link.reverse_media_afc()?,
                &ctl,
                &stage,
                std::io::sink(),
                MAX_FILE,
            )
            .await;
            if let Err(reason) = verify_snapshot(digest, &stamp) {
                if matches!(
                    b.items[i].handoff,
                    Some(Handoff::EvictNew | Handoff::VerifyNewOut)
                ) {
                    if link.reverse_opaque_cargo_witness(false).await?.as_ref()
                        != Some(stage_object)
                    {
                        return Err(CONFLICT.into());
                    }
                    self.put_back_foreign(link, slot, b, i).await?;
                }
                return Err(reason);
            }
        }
        if held.is_none() && (!returning || !occupied) {
            return Err(UNCERTAIN.into());
        }
        if !returning && occupied {
            return Err(CONFLICT.into());
        }
        b.items[i].phase = Phase::Restoring;
        persist_row(slot, b, i)?;
        self.opaque_return_and_verify_old(link, slot, b, i).await?;
        clear_verified_stage(link, &ctl, &stamp).await?;
        b.items[i].phase = Phase::Settled;
        persist_row(slot, b, i)
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn snapshot_io_errors_are_not_relabelled_as_omittable_conflicts() {
        let stamp = io::local_copy(&b"expected"[..], std::io::sink()).unwrap();
        let other = io::local_copy(&b"other"[..], std::io::sink()).unwrap();
        assert_eq!(
            verify_snapshot(Err("transport timeout".into()), &stamp).unwrap_err(),
            "transport timeout"
        );
        assert_eq!(verify_snapshot(Ok(None), &stamp).unwrap_err(), UNCERTAIN);
        assert_eq!(
            verify_snapshot(Ok(Some(other)), &stamp).unwrap_err(),
            CONFLICT
        );
        assert!(verify_snapshot(Ok(Some(stamp.clone())), &stamp).is_ok());
    }

    #[test]
    fn reverse_foreign_readback_is_returned_intact_or_safely_rechecked_on_retry() {
        let foreign = "object:foreign";
        {
            assert_eq!(
                foreign_disposition(false, Some(foreign), foreign).unwrap(),
                ForeignDisposition::FinishReturn
            );
            assert_eq!(
                foreign_disposition(true, None, foreign).unwrap(),
                ForeignDisposition::RecheckOccupant
            );
            assert_eq!(
                foreign_disposition(false, None, foreign).unwrap(),
                ForeignDisposition::RecheckOccupant
            );
            assert!(foreign_disposition(true, Some(foreign), foreign).is_err());
            assert!(foreign_disposition(false, Some("object:unrelated"), foreign).is_err());
        }
    }
}
