use super::*;
use serde::de::DeserializeOwned;

const LARGE_BATCH: usize = 32;
const MAX_CHECKPOINT_BYTES: u64 = 16 * 1024;

#[derive(Serialize, Deserialize)]
struct Checkpoint<T> {
    generation: String,
    index: usize,
    item: T,
}

pub(in super::super) fn is_checkpoint_file(name: &str) -> bool {
    name.strip_prefix("reverse-row-")
        .and_then(|name| name.strip_suffix(".json"))
        .and_then(|decimal| decimal.parse::<usize>().ok().map(|index| (decimal, index)))
        .is_some_and(|(decimal, index)| index < MAX_ITEMS && decimal == index.to_string())
}

fn load_json<T: DeserializeOwned>(path: &Path, max: u64) -> Result<Option<T>> {
    match fs::symlink_metadata(path) {
        Err(error) if error.kind() == std::io::ErrorKind::NotFound => return Ok(None),
        Ok(metadata) if metadata.is_file() && metadata.len() <= max => (),
        _ => return Err(DISK.into()),
    }
    serde_json::from_reader(BufReader::new(read_file(path)?))
        .map(Some)
        .map_err(|_| DISK.into())
}

fn write_json(slot: &Path, name: &str, payload: &impl Serialize) -> Result<()> {
    let temporary = slot.join(format!("journal-{}.tmp", token()));
    let mut output = BufWriter::new(new_file(&temporary)?);
    serde_json::to_writer(&mut output, payload).map_err(|_| DISK)?;
    output.flush().map_err(|_| DISK)?;
    output.get_ref().sync_all().map_err(|_| DISK)?;
    fs::rename(temporary, slot.join(name)).map_err(|_| DISK)?;
    sync_dir(slot)
}

pub(in super::super) fn load_receipt(slot: &Path) -> Result<Option<Batch>> {
    let Some(mut batch) = load_json::<Batch>(&slot.join(RECEIPT), MAX_JOURNAL_BYTES)? else {
        return Ok(None);
    };
    if let Some(generation) = &batch.generation {
        if batch.items.len() < LARGE_BATCH
            || batch.items.len() > MAX_ITEMS
            || !valid_key(generation)
        {
            return Err(DISK.into());
        }
        for (index, item) in batch.items.iter_mut().enumerate() {
            let path = slot.join(format!("reverse-row-{index}.json"));
            let Some(checkpoint) = load_json::<Checkpoint<Item>>(&path, MAX_CHECKPOINT_BYTES)?
            else {
                continue;
            };
            if checkpoint.generation != *generation {
                continue;
            }
            if checkpoint.index != index
                || checkpoint.item.key != item.key
                || checkpoint.item.rel != item.rel
                || checkpoint.item.original_witness != item.original_witness
                || checkpoint.item.replacement != item.replacement
            {
                return Err(DISK.into());
            }
            *item = checkpoint.item;
        }
    }
    validate(&batch)?;
    Ok(Some(batch))
}

pub(super) fn persist(slot: &Path, batch: &mut Batch) -> Result<()> {
    if batch.items.len() < LARGE_BATCH {
        return write_json(slot, RECEIPT, batch);
    }
    let previous = batch.generation.replace(token());
    let version = std::mem::replace(&mut batch.version, CHECKPOINT_VERSION);
    let written = write_json(slot, RECEIPT, batch);
    if written.is_err() {
        batch.generation = previous;
        batch.version = version;
    }
    written
}

pub(super) fn persist_row(slot: &Path, batch: &mut Batch, index: usize) -> Result<()> {
    let Some(generation) = batch.generation.clone() else {
        return persist(slot, batch);
    };
    let payload = Checkpoint {
        generation,
        index,
        item: batch.items.get(index).ok_or(DISK)?,
    };
    write_json(slot, &format!("reverse-row-{index}.json"), &payload)
}

pub(super) fn persist_rows(slot: &Path, batch: &mut Batch, indices: &[usize]) -> Result<()> {
    if indices.is_empty() {
        return Ok(());
    }
    let mut seen = HashSet::new();
    if indices.len() > crate::device::airlift::MAX_GROUP_HANDOFFS
        || indices
            .iter()
            .any(|&i| i >= batch.items.len() || !seen.insert(i))
    {
        return Err(INVALID.into());
    }
    if indices.len() == 1 {
        return persist_row(slot, batch, indices[0]);
    }
    let Some(generation) = batch.generation.clone() else {
        return persist(slot, batch);
    };
    struct Temporary(PathBuf);
    impl Drop for Temporary {
        fn drop(&mut self) {
            let _ = fs::remove_file(&self.0);
        }
    }
    let mut files = Vec::with_capacity(indices.len());
    for &index in indices {
        let path = slot.join(format!("journal-{}.tmp", token()));
        let mut output = BufWriter::new(new_file(&path)?);
        let temp = Temporary(path);
        let payload = Checkpoint {
            generation: generation.clone(),
            index,
            item: &batch.items[index],
        };
        serde_json::to_writer(&mut output, &payload).map_err(|_| DISK)?;
        let file = output.into_inner().map_err(|_| DISK)?;
        files.push((file, temp, slot.join(format!("reverse-row-{index}.json"))));
    }
    std::thread::scope(|scope| -> Result<()> {
        let mut joins = Vec::with_capacity(files.len());
        for (file, _, _) in &files {
            match std::thread::Builder::new().spawn_scoped(scope, move || file.sync_all()) {
                Ok(handle) => joins.push(handle),
                Err(_) => file.sync_all().map_err(|_| DISK)?,
            }
        }
        for handle in joins {
            handle.join().map_err(|_| DISK)?.map_err(|_| DISK)?;
        }
        Ok(())
    })?;
    for (_, temp, target) in &files {
        fs::rename(&temp.0, target).map_err(|_| DISK)?;
    }
    sync_dir(slot)
}

#[cfg(test)]
mod tests {
    use super::*;

    fn large_batch() -> Batch {
        let mut batch = super::super::tests::plan();
        let row = serde_json::to_value(&batch.items[0]).unwrap();
        batch.items = (0..LARGE_BATCH)
            .map(|index| {
                let mut item: Item = serde_json::from_value(row.clone()).unwrap();
                item.rel = format!("Documents/Assets/{index}.bytes");
                item.key = token();
                item
            })
            .collect();
        batch
    }

    #[test]
    #[ignore = "measures real filesystem sync latency; run on the target volume"]
    fn benchmark_six_durable_intents() {
        let temp = tempfile::tempdir().unwrap();
        let mut batch = large_batch();
        let mut samples = [Vec::new(), Vec::new()];
        for round in 0..6 {
            for group in if round % 2 == 0 {
                [false, true]
            } else {
                [true, false]
            } {
                let slot = temp.path().join(format!("{round}-{group}"));
                directory(&slot).unwrap();
                persist(&slot, &mut batch).unwrap();
                let start = std::time::Instant::now();
                for k in 0..12 {
                    let mut rows = Vec::new();
                    for n in 0..6 {
                        let i = (k * 6 + n) % batch.items.len();
                        rows.push(i);
                        batch.items[i].phase = Phase::Skipped;
                    }
                    if group {
                        persist_rows(&slot, &mut batch, &rows).unwrap()
                    } else {
                        for i in rows {
                            persist_row(&slot, &mut batch, i).unwrap()
                        }
                    }
                }
                if round > 0 {
                    samples[group as usize].push(start.elapsed().as_micros());
                }
                let recovered = load_receipt(&slot).unwrap().unwrap();
                assert!(
                    recovered
                        .items
                        .iter()
                        .all(|item| item.phase == Phase::Skipped)
                );
            }
        }
        for s in &mut samples {
            s.sort();
        }
        eprintln!(
            "APFS checkpoints, 12 x 6 rows: serial {} μs; grouped {} μs (medians)",
            samples[0][2], samples[1][2]
        );
    }

    #[test]
    fn group_checkpoints_recover_each_row_and_do_not_publish_invalid_waves() {
        let temp = tempfile::tempdir().unwrap();
        let slot = temp.path();
        let mut batch = large_batch();
        persist(slot, &mut batch).unwrap();
        assert!(persist_rows(slot, &mut batch, &(0..9).collect::<Vec<_>>()).is_err());
        persist_rows(slot, &mut batch, &(0..8).collect::<Vec<_>>()).unwrap();
        for index in [1, 3, 5] {
            batch.items[index].phase = Phase::Skipped;
        }
        assert!(persist_rows(slot, &mut batch, &[1, 1]).is_err());
        let reloaded = load_receipt(slot).unwrap().unwrap();
        assert_eq!(reloaded.items[1].phase, Phase::Waiting);
        persist_rows(slot, &mut batch, &[1, 3, 5]).unwrap();
        let reloaded = load_receipt(slot).unwrap().unwrap();
        for index in 0..reloaded.items.len() {
            let expected = if [1, 3, 5].contains(&index) {
                Phase::Skipped
            } else {
                Phase::Waiting
            };
            assert_eq!(reloaded.items[index].phase, expected);
        }
        fs::remove_file(slot.join("reverse-row-3.json")).unwrap();
        let partial = load_receipt(slot).unwrap().unwrap();
        assert_eq!(partial.items[3].phase, Phase::Waiting);
        assert_eq!(partial.items[1].phase, Phase::Skipped);
    }

    #[test]
    fn reverse_checkpoint_replays_only_durable_rows_and_rejects_crossed_identities() {
        let parent = tempfile::tempdir().unwrap();
        let slot = parent.path().join("slot");
        directory(&slot).unwrap();
        let mut batch = large_batch();
        write_json(&slot, RECEIPT, &batch).unwrap();
        let legacy = load_receipt(&slot).unwrap().unwrap();
        assert_eq!(legacy.version, RECEIPT_VERSION);
        batch.items[0].phase = Phase::Staging;
        persist_row(&slot, &mut batch, 0).unwrap();
        assert_eq!(batch.version, CHECKPOINT_VERSION);
        batch.items[0].phase = Phase::Staged;
        batch.items[0].replacement_witness = Some("ino:1:1:3".into());
        persist_row(&slot, &mut batch, 0).unwrap();
        let tmp = slot.join(format!("journal-{}.tmp", token()));
        fs::write(&tmp, "partial next base or row").unwrap();
        assert_eq!(
            load_receipt(&slot).unwrap().unwrap().items[0].phase,
            Phase::Staged
        );
        let entry = fs::read(slot.join("reverse-row-0.json")).unwrap();
        fs::write(slot.join("reverse-row-1.json"), &entry).unwrap();
        assert!(load_receipt(&slot).is_err());
        fs::remove_file(slot.join("reverse-row-1.json")).unwrap();
        let mut foreign: Checkpoint<Item> = serde_json::from_slice(&entry).unwrap();
        foreign.item.key = token();
        write_json(&slot, "reverse-row-0.json", &foreign).unwrap();
        assert!(load_receipt(&slot).is_err());
        fs::write(slot.join("reverse-row-0.json"), &entry).unwrap();
        let old_generation = batch.generation.clone();
        batch.items[0].phase = Phase::Settled;
        persist(&slot, &mut batch).unwrap();
        assert_ne!(old_generation, batch.generation);
        assert!(slot.join("reverse-row-0.json").exists());
        assert_eq!(
            load_receipt(&slot).unwrap().unwrap().items[0].phase,
            Phase::Settled
        );
        remove_slot(&slot).unwrap();
        assert!(!slot.exists());
    }

    #[test]
    fn reverse_checkpoint_does_not_remove_directories_or_unexpected_files() {
        for name in [
            "reverse-row--1.json",
            "reverse-row-01.json",
            "reverse-row-1024.json",
            "other.json",
        ] {
            assert!(!is_checkpoint_file(name));
        }
        let parent = tempfile::tempdir().unwrap();
        let slot = parent.path().join("slot");
        directory(&slot).unwrap();
        fs::create_dir(slot.join("reverse-row-2.json")).unwrap();
        assert!(remove_slot(&slot).is_err());
    }
}
