use super::*;
use crate::sync::SyncControl;
use std::sync::atomic::{AtomicBool, AtomicUsize, Ordering};

fn ensure_scanning(control: &SyncControl) -> Result<()> {
    control.check().map_err(|error| match error {
        crate::sync::SyncError::Cancelled => "Đã dừng kiểm tra tệp trên iPhone.".to_owned(),
        _ => "Đã hết thời gian kiểm tra tệp trên iPhone.".to_owned(),
    })
}

const PREFLIGHT_READERS: usize = 6;
fn scan_width(count: usize) -> usize {
    match count {
        0..=7 => 1,
        8..=31 => 3,
        _ => PREFLIGHT_READERS,
    }
}

impl DeviceSession {
    pub(crate) async fn preflight_readers(
        &mut self,
        link: &PatchLink,
        bundle: &str,
        count: usize,
    ) -> Result<Vec<AfcClient>> {
        let extra = scan_width(count) - 1;
        if extra == 0 {
            return Ok(Vec::new());
        }
        if link.io_prefix.as_deref() != Some("Documents/") {
            return self.reverse_media_workers(extra).await;
        }
        let mut readers = Vec::with_capacity(extra);
        for _ in 0..extra {
            ensure_scanning(&self.control)?;
            match self
                .patch_house_arrest_reader(bundle, "VendDocuments")
                .await?
            {
                Some(client) => readers.push(client),
                None => break,
            }
        }
        Ok(readers)
    }
}

struct Scope {
    prefix: String,
    anchor: String,
    stamp: (String, String),
    link_target: Option<String>,
}

impl Scope {
    async fn check(&self, afc: &mut AfcClient) -> Result<()> {
        let m = stat(afc, &self.anchor).await?.ok_or(ACCESS)?;
        if kind(&m) != "S_IFDIR" || anchor_stamp(&m)? != self.stamp {
            return Err(ACCESS.into());
        }
        if let Some(target) = &self.link_target {
            let m = stat(afc, &self.prefix).await?.ok_or(ACCESS)?;
            if !is_link_to(&m, target) {
                return Err(ACCESS.into());
            }
        }
        Ok(())
    }
}

impl PatchLink {
    pub(crate) async fn reverse_scan_readers(
        &mut self,
        extra: &mut [AfcClient],
        names: &[String],
        ctl: &SyncControl,
        stop: &AtomicBool,
    ) -> std::result::Result<Vec<ReversePreflight>, ScanFailure> {
        ensure_scanning(ctl)?;
        if extra.len() >= PREFLIGHT_READERS {
            return Err(ScanFailure::Failed(CONFLICT.into()));
        }
        self.verify().await?;
        let paths: Vec<_> = names
            .iter()
            .map(|name| self.document_path(name))
            .collect::<Result<_>>()?;
        let alias = self.io_prefix.is_none();
        let scope = Scope {
            prefix: if alias {
                self.alias.clone()
            } else {
                String::new()
            },
            anchor: self.anchor_path.clone(),
            stamp: self.anchor_stamp.clone().ok_or_else(|| ACCESS.to_owned())?,
            link_target: alias.then(|| self.link_target.clone()),
        };
        let next = AtomicUsize::new(0);
        let done = AtomicUsize::new(0);
        ctl.log(&format!(
            "AirLift: checking {} file(s) on {} bound AFC stream(s).",
            names.len(),
            1 + extra.len()
        ));
        let workers = std::iter::once(&mut self.afc)
            .chain(extra.iter_mut())
            .map(|afc| {
                let (scope, paths, next, done) = (&scope, &paths, &next, &done);
                async move {
                    let scan = async {
                        scope.check(afc).await?;
                        let mut parents = HashSet::new();
                        let mut distinct = HashSet::new();
                        let mut rows = Vec::new();
                        while !stop.load(Ordering::Acquire) {
                            ensure_scanning(ctl)?;
                            let i = next.fetch_add(1, Ordering::Relaxed);
                            let Some(path) = paths.get(i) else { break };
                            ctl.patch_progress(
                                "checking",
                                done.load(Ordering::Relaxed),
                                names.len(),
                                &names[i],
                            );
                            let value =
                                inspect_leaf(afc, path, &scope.prefix, &mut parents, &mut distinct)
                                    .await
                                    .map_err(|e| format!("{}\n{e}", names[i]))?;
                            rows.push((i, value));
                            done.fetch_add(1, Ordering::Relaxed);
                        }
                        scope.check(afc).await?;
                        Ok(rows)
                    };
                    scan.await
                        .inspect_err(|_: &String| stop.store(true, Ordering::Release))
                }
            });
        let mut ordered: Vec<_> = (0..paths.len()).map(|_| None).collect();
        for lane in futures_util::future::join_all(workers).await {
            for (i, value) in lane? {
                ordered[i] = Some(value);
            }
        }
        self.verify().await?;
        ensure_scanning(ctl)?;
        ordered
            .into_iter()
            .collect::<Option<Vec<_>>>()
            .ok_or(ScanFailure::PreparationStopped)
    }
}
