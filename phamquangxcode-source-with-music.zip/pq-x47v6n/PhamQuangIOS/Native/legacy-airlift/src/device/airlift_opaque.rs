use super::*;

#[path = "airlift_group.rs"]
mod group;

#[derive(PartialEq, Debug)]
pub(super) enum Observation {
    Absent,
    Denied,
    Visible,
}

#[derive(Clone, Copy)]
enum Target {
    Protected,
    InitiallyMissing,
}

impl Target {
    fn occupied(self, observation: Observation) -> Result<bool> {
        match (self, observation) {
            (_, Observation::Absent) => Ok(false),
            (_, Observation::Denied) | (Self::InitiallyMissing, Observation::Visible) => Ok(true),
            (Self::Protected, Observation::Visible) => Err(CHANGED.into()),
        }
    }
}
pub(super) enum Leaf {
    Absent,
    Denied,
    Visible(Info),
}
impl Leaf {
    fn observation(self) -> Observation {
        match self {
            Self::Absent => Observation::Absent,
            Self::Denied => Observation::Denied,
            Self::Visible(_) => Observation::Visible,
        }
    }
}
pub(super) async fn observe(client: &mut AfcClient, path: &str) -> Result<Observation> {
    inspect(client, path).await.map(Leaf::observation)
}
pub(super) async fn inspect(client: &mut AfcClient, path: &str) -> Result<Leaf> {
    let reply = tokio::time::timeout(Duration::from_secs(8), client.get_file_info_raw(path))
        .await
        .map_err(|_| WAIT)?;
    classify(reply)
}
fn classify(result: std::result::Result<Info, IdeviceError>) -> Result<Leaf> {
    match result {
        Ok(info) => Ok(Leaf::Visible(info)),
        Err(IdeviceError::Afc(AfcError::ObjectNotFound)) => Ok(Leaf::Absent),
        Err(IdeviceError::Afc(AfcError::PermDenied)) => Ok(Leaf::Denied),
        _ => Err(AFC_ERROR.into()),
    }
}

pub(super) async fn check_denied_sibling(client: &mut AfcClient, parent: &str) -> Result<()> {
    let absent = format!("{parent}/cc365-absent-{:032x}", rand::random::<u128>());
    if observe(client, &absent).await? != Observation::Absent {
        return Err(
            "Không phân biệt được tệp bị từ chối và đường dẫn trống trong thư mục đích.".into(),
        );
    }
    Ok(())
}

fn object_witness(m: &Info) -> Result<String> {
    if kind(m).is_empty()
        || m.get("st_size")
            .and_then(|s| s.parse::<u64>().ok())
            .is_none()
        || ["st_ino", "st_birthtime", "st_mtime"].iter().all(|k| {
            !m.get(*k)
                .and_then(|s| s.parse::<u64>().ok())
                .is_some_and(|v| v > 0)
        })
    {
        return Err(NO_WITNESS.into());
    }
    let mut hash = Sha256::new();
    for key in [
        "st_ifmt",
        "st_size",
        "st_ino",
        "st_birthtime",
        "st_mtime",
        "st_nlink",
        "LinkTarget",
        "st_link_target",
    ] {
        hash.update(m.get(key).map(String::as_bytes).unwrap_or_default());
        hash.update([0]);
    }
    Ok(format!("object:{:x}", hash.finalize()))
}

#[derive(Serialize, Deserialize, PartialEq, Debug)]
enum ProbeIntent {
    Upload,
    Place,
    Recall,
    PutBack(String),
}
impl ProbeIntent {
    fn owns_probe_bytes(&self, observed: &[u8], expected: &[u8]) -> bool {
        observed == expected || (self == &Self::Upload && expected.starts_with(observed))
    }
    fn load(path: &Path) -> Result<Option<Self>> {
        match fs::symlink_metadata(path) {
            Err(e) if e.kind() == std::io::ErrorKind::NotFound => return Ok(None),
            Ok(m) if m.is_file() && m.len() <= 256 => (),
            _ => return Err(JOURNAL_ERROR.into()),
        }
        let file = fs::OpenOptions::new()
            .read(true)
            .custom_flags(libc::O_NOFOLLOW | libc::O_NONBLOCK)
            .open(path)
            .map_err(|_| JOURNAL_ERROR)?;
        serde_json::from_reader(file.take(257))
            .map(Some)
            .map_err(|_| JOURNAL_ERROR.into())
    }
    fn clear(path: &Path) -> Result<()> {
        match fs::remove_file(path) {
            Err(e) if e.kind() == std::io::ErrorKind::NotFound => Ok(()),
            Ok(()) => fs::File::open(path.parent().ok_or(JOURNAL_ERROR)?)
                .and_then(|d| d.sync_all())
                .map_err(|_| JOURNAL_ERROR.into()),
            _ => Err(JOURNAL_ERROR.into()),
        }
    }
}
impl PatchLink {
    async fn check_move_destination(&mut self, direction: ReverseMove) -> Result<()> {
        let (client, path) = match direction {
            ReverseMove::Install | ReverseMove::Return => self.client_path(Place::Target)?,
            ReverseMove::Export => self.client_path(Place::Held)?,
            ReverseMove::Evict => self.client_path(Place::Stage)?,
            ReverseMove::ProbePlace => {
                let (_, path) = self.probe_paths()?;
                (&mut self.afc, path)
            }
            ReverseMove::ProbeRecall => {
                let (path, _) = self.probe_paths()?;
                (self.reverse_media_afc()?, path)
            }
        };
        if observe(client, &path).await? == Observation::Absent {
            Ok(())
        } else {
            Err(CHANGED.into())
        }
    }

    pub(crate) async fn reverse_compare_export_ready(&mut self) -> Result<bool> {
        self.reverse_transfer_out_ready(Place::Held).await
    }
    async fn reverse_transfer_out_ready(&mut self, place: Place) -> Result<bool> {
        self.verify().await?;
        let target = self.reverse_target_path()?;
        self.check_document_parents(&target).await?;
        if observe(&mut self.afc, &target).await? != Observation::Denied {
            return Ok(false);
        }
        let (media, path) = self.client_path(place)?;
        Ok(observe(media, &path).await? == Observation::Absent)
    }
    pub(crate) async fn reverse_opaque_present(&mut self) -> Result<bool> {
        self.target_present(Target::Protected).await
    }

    pub(crate) async fn reverse_new_present(&mut self) -> Result<bool> {
        self.target_present(Target::InitiallyMissing).await
    }

    async fn target_present(&mut self, kind: Target) -> Result<bool> {
        self.verify().await?;
        let target = self.reverse_target_path()?;
        self.check_document_parents(&target).await?;
        kind.occupied(observe(&mut self.afc, &target).await?)
    }

    pub(crate) async fn reverse_opaque_cargo_witness(
        &mut self,
        held: bool,
    ) -> Result<Option<String>> {
        let (afc, path) = self.client_path(if held { Place::Held } else { Place::Stage })?;
        Self::reverse_cargo_witness_on(afc, &path).await
    }
    pub(crate) async fn reverse_cargo_witness_on(
        afc: &mut AfcClient,
        path: &str,
    ) -> Result<Option<String>> {
        stat(afc, path)
            .await?
            .as_ref()
            .map(object_witness)
            .transpose()
    }
    fn probe_paths(&self) -> Result<(String, String)> {
        let (rel, key) = self.selected_reverse()?;
        let parent = rel.rsplit_once('/').ok_or(CONFLICT)?.0;
        let target = self.document_path(&format!("{parent}/cc365-probe-{key}.bin"))?;
        Ok((format!("/cc365-probe-{key}"), target))
    }
    fn probe_bytes(&self) -> Result<[u8; 32]> {
        let (rel, key) = self.selected_reverse()?;
        let mut sha = Sha256::new();
        for s in ["CC365 reverse parent canary v1", &self.identity, rel, key] {
            sha.update(s.as_bytes());
            sha.update([0]);
        }
        Ok(sha.finalize().into())
    }
    pub(crate) async fn reverse_probe_vacant(&mut self) -> Result<()> {
        self.verify().await?;
        let (media, target) = self.probe_paths()?;
        self.check_document_parents(&target).await?;
        if observe(&mut self.afc, &target).await? != Observation::Absent
            || observe(self.reverse_media_afc()?, &media).await? != Observation::Absent
        {
            return Err(CONFLICT.into());
        }
        Ok(())
    }
}

impl DeviceSession {
    async fn send_opaque(&mut self, link: &mut PatchLink, direction: ReverseMove) -> Result<Trial> {
        self.control.check().map_err(|_| WAIT)?;
        let (rel, key) = link.selected_reverse()?.clone();
        let mut trial = Trial::load(&link.journal)?.ok_or(JOURNAL_ERROR)?;
        if trial.token != link.token
            || trial.patch_parent.as_deref() != Some(link.absolute_root.as_str())
            || trial.reverse_docs != link.reverse_docs
            || !trial.matched
        {
            return Err(WAIT.into());
        }
        let prior_sync = trial.sync_started;
        trial.matched = false;
        trial.sync_started = Some(now().saturating_add(12));
        trial.save(&link.journal)?;
        if let Err(error) = link.check_move_destination(direction).await {
            trial.matched = true;
            trial.sync_started = prior_sync;
            trial.save(&link.journal)?;
            return Err(error);
        }
        let ch = link.channel.as_mut().ok_or(ACCESS)?;
        tokio::time::timeout(
            Duration::from_secs(12),
            ch.reverse_move(direction, &link.token, &link.absolute_root, &rel, &key),
        )
        .await
        .map_err(|_| WAIT)??;
        Ok(trial)
    }

    pub(crate) async fn reverse_opaque_export(
        &mut self,
        link: &mut PatchLink,
        evict: bool,
    ) -> Result<()> {
        let place = if evict { Place::Stage } else { Place::Held };
        let direction = if evict {
            ReverseMove::Evict
        } else {
            ReverseMove::Export
        };
        self.export_target(link, Target::Protected, place, direction)
            .await
    }

    pub(crate) async fn reverse_new_export(&mut self, link: &mut PatchLink) -> Result<()> {
        self.export_target(
            link,
            Target::InitiallyMissing,
            Place::Stage,
            ReverseMove::Evict,
        )
        .await
    }

    async fn export_target(
        &mut self,
        link: &mut PatchLink,
        target: Target,
        place: Place,
        direction: ReverseMove,
    ) -> Result<()> {
        if !link.target_present(target).await? || !link.is_absent(place).await? {
            return Err(CHANGED.into());
        }
        let mut trial = self.send_opaque(link, direction).await?;
        let deadline = tokio::time::Instant::now() + Duration::from_secs(15);
        loop {
            self.control.check().map_err(|_| WAIT)?;
            if !link.is_absent(place).await? && !link.target_present(target).await? {
                return observed(link, &mut trial);
            }
            wait_poll(deadline).await?;
        }
    }

    pub(crate) async fn reverse_opaque_return(
        &mut self,
        link: &mut PatchLink,
        stage: bool,
        witness: &str,
    ) -> Result<()> {
        self.return_target(link, Target::Protected, stage, witness)
            .await
    }

    pub(crate) async fn reverse_new_install(
        &mut self,
        link: &mut PatchLink,
        witness: &str,
    ) -> Result<()> {
        self.return_target(link, Target::InitiallyMissing, true, witness)
            .await
    }

    async fn return_target(
        &mut self,
        link: &mut PatchLink,
        target: Target,
        stage: bool,
        witness: &str,
    ) -> Result<()> {
        let place = if stage { Place::Stage } else { Place::Held };
        let actual = if witness.starts_with("object:") {
            link.reverse_opaque_cargo_witness(!stage).await?
        } else {
            link.witness_at(place, Some(witness)).await?
        };
        if actual.as_deref() != Some(witness) || link.target_present(target).await? {
            return Err(CHANGED.into());
        }
        let direction = if stage {
            ReverseMove::Install
        } else {
            ReverseMove::Return
        };
        let mut trial = self.send_opaque(link, direction).await?;
        let deadline = tokio::time::Instant::now() + Duration::from_secs(15);
        loop {
            self.control.check().map_err(|_| WAIT)?;
            if link.is_absent(place).await? && link.target_present(target).await? {
                return observed(link, &mut trial);
            }
            wait_poll(deadline).await?;
        }
    }

    pub(crate) async fn reverse_parent_probe(
        &mut self,
        link: &mut PatchLink,
        recovery: bool,
    ) -> Result<()> {
        let expected = link.probe_bytes()?;
        let (media, target) = link.probe_paths()?;
        let path = link.journal.with_file_name(format!(
            ".cc365-parent-probe-{:x}.json",
            Sha256::digest(expected)
        ));
        let mut intent = ProbeIntent::load(&path)?;
        link.verify().await?;
        link.check_document_parents(&target).await?;
        if !recovery {
            link.reverse_probe_vacant().await?;
            if intent.is_some() {
                return Err(CONFLICT.into());
            }
            save_private_json(&path, &ProbeIntent::Upload)?;
            let c = link.reverse_media_afc()?;
            let handle = io(open_handle(c, &media, AfcFopenMode::WrOnly)).await?;
            let write = io(c.send_op(
                AfcOpcode::Write,
                handle.to_le_bytes().to_vec(),
                expected.to_vec(),
            ))
            .await;
            let close = io(close_handle(c, handle)).await;
            write?;
            close?;
            if read(c, &media).await?.as_deref() != Some(expected.as_slice()) {
                return Err(CONFLICT.into());
            }
            save_private_json(&path, &ProbeIntent::Place)?;
            intent = Some(ProbeIntent::Place);
            self.move_parent_probe(link, false, &media, &target).await?;
        }
        let target_state = observe(&mut link.afc, &target).await?;
        let published = observe(link.reverse_media_afc()?, &media).await?;
        if let Some(ProbeIntent::PutBack(ref expected_object)) = intent {
            if target_state == Observation::Absent && published == Observation::Visible {
                let m = stat(link.reverse_media_afc()?, &media)
                    .await?
                    .ok_or(CHANGED)?;
                if object_witness(&m)? != *expected_object {
                    return Err(CHANGED.into());
                }
                self.move_parent_probe(link, false, &media, &target).await?;
            } else if target_state == Observation::Absent || published != Observation::Absent {
                return Err(CHANGED.into());
            }
            return ProbeIntent::clear(&path);
        }
        if target_state != Observation::Absent && intent != Some(ProbeIntent::Upload) {
            if published != Observation::Absent {
                return Err(CONFLICT.into());
            }
            save_private_json(&path, &ProbeIntent::Recall)?;
            intent = Some(ProbeIntent::Recall);
            self.move_parent_probe(link, true, &media, &target).await?;
        } else if published == Observation::Absent {
            return if recovery {
                ProbeIntent::clear(&path)
            } else {
                Err(WAIT.into())
            };
        }
        let c = link.reverse_media_afc()?;
        let info = stat(c, &media).await?.ok_or(WAIT)?;
        let bytes = if kind(&info) == "S_IFREG"
            && !info.get("st_nlink").is_some_and(|n| n != "1")
            && info
                .get("st_size")
                .and_then(|n| n.parse::<usize>().ok())
                .is_some_and(|n| n <= expected.len())
        {
            match read(c, &media).await {
                Err(_) if intent == Some(ProbeIntent::Recall) => None,
                result => result?,
            }
        } else {
            None
        };
        if let Some(data) = bytes.as_deref().filter(|b| {
            **b == expected
                || (recovery
                    && intent
                        .as_ref()
                        .is_some_and(|phase| phase.owns_probe_bytes(b, &expected)))
        }) {
            remove_file(c, &media, data).await?;
            return ProbeIntent::clear(&path);
        }
        if intent == Some(ProbeIntent::Recall) {
            let object = object_witness(&info)?;
            let current = stat(c, &media).await?.ok_or(CHANGED)?;
            if object_witness(&current)? != object {
                return Err(CHANGED.into());
            }
            save_private_json(&path, &ProbeIntent::PutBack(object))?;
            self.move_parent_probe(link, false, &media, &target).await?;
            if recovery {
                return ProbeIntent::clear(&path);
            }
        }
        Err(CHANGED.into())
    }

    async fn move_parent_probe(
        &mut self,
        link: &mut PatchLink,
        recall: bool,
        media: &str,
        target: &str,
    ) -> Result<()> {
        link.verify().await?;
        link.check_document_parents(target).await?;
        let target_before = observe(&mut link.afc, target).await?;
        let media_before = observe(link.reverse_media_afc()?, media).await?;
        let ready = if recall {
            target_before != Observation::Absent && media_before == Observation::Absent
        } else {
            target_before == Observation::Absent && media_before == Observation::Visible
        };
        if !ready {
            return Err(CONFLICT.into());
        }
        let direction = if recall {
            ReverseMove::ProbeRecall
        } else {
            ReverseMove::ProbePlace
        };
        let mut trial = self.send_opaque(link, direction).await?;
        let deadline = tokio::time::Instant::now() + Duration::from_secs(15);
        loop {
            self.control.check().map_err(|_| WAIT)?;
            let a = observe(&mut link.afc, target).await?;
            let b = observe(link.reverse_media_afc()?, media).await?;
            let delivered = if recall {
                a == Observation::Absent && b == Observation::Visible
            } else {
                a != Observation::Absent && b == Observation::Absent
            };
            if delivered {
                return observed(link, &mut trial);
            }
            wait_poll(deadline).await?;
        }
    }
}
fn observed(link: &PatchLink, trial: &mut Trial) -> Result<()> {
    trial.matched = true;
    trial.sync_started = Some(now());
    trial.save(&link.journal)
}
pub(super) async fn wait_poll(deadline: tokio::time::Instant) -> Result<()> {
    let remaining = deadline.saturating_duration_since(tokio::time::Instant::now());
    if remaining.is_zero() {
        return Err(WAIT.into());
    }
    let elapsed = Duration::from_secs(15).saturating_sub(remaining);
    let delay = if elapsed < Duration::from_millis(90) {
        Duration::from_millis(12)
    } else if elapsed < Duration::from_millis(300) {
        Duration::from_millis(35)
    } else {
        Duration::from_millis(100)
    };
    tokio::time::sleep(delay.min(remaining)).await;
    Ok(())
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn reverse_opaque_requires_distinct_permission_denied_and_missing_observations() {
        assert_eq!(
            classify(Ok(Info::default())).unwrap().observation(),
            Observation::Visible
        );
        assert_eq!(
            classify(Err(AfcError::PermDenied.into()))
                .unwrap()
                .observation(),
            Observation::Denied
        );
        assert_eq!(
            classify(Err(AfcError::ObjectNotFound.into()))
                .unwrap()
                .observation(),
            Observation::Absent
        );
        for error in [
            AfcError::InternalError,
            AfcError::OpTimeout,
            AfcError::ServiceNotConnected,
            AfcError::ObjectIsDir,
        ] {
            assert!(classify(Err(error.into())).is_err());
        }
    }

    #[test]
    fn reverse_probe_recovery_retains_origin_of_truncated_or_unopenable_cargo() {
        let dir = tempfile::tempdir().unwrap();
        let path = dir.path().join("probe-intent");
        let expected = [5; 32];
        for phase in [
            ProbeIntent::Upload,
            ProbeIntent::Place,
            ProbeIntent::Recall,
            ProbeIntent::PutBack("object:verified".into()),
        ] {
            save_private_json(&path, &phase).unwrap();
            let reloaded = ProbeIntent::load(&path).unwrap().unwrap();
            assert_eq!(reloaded, phase);
            assert!(reloaded.owns_probe_bytes(&expected, &expected));
            assert!(!reloaded.owns_probe_bytes(&[0xf1, 0xab], &expected));
            for len in [0, 5, 31] {
                assert_eq!(
                    reloaded.owns_probe_bytes(&expected[..len], &expected),
                    phase == ProbeIntent::Upload
                );
            }
        }
        ProbeIntent::clear(&path).unwrap();
        assert!(ProbeIntent::load(&path).unwrap().is_none());
    }
}
