use super::{DeviceSession, airlift::PatchLink};
use crate::sync::SyncControl;
use rand::{RngCore, rngs::OsRng};
use serde::{Deserialize, Serialize};
use serde_json::{Value, json};
use sha2::{Digest, Sha256};
use std::{
    collections::HashSet,
    fs::{self, File, OpenOptions},
    io::{BufReader, BufWriter, Read, Write},
    os::unix::fs::{DirBuilderExt, OpenOptionsExt},
    path::{Path, PathBuf},
    time::Duration,
};
#[path = "patch_io.rs"]
mod io;
#[path = "patch_reverse.rs"]
mod reverse;
use io::Stamp;
type Result<T> = std::result::Result<T, String>;

const MAX_FILE: u64 = 128 * 1024 * 1024;
const MAX_TOTAL: u64 = 256 * 1024 * 1024;
pub(super) const MAX_ITEMS: usize = 1024;
const MAX_JOURNAL_BYTES: u64 = 4 * 1024 * 1024;
const LIMIT: &str = "Mỗi patch tối đa 1.024 tệp, 128 MiB mỗi tệp và 256 MiB cho cả lô.";
const DISK: &str =
    "Không đọc hoặc lưu được bản sao patch trên thiết bị. Hãy kiểm tra dung lượng trống.";
const INVALID: &str = "Đường dẫn phải dẫn đến một tệp trong vùng của ứng dụng đã chọn.";
const CONFLICT: &str =
    "Tệp đích đã thay đổi. CC365 đã giữ bản sao và dừng để tránh ghi đè dữ liệu mới.";
const PENDING: &str =
    "Patch còn dữ liệu cần khôi phục. Mở lại mục patch và chọn Khôi phục bản gốc.";
const PATCH_BUSY: &str =
    "CC365 đang xử lý một patch. Hãy đợi thao tác hiện tại hoàn tất rồi thử lại.";
static PATCH_JOB_LOCK: tokio::sync::Mutex<()> = tokio::sync::Mutex::const_new(());
const BUNDLE_RESOURCE: &str =
    "Vùng gói ứng dụng chỉ cho phép thay tài nguyên có sẵn. Tệp mã và chữ ký được bảo vệ.";

#[derive(Deserialize)]
pub(crate) struct PatchItem {
    pub(crate) relative_path: String,
    pub(crate) local_path: PathBuf,
}

fn begin_patch_job() -> Result<tokio::sync::MutexGuard<'static, ()>> {
    PATCH_JOB_LOCK.try_lock().map_err(|_| PATCH_BUSY.to_owned())
}

fn relative_ok(s: &str) -> bool {
    !s.is_empty()
        && s.len() <= 1024
        && s.split('/').count() <= 32
        && s.split('/').all(|part| {
            !part.is_empty()
                && part.len() <= 255
                && part != "."
                && part != ".."
                && !part.starts_with('.')
                && !part.contains('\\')
                && !part.chars().any(char::is_control)
        })
}

fn bundle_resource(s: &str, executable: Option<&str>) -> bool {
    if s.eq_ignore_ascii_case(executable.unwrap_or("")) {
        return false;
    }
    s.split('/').all(|part| {
        let lower = part.to_ascii_lowercase();
        !matches!(
            lower.as_str(),
            "info.plist"
                | "_codesignature"
                | "sc_info"
                | "frameworks"
                | "plugins"
                | "appclips"
                | "watch"
                | "coderesources"
                | "embedded.mobileprovision"
                | "pkginfo"
                | "embedded.provisionprofile"
        ) && ![
            ".app",
            ".appex",
            ".framework",
            ".dylib",
            ".metallib",
            ".xpc",
        ]
        .iter()
        .any(|suffix| lower.ends_with(suffix))
    })
}

pub(crate) fn valid_request(
    action: &str,
    bundle: &str,
    scope: &str,
    expected: Option<&str>,
    items: &[PatchItem],
    temp: &Path,
) -> bool {
    if action == "apps" {
        return bundle.is_empty() && scope.is_empty() && items.is_empty() && expected.is_none();
    }
    if !crate::identity::valid_bundle(bundle) || !matches!(scope, "bundle" | "data") {
        return false;
    }
    if expected
        .is_some_and(|s| !s.starts_with('/') || s.len() > 1024 || s.chars().any(char::is_control))
    {
        return false;
    }
    if matches!(action, "status" | "restore") {
        return items.is_empty();
    }
    if action != "apply" || items.is_empty() || items.len() > MAX_ITEMS {
        return false;
    }
    let mut seen = HashSet::new();
    items.iter().all(|i| {
        let key = i.relative_path.to_lowercase();
        let family_ok = scope != "data"
            || i.relative_path.starts_with("Documents/")
            || i.relative_path.starts_with("Library/Caches/");
        relative_ok(&i.relative_path)
            && family_ok
            && !seen.iter().any(|prior: &String| {
                key.starts_with(&format!("{prior}/")) || prior.starts_with(&format!("{key}/"))
            })
            && seen.insert(key)
            && crate::bridge::valid_transfer_path(&i.local_path, temp)
    })
}

fn read_file(p: &Path) -> Result<File> {
    let f = OpenOptions::new()
        .read(true)
        .custom_flags(libc::O_NOFOLLOW | libc::O_NONBLOCK)
        .open(p)
        .map_err(|_| DISK)?;
    if !f.metadata().map_err(|_| DISK)?.is_file() {
        return Err(DISK.into());
    }
    Ok(f)
}
fn new_file(p: &Path) -> Result<File> {
    OpenOptions::new()
        .create_new(true)
        .write(true)
        .mode(0o600)
        .open(p)
        .map_err(|_| DISK.into())
}
fn directory(p: &Path) -> Result<()> {
    match fs::symlink_metadata(p) {
        Ok(m) if m.is_dir() => Ok(()),
        Err(e) if e.kind() == std::io::ErrorKind::NotFound => fs::DirBuilder::new()
            .mode(0o700)
            .create(p)
            .map_err(|_| DISK.into()),
        _ => Err(DISK.into()),
    }
}
fn sync_dir(p: &Path) -> Result<()> {
    File::open(p)
        .and_then(|f| f.sync_all())
        .map_err(|_| DISK.into())
}

#[derive(Serialize, Deserialize)]
struct Entry {
    rel: String,
    original: Option<Stamp>,
    replacement: Stamp,
}
#[derive(Serialize, Deserialize)]
struct Omission {
    path: String,
    reason: String,
}
#[derive(Serialize, Deserialize)]
struct Journal {
    identity: String,
    token: String,
    state: String,
    armed: usize,
    skipped: usize,
    #[serde(default, skip_serializing_if = "Vec::is_empty")]
    omitted_items: Vec<Omission>,
    entries: Vec<Entry>,
}

impl Journal {
    fn reviewed(&self) -> usize {
        self.skipped + self.omitted_items.len()
    }
    fn total(&self) -> usize {
        self.entries.len() + self.reviewed()
    }
    fn omit(
        &mut self,
        ctl: &SyncControl,
        total: usize,
        path: &str,
        reason: &str,
        local: &[&Path],
    ) -> Result<()> {
        for scratch in local {
            fs::remove_file(scratch).map_err(|_| DISK)?;
        }
        self.omitted_items.push(Omission {
            path: path.into(),
            reason: reason.into(),
        });
        ctl.patch_progress(
            "omitted",
            self.reviewed().min(total.saturating_sub(1)),
            total,
            path,
        );
        Ok(())
    }
}

fn token() -> String {
    let mut bytes = [0u8; 16];
    OsRng.fill_bytes(&mut bytes);
    bytes.iter().map(|b| format!("{b:02x}")).collect()
}
fn slot_id(device: &str, bundle: &str, scope: &str) -> String {
    let hash = Sha256::digest(format!("{device}\0{scope}\0{bundle}").as_bytes());
    format!("{hash:x}")
}
fn save(slot: &Path, j: &Journal) -> Result<()> {
    let temp = slot.join(format!("journal-{}.tmp", token()));
    let mut f = BufWriter::new(new_file(&temp)?);
    serde_json::to_writer(&mut f, j).map_err(|_| DISK)?;
    f.flush().map_err(|_| DISK)?;
    f.get_ref().sync_all().map_err(|_| DISK)?;
    fs::rename(temp, slot.join("journal.json")).map_err(|_| DISK)?;
    sync_dir(slot)
}
fn load(slot: &Path) -> Result<Option<Journal>> {
    let p = slot.join("journal.json");
    match fs::symlink_metadata(&p) {
        Err(e) if e.kind() == std::io::ErrorKind::NotFound => return Ok(None),
        Ok(m) if m.is_file() && m.len() <= MAX_JOURNAL_BYTES => (),
        _ => return Err(DISK.into()),
    }
    let j: Journal = serde_json::from_reader(BufReader::new(read_file(&p)?)).map_err(|_| DISK)?;
    if j.token.len() != 32
        || !j.token.bytes().all(|b| b.is_ascii_hexdigit())
        || j.entries.len() > MAX_ITEMS
        || j.armed > j.entries.len()
        || j.skipped > MAX_ITEMS.saturating_sub(j.entries.len())
        || j.omitted_items.len() > MAX_ITEMS.saturating_sub(j.entries.len() + j.skipped)
        || j.omitted_items.iter().any(|o| {
            !relative_ok(&o.path)
                || o.reason.is_empty()
                || o.reason.len() > 512
                || o.reason.chars().any(char::is_control)
        })
        || !matches!(j.state.as_str(), "pending" | "applied" | "restored")
        || j.entries.iter().any(|e| {
            !relative_ok(&e.rel)
                || e.replacement.len > MAX_FILE
                || e.original.as_ref().is_some_and(|s| s.len > MAX_FILE)
        })
    {
        return Err(DISK.into());
    }
    Ok(Some(j))
}
fn artifact(slot: &Path, index: usize, original: bool) -> PathBuf {
    slot.join(format!(
        "{}-{index}",
        if original { "original" } else { "replacement" }
    ))
}
fn remove_slot(slot: &Path) -> Result<()> {
    if !fs::symlink_metadata(slot).is_ok_and(|m| m.is_dir()) {
        return Ok(());
    }
    let files = fs::read_dir(slot)
        .map_err(|_| DISK)?
        .collect::<std::io::Result<Vec<_>>>()
        .map_err(|_| DISK)?;
    for f in &files {
        let name = f.file_name();
        let name = name.to_str().ok_or(DISK)?;
        let known = matches!(name, "journal.json" | "reverse.json")
            || reverse::is_checkpoint_file(name)
            || name
                .strip_prefix("original-")
                .or_else(|| name.strip_prefix("replacement-"))
                .is_some_and(|s| s.parse::<usize>().is_ok_and(|n| n < MAX_ITEMS))
            || name
                .strip_prefix("journal-")
                .and_then(|s| s.strip_suffix(".tmp"))
                .is_some_and(|s| s.len() == 32 && s.bytes().all(|b| b.is_ascii_hexdigit()));
        if !known || !f.file_type().map_err(|_| DISK)?.is_file() {
            return Err(DISK.into());
        }
    }
    for f in files
        .iter()
        .filter(|f| f.file_name() != "journal.json" && f.file_name() != "reverse.json")
    {
        fs::remove_file(f.path()).map_err(|_| DISK)?
    }
    for name in ["journal.json", "reverse.json"] {
        if files.iter().any(|f| f.file_name() == name) {
            fs::remove_file(slot.join(name)).map_err(|_| DISK)?;
        }
    }
    fs::remove_dir(slot).map_err(|_| DISK)?;
    sync_dir(slot.parent().ok_or(DISK)?)
}
fn receipt(j: Option<&Journal>, state: &str, msg: &str) -> Value {
    let restore_paths = j
        .filter(|_| matches!(state, "applied" | "pending"))
        .map(|journal| {
            journal
                .entries
                .iter()
                .take(journal.armed)
                .rev()
                .map(|e| e.rel.as_str())
                .collect::<Vec<_>>()
        });
    let omitted = j.map_or(&[][..], |j| j.omitted_items.as_slice());
    json!({"state":state,"restore_paths":restore_paths,"omitted":omitted.len(),"omitted_items":omitted,"changed":j.map_or(0,|j|j.entries.len()),"skipped":j.map_or(0,|j|j.skipped),
           "bytes":j.map_or(0,|j|j.entries.iter().map(|e|e.replacement.len).sum::<u64>()),"message":msg})
}

fn looks_executable(p: &Path) -> Result<bool> {
    let mut b = [0u8; 4];
    let mut f = read_file(p)?;
    if f.read(&mut b).map_err(|_| DISK)? < 4 {
        return Ok(false);
    }
    Ok(matches!(
        u32::from_be_bytes(b),
        0xfeedface
            | 0xcefaedfe
            | 0xfeedfacf
            | 0xcffaedfe
            | 0xcafebabe
            | 0xbebafeca
            | 0xcafebabf
            | 0xbfbafeca
    ))
}

fn available_storage(slot: &Path) -> Result<u64> {
    let mut remaining = 1024 * 1024 * 1024u64;
    for item in fs::read_dir(slot.parent().ok_or(DISK)?).map_err(|_| DISK)? {
        let item = item.map_err(|_| DISK)?;
        if item.path() == slot || !item.file_type().map_err(|_| DISK)?.is_dir() {
            continue;
        }
        for f in fs::read_dir(item.path()).map_err(|_| DISK)? {
            let f = f.map_err(|_| DISK)?;
            let m = fs::symlink_metadata(f.path()).map_err(|_| DISK)?;
            if m.is_file() {
                remaining = remaining.saturating_sub(m.len());
            }
        }
    }
    Ok(remaining)
}

async fn prepare(
    link: &mut PatchLink,
    ctl: &SyncControl,
    slot: &Path,
    scope: &str,
    items: &[PatchItem],
) -> Result<Journal> {
    let mut j = Journal {
        identity: link.identity.clone(),
        token: token(),
        state: "pending".into(),
        armed: 0,
        skipped: 0,
        omitted_items: Vec::new(),
        entries: Vec::new(),
    };
    let mut input_total = 0;
    let mut backup_total = 0;
    let available = available_storage(slot)?;
    let mut local_used = 0u64;
    for (position, item) in items.iter().enumerate() {
        ctl.check().map_err(|_| "Đã dừng patch.")?;
        let rel = &item.relative_path;
        ctl.patch_progress("checking", position, items.len(), rel);
        if !relative_ok(rel) {
            return Err(INVALID.into());
        }
        if scope == "bundle" && !bundle_resource(rel, link.executable.as_deref()) {
            j.omit(ctl, items.len(), rel, BUNDLE_RESOURCE, &[])?;
            continue;
        }
        if !crate::bridge::valid_transfer_path(&item.local_path, &std::env::temp_dir()) {
            return Err(INVALID.into());
        }
        let source = read_file(&item.local_path)?;
        let length = source.metadata().map_err(|_| DISK)?.len();
        if length > MAX_FILE
            || length > MAX_TOTAL - input_total
            || length > available.saturating_sub(local_used)
        {
            return Err(LIMIT.into());
        }
        let index = j.entries.len();
        link.verify().await?;
        let mapped = io_relative(link, rel)?;
        if let Err(reason) = io::parents(&mut link.afc, ctl, &link.alias, mapped).await {
            if matches!(
                reason.as_str(),
                io::PARENT_MISSING | io::PARENT_TYPE | io::PERMISSION_DENIED
            ) {
                j.omit(ctl, items.len(), rel, &reason, &[])?;
                continue;
            }
            return Err(reason);
        }
        let target = io::join(&link.alias, mapped);
        let backup_path = artifact(slot, index, true);
        let mut backup = new_file(&backup_path)?;
        let original = io::snapshot(
            &mut link.afc,
            ctl,
            &target,
            &mut backup,
            (MAX_TOTAL - backup_total).min(available - local_used - length),
        )
        .await;
        let original = match original {
            Ok(original) => original,
            Err(reason)
                if matches!(
                    reason.as_str(),
                    io::PERMISSION_DENIED | io::UNSUPPORTED_LEAF
                ) =>
            {
                drop(backup);
                j.omit(ctl, items.len(), rel, &reason, &[&backup_path])?;
                continue;
            }
            Err(reason) => return Err(reason),
        };
        backup.sync_all().map_err(|_| DISK)?;
        drop(backup);
        let unsupported = if original.is_none() && link.transport == "airlift_cache_container" {
            Some("Library/Caches chỉ hỗ trợ thay tệp có sẵn tại đường dẫn đích.")
        } else if original.is_none() && link.io_prefix.is_some() {
            Some("Vùng Documents này chỉ hỗ trợ thay tệp đã có.")
        } else if scope == "bundle" && (original.is_none() || looks_executable(&backup_path)?) {
            Some(BUNDLE_RESOURCE)
        } else {
            None
        };
        if let Some(reason) = unsupported {
            j.omit(ctl, items.len(), rel, reason, &[&backup_path])?;
            continue;
        }
        ctl.check().map_err(|_| "Đã dừng patch.")?;
        let replacement_path = artifact(slot, index, false);
        let mut copy = new_file(&replacement_path)?;
        let replacement = io::local_copy(source.take(length + 1), &mut copy)?;
        if replacement.len != length {
            return Err(DISK.into());
        }
        input_total += length;
        copy.sync_all().map_err(|_| DISK)?;
        drop(copy);
        if scope == "bundle" && looks_executable(&replacement_path)? {
            j.omit(
                ctl,
                items.len(),
                rel,
                BUNDLE_RESOURCE,
                &[&backup_path, &replacement_path],
            )?;
            continue;
        }
        if original.as_ref() == Some(&replacement) {
            fs::remove_file(&replacement_path).map_err(|_| DISK)?;
            fs::remove_file(&backup_path).map_err(|_| DISK)?;
            j.skipped += 1;
            ctl.patch_progress(
                "unchanged",
                j.reviewed().min(items.len().saturating_sub(1)),
                items.len(),
                rel,
            );
            continue;
        }
        if let Some(old) = &original {
            backup_total += old.len;
            local_used += old.len
        } else {
            fs::remove_file(&backup_path).map_err(|_| DISK)?
        }
        local_used += length;
        let e = Entry {
            rel: rel.clone(),
            original,
            replacement,
        };
        for restore in [false, true] {
            let temp = stage_path(
                &link.alias,
                io_relative(link, &e.rel)?,
                &j.token,
                index,
                restore,
            );
            if !io::missing(&mut link.afc, ctl, &temp).await? {
                return Err(CONFLICT.into());
            }
        }
        j.entries.push(e);
    }
    sync_dir(slot)?;
    Ok(j)
}

fn io_relative<'a>(link: &PatchLink, rel: &'a str) -> Result<&'a str> {
    let mapped = match &link.io_prefix {
        Some(prefix) => rel
            .strip_prefix(prefix.as_str())
            .ok_or("iOS chỉ cho truy cập Documents của ứng dụng đã chọn.")?,
        None => rel,
    };
    if relative_ok(mapped) {
        Ok(mapped)
    } else {
        Err(INVALID.into())
    }
}

fn stage_path(alias: &str, rel: &str, id: &str, i: usize, restore: bool) -> String {
    let parent = rel
        .rsplit_once('/')
        .map(|(p, _)| io::join(alias, p))
        .unwrap_or_else(|| alias.into());
    let parent = parent.trim_end_matches('/');
    format!(
        "{parent}/.cc365-patch-{id}-{i}-{}",
        if restore { 'r' } else { 'a' }
    )
}

async fn check_anchors(link: &mut PatchLink, ctl: &SyncControl, rel: &str) -> Result<()> {
    link.verify().await?;
    let rel = io_relative(link, rel)?;
    io::parents(&mut link.afc, ctl, &link.alias, rel).await
}

async fn current(link: &mut PatchLink, ctl: &SyncControl, dest: &str) -> Result<Option<Stamp>> {
    io::snapshot(&mut link.afc, ctl, dest, std::io::sink(), MAX_FILE).await
}

async fn publish(
    link: &mut PatchLink,
    ctl: &SyncControl,
    slot: &Path,
    j: &mut Journal,
    delivered: bool,
) -> Result<Value> {
    let total = j.total();
    for i in 0..j.entries.len() {
        if !delivered {
            j.armed = i + 1;
            save(slot, j)?;
        }
        let e = &j.entries[i];
        ctl.patch_progress("applying", j.reviewed() + i, total, &e.rel);
        check_anchors(link, ctl, &e.rel).await?;
        let dest = io::join(&link.alias, io_relative(link, &e.rel)?);
        let temp = stage_path(&link.alias, io_relative(link, &e.rel)?, &j.token, i, false);
        if delivered {
            if current(link, ctl, &temp).await?.as_ref() != Some(&e.replacement) {
                return Err(
                    "Nội dung tệp AirLift giao tại thư mục đích chưa khớp bản đã chọn.".into(),
                );
            }
        } else {
            io::upload(
                &mut link.afc,
                ctl,
                &temp,
                &artifact(slot, i, false),
                &e.replacement,
            )
            .await?;
        }
        check_anchors(link, ctl, &e.rel).await?;
        if current(link, ctl, &dest).await? != e.original {
            return Err(CONFLICT.into());
        }
        check_anchors(link, ctl, &e.rel).await?;
        if e.original.is_some() {
            io::rename(&mut link.afc, ctl, &temp, &dest)
                .await
                .map_err(|e| format!("Thay tệp đã có: {e}"))?;
        } else {
            io::create_only(&mut link.afc, ctl, &temp, &dest)
                .await
                .map_err(|e| format!("Tạo tệp mới: {e}"))?;
        }
        check_anchors(link, ctl, &e.rel).await?;
        if current(link, ctl, &dest).await?.as_ref() != Some(&e.replacement) {
            return Err(CONFLICT.into());
        }
        ctl.patch_progress(
            "applied",
            (j.reviewed() + i + 1).min(total.saturating_sub(1)),
            total,
            &e.rel,
        );
    }
    j.state = "applied".into();
    save(slot, j)?;
    for i in 0..j.entries.len() {
        let _ = fs::remove_file(artifact(slot, i, false));
    }
    Ok(receipt(
        Some(j),
        "applied",
        "Đã áp dụng patch và kiểm tra nội dung tại đích.",
    ))
}

async fn restore(
    link: &mut PatchLink,
    ctl: &SyncControl,
    slot: &Path,
    j: &mut Journal,
) -> Result<Value> {
    if j.identity != link.identity {
        return Err(
            "Thư mục cài đặt hoặc phiên bản ứng dụng đã thay đổi. Bản sao đã được giữ lại.".into(),
        );
    }
    for (i, e) in j.entries.iter().take(j.armed).enumerate() {
        if let Some(stamp) = &e.original {
            if io::local_copy(read_file(&artifact(slot, i, true))?, std::io::sink())? != *stamp {
                return Err(DISK.into());
            }
        }
    }
    j.state = "pending".into();
    save(slot, j)?;
    let total = j.total();
    for i in (0..j.armed).rev() {
        let e = &j.entries[i];
        ctl.patch_progress("restoring", total - i - 1, total, &e.rel);
        check_anchors(link, ctl, &e.rel).await?;
        let target = io::join(&link.alias, io_relative(link, &e.rel)?);
        let temp = stage_path(&link.alias, io_relative(link, &e.rel)?, &j.token, i, true);
        let initial_stage = stage_path(&link.alias, io_relative(link, &e.rel)?, &j.token, i, false);
        io::remove_owned_stage(
            &mut link.afc,
            ctl,
            &initial_stage,
            &artifact(slot, i, false),
        )
        .await?;
        if e.original.is_some() {
            io::remove_owned_stage(&mut link.afc, ctl, &temp, &artifact(slot, i, true)).await?
        }
        let observed = current(link, ctl, &target).await?;
        if observed != e.original {
            if observed.as_ref() != Some(&e.replacement) {
                return Err(CONFLICT.into());
            }
            if let Some(orig) = &e.original {
                io::upload(&mut link.afc, ctl, &temp, &artifact(slot, i, true), orig).await?;
                check_anchors(link, ctl, &e.rel).await?;
                if current(link, ctl, &target).await? != observed {
                    return Err(CONFLICT.into());
                }
                check_anchors(link, ctl, &e.rel).await?;
                io::rename(&mut link.afc, ctl, &temp, &target).await?;
            } else {
                check_anchors(link, ctl, &e.rel).await?;
                io::remove(&mut link.afc, ctl, &target).await?;
            }
            if current(link, ctl, &target).await? != e.original {
                return Err(CONFLICT.into());
            }
        }
        j.armed = i;
        save(slot, j)?;
        ctl.patch_progress(
            "restored",
            (total - i).min(total.saturating_sub(1)),
            total,
            &j.entries[i].rel,
        );
    }
    j.state = "restored".into();
    save(slot, j)?;
    let result = receipt(Some(j), "restored", "Đã khôi phục và kiểm tra các tệp gốc.");
    remove_slot(slot)?;
    Ok(result)
}

impl DeviceSession {
    async fn deliver_patch_payloads(
        &mut self,
        link: &mut PatchLink,
        ctl: &SyncControl,
        slot: &Path,
        j: &mut Journal,
    ) -> Result<()> {
        let mut moves = Vec::with_capacity(j.entries.len());
        for (i, e) in j.entries.iter().enumerate() {
            ctl.patch_progress("staging", j.reviewed(), j.total(), &e.rel);
            check_anchors(link, ctl, &e.rel).await?;
            let temp = stage_path(&link.alias, io_relative(link, &e.rel)?, &j.token, i, false);
            if !io::missing(&mut link.afc, ctl, &temp).await? {
                return Err(CONFLICT.into());
            }
            let logical = stage_path("", &e.rel, &j.token, i, false)
                .trim_start_matches('/')
                .to_owned();
            let source = link.media_stage(i, false);
            io::upload(
                link.media_afc().ok_or(INVALID)?,
                ctl,
                &source,
                &artifact(slot, i, false),
                &e.replacement,
            )
            .await
            .map_err(|e| format!("Gửi tệp vào Media: {e}"))?;
            moves.push((logical, source));
        }
        j.armed = j.entries.len();
        save(slot, j)?;
        self.deliver_patch_stages(link, &moves)
            .await
            .map_err(|e| format!("Chuyển tệp bằng AirLift: {e}"))
    }
    pub(crate) async fn patch(
        &mut self,
        action: &str,
        bundle: &str,
        scope: &str,
        expected_root: Option<&str>,
        items: &[PatchItem],
    ) -> Result<Value> {
        let started = std::time::Instant::now();
        if !valid_request(
            action,
            bundle,
            scope,
            expected_root,
            items,
            &std::env::temp_dir(),
        ) {
            return Err(INVALID.into());
        }
        if action == "apps" {
            return Ok(json!({"apps":self.patch_apps().await?}));
        }
        let _job = begin_patch_job()?;
        let mut lockdown = super::native(
            &self.control.clone(),
            super::IO_TIMEOUT,
            "patch device identity",
            self.lockdown(),
        )
        .await
        .map_err(|_| "Không xác định được iPhone.")?;
        let udid = super::native(
            &self.control,
            super::IO_TIMEOUT,
            "patch device identity",
            lockdown.get_value(Some("UniqueDeviceID"), None),
        )
        .await
        .map_err(|_| "Không xác định được iPhone.")?;
        let udid = udid
            .as_string()
            .filter(|s| !s.is_empty())
            .ok_or("Không xác định được iPhone.")?;
        let root = self
            .pairing_path
            .parent()
            .ok_or(DISK)?
            .join(".cc365-patch-v1");
        directory(&root)?;
        let slot = root.join(slot_id(udid, bundle, scope));
        directory(&slot)?;
        let mut journal = load(&slot)?;
        let reverse_journal = reverse::load_receipt(&slot)?;
        if journal.is_some() && reverse_journal.is_some() {
            return Err(CONFLICT.into());
        }
        if journal.as_ref().is_some_and(|j| j.state == "restored") {
            remove_slot(&slot)?;
            journal = None;
            directory(&slot)?;
        }
        let documents = scope == "data"
            && items
                .iter()
                .all(|i| i.relative_path.starts_with("Documents/"));
        if reverse_journal.is_some() || (action == "apply" && documents && journal.is_none()) {
            return self
                .reverse_documents(action, bundle, expected_root, items, &slot, reverse_journal)
                .await;
        }
        if action == "apply"
            && scope == "data"
            && !documents
            && items
                .iter()
                .any(|i| i.relative_path.starts_with("Documents/"))
        {
            return Err("Hãy áp dụng nhóm tệp Documents trong một lượt riêng.".into());
        }
        if action == "status" {
            return Ok(match journal {
                Some(ref j) => receipt(
                    Some(j),
                    &j.state,
                    if j.state == "pending" {
                        PENDING
                    } else {
                        "Đã lưu bản gốc của patch."
                    },
                ),
                None => receipt(None, "none", ""),
            });
        }
        if action == "apply" && journal.is_some() {
            return Err("Hãy khôi phục bản gốc của patch trước khi áp dụng patch khác.".into());
        }
        if action == "restore" && journal.is_none() {
            return Ok(receipt(
                None,
                "none",
                "Ứng dụng này chưa có bản patch cần khôi phục.",
            ));
        }
        if journal.is_none() {
            remove_slot(&slot)?;
            directory(&slot)?;
            sync_dir(&root)?
        }
        let paths: Vec<&str> = match &journal {
            Some(j) => j.entries.iter().map(|e| e.rel.as_str()).collect(),
            None => items.iter().map(|e| e.relative_path.as_str()).collect(),
        };
        let cache_count = paths
            .iter()
            .filter(|p| p.starts_with("Library/Caches/"))
            .count();
        let cache_only = scope == "data" && cache_count > 0 && cache_count == paths.len();
        if action == "apply" && scope == "data" && cache_count > 0 && !cache_only {
            return Err("Hãy áp dụng riêng nhóm tệp Library/Caches của ứng dụng.".into());
        }
        let documents_only = scope == "data" && paths.iter().all(|p| p.starts_with("Documents/"));
        let slots = if action == "apply" { items.len() } else { 0 };
        let mut link = if cache_only {
            match self.open_container_cache_link(bundle, slots).await? {
                Some(link) => link,
                None if action == "restore" => {
                    self.open_patch_link_with_slots(bundle, scope, 0, false).await?
                }
                None => return Err(
                    "iOS không mở được Library/Caches của ứng dụng đích để sao lưu. CC365 chưa thay tệp nào.".into()
                ),
            }
        } else {
            self.open_patch_link_with_slots(bundle, scope, slots, documents_only)
                .await?
        };
        let ctl = self.control.clone();
        let run = async {
            if expected_root.is_some_and(|p| {
                p.strip_prefix("/private").unwrap_or(p)
                    != link
                        .absolute_root
                        .strip_prefix("/private")
                        .unwrap_or(&link.absolute_root)
            }) {
                return Err("Ứng dụng đã đổi đường dẫn cài đặt. Hãy chọn lại ứng dụng.".into());
            }
            if action == "restore" {
                return restore(&mut link, &ctl, &slot, journal.as_mut().ok_or(DISK)?).await;
            }
            let mut j = prepare(&mut link, &ctl, &slot, scope, items).await?;
            if j.entries.is_empty() {
                let message = if j.omitted_items.is_empty() {
                    "Các tệp đích đã khớp nội dung."
                } else {
                    "Đã kiểm tra xong các tệp. Xem lý do trong mục Tệp bỏ qua."
                };
                let result = receipt(Some(&j), "unchanged", message);
                remove_slot(&slot)?;
                return Ok(result);
            }
            save(&slot, &j)?;
            let deliver_via_atc = scope == "bundle" || link.io_prefix.is_some() || cache_only;
            if deliver_via_atc {
                self.deliver_patch_payloads(&mut link, &ctl, &slot, &mut j)
                    .await?
            }
            publish(&mut link, &ctl, &slot, &mut j, deliver_via_atc).await
        }
        .await;
        let run = run.map(|mut value| {
            value["transport"] = json!(link.transport);
            if value["state"] == "applied" {
                if scope == "bundle" {
                    value["message"] = json!(
                        "AirLift đã chuyển tài nguyên. Đã thay và kiểm tra nội dung trong gói .app."
                    );
                } else if cache_only {
                    value["message"] =
                        json!("Đã thay tệp trong Library/Caches và kiểm tra lại nội dung.");
                } else if link.io_prefix.is_some() {
                    value["message"] = json!(
                        "AirLift đã chuyển tệp. Đã kiểm tra và thay tại Documents của ứng dụng."
                    );
                }
            }
            value
        });
        let total = if action == "apply" {
            items.len()
        } else {
            journal.as_ref().map_or(0, |j| j.total())
        };
        if run.is_ok() {
            ctl.patch_progress("finishing", total.saturating_sub(1), total, "");
        }
        let closed = self.close_patch_link(link).await;
        if let Err(close_error) = closed {
            let message = run.err().unwrap_or_default();
            return Err(format!("{message} {close_error}").trim().to_owned());
        }
        if let Err(error) = run.as_ref() {
            if action == "apply" {
                match load(&slot)? {
                    None => {
                        remove_slot(&slot)?;
                    }
                    Some(mut j) if j.state == "pending" && ctl.check().is_ok() => {
                        let reopened = if cache_only {
                            self.open_container_cache_link(bundle, 0).await
                        } else {
                            self.open_patch_link_with_slots(bundle, scope, 0, documents_only)
                                .await
                                .map(Some)
                        };
                        if let Ok(Some(mut fresh)) = reopened {
                            let recovery = restore(&mut fresh, &ctl, &slot, &mut j).await;
                            let closed = self.close_patch_link(fresh).await;
                            if recovery.is_ok() && closed.is_ok() {
                                return Err(format!("{error} Đã khôi phục bản gốc."));
                            }
                        }
                        return Err(format!("{error} {PENDING}"));
                    }
                    _ => {}
                }
            }
        }
        run.map(|mut value| {
            ctl.patch_progress("complete", total, total, "");
            value["elapsed_ms"] = json!(started.elapsed().as_millis().min(u64::MAX as u128) as u64);
            value
        })
    }
}

#[cfg(test)]
#[path = "patch_cases.rs"]
mod tests;

#[derive(Serialize, Deserialize)]
struct SavedTarget {
    device: String,
    bundle: String,
    scope: String,
    app: Value,
    updated: u64,
}
fn valid_saved_app(row: &SavedTarget) -> bool {
    let app = &row.app;
    let valid_name = app["name"]
        .as_str()
        .is_some_and(|s| !s.is_empty() && s.len() <= 1024 && !s.chars().any(char::is_control));
    let uuid = |s: &str| {
        s.len() == 36
            && s.bytes().enumerate().all(|(i, b)| {
                if [8, 13, 18, 23].contains(&i) {
                    b == b'-'
                } else {
                    b.is_ascii_hexdigit()
                }
            })
    };
    let data = app["data_path"].as_str().filter(|s| {
        s.strip_prefix("/var/mobile/Containers/Data/Application/")
            .is_some_and(uuid)
    });
    let bundle = app["bundle_path"].as_str().filter(|s| {
        s.strip_prefix("/var/containers/Bundle/Application/")
            .is_some_and(|tail| {
                tail.split_once('/').is_some_and(|(id, leaf)| {
                    uuid(id)
                        && leaf.ends_with(".app")
                        && leaf != ".app"
                        && leaf.len() <= 255
                        && !leaf.contains('/')
                        && !leaf.chars().any(char::is_control)
                })
            })
    });
    valid_name
        && app["bundle_id"].as_str() == Some(&row.bundle)
        && (app["data_path"].is_null() || data.is_some())
        && (app["bundle_path"].is_null() || bundle.is_some())
        && (if row.scope == "data" {
            data.is_some()
        } else {
            bundle.is_some()
        })
        && (app["target_id"].is_null()
            || app["target_id"]
                .as_str()
                .is_some_and(|target| data.is_some_and(|path| target == format!("path:{path}"))))
        && (app["file_sharing_enabled"].is_null() || app["file_sharing_enabled"].is_boolean())
}
fn targets_root(pairing: &Path) -> Result<PathBuf> {
    Ok(pairing
        .parent()
        .ok_or(DISK)?
        .join(".viet99-airlift-targets"))
}
pub(crate) fn remember_target(
    pairing: &Path,
    device: &str,
    bundle: &str,
    scope: &str,
    app: Value,
) -> Result<()> {
    let root = targets_root(pairing)?;
    directory(&root)?;
    let id = slot_id(device, bundle, scope);
    let path = root.join(format!("{id}.json"));
    let slot = pairing
        .parent()
        .ok_or(DISK)?
        .join(".cc365-patch-v1")
        .join(&id);
    let active = load(&slot)?.is_some_and(|j| matches!(j.state.as_str(), "applied" | "pending"))
        || reverse::load_receipt(&slot)?.is_some_and(|j| {
            matches!(
                reverse::report(&j)["state"].as_str(),
                Some("applied" | "pending")
            )
        });
    if active {
        if fs::symlink_metadata(&path).is_ok_and(|m| m.is_file()) {
            return Ok(());
        }
        return Err(
            "Biên nhận AirLift đang có bản gốc cần khôi phục; không đổi đích của phiên đã lưu."
                .into(),
        );
    }
    let tmp = root.join(format!("{id}-{}.tmp", token()));
    let row = SavedTarget {
        device: device.into(),
        bundle: bundle.into(),
        scope: scope.into(),
        app,
        updated: std::time::SystemTime::now()
            .duration_since(std::time::UNIX_EPOCH)
            .unwrap_or_default()
            .as_secs(),
    };
    let result = (|| {
        let mut file = new_file(&tmp)?;
        serde_json::to_writer(&mut file, &row).map_err(|_| DISK)?;
        file.sync_all().map_err(|_| DISK)?;
        fs::rename(&tmp, &path).map_err(|_| DISK)?;
        sync_dir(&root)
    })();
    if result.is_err() {
        let _ = fs::remove_file(tmp);
    }
    result
}
pub(crate) fn history(pairing: &Path) -> Result<Value> {
    let root = targets_root(pairing)?;
    if !root.exists() {
        return Ok(json!({"patches":[]}));
    }
    if !fs::symlink_metadata(&root).is_ok_and(|m| m.is_dir()) {
        return Err(DISK.into());
    }
    let mut rows = Vec::new();
    let mut invalid = 0;
    let mut output_bytes = 0usize;
    for file in fs::read_dir(&root).map_err(|_| DISK)?.take(1025) {
        if rows.len() + invalid >= 1024 {
            invalid += 1;
            break;
        }
        let result = (|| -> Result<Option<Value>> {
            let file = file.map_err(|_| DISK)?;
            let name = file.file_name();
            let name = name.to_str().ok_or(DISK)?;
            let id = name
                .strip_suffix(".json")
                .filter(|s| s.len() == 64 && s.bytes().all(|b| b.is_ascii_hexdigit()))
                .ok_or(DISK)?;
            let mut f = read_file(&file.path())?;
            if f.metadata().map_err(|_| DISK)?.len() > 16384 {
                return Err(DISK.into());
            }
            let row: SavedTarget =
                serde_json::from_reader((&mut f).take(16385)).map_err(|_| DISK)?;
            if !crate::identity::valid_bundle(&row.bundle)
                || !matches!(row.scope.as_str(), "data" | "bundle")
                || slot_id(&row.device, &row.bundle, &row.scope) != id
                || !valid_saved_app(&row)
            {
                return Err(DISK.into());
            }
            let slot = pairing
                .parent()
                .ok_or(DISK)?
                .join(".cc365-patch-v1")
                .join(id);
            if fs::symlink_metadata(&slot).is_ok_and(|m| !m.is_dir())
                || fs::symlink_metadata(slot.parent().ok_or(DISK)?).is_ok_and(|m| !m.is_dir())
            {
                return Err(DISK.into());
            }
            let normal = load(&slot)?;
            let reverse = reverse::load_receipt(&slot)?;
            if normal.is_some() && reverse.is_some() {
                return Err(CONFLICT.into());
            }
            let status = if let Some(j) = normal {
                receipt(Some(&j), &j.state, "Đã lưu bản gốc AirLift.")
            } else if let Some(j) = reverse {
                reverse::report(&j)
            } else {
                return Ok(None);
            };
            if status["state"] != "pending" && status["state"] != "applied" {
                return Ok(None);
            }
            Ok(Some(
                json!({"id":format!("airlift-{id}"),"app":row.app,"patch_scope":row.scope,"status":status,"updated_at":row.updated,"can_restore":true}),
            ))
        })();
        match result {
            Ok(Some(v)) => {
                let bytes = serde_json::to_vec(&v).map_err(|_| DISK)?.len();
                if rows.len() >= 128 || bytes > 8 * 1024 * 1024 - output_bytes {
                    invalid += 1;
                    break;
                }
                output_bytes += bytes;
                rows.push(v)
            }
            Ok(None) => {}
            Err(_) => invalid += 1,
        }
    }
    rows.sort_by(|a, b| {
        b["updated_at"]
            .as_u64()
            .cmp(&a["updated_at"].as_u64())
            .then_with(|| a["id"].as_str().cmp(&b["id"].as_str()))
    });
    Ok(
        json!({"patches":rows,"notice":(invalid>0).then_some("Một số biên nhận AirLift không đọc được; bản sao được giữ nguyên.")}),
    )
}

#[cfg(test)]
mod saved_target_tests {
    use super::*;
    fn app(path: &str) -> Value {
        json!({"bundle_id":"fixture.app","name":"Fixture","data_path":path,"target_id":format!("path:{path}")})
    }
    #[test]
    fn active_receipt_retains_exact_original_target_when_app_reinstalled() {
        let root = tempfile::tempdir().unwrap();
        let pairing = root.path().join("pairing.plist");
        let first = "/var/mobile/Containers/Data/Application/00000000-0000-0000-0000-000000000001";
        let second = "/var/mobile/Containers/Data/Application/00000000-0000-0000-0000-000000000002";
        remember_target(&pairing, "device-test", "fixture.app", "data", app(first)).unwrap();
        let id = slot_id("device-test", "fixture.app", "data");
        let slot = root.path().join(".cc365-patch-v1").join(&id);
        fs::create_dir_all(&slot).unwrap();
        let j = Journal {
            identity: "fixture".into(),
            token: token(),
            state: "pending".into(),
            armed: 0,
            skipped: 0,
            omitted_items: vec![],
            entries: vec![],
        };
        save(&slot, &j).unwrap();
        remember_target(&pairing, "device-test", "fixture.app", "data", app(second)).unwrap();
        let page = history(&pairing).unwrap();
        assert_eq!(page["patches"].as_array().unwrap().len(), 1);
        assert_eq!(page["patches"][0]["app"]["data_path"], first);
        assert!(!pairing.exists());
    }
    #[test]
    fn history_refuses_symlink_receipt_and_preserves_all_backup_bytes() {
        let root = tempfile::tempdir().unwrap();
        let pairing = root.path().join("pairing.plist");
        let app =
            app("/var/mobile/Containers/Data/Application/00000000-0000-0000-0000-000000000001");
        remember_target(&pairing, "device-test", "fixture.app", "data", app).unwrap();
        let id = slot_id("device-test", "fixture.app", "data");
        let slot = root.path().join(".cc365-patch-v1").join(&id);
        fs::create_dir_all(&slot).unwrap();
        let external = root.path().join("external.json");
        fs::write(&external, b"retained bytes").unwrap();
        std::os::unix::fs::symlink(&external, slot.join("journal.json")).unwrap();
        let page = history(&pairing).unwrap();
        assert_eq!(page["patches"], json!([]));
        assert!(!page["notice"].is_null());
        assert_eq!(fs::read(&external).unwrap(), b"retained bytes");
        assert!(slot.join("journal.json").is_symlink());
    }
}

#[cfg(test)]
mod input_boundary_tests {
    use super::*;
    #[test]
    fn data_scope_cannot_expand_to_preferences_or_ambiguous_destination_ancestors() {
        let root = tempfile::tempdir().unwrap();
        let parent = root
            .path()
            .join("CC365-Files/00000000-0000-0000-0000-000000000001");
        fs::create_dir_all(&parent).unwrap();
        let local = parent.join("source");
        fs::write(&local, b"fixture").unwrap();
        let items = |paths: &[&str]| {
            paths
                .iter()
                .map(|p| PatchItem {
                    relative_path: (*p).into(),
                    local_path: local.clone(),
                })
                .collect::<Vec<_>>()
        };
        assert!(valid_request(
            "apply",
            "fixture.app",
            "data",
            None,
            &items(&["Documents/a", "Library/Caches/b"]),
            root.path()
        ));
        for paths in [
            &["Library/Preferences/a"][..],
            &["Documents/a", "Documents/a/b"],
            &["Documents/A/b", "Documents/a"],
            &["Documents/a", "Documents/A"],
        ] {
            assert!(!valid_request(
                "apply",
                "fixture.app",
                "data",
                None,
                &items(paths),
                root.path()
            ));
        }
    }
}

#[cfg(test)]
mod saved_metadata_tests {
    use super::*;
    #[test]
    fn malformed_saved_app_fields_cannot_poison_the_whole_history_response() {
        let original = json!({"bundle_id":"fixture.app","name":"Fixture","data_path":"/var/mobile/Containers/Data/Application/00000000-0000-0000-0000-000000000001","target_id":"path:/var/mobile/Containers/Data/Application/00000000-0000-0000-0000-000000000001"});
        let mut row = SavedTarget {
            device: "device-test".into(),
            bundle: "fixture.app".into(),
            scope: "data".into(),
            app: original.clone(),
            updated: 0,
        };
        assert!(valid_saved_app(&row));
        for (key, bad) in [
            ("name", json!(32)),
            ("bundle_id", json!("other.app")),
            ("data_path", json!("/var/mobile/Media")),
            ("target_id", json!(23)),
            ("target_id", json!("path:/wrong")),
            ("file_sharing_enabled", json!("yes")),
        ] {
            row.app = original.clone();
            row.app[key] = bad;
            assert!(!valid_saved_app(&row), "{key}");
        }
        row.app = Value::Null;
        assert!(!valid_saved_app(&row));
    }
}
