use super::*;
use idevice::afc::AfcClient;

const LANES: usize = 6;

fn stage_width(jobs: &[Upload]) -> usize {
    let bytes: u64 = jobs.iter().map(|j| j.replacement.len).sum();
    let max = if jobs.len() >= 8 && bytes <= jobs.len() as u64 * 1024 * 1024 {
        LANES
    } else {
        3
    };
    jobs.len().min(max)
}

struct Upload {
    index: usize,
    name: String,
    local: PathBuf,
    media: String,
    original_witness: Option<String>,
    replacement: Stamp,
}

fn distribute(jobs: Vec<Upload>, stream_count: usize) -> [Vec<Upload>; LANES] {
    let mut jobs = jobs;
    jobs.sort_by_key(|job| std::cmp::Reverse(job.replacement.len));
    let mut lanes: [Vec<Upload>; LANES] = Default::default();
    let mut loads = [0u64; LANES];
    for job in jobs {
        let least = (0..stream_count).min_by_key(|&lane| loads[lane]).unwrap();
        loads[least] += job.replacement.len.max(64 * 1024);
        lanes[least].push(job);
    }
    lanes
}

#[derive(Debug)]
enum UploadResult {
    Staged(usize, String),
    Refused(usize, String),
}

pub(super) async fn upload_compared_file(
    client: &mut AfcClient,
    ctl: &SyncControl,
    stage: &str,
    source: &Path,
    stamp: &Stamp,
) -> Result<String> {
    upload_verified(client, ctl, stage, source, stamp, None).await
}

async fn upload_verified(
    client: &mut AfcClient,
    ctl: &SyncControl,
    stage: &str,
    source: &Path,
    stamp: &Stamp,
    expected: Option<&str>,
) -> Result<String> {
    let uploaded = io::upload_with_witness(client, ctl, stage, source, stamp).await?;
    let native = uploaded.filter(|_| expected.is_none_or(|w| w.starts_with("sha1:")));
    let observed = match native {
        Some(witness) => witness,
        None => PatchLink::reverse_verified_stage_witness(client, stage, expected)
            .await?
            .ok_or(UNCERTAIN)?,
    };
    let digest = io::snapshot(client, ctl, stage, std::io::sink(), stamp.len).await?;
    if digest.as_ref() != Some(stamp) || witness_size(&observed)? != stamp.len {
        return Err(CONFLICT.to_string());
    }
    if observed.starts_with("sha1:") {
        if stamp.sha1_witness() != observed {
            return Err(CONFLICT.to_string());
        }
    } else if PatchLink::reverse_verified_stage_witness(client, stage, Some(&observed))
        .await?
        .as_ref()
        != Some(&observed)
    {
        return Err(CONFLICT.to_string());
    }
    Ok(observed)
}

async fn upload_lane(
    client: Option<&mut AfcClient>,
    ctl: &SyncControl,
    jobs: Vec<Upload>,
    progress: &impl Fn(usize),
) -> Result<Vec<UploadResult>> {
    let mut verified = Vec::with_capacity(jobs.len());
    if jobs.is_empty() {
        return Ok(verified);
    }
    let client = client.ok_or(UNCERTAIN)?;
    for job in jobs {
        progress(job.index);
        let result = upload_verified(
            client,
            ctl,
            &job.media,
            &job.local,
            &job.replacement,
            job.original_witness.as_deref(),
        )
        .await;
        match result {
            Ok(witness) => {
                verified.push(UploadResult::Staged(job.index, witness));
                ctl.log("AirLift reverse: Media stage verified.");
            }
            Err(reason)
                if reason == io::PERMISSION_DENIED
                    || PatchLink::is_local_patch_refusal(&reason) =>
            {
                let content = io::snapshot(client, ctl, &job.media, std::io::sink(), MAX_FILE)
                    .await
                    .map_err(|e| format!("{}\n{e}", job.name))?;
                if let Some(content) = content {
                    if content != job.replacement {
                        return Err(format!("{}\n{CONFLICT}", job.name));
                    }
                    io::remove(client, ctl, &job.media)
                        .await
                        .map_err(|e| format!("{}\n{e}", job.name))?;
                    if !io::missing(client, ctl, &job.media).await? {
                        return Err(UNCERTAIN.into());
                    }
                }
                verified.push(UploadResult::Refused(job.index, reason));
            }
            Err(error) => return Err(format!("{}\n{error}", job.name)),
        }
    }
    Ok(verified)
}

impl DeviceSession {
    pub(super) async fn stage_reverse_batch(
        &mut self,
        link: &mut PatchLink,
        slot: &Path,
        batch: &mut Batch,
        indices: &[usize],
        defer_opaque: bool,
    ) -> Result<()> {
        let mut probed: HashSet<String> = batch
            .items
            .iter()
            .filter(|row| {
                matches!(row.original_witness.as_str(), "opaque" | "missing")
                    && matches!(row.phase, Phase::Installed | Phase::Skipped)
            })
            .filter_map(|row| {
                row.rel
                    .rsplit_once('/')
                    .map(|(parent, _)| parent.to_owned())
            })
            .collect();
        let mut unavailable_parents = std::collections::HashMap::<String, String>::new();
        let mut jobs = Vec::with_capacity(indices.len());
        for &i in indices {
            let row = &batch.items[i];
            link.select_reverse_doc(&row.rel, &row.key)?;
            if row.phase != Phase::Waiting {
                return Err(UNCERTAIN.into());
            }
            let opaque = matches!(row.original_witness.as_str(), "opaque" | "missing");
            let parent = row.rel.rsplit_once('/').ok_or(INVALID)?.0.to_owned();
            let stage = link.reverse_stage_path()?;
            if !io::missing(link.reverse_media_afc()?, &self.control, &stage).await? {
                return Err(CONFLICT.into());
            }
            if opaque && !probed.contains(&parent) {
                let reason = match unavailable_parents.get(&parent) {
                    Some(reason) => Some(reason.clone()),
                    None => link.reverse_review_parent().await?,
                };
                if let Some(reason) = reason {
                    unavailable_parents.insert(parent, reason.clone());
                    omit_row(slot, batch, i, &reason)?;
                    report_progress(&self.control, "omitted", batch, true, i);
                    continue;
                }
            }
            if opaque && probed.insert(parent) {
                report_progress(&self.control, "staging", batch, true, i);
                link.reverse_probe_vacant().await?;
                batch.items[i].phase = Phase::Probing;
                persist_row(slot, batch, i)?;
                self.reverse_parent_probe(link, false).await?;
                batch.items[i].phase = Phase::Waiting;
                persist_row(slot, batch, i)?;
            }
            let row = &batch.items[i];
            if defer_opaque && row.original_witness == "opaque" {
                continue;
            }
            jobs.push(Upload {
                index: i,
                name: row.rel.clone(),
                local: artifact(slot, i, false),
                media: stage,
                original_witness: (!opaque).then(|| row.original_witness.clone()),
                replacement: row.replacement.clone(),
            });
        }
        if jobs.is_empty() {
            return Ok(());
        }
        for job in &jobs {
            batch.items[job.index].phase = Phase::Staging;
        }
        persist(slot, batch)?;
        let extra = stage_width(&jobs).saturating_sub(1);
        let mut workers = if extra > 0 {
            self.reverse_media_workers(extra).await?
        } else {
            Vec::new()
        };
        let stream_count = 1 + workers.len();
        if workers.len() < extra {
            self.control
                .check()
                .map_err(|_| "Đã dừng chuẩn bị patch.")?;
            if !io::missing(link.reverse_media_afc()?, &self.control, &jobs[0].media).await? {
                return Err(CONFLICT.into());
            }
        }
        self.control.log(&format!(
            "AirLift reverse: staging {} file(s) on {stream_count} Media stream(s).",
            jobs.len()
        ));
        let lanes = distribute(jobs, stream_count);
        let ctl = self.control.clone();
        let progress = |index| report_progress(&ctl, "staging", batch, true, index);
        let clients = std::iter::once(link.reverse_media_afc()?).chain(workers.iter_mut());
        let tasks = clients
            .zip(lanes)
            .map(|(client, jobs)| upload_lane(Some(client), &ctl, jobs, &progress));
        let completed = futures_util::future::join_all(tasks).await;
        for lane in completed {
            for result in lane? {
                match result {
                    UploadResult::Staged(index, witness) => {
                        batch.items[index].replacement_witness = Some(witness);
                        batch.items[index].phase = Phase::Staged;
                    }
                    UploadResult::Refused(index, reason) => {
                        batch.items[index].phase = Phase::Settled;
                        omit_row(slot, batch, index, &reason)?;
                        report_progress(&ctl, "omitted", batch, true, index);
                    }
                }
            }
        }
        persist(slot, batch)
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[tokio::test]
    async fn staging_skips_only_reconciled_object_refusals_and_keeps_other_bytes() {
        let device = tempfile::tempdir().unwrap();
        let local = tempfile::tempdir().unwrap();
        let source = local.path().join("payload");
        std::fs::write(&source, b"replacement").unwrap();
        let stamp = io::local_copy(&b"replacement"[..], std::io::sink()).unwrap();
        let job = |index: usize, file: &str| Upload {
            index,
            name: format!("Documents/{file}"),
            local: source.clone(),
            media: format!("/{file}"),
            original_witness: None,
            replacement: stamp.clone(),
        };
        let mut afc = crate::device::patch::tests::afc(device.path().into());
        let ctl = crate::device::patch::tests::control();
        let events = std::cell::RefCell::new(Vec::new());
        let results = upload_lane(
            Some(&mut afc),
            &ctl,
            vec![
                job(0, "denied.bin"),
                job(1, "stage-hash-denied.bin"),
                job(2, "good.bin"),
            ],
            &|i| events.borrow_mut().push(i),
        )
        .await
        .unwrap();
        assert!(matches!(
            results.as_slice(),
            [
                UploadResult::Refused(0, _),
                UploadResult::Refused(1, _),
                UploadResult::Staged(2, _)
            ]
        ));
        assert_eq!(*events.borrow(), [0, 1, 2]);
        assert!(!device.path().join("denied.bin").exists());
        assert!(!device.path().join("stage-hash-denied.bin").exists());
        assert_eq!(
            std::fs::read(device.path().join("good.bin")).unwrap(),
            b"replacement"
        );

        for (name, retained) in [
            ("stage-changed.bin", &b"foreign"[..]),
            ("stage-offline.bin", &b"replacement"[..]),
        ] {
            let result = upload_lane(
                Some(&mut afc),
                &ctl,
                vec![job(0, name), job(1, "next.bin")],
                &|_| {},
            )
            .await;
            assert!(result.is_err(), "{name}");
            assert_eq!(std::fs::read(device.path().join(name)).unwrap(), retained);
            assert!(!device.path().join("next.bin").exists());
        }
    }

    #[test]
    fn reverse_parallel_stage_assigns_every_owned_slot_once_across_available_lanes() {
        let template = io::local_copy(&b"x"[..], std::io::sink()).unwrap();
        let jobs = || {
            (0..16)
                .map(|i| Upload {
                    index: i,
                    name: format!("Documents/asset{i}"),
                    local: PathBuf::from(format!("source{i}")),
                    media: format!("/cc365-put-{i:032x}"),
                    original_witness: None,
                    replacement: template.clone(),
                })
                .collect()
        };
        for (streams, expected) in [
            (1, [16, 0, 0, 0, 0, 0]),
            (2, [8, 8, 0, 0, 0, 0]),
            (3, [6, 5, 5, 0, 0, 0]),
            (6, [3, 3, 3, 3, 2, 2]),
        ] {
            let lanes = distribute(jobs(), streams);
            assert_eq!(lanes.each_ref().map(|lane| lane.len()), expected);
            let mut ids: Vec<_> = lanes.into_iter().flatten().map(|j| j.index).collect();
            ids.sort_unstable();
            assert_eq!(ids, (0..16).collect::<Vec<_>>());
        }
        assert_eq!(
            template.sha1_witness(),
            "sha1:11f6ad8ec52a2984abaafd7c3b516503785c2072:1"
        );
    }
}
