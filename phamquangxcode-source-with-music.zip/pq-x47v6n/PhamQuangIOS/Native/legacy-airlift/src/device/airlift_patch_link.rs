use super::*;
use sha2::{Digest, Sha256};
use std::path::PathBuf;
use tokio::io::{AsyncReadExt, AsyncWriteExt};

const BUNDLE_PARENT: &str = "/var/containers/Bundle/Application/";
const DATA_PARENT: &str = "/var/mobile/Containers/Data/Application/";
const ACCESS: &str = "iOS không cho AirLift truy cập thư mục của ứng dụng đã chọn.";
const CLOSED: &str = "Phiên AirLift cần được khôi phục. Mở lại Patch để tiếp tục dọn phiên.";
const APP_MISSING: &str = "Không tìm thấy ứng dụng đã chọn hoặc vị trí cài đặt đã thay đổi.";

#[derive(Serialize)]
pub(crate) struct PatchApp {
    pub(crate) bundle_id: String,
    pub(crate) name: String,
    pub(crate) bundle_path: String,
    pub(crate) data_path: Option<String>,
    pub(crate) file_sharing_enabled: Option<bool>,
    #[serde(skip)]
    executable: String,
    #[serde(skip)]
    version: String,
}

#[derive(Debug, PartialEq)]
pub(crate) enum ReversePreflight {
    Ready(String),
    Unavailable(String),
}

#[derive(Debug, PartialEq)]
pub(crate) enum ScanFailure {
    PreparationStopped,
    Failed(String),
}
impl From<String> for ScanFailure {
    fn from(error: String) -> Self {
        Self::Failed(error)
    }
}
impl ScanFailure {
    pub(crate) fn reason(self, local_error: Option<String>) -> String {
        match self {
            Self::PreparationStopped => {
                local_error.unwrap_or_else(|| "Đã dừng chuẩn bị patch.".into())
            }
            Self::Failed(error) => error,
        }
    }
}

pub(crate) const MAX_GROUP_HANDOFFS: usize = 8;

#[derive(Debug, PartialEq, Eq)]
pub(crate) enum GroupDelivery {
    Complete,
    Prefix(usize),
    Individual,
}

pub(crate) struct PatchLink {
    pub(crate) afc: AfcClient,
    media: Option<AfcClient>,
    channel: Option<airlift_wire::BooksSession>,
    pub(crate) io_prefix: Option<String>,
    pub(crate) transport: &'static str,
    pub(crate) alias: String,
    pub(crate) absolute_root: String,
    pub(crate) identity: String,
    pub(crate) executable: Option<String>,
    anchor_path: String,
    anchor_stamp: Option<(String, String)>,
    parent: String,
    pub(crate) link_target: String,
    reverse_docs: Vec<(String, String)>,
    reverse_active: usize,
    journal: PathBuf,
    token: String,
    gate: Option<tokio::sync::MutexGuard<'static, ()>>,
}

fn valid_component(s: &str) -> bool {
    !s.is_empty()
        && s.len() <= 255
        && !matches!(s, "." | "..")
        && !s.contains(['/', '\\'])
        && !s.chars().any(char::is_control)
}
fn uuid(s: &str) -> bool {
    s.len() == 36
        && s.bytes().enumerate().all(|(i, b)| match i {
            8 | 13 | 18 | 23 => b == b'-',
            _ => b.is_ascii_hexdigit(),
        })
}
pub(super) fn valid_parent(s: &str) -> bool {
    [BUNDLE_PARENT, DATA_PARENT]
        .iter()
        .any(|prefix| s.strip_prefix(prefix).is_some_and(uuid))
}
fn canonical_device_path(s: &str) -> &str {
    s.strip_prefix("/private/var/")
        .map_or(s, |_| &s["/private".len()..])
}
fn bundle_id(s: &str) -> bool {
    s.len() <= 255
        && s.split('.').all(|component| {
            !component.is_empty()
                && component
                    .bytes()
                    .all(|c| c.is_ascii_alphanumeric() || c == b'-')
        })
}

impl PatchApp {
    fn from_record(key: &str, row: &Dictionary) -> Option<Self> {
        let field = |k: &str| row.get(k).and_then(Plist::as_string);
        if !bundle_id(key)
            || field("CFBundleIdentifier") != Some(key)
            || field("ApplicationType").is_some_and(|t| t != "User")
        {
            return None;
        }
        let bundle_path = canonical_device_path(field("Path")?);
        let (container, leaf) = bundle_path.rsplit_once('/')?;
        if !container.strip_prefix(BUNDLE_PARENT).is_some_and(uuid)
            || !valid_component(leaf)
            || !leaf.ends_with(".app")
            || leaf == ".app"
        {
            return None;
        }
        let executable = field("CFBundleExecutable").filter(|s| valid_component(s))?;
        let data_path = field("Container")
            .map(canonical_device_path)
            .filter(|p| p.strip_prefix(DATA_PARENT).is_some_and(uuid))
            .map(str::to_owned);
        Some(Self {
            bundle_id: key.to_string(),
            name: field("CFBundleDisplayName")
                .or_else(|| field("CFBundleName"))
                .filter(|n| !n.is_empty() && n.len() <= 1024)
                .unwrap_or(key)
                .to_string(),
            bundle_path: bundle_path.to_string(),
            data_path,
            file_sharing_enabled: row.get("UIFileSharingEnabled").and_then(Plist::as_boolean),
            executable: executable.to_string(),
            version: field("CFBundleVersion").unwrap_or("").to_string(),
        })
    }
}

impl DeviceSession {
    pub(crate) async fn lookup_patch_apps(
        &mut self,
        wanted: Option<&str>,
    ) -> Result<Vec<PatchApp>> {
        const ERROR: &str = "Không đọc được danh sách ứng dụng từ iPhone.";
        let table = super::super::native(
            &self.control.clone(),
            Duration::from_secs(30),
            "Application lookup",
            async {
                let mut stream = self.service("com.apple.mobile.installation_proxy").await?;
                let mut options = Dictionary::new();
                options.insert("ApplicationType".into(), "User".into());
                options.insert(
                    "ReturnAttributes".into(),
                    Plist::Array(
                        [
                            "CFBundleIdentifier",
                            "CFBundleDisplayName",
                            "CFBundleName",
                            "Path",
                            "Container",
                            "ApplicationType",
                            "CFBundleExecutable",
                            "CFBundleVersion",
                            "UIFileSharingEnabled",
                        ]
                        .iter()
                        .map(|s| (*s).into())
                        .collect(),
                    ),
                );
                if let Some(id) = wanted {
                    options.insert("BundleIDs".into(), Plist::Array(vec![id.into()]));
                }
                let mut request = Dictionary::new();
                request.insert("Command".into(), "Lookup".into());
                request.insert("ClientOptions".into(), Plist::Dictionary(options));
                let mut encoded = Vec::new();
                Plist::Dictionary(request).to_writer_binary(&mut encoded)?;
                stream.write_u32(encoded.len() as u32).await?;
                stream.write_all(&encoded).await?;
                stream.flush().await?;
                let n = stream.read_u32().await? as usize;
                if !(1..=8 * 1024 * 1024).contains(&n) {
                    return Err(super::super::invalid("Invalid app lookup size"));
                }
                let mut body = vec![0; n];
                stream.read_exact(&mut body).await?;
                let mut response: Dictionary = plist::from_bytes(&body)?;
                response
                    .remove("LookupResult")
                    .and_then(Plist::into_dictionary)
                    .ok_or_else(|| super::super::invalid("No app lookup result"))
            },
        )
        .await
        .map_err(|_| ERROR)?;
        let mut apps: Vec<_> = table
            .iter()
            .filter(|(key, _)| wanted.is_none_or(|id| id == *key))
            .filter_map(|(key, row)| PatchApp::from_record(key, row.as_dictionary()?))
            .collect();
        apps.sort_by(|a, b| {
            a.name
                .to_lowercase()
                .cmp(&b.name.to_lowercase())
                .then_with(|| a.bundle_id.cmp(&b.bundle_id))
        });
        Ok(apps)
    }

    pub(crate) async fn patch_apps(&mut self) -> Result<Vec<PatchApp>> {
        self.lookup_patch_apps(None).await
    }

    pub(crate) async fn open_patch_link_with_slots(
        &mut self,
        bundle: &str,
        scope: &str,
        slots: usize,
        documents_only: bool,
    ) -> Result<PatchLink> {
        self.open_scoped_patch_link(bundle, scope, slots, documents_only, None, &[])
            .await
    }

    pub(crate) async fn open_container_cache_link(
        &mut self,
        bundle: &str,
        slots: usize,
    ) -> Result<Option<PatchLink>> {
        if slots > MAX_ITEMS || !bundle_id(bundle) {
            return Err(APP_MISSING.into());
        }
        let Ok(container) = self.patch_house_arrest(bundle, "VendContainer").await else {
            return Ok(None);
        };
        self.open_scoped_patch_link(bundle, "data", slots, false, Some(container), &[])
            .await
            .map(Some)
    }

    async fn open_scoped_patch_link(
        &mut self,
        bundle: &str,
        scope: &str,
        slots: usize,
        documents_only: bool,
        container: Option<AfcClient>,
        reverse_docs: &[(String, String)],
    ) -> Result<PatchLink> {
        if slots > MAX_ITEMS || !bundle_id(bundle) || !matches!(scope, "bundle" | "data") {
            return Err(APP_MISSING.into());
        }
        let gate = AIRLIFT_LOCK.try_lock().map_err(|_| BUSY)?;
        let (device, supported) = self.airlift_device().await?;
        let journal = self
            .pairing_path
            .with_file_name(format!(".cc365-airlift-{device}.json"));
        if Trial::load(&journal)?.is_some() {
            let r = self.run_airlift_check(true).await?;
            if r["cleanupComplete"] != true {
                return Err(CLOSED.into());
            }
        }
        if !supported {
            return Err("Patch AirLift chỉ được bật cho iOS 18.7.2–18.8.x.".into());
        }
        let app = self
            .lookup_patch_apps(Some(bundle))
            .await?
            .pop()
            .ok_or(APP_MISSING)?;
        let (root, parent, leaf, executable) = match scope {
            "bundle" => {
                let (p, l) = app.bundle_path.rsplit_once('/').ok_or(APP_MISSING)?;
                (
                    app.bundle_path.clone(),
                    p.to_string(),
                    Some(l.to_string()),
                    Some(app.executable),
                )
            }
            "data" => {
                let path = app.data_path.ok_or(ACCESS)?;
                (path.clone(), path, None, None)
            }
            _ => return Err(APP_MISSING.into()),
        };
        let cache_container = container.is_some();
        let vended = if scope == "data" && documents_only {
            self.patch_house_arrest(bundle, "VendDocuments").await.ok()
        } else {
            container
        };
        let mut c = io(self.afc()).await?;
        let mut t = Trial::new(preflight(&mut c).await?);
        if !reverse_docs.is_empty() {
            if !documents_only || scope != "data" || !valid_reverse_plan(&root, reverse_docs) {
                return Err(CONFLICT.into());
            }
            t.reverse_docs = reverse_docs.to_vec();
            t.reverse_redelivery = true;
        }
        t.patch_parent = Some(parent.clone());
        t.patch_slots = if vended.is_some() || leaf.is_some() {
            slots
        } else {
            0
        };
        for p in [format!("/{}", t.link()), format!("/{}", t.source())] {
            if stat(&mut c, &p).await?.is_some() {
                return Err(CONFLICT.into());
            }
        }
        t.save(&journal)?;
        let start = if vended.is_some() && reverse_docs.is_empty() {
            if slots > 0 {
                prepare_archive(self, &mut c, &mut t, &journal)
                    .await
                    .map(|()| None)
            } else {
                Ok(None)
            }
        } else {
            stage(self, &mut c, &mut t, &journal).await
        };
        let pointer = format!("/{}", t.link());
        let identity = {
            let mut hash = Sha256::new();
            for v in [
                &device,
                bundle,
                &app.bundle_path,
                &app.version,
                scope,
                &root,
            ] {
                hash.update(v.as_bytes());
                hash.update([0]);
            }
            format!("{:x}", hash.finalize())
        };
        let scoped_docs = vended.is_some() && !cache_container;
        let (afc, media) = match vended {
            Some(afc) => (afc, Some(c)),
            None => (c, None),
        };
        let mut link = PatchLink {
            afc,
            media,
            channel: None,
            io_prefix: scoped_docs.then(|| "Documents/".to_owned()),
            transport: if cache_container {
                "airlift_cache_container"
            } else if scoped_docs {
                "airlift_documents"
            } else if leaf.is_some() {
                "airlift_bundle"
            } else {
                "airlift"
            },
            alias: if cache_container {
                "/".to_owned()
            } else if scoped_docs {
                "/Documents".to_owned()
            } else {
                leaf.map_or_else(|| pointer.clone(), |l| format!("{pointer}/{l}"))
            },
            absolute_root: root,
            identity,
            executable,
            anchor_path: String::new(),
            anchor_stamp: None,
            parent: pointer,
            link_target: format!("../../..{parent}"),
            reverse_docs: reverse_docs.to_vec(),
            reverse_active: 0,
            journal,
            token: t.token,
            gate: Some(gate),
        };
        let result = match start {
            Ok(channel) => {
                link.channel = channel;
                match link.bind_identity(bundle).await {
                    Ok(()) => link.check_reverse_manifest(),
                    err => err,
                }
            }
            Err(e) => Err(e),
        };
        if let Err(err) = result {
            return Err(match self.close_patch_link(link).await {
                Ok(()) => err,
                Err(_) => format!("{err} {CLOSED}"),
            });
        }
        Ok(link)
    }

    async fn patch_house_arrest(&mut self, bundle: &str, command: &str) -> Result<AfcClient> {
        self.patch_house_arrest_reader(bundle, command)
            .await?
            .ok_or(ACCESS.into())
    }
    pub(crate) async fn patch_house_arrest_reader(
        &mut self,
        bundle: &str,
        command: &str,
    ) -> Result<Option<AfcClient>> {
        super::super::native(
            &self.control.clone(),
            Duration::from_secs(20),
            "Open selected application files",
            async {
                let mut stream = self.service("com.apple.mobile.house_arrest").await?;
                let mut req = Dictionary::new();
                req.insert("Command".into(), command.into());
                req.insert("Identifier".into(), bundle.into());
                let mut body = Vec::new();
                Plist::Dictionary(req).to_writer_binary(&mut body)?;
                stream.write_u32(body.len() as u32).await?;
                stream.write_all(&body).await?;
                stream.flush().await?;
                let n = stream.read_u32().await? as usize;
                if !(1..=256 * 1024).contains(&n) {
                    return Err(super::super::invalid("Invalid House Arrest response"));
                }
                let mut response = vec![0; n];
                stream.read_exact(&mut response).await?;
                let d: Dictionary = plist::from_bytes(&response)?;
                if matches!(
                    d.get("Error").and_then(Plist::as_string),
                    Some(
                        "Busy" | "DeviceBusy" | "ServiceLimit" | "NoResources" | "PermissionDenied"
                    )
                ) {
                    return Ok(None);
                }
                if d.contains_key("Error")
                    || d.get("Status").and_then(Plist::as_string) != Some("Complete")
                {
                    return Err(super::super::invalid("File sharing not granted"));
                }
                Ok(Some(AfcClient::new(idevice::Idevice::new(
                    super::super::bounded_afc::BoundedAfc::wrap(stream),
                    "Viet99",
                ))))
            },
        )
        .await
        .map_err(|_| ACCESS.into())
    }

    pub(crate) async fn deliver_patch_stages(
        &mut self,
        link: &mut PatchLink,
        stages: &[(String, String)],
    ) -> Result<()> {
        if stages.is_empty() {
            return Ok(());
        }
        link.verify().await?;
        let mut saved = Trial::load(&link.journal)?.ok_or(JOURNAL_ERROR)?;
        if saved.token != link.token || stages.len() > saved.patch_slots {
            return Err(CONFLICT.into());
        }
        let scope = if link.executable.is_some() {
            let (container, leaf) = link.absolute_root.rsplit_once('/').ok_or(ACCESS)?;
            if saved.patch_parent.as_deref() != Some(container)
                || link.alias != format!("{}/{leaf}", link.parent)
            {
                return Err(CONFLICT.into());
            }
            airlift_wire::DeliveryScope::Bundle(leaf.to_owned())
        } else if link.transport == "airlift_cache_container" && link.media.is_some() {
            airlift_wire::DeliveryScope::Cache
        } else if link.io_prefix.as_deref() == Some("Documents/") && link.media.is_some() {
            airlift_wire::DeliveryScope::Documents
        } else {
            return Err(ACCESS.into());
        };
        let mut moves = Vec::new();
        let mut checks = Vec::new();
        let mut seen = std::collections::HashSet::new();
        for (destination, media_file) in stages {
            let from = format!("../..{media_file}");
            let (to, dest) = match &scope {
                airlift_wire::DeliveryScope::Documents | airlift_wire::DeliveryScope::Cache => (
                    format!("{}/{destination}", link.parent.trim_start_matches('/')),
                    format!("/{destination}"),
                ),
                airlift_wire::DeliveryScope::Bundle(_) => {
                    let path = format!("{}/{destination}", link.alias);
                    (path.trim_start_matches('/').to_owned(), path)
                }
            };
            if !airlift_wire::valid_delivery(&link.token, &scope, &from, &to)
                || !seen.insert(media_file)
            {
                return Err(CONFLICT.into());
            }
            if stat(&mut link.afc, &dest).await?.is_some() {
                return Err(CONFLICT.into());
            }
            let info = stat(link.media_afc().ok_or(ACCESS)?, media_file)
                .await?
                .ok_or(CONFLICT)?;
            if kind(&info) != "S_IFREG" {
                return Err(CONFLICT.into());
            }
            let size = info
                .get("st_size")
                .and_then(|s| s.parse::<u64>().ok())
                .ok_or(CONFLICT)?;
            moves.push((from, to));
            checks.push((dest, size));
        }
        if link.media.is_some() {
            let media = link.media.as_mut().ok_or(ACCESS)?;
            let base = format!("/{}", saved.source());
            let jump = format!("{base}/a/b/c/jump");
            if !known_parents(media, &jump).await?
                || !stat(media, &jump)
                    .await?
                    .as_ref()
                    .is_some_and(|m| is_link_to(m, &link.link_target))
                || read(media, &format!("{base}/payload")).await?.as_deref()
                    != Some(&saved.challenge)
                || stat(media, &link.parent).await?.is_some()
            {
                return Err(CONFLICT.into());
            }
            airlift_books::snapshot(media, &link.journal, &saved).await?;
            link.channel = start_books(self, media, &mut saved, &link.journal).await?;
            if link.channel.is_none() {
                return Err(ACCESS.into());
            }
            link.verify().await?;
        }
        let channel = link.channel.as_mut().ok_or(ACCESS)?;
        channel.validate_delivery(&link.token, &scope, &moves)?;
        const BATCH: usize = 32;
        const SEND_WINDOW: Duration = Duration::from_secs(30);
        for (batch, destinations) in moves.chunks(BATCH).zip(checks.chunks(BATCH)) {
            saved.matched = false;
            saved.sync_started = Some(now().saturating_add(SEND_WINDOW.as_secs()));
            saved.save(&link.journal)?;
            tokio::time::timeout(SEND_WINDOW, channel.deliver(&link.token, &scope, batch))
                .await
                .map_err(|_| "Hết thời gian gửi nhóm tệp qua AirLift.")??;
            saved.sync_started = Some(now());
            saved.save(&link.journal)?;
            let deadline = tokio::time::Instant::now() + Duration::from_secs(45);
            for (dest, expected) in destinations {
                loop {
                    self.control.check().map_err(|_| CLOSED)?;
                    if let Some(info) = stat(&mut link.afc, dest).await? {
                        if kind(&info) != "S_IFREG" {
                            return Err(CONFLICT.into());
                        }
                        if info.get("st_size").and_then(|s| s.parse::<u64>().ok())
                            == Some(*expected)
                        {
                            break;
                        }
                    }
                    if tokio::time::Instant::now() >= deadline {
                        return Err("iOS chưa giao đủ tệp AirLift đến vị trí đã chọn.".into());
                    }
                    tokio::time::sleep(Duration::from_millis(150)).await;
                }
            }
        }
        saved.matched = true;
        saved.save(&link.journal)
    }
    pub(crate) async fn close_patch_link(&mut self, link: PatchLink) -> Result<()> {
        let PatchLink {
            afc,
            journal,
            token,
            gate,
            channel,
            media,
            ..
        } = link;
        drop(channel);
        drop(media);
        drop(afc);
        let saved = Trial::load(&journal)?.ok_or(JOURNAL_ERROR)?;
        if saved.token != token || saved.patch_parent.is_none() {
            return Err(JOURNAL_ERROR.into());
        }
        let result = self.run_airlift_check(true).await?;
        drop(gate);
        if result["cleanupComplete"] == true {
            Ok(())
        } else {
            Err(CLOSED.into())
        }
    }
}

impl PatchLink {
    pub(crate) fn media_stage(&self, index: usize, restore: bool) -> String {
        format!(
            "/cl-src-{}/patch-{index}-{}",
            self.token,
            if restore { 'r' } else { 'a' }
        )
    }
    pub(crate) fn media_afc(&mut self) -> Option<&mut AfcClient> {
        if self.executable.is_some() {
            Some(&mut self.afc)
        } else {
            self.media.as_mut()
        }
    }
    #[cfg(test)]
    pub(crate) async fn fixture(afc: AfcClient) -> Self {
        Self {
            afc,
            media: None,
            channel: None,
            io_prefix: None,
            transport: "airlift",
            alias: "/link/Example.app".into(),
            absolute_root: "/fixture/Example.app".into(),
            identity: "test-app".into(),
            executable: Some("Example".into()),
            anchor_path: "/link/Example.app".into(),
            anchor_stamp: Some(("1".into(), "42".into())),
            parent: "/link".into(),
            link_target: "/fixture".into(),
            reverse_docs: Vec::new(),
            reverse_active: 0,
            journal: PathBuf::new(),
            token: String::new(),
            gate: None,
        }
    }
    #[cfg(test)]
    pub(super) async fn fixture_documents(afc: AfcClient, path: &str) -> Self {
        let mut link = Self::fixture(afc).await;
        link.executable = None;
        link.alias = "/link".into();
        link.absolute_root = format!("{DATA_PARENT}12345678-1234-1234-1234-123456789ABC");
        link.anchor_path = "/link/Documents".into();
        link.reverse_docs = vec![(path.to_owned(), "1".repeat(32))];
        link
    }
    async fn bind_identity(&mut self, bundle: &str) -> Result<()> {
        let anchor = if self.transport == "airlift_cache_container" {
            if !stat(&mut self.afc, "/Library")
                .await?
                .is_some_and(|m| kind(&m) == "S_IFDIR")
            {
                return Err(ACCESS.into());
            }
            "/Library/Caches".to_owned()
        } else if self.executable.is_some() || self.media.is_some() {
            self.alias.clone()
        } else {
            format!("{}/Documents", self.alias)
        };
        let metadata = stat(&mut self.afc, &anchor).await?.ok_or(ACCESS)?;
        if kind(&metadata) != "S_IFDIR" {
            return Err(ACCESS.into());
        }
        self.anchor_stamp = Some(anchor_stamp(&metadata)?);
        self.anchor_path = anchor;
        self.verify().await?;
        if self.media.is_some() {
            return Ok(());
        }
        let (name, key) = if self.executable.is_some() {
            ("Info.plist", "CFBundleIdentifier")
        } else {
            (
                ".com.apple.mobile_container_manager.metadata.plist",
                "MCMMetadataIdentifier",
            )
        };
        if let Ok(record) = read_identity(&mut self.afc, &format!("{}/{name}", self.alias)).await {
            if record.get(key).and_then(Plist::as_string) != Some(bundle) {
                return Err(ACCESS.into());
            }
            if let Some(executable) = &self.executable {
                if record.get("CFBundleExecutable").and_then(Plist::as_string)
                    != Some(executable.as_str())
                {
                    return Err(ACCESS.into());
                }
            }
        }
        Ok(())
    }

    pub(crate) async fn verify(&mut self) -> Result<()> {
        let root = stat(&mut self.afc, &self.anchor_path)
            .await?
            .ok_or(ACCESS)?;
        if kind(&root) != "S_IFDIR" || self.anchor_stamp.as_ref() != Some(&anchor_stamp(&root)?) {
            return Err(ACCESS.into());
        }
        let cache = self.transport == "airlift_cache_container" && self.media.is_some();
        if cache && !dir(&mut self.afc, "/Library").await? {
            return Err(ACCESS.into());
        }
        if self.media.is_some() && self.channel.is_none() {
            return Ok(());
        }
        let verify_reverse_docs = self.media.is_some() && !self.reverse_docs.is_empty();
        let namespaced = self
            .channel
            .as_ref()
            .is_some_and(|channel| channel.uses_reverse_namespace())
            && !self.reverse_docs.is_empty();
        let media = self.media.as_mut().unwrap_or(&mut self.afc);
        if namespaced && !dir(media, &format!("/cl-src-{}", self.token)).await? {
            return Err(ACCESS.into());
        }
        if !stat(media, &self.parent)
            .await?
            .as_ref()
            .is_some_and(|m| is_link_to(m, &self.link_target))
        {
            return Err(ACCESS.into());
        }
        if verify_reverse_docs {
            let remote_docs = stat(media, &format!("{}/Documents", self.parent))
                .await?
                .ok_or(ACCESS)?;
            if !same_cache_directory(&root, &remote_docs) {
                return Err(ACCESS.into());
            }
        }
        if cache {
            let library = format!("{}/Library", self.parent);
            if !dir(media, &library).await? {
                return Err(ACCESS.into());
            }
            let remote = stat(media, &format!("{library}/Caches"))
                .await?
                .ok_or(ACCESS)?;
            if !same_cache_directory(&root, &remote) {
                return Err(ACCESS.into());
            }
        }
        Ok(())
    }
}

#[path = "airlift_reverse.rs"]
mod reverse;
pub(super) use reverse::valid_reverse_plan;
pub(crate) use reverse::{MAX_REVERSE_PLAN_ITEMS, reverse_plan_fits};

fn same_cache_directory(vended: &Info, media: &Info) -> bool {
    if kind(vended) != "S_IFDIR" || kind(media) != "S_IFDIR" {
        return false;
    }
    let mut shared = false;
    for key in ["st_birthtime", "st_ino"] {
        let number = |m: &Info| m.get(key)?.parse::<u64>().ok().filter(|v| *v > 0);
        if let (Some(a), Some(b)) = (number(vended), number(media)) {
            if a != b {
                return false;
            }
            shared = true;
        }
    }
    shared
}

fn anchor_stamp(info: &Info) -> Result<(String, String)> {
    let birth = info.get("st_birthtime").cloned().unwrap_or_default();
    let inode = info.get("st_ino").cloned().unwrap_or_default();
    if birth.is_empty() && inode.is_empty() {
        return Err(ACCESS.into());
    }
    Ok((birth, inode))
}

async fn read_identity(c: &mut AfcClient, path: &str) -> Result<Dictionary> {
    let m = stat(c, path).await.map_err(|_| ACCESS)?.ok_or(ACCESS)?;
    let n = m
        .get("st_size")
        .and_then(|n| n.parse::<usize>().ok())
        .filter(|n| (1..=2 * 1024 * 1024).contains(n))
        .ok_or(ACCESS)?;
    if kind(&m) != "S_IFREG" {
        return Err(ACCESS.into());
    }
    let handle = io(open_handle(c, path, AfcFopenMode::RdOnly))
        .await
        .map_err(|_| ACCESS)?;
    let result: Result<Dictionary> = async {
        let mut buf = Vec::with_capacity(n);
        while buf.len() < n {
            let size = (n - buf.len()).min(16 * 1024) as u64;
            let args = [handle.to_le_bytes(), size.to_le_bytes()].concat();
            let block = io(c.send_op(AfcOpcode::Read, args, vec![])).await?.payload;
            if block.is_empty() || block.len() > size as usize {
                return Err(ACCESS.into());
            }
            buf.extend_from_slice(&block);
        }
        plist::from_bytes(&buf).map_err(|_| ACCESS.to_string())
    }
    .await;
    let close = io(close_handle(c, handle)).await;
    close.map_err(|_| ACCESS)?;
    result.map_err(|_| ACCESS.into())
}

pub(super) fn link_archive(parent: &str, challenge: &[u8; 32]) -> Result<Vec<u8>> {
    if !valid_parent(parent) {
        return Err(CONFLICT.into());
    }
    let mut document = Dictionary::new();
    document.insert("Version".into(), 2u64.into());
    let mut metadata = Vec::new();
    Plist::Dictionary(document)
        .to_writer_binary(&mut metadata)
        .map_err(|_| JOURNAL_ERROR)?;
    let mut packed = StoredArchive::default();
    packed.entry("META-INF/", 0o40755, &[]);
    packed.entry("META-INF/com.apple.ZipMetadata.plist", 0o100600, &metadata);
    for name in ["a/", "a/b/", "a/b/c/"] {
        packed.entry(name, 0o40755, &[]);
    }
    let mut mirror = String::new();
    for part in parent.trim_start_matches('/').split('/') {
        mirror.push_str(part);
        mirror.push('/');
        packed.entry(&mirror, 0o40755, &[]);
    }
    packed.entry(
        "a/b/c/jump",
        0o120777,
        format!("../../..{parent}").as_bytes(),
    );
    packed.entry("payload", 0o100600, challenge);
    Ok(packed.finish())
}

#[derive(Default)]
struct StoredArchive {
    local: Vec<u8>,
    central: Vec<u8>,
    entries: u16,
}
impl StoredArchive {
    fn entry(&mut self, name: &str, mode: u16, body: &[u8]) {
        let offset = self.local.len() as u32;
        let mut crc = flate2::Crc::new();
        crc.update(body);
        let mut shared = Vec::with_capacity(26);
        for v in [20u16, 0, 0, 0, 33] {
            shared.extend(v.to_le_bytes());
        }
        for v in [crc.sum(), body.len() as u32, body.len() as u32] {
            shared.extend(v.to_le_bytes());
        }
        for v in [name.len() as u16, 6] {
            shared.extend(v.to_le_bytes());
        }
        let mut name_extra = name.as_bytes().to_vec();
        name_extra.extend(0x5a53u16.to_le_bytes());
        name_extra.extend(2u16.to_le_bytes());
        name_extra.extend(mode.to_le_bytes());
        self.local.extend(0x04034b50u32.to_le_bytes());
        self.local.extend(&shared);
        self.local.extend(&name_extra);
        self.local.extend(body);
        self.central.extend(0x02014b50u32.to_le_bytes());
        self.central.extend(0x0314u16.to_le_bytes());
        self.central.extend(&shared);
        self.central.extend([0u8; 6]);
        self.central.extend((u32::from(mode) << 16).to_le_bytes());
        self.central.extend(offset.to_le_bytes());
        self.central.extend(name_extra);
        self.entries += 1;
    }
    fn finish(mut self) -> Vec<u8> {
        let start = self.local.len() as u32;
        let size = self.central.len() as u32;
        self.local.extend(self.central);
        self.local.extend(0x06054b50u32.to_le_bytes());
        for v in [0u16, 0, self.entries, self.entries] {
            self.local.extend(v.to_le_bytes());
        }
        self.local.extend(size.to_le_bytes());
        self.local.extend(start.to_le_bytes());
        self.local.extend(0u16.to_le_bytes());
        self.local
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    const ID: &str = "FFFFFFFF-0000-4C41-8ABC-000000000000";

    #[test]
    fn cache_verifiers_require_shared_nonzero_stable_metadata() {
        let stat = |birth: &str, inode: &str| {
            [
                ("st_ifmt", "S_IFDIR"),
                ("st_birthtime", birth),
                ("st_ino", inode),
            ]
            .into_iter()
            .map(|(k, v)| (k.to_owned(), v.to_owned()))
            .collect()
        };
        assert!(same_cache_directory(&stat("123", "9"), &stat("123", "")));
        assert!(same_cache_directory(&stat("", "9"), &stat("0", "9")));
        assert!(!same_cache_directory(&stat("123", "9"), &stat("123", "7")));
        assert!(!same_cache_directory(&stat("", "0"), &stat("0", "")));
        let mut link = stat("123", "9");
        link.insert("LinkTarget".into(), "/other".into());
        assert!(!same_cache_directory(&link, &stat("123", "9")));
    }

    #[test]
    fn validated_installation_paths_are_scoped_to_one_user_app() {
        let bundle = format!("{BUNDLE_PARENT}{ID}/Demo.app");
        let data = format!("{DATA_PARENT}{ID}");
        let doc: Dictionary = [
            ("CFBundleIdentifier", "com.example.Demo"),
            ("CFBundleExecutable", "Demo"),
            ("Path", bundle.as_str()),
            ("Container", data.as_str()),
        ]
        .into_iter()
        .map(|(k, v)| (k.to_string(), Plist::from(v)))
        .collect();
        let good = PatchApp::from_record("com.example.Demo", &doc).unwrap();
        assert_eq!(good.bundle_path, bundle);
        assert_eq!(good.data_path.as_deref(), Some(data.as_str()));
        assert!(serde_json::to_value(&good).unwrap()["file_sharing_enabled"].is_null());
        for flag in [false, true] {
            let mut row = doc.clone();
            row.insert("UIFileSharingEnabled".into(), Plist::Boolean(flag));
            let app = PatchApp::from_record("com.example.Demo", &row).unwrap();
            assert_eq!(
                serde_json::to_value(&app).unwrap()["file_sharing_enabled"],
                flag
            );
        }
        for bad in [
            "/Applications/Foo.app",
            "/private/var/mobile",
            "/System/Applications/Foo.app",
            "/var/containers/Bundle/Application/all/Foo.app",
        ] {
            let mut badrow = doc.clone();
            badrow.insert("Path".into(), bad.into());
            assert!(PatchApp::from_record("com.example.Demo", &badrow).is_none());
        }
        for path in [
            "/",
            BUNDLE_PARENT,
            DATA_PARENT,
            "/var/tmp",
            "/var/mobile/Containers/Data/Application/../Shared",
        ] {
            assert!(link_archive(path, &[3; 32]).is_err());
        }
    }

    #[test]
    fn link_archive_is_a_readable_posix_zip_with_a_unique_expected_link() {
        let parent = format!("{BUNDLE_PARENT}{ID}");
        let bytes = link_archive(&parent, &[7; 32]).unwrap();
        let directory = tempfile::tempdir().unwrap();
        let path = directory.path().join("trial.zip");
        fs::write(&path, bytes).unwrap();
        let status = std::process::Command::new("unzip")
            .args(["-tqq"])
            .arg(&path)
            .status()
            .unwrap();
        assert!(status.success());
        let read = std::process::Command::new("unzip")
            .arg("-p")
            .arg(path)
            .arg("a/b/c/jump")
            .output()
            .unwrap();
        assert!(read.status.success());
        assert_eq!(read.stdout, format!("../../..{parent}").as_bytes());
    }
}
