use super::*;
use idevice::{
    Idevice,
    afc::{MAGIC, opcode::AfcOpcode as Op},
};
use std::collections::BTreeMap;
use tokio::io::{AsyncReadExt, AsyncWriteExt};

#[derive(Clone, Debug, PartialEq, Eq)]
pub(super) enum Node {
    Dir,
    File(Vec<u8>),
    IdentifiedFile(Vec<u8>),
    Link(&'static str),
    Status(u64),
}
pub(super) type Tree = BTreeMap<String, Node>;

pub(super) struct MemoryAfc {
    tree: Tree,
    opened: Option<String>,
    sibling_probes: usize,
    leaf_checks: usize,
    removes: Vec<String>,
}
impl MemoryAfc {
    fn respond(&mut self, op: Op, body: &[u8]) -> (Op, Vec<u8>, Vec<u8>) {
        let path = || std::str::from_utf8(body).unwrap().trim_end_matches('\0');
        if matches!(op, Op::GetFileInfo) {
            let name = path();
            if name.contains("/cc365-absent-") {
                self.sibling_probes += 1;
            }
            if name.contains("/pack/file") {
                self.leaf_checks += 1;
            }
        }
        let status = |n: u64| (Op::Status, n.to_le_bytes().to_vec(), vec![]);
        let data = |bytes| (Op::Data, vec![], bytes);
        match op {
            Op::GetFileInfo => match self.tree.get(path()) {
                Some(Node::Dir) => {
                    data(b"st_ifmt\0S_IFDIR\0st_birthtime\x001\0st_ino\x0042\0".to_vec())
                }
                Some(Node::Status(error)) => status(*error),
                Some(Node::Link(target)) => {
                    data(format!("st_ifmt\0S_IFLNK\0LinkTarget\0{target}\0").into_bytes())
                }
                Some(Node::IdentifiedFile(bytes)) => data(format!("st_ifmt\0S_IFREG\0st_size\0{}\0st_ino\x00107\0st_birthtime\x00200\0st_mtime\x00300\0st_nlink\x001\0",bytes.len()).into_bytes()),
                Some(Node::File(bytes)) => {
                    data(format!("st_ifmt\0S_IFREG\0st_size\0{}\0", bytes.len()).into_bytes())
                }
                None => status(8),
            },
            Op::GetFileHash => match self.tree.get(path()) {
                Some(Node::IdentifiedFile(bytes)) => {
                    use sha1::Digest;
                    data(sha1::Sha1::digest(bytes).to_vec())
                }
                _ => status(AfcError::PermDenied as u64),
            },
            Op::ReadDir => {
                assert_eq!(self.tree.get(path()), Some(&Node::Dir));
                let prefix = format!("{}/", path());
                let mut result = b".\0..\0".to_vec();
                for entry in self
                    .tree
                    .keys()
                    .filter_map(|p| p.strip_prefix(&prefix))
                    .filter(|p| !p.contains('/'))
                {
                    result.extend_from_slice(entry.as_bytes());
                    result.push(0);
                }
                data(result)
            }
            Op::FileOpen => {
                assert_eq!(
                    &body[..8],
                    &1_u64.to_le_bytes(),
                    "only read-only opens expected"
                );
                let name = std::str::from_utf8(&body[8..])
                    .unwrap()
                    .trim_end_matches('\0');
                assert!(matches!(self.tree.get(name), Some(Node::File(_))));
                self.opened = Some(name.into());
                (Op::FileOpenRes, 1_u64.to_le_bytes().to_vec(), vec![])
            }
            Op::Read => match &self.tree[self.opened.as_ref().unwrap()] {
                Node::File(bytes) => data(bytes.clone()),
                _ => unreachable!(),
            },
            Op::FileClose => {
                self.opened.take().unwrap();
                status(0)
            }
            Op::RemovePath => {
                let p = path();
                assert!(
                    !self
                        .tree
                        .keys()
                        .any(|name| name.starts_with(&format!("{p}/"))),
                    "never recursively delete"
                );
                self.tree.remove(p).unwrap();
                self.removes.push(p.into());
                status(0)
            }
            _ => panic!("unexpected mutation or unimplemented AFC request {op:?}"),
        }
    }
}
pub(super) fn memory(tree: Tree) -> (AfcClient, tokio::task::JoinHandle<MemoryAfc>) {
    let (host, mut peer) = tokio::io::duplex(32 * 1024);
    let task = tokio::spawn(async move {
        let mut fs = MemoryAfc {
            tree,
            opened: None,
            sibling_probes: 0,
            leaf_checks: 0,
            removes: vec![],
        };
        while let Ok(magic) = peer.read_u64_le().await {
            assert_eq!(magic, MAGIC);
            let length = peer.read_u64_le().await.unwrap() as usize;
            let _header_length = peer.read_u64_le().await.unwrap();
            let sequence = peer.read_u64_le().await.unwrap();
            let op = Op::try_from(peer.read_u64_le().await.unwrap()).unwrap();
            assert!((40..32768).contains(&length));
            let mut body = vec![0; length - 40];
            peer.read_exact(&mut body).await.unwrap();
            let (op, header, data) = fs.respond(op, &body);
            for value in [
                MAGIC,
                40 + (header.len() + data.len()) as u64,
                40 + header.len() as u64,
                sequence,
                op as u64,
            ] {
                peer.write_u64_le(value).await.unwrap();
            }
            peer.write_all(&header).await.unwrap();
            peer.write_all(&data).await.unwrap();
        }
        fs
    });
    (
        AfcClient::new(Idevice::new(Box::new(host), "AirLift memory fixture")),
        task,
    )
}

#[tokio::test]
async fn reverse_preflight_distinguishes_missing_leaf_from_unreadable_existing_or_missing_parent() {
    let parent = "Documents/Resources/1.64.1/assetbundle/battle/skin";
    let leaf = format!("{parent}/1678_sunwukong_aw1_battle_low_raw_h.assetbundle");
    let mut tree = Tree::from([("/link".into(), Node::Link("/fixture"))]);
    for (i, _) in leaf.match_indices('/') {
        tree.insert(format!("/link/{}", &leaf[..i]), Node::Dir);
    }
    tree.insert(
        format!("/link/{parent}/existing"),
        Node::Status(AfcError::PermDenied as u64),
    );
    tree.insert(format!("/link/{parent}/weak"), Node::File(vec![1]));
    tree.insert(
        format!("/link/{parent}/offline"),
        Node::Status(AfcError::ServiceNotConnected as u64),
    );
    tree.insert(format!("/link/{parent}/redirect"), Node::Link("/other"));
    let (afc, task) = memory(tree);
    let mut link = patch_link::PatchLink::fixture_documents(afc, &leaf).await;

    assert_eq!(
        link.reverse_preflight_witness(&leaf).await.unwrap(),
        ReversePreflight::Ready("missing".into())
    );
    assert!(!link.reverse_new_present().await.unwrap());
    assert_eq!(
        link.reverse_preflight_witness(&format!("{parent}/existing"))
            .await
            .unwrap(),
        ReversePreflight::Ready("opaque".into())
    );
    assert!(matches!(
        link.reverse_preflight_witness(&format!("{parent}/weak"))
            .await
            .unwrap(),
        ReversePreflight::Unavailable(_)
    ));
    assert!(
        link.reverse_preflight_witness(&format!("{parent}/offline"))
            .await
            .is_err()
    );
    for (name, message) in [
        ("uninstalled", "Thiếu thư mục cha"),
        ("existing", "iOS từ chối xác minh thư mục cha"),
        ("redirect", "Đường dẫn cha phải là thư mục thật"),
    ] {
        let ReversePreflight::Unavailable(error) = link
            .reverse_preflight_witness(&format!("{parent}/{name}/file"))
            .await
            .unwrap()
        else {
            panic!("invalid parent accepted")
        };
        assert!(error.starts_with(message));
        assert!(error.ends_with(&format!("{parent}/{name}")));
    }
    drop(link);
    assert!(task.await.unwrap().removes.is_empty());
}

#[tokio::test]
async fn bulk_preflight_uses_all_bound_streams_and_rejects_one_wrong_install() {
    use std::sync::{Arc, atomic::AtomicBool};
    let names: Vec<_> = (0..72).map(|i| format!("Documents/pack/file{i}")).collect();
    let mut tree = Tree::from([
        ("/link".into(), Node::Link("/fixture")),
        ("/link/Documents".into(), Node::Dir),
        ("/link/Documents/pack".into(), Node::Dir),
    ]);
    for name in names.iter().step_by(2) {
        tree.insert(
            format!("/link/{name}"),
            Node::Status(AfcError::PermDenied as u64),
        );
    }
    let ctl = crate::sync::SyncControl::new(Arc::new(AtomicBool::new(false)), Arc::new(|_| {}));
    let (afc, host) = memory(tree.clone());
    let mut link = patch_link::PatchLink::fixture_documents(afc, &names[0]).await;
    let (mut extra, workers): (Vec<_>, Vec<_>) = (0..5).map(|_| memory(tree.clone())).unzip();
    let ordered = link
        .reverse_scan_readers(&mut extra, &names, &ctl, &AtomicBool::new(false))
        .await
        .unwrap();
    assert_eq!(ordered.len(), names.len());
    for (i, result) in ordered.into_iter().enumerate() {
        assert_eq!(
            result,
            ReversePreflight::Ready(if i % 2 == 0 { "opaque" } else { "missing" }.into())
        );
    }
    drop(extra);
    drop(link);
    let mut probes = 0;
    let mut leaves = 0;
    for worker in std::iter::once(host).chain(workers) {
        let fs = worker.await.unwrap();
        assert!(fs.removes.is_empty());
        assert!(fs.leaf_checks > 0);
        probes += fs.sibling_probes;
        leaves += fs.leaf_checks;
    }
    assert_eq!(leaves, names.len());
    assert!((1..=6).contains(&probes));

    let (afc, _) = memory(tree.clone());
    let mut link = patch_link::PatchLink::fixture_documents(afc, &names[0]).await;
    tree.insert("/link".into(), Node::Link("/different-install"));
    let (bad, server) = memory(tree);
    let mut extra = [bad];
    let scan = link
        .reverse_scan_readers(&mut extra, &names, &ctl, &AtomicBool::new(false))
        .await;
    assert!(scan.is_err());
    drop(extra);
    let fs = server.await.unwrap();
    assert_eq!(fs.leaf_checks, 0);
    assert!(fs.removes.is_empty());
}

#[tokio::test]
async fn partial_preflight_preserves_source_error_without_masking_device_or_cancel() {
    use std::sync::{Arc, atomic::AtomicBool};
    let tree = Tree::from([
        ("/link".into(), Node::Link("/fixture")),
        ("/link/Documents".into(), Node::Dir),
    ]);
    let names = vec!["Documents/payload".to_owned()];
    let (afc, _server) = memory(tree);
    let mut link = patch_link::PatchLink::fixture_documents(afc, &names[0]).await;
    let stop = AtomicBool::new(true);
    let ctl = crate::sync::SyncControl::new(Arc::new(AtomicBool::new(false)), Arc::new(|_| {}));
    let partial = link
        .reverse_scan_readers(&mut [], &names, &ctl, &stop)
        .await
        .unwrap_err();
    assert_eq!(partial, ScanFailure::PreparationStopped);
    assert_eq!(
        partial.reason(Some("source write failed".into())),
        "source write failed"
    );
    let cancelled =
        crate::sync::SyncControl::new(Arc::new(AtomicBool::new(true)), Arc::new(|_| {}));
    let reason = link
        .reverse_scan_readers(&mut [], &names, &cancelled, &stop)
        .await
        .unwrap_err()
        .reason(Some("source write failed".into()));
    assert_eq!(reason, "Đã dừng kiểm tra tệp trên iPhone.");
    assert_eq!(
        ScanFailure::Failed("AFC offline".into()).reason(Some("source stopped".into())),
        "AFC offline"
    );
}

#[tokio::test]
async fn occupied_books_preflight_performs_only_read_operations() {
    let mut tree = Tree::from([(BOOKS.into(), Node::Dir), (SYNC.into(), Node::Dir)]);
    for name in [
        "library.sqlite",
        "library.sqlite-shm",
        "library.sqlite-wal",
        "Books.plist",
    ] {
        tree.insert(format!("{SYNC}/{name}"), Node::File(b"existing".to_vec()));
    }
    let (mut c, task) = memory(tree);
    assert!(preflight(&mut c).await.unwrap());
    drop(c);
    let fs = task.await.unwrap();
    assert!(fs.removes.is_empty());
    assert_eq!(fs.tree.len(), 6);
}

#[tokio::test]
async fn correct_readback_is_verified_and_only_own_artifacts_are_removed() {
    let mut trial = Trial::new(true);
    trial.books_snapshot = false;
    trial.publish_attempted = true;
    trial.sync_started = Some(now());
    trial.matched = true;
    let tree = Tree::from([
        (BOOKS.into(), Node::Dir),
        (SYNC.into(), Node::Dir),
        (MANIFEST.into(), Node::File(trial.manifest().unwrap())),
        (
            format!("{SYNC}/{}", trial.marker()),
            Node::File(trial.challenge.to_vec()),
        ),
        (trial.readback(), Node::File(trial.challenge.to_vec())),
        (format!("/{}", trial.link()), Node::Link(JUMP)),
        ("/sibling".into(), Node::File(b"other".to_vec())),
    ]);
    let (mut c, task) = memory(tree);
    assert_eq!(
        read(&mut c, &trial.readback()).await.unwrap().as_deref(),
        Some(trial.challenge.as_slice())
    );
    assert!(cleanup(&mut c, &trial).await.unwrap());
    drop(c);
    let fs = task.await.unwrap();
    assert_eq!(
        fs.tree,
        Tree::from([
            (BOOKS.into(), Node::Dir),
            ("/sibling".into(), Node::File(b"other".to_vec()))
        ])
    );
}

#[tokio::test]
async fn altered_or_redirected_readback_is_preserved() {
    for node in [Node::File(vec![b'x'; 32]), Node::Link("../foreign")] {
        let expected = Trial::new(false);
        let (mut c, task) = memory(Tree::from([(expected.readback(), node)]));
        assert!(!cleanup(&mut c, &expected).await.unwrap_or(false));
        drop(c);
        let fs = task.await.unwrap();
        assert!(fs.tree.contains_key(&expected.readback()));
        assert!(fs.removes.is_empty());
    }
}

#[tokio::test]
async fn cleanup_preserves_the_service_books_database() {
    let mut t = Trial::new(true);
    t.books_snapshot = false;
    t.publish_attempted = true;
    t.sync_started = Some(now());
    t.matched = true;
    let tree = Tree::from([
        (BOOKS.into(), Node::Dir),
        (SYNC.into(), Node::Dir),
        (MANIFEST.into(), Node::File(t.manifest().unwrap())),
        (
            format!("{SYNC}/{}", t.marker()),
            Node::File(t.challenge.to_vec()),
        ),
        (format!("{SYNC}/Database"), Node::Dir),
        (
            format!("{SYNC}/Database/library.sqlite"),
            Node::File(b"system".to_vec()),
        ),
    ]);
    let (mut c, task) = memory(tree);
    let _receipt = cleanup(&mut c, &t).await.unwrap();
    drop(c);
    let fs = task.await.unwrap();
    assert!(!fs.tree.contains_key(MANIFEST));
    assert_eq!(
        fs.tree[&format!("{SYNC}/Database/library.sqlite")],
        Node::File(b"system".to_vec())
    );
}

#[tokio::test]
async fn missing_link_after_unconfirmed_sync_keeps_the_recovery_open() {
    let mut trial = Trial::new(false);
    trial.sync_started = Some(now());
    let (mut c, task) = memory(Tree::new());
    assert!(!cleanup(&mut c, &trial).await.unwrap());
    drop(c);
    assert!(task.await.unwrap().removes.is_empty());
}

#[tokio::test]
async fn foreign_books_directory_created_during_publication_is_preserved() {
    let mut trial = Trial::new(false);
    trial.books_snapshot = false;
    trial.publish_attempted = true;
    let (mut c, task) = memory(Tree::from([
        (BOOKS.into(), Node::Dir),
        (SYNC.into(), Node::Dir),
        (format!("{SYNC}/Database"), Node::Dir),
    ]));
    let _receipt = cleanup(&mut c, &trial).await.unwrap();
    drop(c);
    let fs = task.await.unwrap();
    assert!(fs.removes.is_empty());
    assert_eq!(fs.tree.len(), 3);
}

#[tokio::test]
async fn changed_ownership_marker_stops_cleanup_before_touching_shared_books() {
    let mut t = Trial::new(true);
    t.books_snapshot = false;
    t.publish_attempted = true;
    t.matched = true;
    let tree = Tree::from([
        (BOOKS.into(), Node::Dir),
        (SYNC.into(), Node::Dir),
        (MANIFEST.into(), Node::File(t.manifest().unwrap())),
        (
            format!("{SYNC}/{}", t.marker()),
            Node::File(b"foreign".to_vec()),
        ),
    ]);
    let (mut c, task) = memory(tree);
    assert!(!cleanup(&mut c, &t).await.unwrap());
    drop(c);
    let fs = task.await.unwrap();
    assert!(fs.removes.is_empty());
    assert!(fs.tree.contains_key(MANIFEST));
}
