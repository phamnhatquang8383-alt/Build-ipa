use super::patch::MAX_ITEMS;
use super::{DeviceSession, NativeAtcChannel, invalid, native};
use crate::sync::{AtcChannel, SyncError};
use idevice::IdeviceError;
use plist::{Dictionary, Value};
use std::time::Duration;
use tokio::io::{AsyncRead, AsyncReadExt, AsyncWrite, AsyncWriteExt};

const BOOK_HELLO_1_0_1: &[u8; 84] = include_bytes!("airlift-book-hello-1-0-1.bin");
const MAX_ZIP: usize = 1024 * 1024;
const MAX_REPLY: usize = 256 * 1024;
const ZIP_ERROR: &str = "iOS không nhận được tệp thử qua dịch vụ chuyển tệp.";

pub(super) fn valid_token(token: &str) -> bool {
    let hex = token.strip_prefix('n').unwrap_or(token);
    hex.len() == 20
        && hex
            .bytes()
            .all(|c| c.is_ascii_digit() || (b'a'..=b'f').contains(&c))
}

pub(super) async fn transfer(
    session: &mut DeviceSession,
    source: &str,
    zip: &[u8],
) -> Result<(), String> {
    if !source.strip_prefix("cl-src-").is_some_and(valid_token)
        || zip.is_empty()
        || zip.len() > MAX_ZIP
    {
        return Err("Dữ liệu tệp thử không hợp lệ.".into());
    }
    native(
        &session.control.clone(),
        Duration::from_secs(30),
        "StreamingZip canary",
        async {
            let mut stream = session.service("com.apple.streaming_zip_conduit").await?;
            upload(&mut stream, source, zip).await
        },
    )
    .await
    .map_err(|_| ZIP_ERROR.to_owned())
}

async fn upload<S: AsyncRead + AsyncWrite + Unpin>(
    stream: &mut S,
    source: &str,
    zip: &[u8],
) -> Result<(), IdeviceError> {
    let init = dict([("MediaSubdir", Value::String(source.to_owned()))]);
    let mut header = vec![];
    init.to_writer_binary(&mut header)?;
    stream.write_u32(header.len() as u32).await?;
    stream.write_all(&header).await?;
    stream.write_all(zip).await?;
    stream.flush().await?;
    drain_replies(stream).await
}

async fn drain_replies<S: AsyncRead + Unpin>(stream: &mut S) -> Result<(), IdeviceError> {
    for _ in 0..64 {
        let mut header = [0u8; 4];
        match tokio::time::timeout(Duration::from_secs(4), stream.read(&mut header[..1])).await {
            Err(_) | Ok(Ok(0)) => return Ok(()),
            Ok(result) => {
                result?;
            }
        }
        stream.read_exact(&mut header[1..]).await?;
        let count = u32::from_be_bytes(header) as usize;
        if !(1..=MAX_REPLY).contains(&count) {
            return Err(invalid("invalid streaming zip reply length"));
        }
        let mut body = vec![0; count];
        stream.read_exact(&mut body).await?;
        let data = plist::from_bytes::<Value>(&body)?;
        let d = data
            .as_dictionary()
            .ok_or_else(|| invalid("invalid streaming zip reply"))?;
        if d.contains_key("Error")
            || d.contains_key("ErrorDescription")
            || matches!(
                d.get("Status").and_then(Value::as_string),
                Some("Failed" | "Error" | "Failure")
            )
        {
            return Err(invalid("streaming zip rejected canary"));
        }
        if d.get("Status").and_then(Value::as_string) == Some("Complete") {
            return Ok(());
        }
    }
    Err(invalid("excessive streaming zip replies"))
}

fn dict<const N: usize>(data: [(&str, Value); N]) -> Value {
    Value::Dictionary(data.into_iter().map(|(k, v)| (k.to_string(), v)).collect())
}
fn message(session: u64, command: &str, params: Value) -> Dictionary {
    [
        ("Session".to_owned(), Value::Integer(session.into())),
        ("Command".to_owned(), command.into()),
        ("Params".to_owned(), params),
    ]
    .into_iter()
    .collect()
}
fn fresh_library_id() -> String {
    let mut bytes = rand::random::<[u8; 16]>();
    bytes[6] = (bytes[6] & 0x0f) | 0x40;
    bytes[8] = (bytes[8] & 0x3f) | 0x80;
    let hex = format!("{:032X}", u128::from_be_bytes(bytes));
    format!(
        "{}-{}-{}-{}-{}",
        &hex[..8],
        &hex[8..12],
        &hex[12..16],
        &hex[16..20],
        &hex[20..]
    )
}
fn book_types() -> Value {
    Value::Array(vec!["Book".into()])
}
fn host_info(library_id: &str) -> Value {
    dict([
        ("Type", "iTunes".into()),
        ("Version", "13.7.0.161".into()),
        ("MacOSVersion", "iOS 27.0".into()),
        ("SyncHostName", "CC365".into()),
        ("LibraryID", library_id.into()),
        ("SyncedDataclasses", book_types()),
        ("SyncedAssetTypes", book_types()),
        ("Wakeable", false.into()),
    ])
}
#[derive(Debug, Default)]
struct AssetIndex(std::collections::HashMap<String, bool>);

impl AssetIndex {
    fn parse(incoming: &Dictionary) -> Self {
        let mut index = Self::default();
        if let Some(rows) = incoming
            .get("Params")
            .and_then(Value::as_dictionary)
            .and_then(|p| p.get("AssetManifest"))
            .and_then(Value::as_dictionary)
            .and_then(|p| p.get("Book"))
            .and_then(Value::as_array)
        {
            for row in rows.iter().filter_map(Value::as_dictionary) {
                let Some(id) = row.get("AssetID").and_then(Value::as_string) else {
                    continue;
                };
                let valid = row.get("IsDownload").is_some_and(|v| {
                    v.as_boolean() == Some(true) || v.as_unsigned_integer() == Some(1)
                });
                index
                    .0
                    .entry(id.to_owned())
                    .and_modify(|unique| *unique = false)
                    .or_insert(valid);
            }
        }
        index
    }
    fn allows(&self, id: &str) -> bool {
        self.0.get(id) == Some(&true)
    }
    fn covers(&self, moves: &[(String, String)]) -> bool {
        let mut requested = std::collections::HashSet::with_capacity(moves.len());
        !moves.is_empty()
            && moves
                .iter()
                .all(|(id, _)| requested.insert(id.as_str()) && self.allows(id))
    }
}
#[cfg(test)]
fn has_canary_assets(incoming: &Dictionary, moves: &[(String, String)]) -> bool {
    AssetIndex::parse(incoming).covers(moves)
}

async fn wait(
    channel: &mut impl AtcChannel,
    want: &str,
    limit: usize,
) -> Result<Dictionary, String> {
    for _ in 0..limit {
        let msg = channel
            .receive()
            .await
            .map_err(|_| format!("Chưa nhận được {want} từ dịch vụ Sách."))?;
        let name = msg.get("Command").and_then(Value::as_string);
        if name == Some(want) {
            return Ok(msg);
        }
        if matches!(name, Some("SyncFailed" | "SyncFinished")) {
            break;
        }
    }
    Err(format!("Phiên đồng bộ Sách kết thúc trước {want}."))
}

fn valid_canary_moves(moves: &[(String, String)]) -> bool {
    if moves.len() != 3 {
        return false;
    }
    let Some(token) = moves[0]
        .1
        .strip_prefix("cl-link-")
        .filter(|t| valid_token(t))
    else {
        return false;
    };
    let leaf = format!("cl-canary-{token}.bin");
    moves[0].0 == format!("../../cl-src-{token}/a/b/c/jump")
        && moves[1].0 == format!("../../cl-src-{token}/payload")
        && moves[1].1 == format!("cl-link-{token}/{leaf}")
        && moves[2].0 == format!("../../../../tmp/{leaf}")
        && moves[2].1 == format!("cl-read-{token}")
}

pub(super) async fn books(
    session: &mut DeviceSession,
    moves: &[(String, String)],
    reverse_namespaced: bool,
    before_moves: impl FnOnce() -> Result<(), String>,
) -> Result<BooksSession, String> {
    let valid_link = match moves {
        [(source, destination)] => destination
            .strip_prefix("cl-link-")
            .filter(|token| valid_token(token))
            .is_some_and(|token| source == &format!("../../cl-src-{token}/a/b/c/jump")),
        _ => false,
    };
    if !(valid_link || valid_canary_moves(moves)) {
        return Err("Đường dẫn của tệp thử không hợp lệ.".into());
    }
    let mut ch = session
        .atc()
        .await
        .map_err(|_| "Không mở được dịch vụ đồng bộ Sách.")?;
    let manifest = tokio::time::timeout(
        Duration::from_secs(90),
        exchange(&mut ch, moves, before_moves),
    )
    .await
    .map_err(|_| "Hết thời gian chờ phiên đồng bộ Sách.")??;
    Ok(BooksSession {
        channel: ch,
        manifest,
        sent_reverse: Default::default(),
        reverse_namespaced,
    })
}

pub(super) struct BooksSession<C = NativeAtcChannel> {
    channel: C,
    manifest: AssetIndex,
    sent_reverse: std::collections::HashSet<String>,
    reverse_namespaced: bool,
}

impl<C: AtcChannel> BooksSession<C> {
    pub(super) fn uses_reverse_namespace(&self) -> bool {
        self.reverse_namespaced
    }

    pub(super) fn validate_delivery(
        &self,
        token: &str,
        scope: &DeliveryScope,
        moves: &[(String, String)],
    ) -> Result<(), String> {
        if moves.is_empty()
            || moves.len() > MAX_ITEMS
            || !valid_token(token)
            || moves
                .iter()
                .any(|(from, to)| !valid_delivery(token, scope, from, to))
            || !self.manifest.covers(moves)
        {
            return Err("Danh sách ATC chưa xác nhận đúng các tệp của patch.".into());
        }
        Ok(())
    }

    pub(super) async fn deliver(
        &mut self,
        token: &str,
        scope: &DeliveryScope,
        moves: &[(String, String)],
    ) -> Result<(), String> {
        self.validate_delivery(token, scope, moves)?;
        for (from, to) in moves {
            send_file(&mut self.channel, from, to).await?;
        }
        Ok(())
    }
}

#[derive(Clone, Copy, PartialEq)]
pub(super) enum ReverseMove {
    Export,
    Return,
    Install,
    Evict,
    ProbePlace,
    ProbeRecall,
}

impl ReverseMove {
    pub(super) const ALL: [Self; 6] = [
        Self::Export,
        Self::Return,
        Self::Install,
        Self::Evict,
        Self::ProbePlace,
        Self::ProbeRecall,
    ];

    pub(super) fn paths(
        self,
        token: &str,
        root: &str,
        relative: &str,
        key: &str,
    ) -> Option<(String, String)> {
        if !valid_token(token) || !valid_reverse_key(key) || !valid_reverse_relative(relative) {
            return None;
        }
        let container = root.strip_prefix("/var/mobile/Containers/Data/Application/")?;
        if container.len() != 36
            || !container.bytes().enumerate().all(|(i, c)| {
                if matches!(i, 8 | 13 | 18 | 23) {
                    c == b'-'
                } else {
                    c.is_ascii_hexdigit()
                }
            })
        {
            return None;
        }
        let leaf = format!("cl-link-{token}/{relative}");
        let held = format!("cc365-held-{key}");
        let staged = format!("cc365-put-{key}");
        let parent = relative.rsplit_once('/')?.0;
        let probe_media = format!("cc365-probe-{key}");
        let probe_target = format!("cl-link-{token}/{parent}/cc365-probe-{key}.bin");
        Some(match self {
            Self::ProbePlace => (format!("../../{probe_media}"), probe_target),
            Self::ProbeRecall => (format!("../../{probe_target}"), probe_media),
            Self::Export => (format!("../../{leaf}"), held),
            Self::Return => (format!("../../{held}"), leaf),
            Self::Install => (format!("../../{staged}"), leaf),
            Self::Evict => (
                format!("../../../Containers/Data/Application/{container}/{relative}"),
                staged,
            ),
        })
    }

    pub(super) fn assets(
        self,
        token: &str,
        root: &str,
        relative: &str,
        key: &str,
    ) -> Option<[(String, String); 2]> {
        let first = self.paths(token, root, relative, key)?;
        let second = if let Some(raw) = first.0.strip_prefix("../../../Containers/") {
            format!("../../../../mobile/Containers/{raw}")
        } else {
            format!("../../../Media/{}", first.0.strip_prefix("../../")?)
        };
        let destination = first.1.clone();
        Some([first, (second, destination)])
    }

    pub(super) fn assets_for_lease(
        self,
        token: &str,
        root: &str,
        relative: &str,
        key: &str,
        namespaced: bool,
    ) -> Option<[(String, String); 2]> {
        let mut assets = self.assets(token, root, relative, key)?;
        if namespaced {
            for (source, _) in &mut assets {
                let suffix = source.strip_prefix("../../")?;
                *source = format!("../../cl-src-{token}/../{suffix}");
            }
        }
        Some(assets)
    }
}
pub(super) fn valid_reverse_key(key: &str) -> bool {
    key.len() == 32
        && key
            .bytes()
            .all(|c| c.is_ascii_digit() || (b'a'..=b'f').contains(&c))
}
pub(super) fn valid_reverse_relative(rel: &str) -> bool {
    rel.starts_with("Documents/")
        && rel.len() <= 1024
        && rel.split('/').count() <= 32
        && rel.split('/').all(|p| {
            !p.is_empty()
                && !p.starts_with('.')
                && p.len() <= 255
                && !p.contains('\\')
                && !p.chars().any(char::is_control)
        })
}

impl<C: AtcChannel> BooksSession<C> {
    pub(super) fn reverse_assets(
        &self,
        direction: ReverseMove,
        token: &str,
        root: &str,
        rel: &str,
        key: &str,
    ) -> Option<[(String, String); 2]> {
        direction.assets_for_lease(token, root, rel, key, self.reverse_namespaced)
    }
    pub(super) fn has_reverse_assets(&self, assets: &[(String, String)]) -> bool {
        self.manifest.covers(assets)
    }
    pub(super) fn next_reverse_frame(
        &self,
        direction: ReverseMove,
        token: &str,
        root: &str,
        rel: &str,
        key: &str,
    ) -> Result<(String, String), String> {
        let candidates = self
            .reverse_assets(direction, token, root, rel, key)
            .ok_or("Đường dẫn sao lưu AirLift không hợp lệ.")?;
        let pair = candidates
            .into_iter()
            .find(|(id, _)| !self.sent_reverse.contains(id))
            .ok_or("Phiên AirLift đã dùng hết các lượt di chuyển cho tệp này.")?;
        if !self.manifest.allows(&pair.0) {
            return Err("iOS chưa xác nhận tệp trong phiên sao lưu AirLift.".into());
        }
        Ok(pair)
    }
    pub(super) async fn reverse_move(
        &mut self,
        direction: ReverseMove,
        token: &str,
        root: &str,
        rel: &str,
        key: &str,
    ) -> Result<(), String> {
        let pair = self.next_reverse_frame(direction, token, root, rel, key)?;
        self.sent_reverse.insert(pair.0.clone());
        send_file(&mut self.channel, &pair.0, &pair.1).await
    }
}

pub(super) enum DeliveryScope {
    Documents,
    Cache,
    Bundle(String),
}

impl DeliveryScope {
    fn leaf(&self) -> Option<&str> {
        match self {
            Self::Documents => Some("Documents"),
            Self::Cache => Some("Library/Caches"),
            Self::Bundle(leaf)
                if leaf.len() <= 255
                    && !leaf.starts_with('.')
                    && leaf.ends_with(".app")
                    && !leaf.contains(['/', '\\'])
                    && !leaf.chars().any(char::is_control) =>
            {
                Some(leaf)
            }
            Self::Bundle(_) => None,
        }
    }
}

pub(super) fn valid_delivery(token: &str, scope: &DeliveryScope, from: &str, to: &str) -> bool {
    let src = format!("../../cl-src-{token}/patch-");
    let Some(index) = from
        .strip_prefix(&src)
        .and_then(|s| s.strip_suffix("-a"))
        .and_then(|s| s.parse::<usize>().ok())
        .filter(|i| *i < MAX_ITEMS)
    else {
        return false;
    };
    if from != format!("{src}{index}-a") {
        return false;
    }
    let Some(leaf) = scope.leaf() else {
        return false;
    };
    let base = format!("cl-link-{token}/{leaf}/");
    let Some(relative) = to.strip_prefix(&base) else {
        return false;
    };
    let mut parts: Vec<_> = relative.split('/').collect();
    let Some(file) = parts.pop() else {
        return false;
    };
    let suffix = format!("-{index}-a");
    let Some(transaction) = file
        .strip_prefix(".cc365-patch-")
        .and_then(|p| p.strip_suffix(&suffix))
    else {
        return false;
    };
    transaction.len() == 32
        && transaction.bytes().all(|c| c.is_ascii_hexdigit())
        && relative.len() <= 1200
        && parts.len() <= 32
        && parts.iter().all(|p| {
            !p.is_empty()
                && !p.starts_with('.')
                && p.len() <= 255
                && !p.contains('\\')
                && !p.chars().any(char::is_control)
                && (!matches!(scope, DeliveryScope::Bundle(_)) || !nested_bundle(p))
        })
}

fn nested_bundle(part: &str) -> bool {
    let p = part.to_ascii_lowercase();
    matches!(
        p.as_str(),
        "_codesignature" | "sc_info" | "frameworks" | "plugins" | "appclips" | "watch"
    ) || [".app", ".appex", ".framework", ".xpc"]
        .iter()
        .any(|suffix| p.ends_with(suffix))
}

async fn send_file(
    ch: &mut impl AtcChannel,
    source: &str,
    destination: &str,
) -> Result<(), String> {
    ch.send(&message(
        1,
        "FileComplete",
        dict([
            ("AssetID", source.into()),
            ("Dataclass", "Book".into()),
            ("AssetPath", destination.into()),
        ]),
    ))
    .await
    .map_err(|_| "Gửi tệp qua AirLift không thành công.".to_owned())
}

fn books_hello(cap: Option<&Dictionary>) -> Result<&'static [u8], String> {
    let fields = ["version", "deviceType", "protocolVersion"].map(|key| {
        cap.and_then(|c| c.get(key))
            .and_then(Value::as_unsigned_integer)
    });
    if fields == [Some(1), Some(0), Some(1)] {
        Ok(BOOK_HELLO_1_0_1)
    } else {
        Err("Phiên bản giao thức đồng bộ Sách này chưa được CC365 hỗ trợ.".into())
    }
}
async fn exchange(
    ch: &mut impl AtcChannel,
    moves: &[(String, String)],
    before_moves: impl FnOnce() -> Result<(), String>,
) -> Result<AssetIndex, String> {
    let send_error = |_: SyncError| "Gửi yêu cầu đồng bộ Sách không thành công.".to_string();
    let mut capabilities = None;
    let mut allowed = false;
    for _ in 0..12 {
        let event = ch
            .receive()
            .await
            .map_err(|_| "Không nhận được thông tin đồng bộ Sách.")?;
        let command = event.get("Command").and_then(Value::as_string);
        if let Some(info) = event
            .get("Params")
            .and_then(Value::as_dictionary)
            .and_then(|p| p.get("GrappaSupportInfo"))
            .and_then(Value::as_dictionary)
        {
            capabilities = Some(info.clone());
        }
        allowed |= command == Some("SyncAllowed");
        if matches!(command, Some("SyncFailed" | "SyncFinished")) {
            break;
        }
        if allowed && capabilities.is_some() {
            break;
        }
    }
    if !allowed {
        return Err("iOS chưa cho phép đồng bộ Sách.".into());
    }
    let hello = books_hello(capabilities.as_ref())?;
    let mut info = host_info(&fresh_library_id());
    ch.send(&message(
        0,
        "HostInfo",
        dict([
            ("HostInfo", info.clone()),
            ("LocalCloudSupport", false.into()),
        ]),
    ))
    .await
    .map_err(send_error)?;
    tokio::time::sleep(Duration::from_millis(200)).await;
    info.as_dictionary_mut()
        .expect("host_info is a dictionary")
        .insert("Grappa".to_owned(), Value::Data(hello.to_vec()));
    ch.send(&message(
        1,
        "RequestingSync",
        dict([
            ("Dataclasses", book_types()),
            ("DataclassAnchors", dict([])),
            ("HostInfo", info),
        ]),
    ))
    .await
    .map_err(send_error)?;
    let ready = wait(ch, "ReadyForSync", 12).await?;
    let _device_hello = ready
        .get("Params")
        .and_then(Value::as_dictionary)
        .and_then(|p| p.get("DeviceInfo"))
        .and_then(Value::as_dictionary)
        .and_then(|d| d.get("Grappa"))
        .and_then(Value::as_data)
        .filter(|r| !r.is_empty() && r.len() <= 8192)
        .ok_or("Thiếu phản hồi bắt tay đồng bộ Sách từ iOS.")?;
    ch.send(&message(
        1,
        "FinishedSyncingMetadata",
        dict([
            ("SyncTypes", dict([("Book", Value::Integer(1u64.into()))])),
            ("DataclassAnchors", dict([])),
        ]),
    ))
    .await
    .map_err(send_error)?;
    let manifest = AssetIndex::parse(&wait(ch, "AssetManifest", 20).await?);
    if !manifest.covers(moves) {
        return Err("Danh sách Sách chưa xác nhận đủ ba mục của tệp thử.".into());
    }
    before_moves()?;
    for (index, (source, destination)) in moves.iter().enumerate() {
        if index != 0 {
            tokio::time::sleep(Duration::from_millis(900)).await;
        }
        send_file(ch, source, destination).await?;
    }
    if moves.len() != 1 {
        tokio::time::sleep(Duration::from_secs(2)).await;
    }
    Ok(manifest)
}

#[cfg(test)]
mod tests {
    use super::*;
    use std::collections::VecDeque;
    const TOKEN: &str = "0123456789abcdef1234";

    fn moves() -> [(String, String); 3] {
        let leaf = format!("cl-canary-{TOKEN}.bin");
        [
            (
                format!("../../cl-src-{TOKEN}/a/b/c/jump"),
                format!("cl-link-{TOKEN}"),
            ),
            (
                format!("../../cl-src-{TOKEN}/payload"),
                format!("cl-link-{TOKEN}/{leaf}"),
            ),
            (
                format!("../../../../tmp/{leaf}"),
                format!("cl-read-{TOKEN}"),
            ),
        ]
    }
    #[test]
    fn patch_deliveries_only_write_new_owned_names_in_the_selected_documents_scope() {
        let from = format!("../../cl-src-{TOKEN}/patch-3-a");
        let suffix = ".cc365-patch-ffffffffffffffffffffffffffffffff-3-a";
        let to = format!("cl-link-{TOKEN}/Documents/Test/{suffix}");
        assert!(valid_delivery(TOKEN, &DeliveryScope::Documents, &from, &to));
        for other in [
            to.replace("/Test/", "/../"),
            to.replace("Documents/", "Library/"),
            to.replace(TOKEN, "00000000000000000000"),
            to.replace("-3-a", "-2-a"),
            to.replace(suffix, "original.txt"),
            to.replace("/Test/", "/.outside/"),
        ] {
            assert!(!valid_delivery(
                TOKEN,
                &DeliveryScope::Documents,
                &from,
                &other
            ));
        }
        assert!(!valid_delivery(
            TOKEN,
            &DeliveryScope::Documents,
            "../../ordinary-user-file",
            &to
        ));
        assert!(!valid_delivery(
            TOKEN,
            &DeliveryScope::Documents,
            &from.replace("patch-3", "patch-03"),
            &to
        ));
    }

    #[test]
    fn cache_delivery_is_bound_to_a_staging_sibling_in_library_caches() {
        let from = format!("../../cl-src-{TOKEN}/patch-1-a");
        let stage = ".cc365-patch-ffffffffffffffffffffffffffffffff-1-a";
        let prefix = format!("cl-link-{TOKEN}/");
        let allowed = format!("{prefix}Library/Caches/catalog/{stage}");
        assert!(valid_delivery(
            TOKEN,
            &DeliveryScope::Cache,
            &from,
            &allowed
        ));
        for outside in [
            format!("{prefix}Documents/{stage}"),
            format!("{prefix}Library/CachesExtra/{stage}"),
            format!("{prefix}Library/Caches/../Preferences/{stage}"),
            format!("{prefix}Library/Caches/catalog/data.bin"),
        ] {
            assert!(!valid_delivery(
                TOKEN,
                &DeliveryScope::Cache,
                &from,
                &outside
            ));
        }
    }

    fn manifest(rows: Vec<Value>) -> Dictionary {
        message(
            1,
            "AssetManifest",
            dict([("AssetManifest", dict([("Book", Value::Array(rows))]))]),
        )
    }
    fn download_rows() -> Vec<Value> {
        moves()
            .iter()
            .map(|(asset, _)| {
                dict([
                    ("AssetID", asset.as_str().into()),
                    ("IsDownload", true.into()),
                ])
            })
            .collect()
    }

    #[test]
    fn limits_session_to_three_matching_canary_paths() {
        let good = moves();
        assert!(valid_canary_moves(&good));
        for (index, (source, dest)) in good.iter().enumerate() {
            for wrong in [
                (format!("{source}/.."), dest.clone()),
                (source.clone(), format!("{dest}/another")),
            ] {
                let mut other = good.clone();
                other[index] = wrong;
                assert!(!valid_canary_moves(&other));
            }
        }
        let mut mixed = good.clone();
        mixed[2].1 = "cl-read-2223456789abcdef1234".to_owned();
        assert!(!valid_canary_moves(&mixed));
    }

    #[test]
    fn manifest_requires_exactly_our_three_distinct_downloads() {
        let original = download_rows();
        assert!(has_canary_assets(&manifest(original.clone()), &moves()));
        let mut extra = original.clone();
        extra.push(dict([
            ("AssetID", "other-host".into()),
            ("IsDownload", true.into()),
        ]));
        let mut duplicate = original.clone();
        duplicate[0] = duplicate[1].clone();
        let mut missing_flag = original.clone();
        missing_flag[0]
            .as_dictionary_mut()
            .unwrap()
            .remove("IsDownload");
        let mut not_download = original.clone();
        not_download[0]
            .as_dictionary_mut()
            .unwrap()
            .insert("IsDownload".to_owned(), false.into());
        assert!(has_canary_assets(&manifest(extra), &moves()));
        for invalid in [
            duplicate,
            missing_flag,
            not_download,
            original[..2].to_vec(),
        ] {
            assert!(!has_canary_assets(&manifest(invalid), &moves()));
        }
    }

    struct Peer {
        events: VecDeque<Dictionary>,
        sent: Vec<Dictionary>,
    }
    impl AtcChannel for Peer {
        async fn receive(&mut self) -> Result<Dictionary, SyncError> {
            self.events
                .pop_front()
                .ok_or(SyncError::Transport("mock peer closed"))
        }
        async fn send(&mut self, m: &Dictionary) -> Result<(), SyncError> {
            self.sent.push(m.clone());
            Ok(())
        }
    }
    fn peer(final_event: Dictionary) -> Peer {
        Peer {
            events: [
                message(
                    0,
                    "Capabilities",
                    dict([(
                        "GrappaSupportInfo",
                        dict([
                            ("version", 1u64.into()),
                            ("deviceType", 0u64.into()),
                            ("protocolVersion", 1u64.into()),
                        ]),
                    )]),
                ),
                message(0, "SyncAllowed", dict([])),
                message(
                    1,
                    "ReadyForSync",
                    dict([("DeviceInfo", dict([("Grappa", Value::Data(vec![2]))]))]),
                ),
                final_event,
            ]
            .into(),
            sent: vec![],
        }
    }

    #[tokio::test]
    async fn bundle_file_complete_targets_only_a_fresh_sibling_inside_the_bound_app() {
        let scope = DeliveryScope::Bundle("Specific App.app".to_owned());
        let source = format!("../../cl-src-{TOKEN}/patch-0-a");
        let sibling = format!(
            "cl-link-{TOKEN}/Specific App.app/Resources/.cc365-patch-{}-0-a",
            "f".repeat(32)
        );
        let expected = vec![(source.clone(), sibling.clone())];
        let mut session = BooksSession {
            reverse_namespaced: false,
            sent_reverse: Default::default(),
            channel: Peer {
                events: VecDeque::new(),
                sent: vec![],
            },
            manifest: AssetIndex::parse(&manifest(vec![dict([
                ("AssetID", source.clone().into()),
                ("IsDownload", true.into()),
            ])])),
        };
        for wrong in [
            sibling.replace("Specific App.app", "Other.app"),
            sibling.replace("Specific App.app", "Documents"),
            sibling.replace("/Resources/", "/Other.app/"),
            sibling.replace("/Resources/", "/../"),
            sibling.replace(
                &format!(".cc365-patch-{}-0-a", "f".repeat(32)),
                "original.txt",
            ),
        ] {
            assert!(
                session
                    .deliver(TOKEN, &scope, &[(source.clone(), wrong)])
                    .await
                    .is_err()
            );
        }
        assert!(
            session
                .deliver(
                    TOKEN,
                    &DeliveryScope::Bundle("../Specific App.app".into()),
                    &expected
                )
                .await
                .is_err()
        );
        assert!(session.channel.sent.is_empty());
        session.deliver(TOKEN, &scope, &expected).await.unwrap();
        let params = session.channel.sent[0]["Params"].as_dictionary().unwrap();
        assert_eq!(params["AssetPath"].as_string(), Some(sibling.as_str()));
        assert_eq!(params["AssetID"].as_string(), Some(source.as_str()));
    }

    #[tokio::test]
    async fn grouped_patch_frames_preserve_the_exact_declared_ids_order_and_destinations() {
        use crate::device::airlift::MAX_GROUP_HANDOFFS;
        let root = "/var/mobile/Containers/Data/Application/12345678-1234-1234-1234-123456789ABC";
        let jobs: Vec<_> = (0..MAX_GROUP_HANDOFFS)
            .map(|i| (format!("Documents/pack/r{i}"), format!("{i:032x}")))
            .collect();
        let mut rows = Vec::new();
        for (rel, key) in &jobs {
            for direction in ReverseMove::ALL {
                for (src, _) in direction.assets(TOKEN, root, rel, key).unwrap() {
                    rows.push(dict([("AssetID", src.into()), ("IsDownload", true.into())]));
                }
            }
        }
        let mut session = BooksSession {
            reverse_namespaced: false,
            sent_reverse: Default::default(),
            channel: Peer {
                events: VecDeque::new(),
                sent: vec![],
            },
            manifest: AssetIndex::parse(&manifest(rows)),
        };
        let mut ids = std::collections::HashSet::new();
        for direction in [
            ReverseMove::Export,
            ReverseMove::Return,
            ReverseMove::Install,
            ReverseMove::Evict,
            ReverseMove::Install,
        ] {
            for (rel, key) in &jobs {
                let predicted = session
                    .next_reverse_frame(direction, TOKEN, root, rel, key)
                    .unwrap();
                assert_eq!(
                    session
                        .next_reverse_frame(direction, TOKEN, root, rel, key)
                        .unwrap(),
                    predicted
                );
                session
                    .reverse_move(direction, TOKEN, root, rel, key)
                    .await
                    .unwrap();
                let frame = session.channel.sent.last().unwrap();
                assert_eq!(frame["Command"].as_string(), Some("FileComplete"));
                let params = frame["Params"].as_dictionary().unwrap();
                assert_eq!(params["AssetID"].as_string(), Some(predicted.0.as_str()));
                assert_eq!(params["AssetPath"].as_string(), Some(predicted.1.as_str()));
                assert!(ids.insert(predicted.0));
            }
        }
        let previous = session.channel.sent.len();
        for (rel, key) in &jobs {
            assert!(
                session
                    .reverse_move(ReverseMove::Install, TOKEN, root, rel, key)
                    .await
                    .is_err()
            );
            assert!(
                session
                    .next_reverse_frame(ReverseMove::Export, TOKEN, root, "Documents/other", key)
                    .is_err()
            );
        }
        assert_eq!(session.channel.sent.len(), previous);
    }

    #[tokio::test]
    async fn reverse_documents_only_sends_the_exact_declared_book_asset() {
        let root = "/var/mobile/Containers/Data/Application/12345678-1234-1234-1234-123456789ABC";
        let relative = "Documents/Resources/sample.bytes";
        let key = "a".repeat(32);
        let pairs: Vec<_> = ReverseMove::ALL
            .iter()
            .map(|d| d.paths(TOKEN, root, relative, &key).unwrap())
            .collect();
        assert_eq!(
            pairs[0],
            (
                format!("../../cl-link-{TOKEN}/{relative}"),
                format!("cc365-held-{key}")
            )
        );
        assert_eq!(
            pairs[1],
            (
                format!("../../cc365-held-{key}"),
                format!("cl-link-{TOKEN}/{relative}")
            )
        );
        assert_eq!(
            pairs[2],
            (
                format!("../../cc365-put-{key}"),
                format!("cl-link-{TOKEN}/{relative}")
            )
        );
        assert_eq!(
            pairs[3],
            (
                format!(
                    "../../../Containers/Data/Application/{}/{relative}",
                    root.rsplit('/').next().unwrap()
                ),
                format!("cc365-put-{key}")
            )
        );
        let sibling = format!("cl-link-{TOKEN}/Documents/Resources/cc365-probe-{key}.bin");
        assert_eq!(
            pairs[4],
            (format!("../../cc365-probe-{key}"), sibling.clone())
        );
        assert_eq!(
            pairs[5],
            (format!("../../{sibling}"), format!("cc365-probe-{key}"))
        );
        assert_eq!(
            pairs
                .iter()
                .map(|p| &p.0)
                .collect::<std::collections::HashSet<_>>()
                .len(),
            6
        );
        let mut declared = pairs.clone();
        for d in ReverseMove::ALL {
            let [_primary, secondary] = d.assets(TOKEN, root, relative, &key).unwrap();
            declared.push(secondary);
        }
        assert_eq!(
            declared
                .iter()
                .map(|p| &p.0)
                .collect::<std::collections::HashSet<_>>()
                .len(),
            12
        );
        let rows = declared
            .iter()
            .map(|(s, _)| dict([("AssetID", s.as_str().into()), ("IsDownload", true.into())]))
            .collect::<Vec<_>>();
        let mut session = BooksSession {
            reverse_namespaced: false,
            sent_reverse: Default::default(),
            channel: Peer {
                events: VecDeque::new(),
                sent: vec![],
            },
            manifest: AssetIndex::parse(&manifest(rows[..1].to_vec())),
        };
        assert!(!session.has_reverse_assets(&pairs));
        assert!(
            session
                .reverse_move(ReverseMove::Return, TOKEN, root, relative, &key)
                .await
                .is_err()
        );
        assert!(
            session
                .reverse_move(
                    ReverseMove::Export,
                    TOKEN,
                    root,
                    "Documents/../Documents/other",
                    &key
                )
                .await
                .is_err()
        );
        assert!(session.channel.sent.is_empty());
        session.manifest = AssetIndex::parse(&manifest(rows));
        assert!(session.has_reverse_assets(&pairs));
        for d in ReverseMove::ALL {
            session
                .reverse_move(d, TOKEN, root, relative, &key)
                .await
                .unwrap();
        }
        for d in ReverseMove::ALL {
            session
                .reverse_move(d, TOKEN, root, relative, &key)
                .await
                .unwrap();
            assert!(
                session
                    .reverse_move(d, TOKEN, root, relative, &key)
                    .await
                    .is_err()
            );
        }
        assert_eq!(session.channel.sent.len(), 12);
        for ((from, to), frame) in declared.iter().zip(session.channel.sent) {
            assert_eq!(
                frame["Params"].as_dictionary().unwrap()["AssetID"].as_string(),
                Some(from.as_str())
            );
            assert_eq!(
                frame["Params"].as_dictionary().unwrap()["AssetPath"].as_string(),
                Some(to.as_str())
            );
        }
    }

    #[test]
    fn lease_namespaces_preserve_real_filesystem_targets_and_isolate_repeated_keys() {
        use std::collections::HashSet;
        let fixture = tempfile::tempdir().unwrap();
        let media = fixture.path().join("var/mobile/Media");
        let sync = media.join("Books/Sync");
        let container = "12345678-1234-1234-1234-123456789ABC";
        let root = format!("/var/mobile/Containers/Data/Application/{container}");
        let target = fixture.path().join(root.trim_start_matches('/'));
        let rel = "Documents/Resources/sample.bytes";
        let key = "a".repeat(32);
        std::fs::create_dir_all(&sync).unwrap();
        std::fs::create_dir_all(target.join("Documents/Resources")).unwrap();
        std::fs::write(target.join(rel), b"original fixture").unwrap();
        std::fs::write(
            target.join(format!("Documents/Resources/cc365-probe-{key}.bin")),
            b"target probe",
        )
        .unwrap();
        for name in [
            format!("cc365-held-{key}"),
            format!("cc365-put-{key}"),
            format!("cc365-probe-{key}"),
        ] {
            std::fs::write(media.join(name), b"media fixture").unwrap();
        }
        let mut seen = HashSet::new();
        for token in ["00000000000000000001", "00000000000000000002"] {
            std::fs::create_dir(media.join(format!("cl-src-{token}"))).unwrap();
            std::os::unix::fs::symlink(&target, media.join(format!("cl-link-{token}"))).unwrap();
            for direction in ReverseMove::ALL {
                let legacy = direction.assets(token, &root, rel, &key).unwrap();
                let current = direction
                    .assets_for_lease(token, &root, rel, &key, true)
                    .unwrap();
                assert_eq!(
                    direction
                        .assets_for_lease(token, &root, rel, &key, false)
                        .unwrap(),
                    legacy
                );
                for (old, new) in legacy.iter().zip(current) {
                    assert_eq!(new.1, old.1, "destination must not change");
                    assert_eq!(
                        std::fs::canonicalize(sync.join(&new.0)).unwrap(),
                        std::fs::canonicalize(sync.join(&old.0)).unwrap()
                    );
                    assert!(
                        seen.insert(new.0),
                        "each candidate is unique across directions and leases"
                    );
                }
            }
        }
        assert_eq!(seen.len(), 24);
    }

    #[tokio::test]
    async fn reverse_frames_use_only_the_namespace_version_declared_by_the_session() {
        let root = "/var/mobile/Containers/Data/Application/12345678-1234-1234-1234-123456789ABC";
        let rel = "Documents/fixture.bin";
        let key = "a".repeat(32);
        let legacy: Vec<_> = ReverseMove::ALL
            .into_iter()
            .flat_map(|d| d.assets(TOKEN, root, rel, &key).unwrap())
            .collect();
        let current: Vec<_> = ReverseMove::ALL
            .into_iter()
            .flat_map(|d| d.assets_for_lease(TOKEN, root, rel, &key, true).unwrap())
            .collect();
        let declared = |pairs: &[(String, String)]| {
            manifest(
                pairs
                    .iter()
                    .map(|(id, _)| {
                        dict([("AssetID", id.as_str().into()), ("IsDownload", true.into())])
                    })
                    .collect(),
            )
        };
        for (version, pairs, wrong) in [(false, &legacy, &current), (true, &current, &legacy)] {
            let mut session = BooksSession {
                reverse_namespaced: version,
                sent_reverse: Default::default(),
                channel: Peer {
                    events: VecDeque::new(),
                    sent: vec![],
                },
                manifest: AssetIndex::parse(&declared(wrong)),
            };
            assert!(
                session
                    .reverse_move(ReverseMove::Export, TOKEN, root, rel, &key)
                    .await
                    .is_err()
            );
            assert!(
                session.channel.sent.is_empty(),
                "never fall back to a foreign legacy/current ID"
            );
            session.manifest = AssetIndex::parse(&declared(pairs));
            for direction in ReverseMove::ALL {
                let expected = session
                    .reverse_assets(direction, TOKEN, root, rel, &key)
                    .unwrap();
                for pair in expected {
                    session
                        .reverse_move(direction, TOKEN, root, rel, &key)
                        .await
                        .unwrap();
                    let params = session.channel.sent.last().unwrap()["Params"]
                        .as_dictionary()
                        .unwrap();
                    assert_eq!(params["AssetID"].as_string(), Some(pair.0.as_str()));
                    assert_eq!(params["AssetPath"].as_string(), Some(pair.1.as_str()));
                }
            }
        }
    }

    #[tokio::test]
    async fn patch_batch_uses_one_manifest_and_sends_no_partial_batch_if_a_slot_is_missing() {
        let mut batch = Vec::new();
        let mut rows = Vec::new();
        for index in 0..522 {
            let source = format!("../../cl-src-{TOKEN}/patch-{index}-a");
            let dest = format!(
                "cl-link-{TOKEN}/Documents/.cc365-patch-{}-{index}-a",
                "b".repeat(32)
            );
            rows.push(dict([
                ("AssetID", source.as_str().into()),
                ("IsDownload", true.into()),
            ]));
            batch.push((source, dest));
        }
        let mut session = BooksSession {
            reverse_namespaced: false,
            sent_reverse: Default::default(),
            channel: Peer {
                events: VecDeque::new(),
                sent: vec![],
            },
            manifest: AssetIndex::parse(&manifest(rows[..521].to_vec())),
        };
        assert!(
            session
                .deliver(TOKEN, &DeliveryScope::Documents, &batch)
                .await
                .is_err()
        );
        assert!(session.channel.sent.is_empty());
        session.manifest = AssetIndex::parse(&manifest(rows));
        session
            .deliver(TOKEN, &DeliveryScope::Documents, &batch)
            .await
            .unwrap();
        assert_eq!(session.channel.sent.len(), batch.len());
        for (msg, (src, dst)) in session.channel.sent.iter().zip(batch) {
            assert_eq!(msg["Session"].as_unsigned_integer(), Some(1));
            assert_eq!(msg["Command"].as_string(), Some("FileComplete"));
            let params = msg["Params"].as_dictionary().unwrap();
            assert_eq!(params["AssetID"].as_string(), Some(src.as_str()));
            assert_eq!(params["AssetPath"].as_string(), Some(dst.as_str()));
        }
    }

    #[tokio::test]
    async fn single_patch_link_hands_control_to_afc_as_soon_as_the_move_was_sent() {
        let rows = download_rows();
        let mut channel = peer(manifest(rows));
        let mut armed = false;
        let path = moves();
        tokio::time::timeout(
            Duration::from_millis(1800),
            exchange(&mut channel, &path[..1], || {
                armed = true;
                Ok(())
            }),
        )
        .await
        .expect("fixed post-move sleep delayed the AFC probe")
        .unwrap();
        assert!(armed);
        let sends: Vec<_> = channel
            .sent
            .iter()
            .filter(|p| p["Command"].as_string() == Some("FileComplete"))
            .collect();
        assert_eq!(sends.len(), 1);
        assert_eq!(
            sends[0]["Params"].as_dictionary().unwrap()["AssetPath"].as_string(),
            Some(path[0].1.as_str())
        );
    }

    #[tokio::test]
    async fn books_exchange_matches_host_message_envelopes_and_destinations() {
        let moves = moves();
        let mut rows = download_rows();
        rows.push(dict([
            ("AssetID", "another-book".into()),
            ("IsDownload", true.into()),
        ]));
        let mut ch = peer(manifest(rows));
        let mut armed = false;
        exchange(&mut ch, &moves, || {
            armed = true;
            Ok(())
        })
        .await
        .unwrap();
        assert!(armed);
        let commands: Vec<_> = ch
            .sent
            .iter()
            .map(|m| {
                (
                    m["Session"].as_unsigned_integer().unwrap(),
                    m["Command"].as_string().unwrap(),
                )
            })
            .collect();
        assert_eq!(
            commands,
            [
                (0, "HostInfo"),
                (1, "RequestingSync"),
                (1, "FinishedSyncingMetadata"),
                (1, "FileComplete"),
                (1, "FileComplete"),
                (1, "FileComplete")
            ]
        );
        let host = ch.sent[0]["Params"].as_dictionary().unwrap();
        assert_eq!(host["LocalCloudSupport"].as_boolean(), Some(false));
        let request = ch.sent[1]["Params"].as_dictionary().unwrap();
        let mut expected = host["HostInfo"].clone();
        assert!(
            expected
                .as_dictionary_mut()
                .unwrap()
                .insert("Grappa".into(), Value::Data(BOOK_HELLO_1_0_1.to_vec()))
                .is_none()
        );
        assert_eq!(request["HostInfo"], expected);
        assert_eq!(request["Dataclasses"], book_types());
        assert_eq!(request["DataclassAnchors"], dict([]));
        assert_eq!(
            ch.sent[2]["Params"],
            dict([
                ("DataclassAnchors", dict([])),
                ("SyncTypes", dict([("Book", Value::Integer(1u64.into()))]))
            ])
        );
        for ((id, path), sent) in moves.iter().zip(&ch.sent[3..]) {
            assert_eq!(
                sent["Params"],
                dict([
                    ("AssetID", id.as_str().into()),
                    ("Dataclass", "Book".into()),
                    ("AssetPath", path.as_str().into())
                ])
            );
        }
    }

    #[tokio::test]
    async fn session_failure_or_incomplete_manifest_sends_no_file_completions() {
        for end in [
            message(1, "SyncFailed", dict([])),
            manifest(download_rows()[..2].to_vec()),
        ] {
            let mut ch = peer(end);
            assert!(
                exchange(&mut ch, &moves(), || panic!(
                    "must not publish incomplete manifest"
                ))
                .await
                .is_err()
            );
            assert!(
                ch.sent
                    .iter()
                    .all(|m| m["Command"].as_string() != Some("FileComplete"))
            );
        }
    }

    #[tokio::test]
    async fn incompatible_handshake_never_sends_assets() {
        for problem in 0..3 {
            let mut ch = peer(manifest(download_rows()));
            match problem {
                0 => {
                    ch.events[0] = message(
                        0,
                        "Capabilities",
                        dict([("GrappaSupportInfo", dict([("version", 99u64.into())]))]),
                    );
                }
                1 => {
                    ch.events[2] = message(1, "ReadyForSync", dict([]));
                }
                _ => {
                    ch.events[2] = message(1, "SyncFailed", dict([]));
                }
            }
            assert!(
                exchange(&mut ch, &moves(), || panic!("invalid handshake"))
                    .await
                    .is_err()
            );
            assert!(
                !ch.sent
                    .iter()
                    .any(|m| m["Command"].as_string() == Some("FinishedSyncingMetadata"))
            );
        }
    }

    #[tokio::test]
    async fn empty_zip_reply_closure_is_allowed_but_partial_header_is_rejected() {
        for (bytes, expected_ok) in [(&[][..], true), (&[0, 0][..], false)] {
            let (mut client, mut server) = tokio::io::duplex(64);
            server.write_all(bytes).await.unwrap();
            server.shutdown().await.unwrap();
            assert_eq!(drain_replies(&mut client).await.is_ok(), expected_ok);
        }
    }

    #[tokio::test]
    async fn zip_service_receives_big_endian_binary_init_and_unmodified_zip_then_checks_reply() {
        let payload = b"PK\x03\x04test";
        let source = format!("cl-src-{TOKEN}");
        for status in ["Complete", "Error"] {
            let (mut client, mut server) = tokio::io::duplex(2048);
            let server_task = async {
                let header_len = server.read_u32().await.unwrap();
                assert!(header_len < 1024);
                let mut header = vec![0; header_len as usize];
                server.read_exact(&mut header).await.unwrap();
                assert!(header.starts_with(b"bplist00"));
                assert_eq!(
                    plist::from_bytes::<Value>(&header).unwrap(),
                    dict([("MediaSubdir", source.as_str().into())])
                );
                let mut zip = [0; 8];
                server.read_exact(&mut zip).await.unwrap();
                assert_eq!(&zip, payload);
                let mut reply = vec![];
                dict([("Status", status.into())])
                    .to_writer_binary(&mut reply)
                    .unwrap();
                server.write_u32(reply.len() as u32).await.unwrap();
                server.write_all(&reply).await.unwrap();
            };
            let (result, ()) = tokio::join!(upload(&mut client, &source, payload), server_task);
            assert_eq!(result.is_ok(), status == "Complete");
        }
    }
}
