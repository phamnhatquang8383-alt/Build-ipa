use super::*;
use crate::device::files::{close_handle, open_handle};
use idevice::{
    IdeviceError,
    afc::{
        AfcClient,
        errors::AfcError,
        opcode::{AfcFopenMode, AfcOpcode},
    },
};
use sha1::Sha1;
use sha2::{Digest, Sha256};
use std::future::Future;

pub(super) const PERMISSION_DENIED: &str = "iOS từ chối truy cập đường dẫn này.";
pub(super) const UNSUPPORTED_LEAF: &str = "Patch chỉ hỗ trợ tệp thường không có liên kết.";
pub(super) const PARENT_MISSING: &str = "Thiếu thư mục cha trong ứng dụng.";
pub(super) const PARENT_TYPE: &str = "Thư mục cha là liên kết hoặc sai loại.";
const READ_BLOCK: u64 = 16 * 1024;
const WRITE_BLOCK: usize = 64 * 1024;
pub(super) const CHANGED: &str = "Nội dung tệp đã thay đổi. CC365 đã giữ bản sao để khôi phục.";

#[derive(Clone, Debug, PartialEq, Eq, serde::Serialize, serde::Deserialize)]
pub(super) struct Stamp {
    pub len: u64,
    hash: [u8; 32],
    transport_hash: [u8; 20],
}

impl Stamp {
    pub(super) fn sha1_witness(&self) -> String {
        use std::fmt::Write;
        let mut expected = String::from("sha1:");
        for byte in self.transport_hash {
            let _ = write!(expected, "{byte:02x}");
        }
        let _ = write!(expected, ":{}", self.len);
        expected
    }
}

#[derive(Default)]
struct Hasher {
    len: u64,
    strong: Sha256,
    transport: Sha1,
}

impl Hasher {
    fn add(&mut self, bytes: &[u8]) -> Result<()> {
        self.len += bytes.len() as u64;
        if self.len > MAX_FILE {
            return Err(LIMIT.into());
        }
        self.strong.update(bytes);
        self.transport.update(bytes);
        Ok(())
    }
    fn finish(self) -> Stamp {
        Stamp {
            len: self.len,
            hash: self.strong.finalize().into(),
            transport_hash: self.transport.finalize().into(),
        }
    }
}

pub(super) fn local_copy(mut input: impl Read, mut out: impl Write) -> Result<Stamp> {
    let mut hash = Hasher::default();
    let mut buf = vec![0u8; WRITE_BLOCK];
    loop {
        let n = input.read(&mut buf).map_err(|_| DISK)?;
        if n == 0 {
            break;
        }
        hash.add(&buf[..n])?;
        out.write_all(&buf[..n]).map_err(|_| DISK)?;
    }
    Ok(hash.finish())
}

async fn call<T>(
    control: &SyncControl,
    op: impl Future<Output = std::result::Result<T, IdeviceError>>,
) -> Result<T> {
    control
        .wait(Duration::from_secs(30), async { Ok(op.await) })
        .await
        .map_err(|_| "Kết nối đã dừng hoặc hết thời gian. Hãy mở lại mục patch.")?
        .map_err(|error| match error {
            IdeviceError::Afc(AfcError::PermDenied) => PERMISSION_DENIED.into(),
            IdeviceError::Afc(error) => {
                let reason = error.to_string();
                format!("iOS báo {reason} (AFC {}).", error as u64)
            }
            _ => format!(
                "Không hoàn tất thao tác tệp trên iPhone ({}).",
                error.code()
            ),
        })
}

#[derive(PartialEq, Eq, Debug)]
struct Stat {
    kind: String,
    len: Option<u64>,
    inode: Option<u64>,
    birthtime: Option<String>,
    mtime: Option<String>,
    links: Option<u64>,
}

async fn stat(afc: &mut AfcClient, ctl: &SyncControl, path: &str) -> Result<Option<Stat>> {
    call(ctl, async {
        let raw = match afc.get_file_info_raw(path).await {
            Ok(raw) => raw,
            Err(IdeviceError::Afc(AfcError::ObjectNotFound)) => return Ok(None),
            Err(error) => return Err(error),
        };
        let kind = if raw.contains_key("LinkTarget") || raw.contains_key("st_link_target") {
            "S_IFLNK".to_string()
        } else {
            raw.get("st_ifmt").cloned().unwrap_or_default()
        };
        Ok(Some(Stat {
            kind,
            len: raw.get("st_size").and_then(|v| v.parse().ok()),
            inode: raw.get("st_ino").and_then(|v| v.parse().ok()),
            birthtime: raw.get("st_birthtime").cloned(),
            mtime: raw.get("st_mtime").cloned(),
            links: raw.get("st_nlink").and_then(|v| v.parse().ok()),
        }))
    })
    .await
}

pub(super) fn join(alias: &str, relative: &str) -> String {
    format!("{}/{}", alias.trim_end_matches('/'), relative)
}

pub(super) async fn parents(
    afc: &mut AfcClient,
    ctl: &SyncControl,
    alias: &str,
    rel: &str,
) -> Result<()> {
    let mut path = alias.trim_end_matches('/').to_owned();
    let parts: Vec<_> = rel.split('/').collect();
    for part in &parts[..parts.len() - 1] {
        path.push('/');
        path.push_str(part);
        match stat(afc, ctl, &path).await? {
            Some(parent) if parent.kind == "S_IFDIR" => (),
            Some(parent) if parent.kind.is_empty() => return Err(CHANGED.into()),
            Some(_) => return Err(PARENT_TYPE.into()),
            None => return Err(PARENT_MISSING.into()),
        }
    }
    Ok(())
}

async fn confirm_closed(afc: &mut AfcClient, ctl: &SyncControl, handle: u64) -> Result<()> {
    call(ctl, close_handle(afc, handle))
        .await
        .map_err(|error| format!("Chưa xác nhận được việc đóng tệp trên iPhone. {error}"))
}
async fn file_response<T>(
    afc: &mut AfcClient,
    ctl: &SyncControl,
    handle: u64,
    response: Result<T>,
) -> Result<T> {
    if response
        .as_ref()
        .err()
        .is_some_and(|error| error == PERMISSION_DENIED)
    {
        confirm_closed(afc, ctl, handle).await?;
    }
    response
}

pub(super) async fn missing(afc: &mut AfcClient, ctl: &SyncControl, path: &str) -> Result<bool> {
    Ok(stat(afc, ctl, path).await?.is_none())
}

pub(super) async fn snapshot(
    afc: &mut AfcClient,
    ctl: &SyncControl,
    path: &str,
    out: impl Write,
    budget: u64,
) -> Result<Option<Stamp>> {
    snapshot_internal(afc, ctl, path, out, budget, false).await
}

async fn snapshot_internal(
    afc: &mut AfcClient,
    ctl: &SyncControl,
    path: &str,
    mut out: impl Write,
    budget: u64,
    allow_shared_staging_inode: bool,
) -> Result<Option<Stamp>> {
    let Some(initial) = stat(afc, ctl, path).await? else {
        return Ok(None);
    };
    if initial.kind.is_empty() {
        return Err(CHANGED.into());
    }
    if initial.kind != "S_IFREG"
        || (!allow_shared_staging_inode && initial.links.is_some_and(|n| n > 1))
    {
        return Err(UNSUPPORTED_LEAF.into());
    }
    let len = initial.len.ok_or(CHANGED)?;
    if len > budget.min(MAX_FILE) {
        return Err(LIMIT.into());
    }
    let handle = call(ctl, open_handle(afc, path, AfcFopenMode::RdOnly)).await?;
    let mut hasher = Hasher::default();
    while hasher.len < len {
        let n = (len - hasher.len).min(READ_BLOCK);
        let args = [handle.to_le_bytes(), n.to_le_bytes()].concat();
        let response = call(ctl, afc.send_op(AfcOpcode::Read, args, vec![])).await;
        let data = file_response(afc, ctl, handle, response).await?.payload;
        if data.is_empty() || data.len() as u64 > n {
            return Err(CHANGED.into());
        }
        out.write_all(&data).map_err(|_| DISK)?;
        hasher.add(&data)?;
    }
    confirm_closed(afc, ctl, handle).await?;
    if stat(afc, ctl, path).await?.as_ref() != Some(&initial) {
        return Err(CHANGED.into());
    }
    Ok(Some(hasher.finish()))
}

pub(super) async fn upload(
    afc: &mut AfcClient,
    ctl: &SyncControl,
    path: &str,
    data: &Path,
    stamp: &Stamp,
) -> Result<()> {
    upload_with_witness(afc, ctl, path, data, stamp)
        .await
        .map(|_| ())
}

pub(super) async fn upload_with_witness(
    afc: &mut AfcClient,
    ctl: &SyncControl,
    path: &str,
    data: &Path,
    stamp: &Stamp,
) -> Result<Option<String>> {
    if !missing(afc, ctl, path).await? {
        return Err(CHANGED.into());
    }
    let mut f = read_file(data)?;
    let handle = call(ctl, open_handle(afc, path, AfcFopenMode::WrOnly)).await?;
    let mut buf = vec![0; WRITE_BLOCK];
    let mut hash = Hasher::default();
    loop {
        let n = f.read(&mut buf).map_err(|_| DISK)?;
        if n == 0 {
            break;
        }
        hash.add(&buf[..n])?;
        let response = call(
            ctl,
            afc.send_op(
                AfcOpcode::Write,
                handle.to_le_bytes().to_vec(),
                buf[..n].to_vec(),
            ),
        )
        .await;
        file_response(afc, ctl, handle, response).await?;
    }
    confirm_closed(afc, ctl, handle).await?;
    if hash.finish() != *stamp {
        return Err(DISK.into());
    }
    let transport_hash = call(ctl, async {
        match afc.get_file_hash(path).await {
            Ok(d) => Ok(Some(d)),
            Err(IdeviceError::Afc(AfcError::OpNotSupported | AfcError::UnknownPacketType)) => {
                Ok(None)
            }
            Err(e) => Err(e),
        }
    })
    .await?;
    match transport_hash {
        Some(d) if d.len() == 20 => {
            if d.as_slice() != stamp.transport_hash {
                return Err(CHANGED.into());
            }
            return Ok(Some(stamp.sha1_witness()));
        }
        Some(d) if d.len() == 32 => {
            if d.as_slice() != stamp.hash {
                return Err(CHANGED.into());
            }
        }
        _ => {
            if snapshot(afc, ctl, path, std::io::sink(), MAX_FILE)
                .await?
                .as_ref()
                != Some(stamp)
            {
                return Err(CHANGED.into());
            }
        }
    }
    Ok(None)
}

pub(super) async fn rename(
    afc: &mut AfcClient,
    ctl: &SyncControl,
    from: &str,
    to: &str,
) -> Result<()> {
    call(ctl, afc.rename(from, to)).await
}
pub(super) async fn remove(afc: &mut AfcClient, ctl: &SyncControl, path: &str) -> Result<()> {
    call(ctl, afc.remove(path)).await
}

pub(super) async fn remove_owned_stage(
    afc: &mut AfcClient,
    ctl: &SyncControl,
    path: &str,
    source: &Path,
) -> Result<()> {
    if let Some(s) = snapshot_internal(afc, ctl, path, std::io::sink(), MAX_FILE, true).await? {
        let mut f = read_file(source)?;
        if local_copy((&mut f).take(s.len), std::io::sink())? != s {
            return Err(CHANGED.into());
        }
        remove(afc, ctl, path).await?;
    }
    Ok(())
}

pub(super) async fn create_only(
    afc: &mut AfcClient,
    ctl: &SyncControl,
    from: &str,
    to: &str,
) -> Result<()> {
    call(
        ctl,
        afc.link(from, to, idevice::afc::opcode::LinkType::Hardlink),
    )
    .await?;
    remove(afc, ctl, from).await
}
