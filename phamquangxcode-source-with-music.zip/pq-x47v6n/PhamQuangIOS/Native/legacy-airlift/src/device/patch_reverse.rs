use super::super::airlift::{
    MAX_REVERSE_PLAN_ITEMS, ReversePreflight, ScanFailure, reverse_plan_fits,
};
use super::*;

#[path = "patch_checkpoint.rs"]
mod checkpoint;
pub(super) use checkpoint::{is_checkpoint_file, load_receipt};
use checkpoint::{persist, persist_row};

#[path = "patch_added.rs"]
mod added;
#[path = "patch_compare.rs"]
mod compare;
#[path = "patch_group.rs"]
mod group;
#[path = "patch_opaque.rs"]
mod opaque;
#[path = "patch_prepare.rs"]
mod prepare;
use opaque::Handoff;
use std::sync::{
    Arc,
    atomic::{AtomicBool, Ordering},
};
#[path = "patch_stage.rs"]
mod staging;

const BATCH: usize = MAX_REVERSE_PLAN_ITEMS;
const REUSE_BYTES: u64 = 32 << 20;
const REUSE_WINDOW: Duration = Duration::from_secs(15);

fn single_lease_plan(count: usize, bytes: u64) -> bool {
    (1..=BATCH).contains(&count) && bytes <= REUSE_BYTES
}

fn lease_width(batch: &Batch, indices: &[usize]) -> usize {
    let mut plans = Vec::new();
    let mut bytes = 0u64;
    for &index in indices.iter().take(BATCH) {
        let row = &batch.items[index];
        let next = bytes.saturating_add(row.replacement.len);
        if !plans.is_empty() && next > REUSE_BYTES {
            break;
        }
        plans.push((row.rel.clone(), row.key.clone()));
        if !reverse_plan_fits(&plans) {
            plans.pop();
            break;
        }
        bytes = next;
    }
    plans.len().max(usize::from(!indices.is_empty()))
}
const RECEIPT: &str = "reverse.json";
const IDENTITY: &str =
    "Ứng dụng đã đổi bản cài hoặc thư mục dữ liệu. CC365 giữ bản sao để khôi phục đúng ứng dụng.";
const UNCERTAIN: &str = "Trạng thái tệp chưa khớp phiên đã lưu. CC365 đã giữ bản gốc và dừng.";
const RECOVER: &str = "Hãy mở lại mục patch của ứng dụng và bấm Khôi phục bản gốc.";
const RECEIPT_VERSION: u8 = 1;
const CHECKPOINT_VERSION: u8 = 2;

#[derive(Debug, Clone, Copy, PartialEq, Eq, Serialize, Deserialize)]
#[serde(rename_all = "snake_case")]
enum Phase {
    Probing,
    Comparing,
    Waiting,
    Staging,
    Staged,
    Moving,
    Installed,
    Restoring,
    Omitted,
    Skipped,
    Settled,
}

#[derive(Serialize, Deserialize)]
struct Item {
    rel: String,
    key: String,
    original_witness: String,
    #[serde(default, skip_serializing_if = "Option::is_none")]
    omission: Option<String>,
    #[serde(default, skip_serializing_if = "Option::is_none")]
    added: Option<added::Created>,
    replacement: Stamp,
    replacement_witness: Option<String>,
    original: Option<Stamp>,
    handoff: Option<Handoff>,
    cargo: Option<String>,
    foreign_cargo: Option<String>,
    #[serde(default)]
    rebuilding_held: bool,
    return_witness: Option<String>,
    phase: Phase,
}

#[derive(Serialize, Deserialize)]
pub(super) struct Batch {
    #[serde(default, skip_serializing_if = "Option::is_none")]
    generation: Option<String>,
    version: u8,
    identity: String,
    root: String,
    items: Vec<Item>,
    state: String,
}

fn witness_size(witness: &str) -> Result<u64> {
    let valid = |v: &str| !v.is_empty() && v.len() <= 20 && v.bytes().all(|c| c.is_ascii_digit());
    let parts: Vec<_> = witness.split(':').collect();
    let size = match parts.as_slice() {
        ["sha1", hash, len] if hash.len() == 40 && hash.bytes().all(|c| c.is_ascii_hexdigit()) => {
            *len
        }
        ["ino", ino, modified, len]
            if valid(ino)
                && valid(modified)
                && ino.parse::<u64>().is_ok_and(|n| n > 0)
                && modified.parse::<u64>().is_ok_and(|n| n > 0) =>
        {
            *len
        }
        _ => return Err(UNCERTAIN.into()),
    };
    if !valid(size) {
        return Err(UNCERTAIN.into());
    }
    size.parse().map_err(|_| UNCERTAIN.into())
}

fn valid_key(s: &str) -> bool {
    s.len() == 32
        && s.bytes()
            .all(|b| b.is_ascii_digit() || (b'a'..=b'f').contains(&b))
}

fn validate(batch: &Batch) -> Result<()> {
    let expected_version = if batch.generation.is_some() {
        CHECKPOINT_VERSION
    } else {
        RECEIPT_VERSION
    };
    if batch.version != expected_version
        || batch.identity.is_empty()
        || batch.root.is_empty()
        || batch.items.is_empty()
        || batch.items.len() > MAX_ITEMS
        || !matches!(batch.state.as_str(), "pending" | "applied" | "restored")
    {
        return Err(DISK.into());
    }
    let mut keys = HashSet::new();
    let mut paths = HashSet::new();
    let mut old_bytes = 0u64;
    let mut new_bytes = 0u64;
    for row in &batch.items {
        let opaque = row.original_witness == "opaque";
        let missing = row.original_witness == "missing";
        let omitted = row.phase == Phase::Omitted;
        let unavailable = row.original_witness == "unavailable";
        let reason_valid = row
            .omission
            .as_deref()
            .is_some_and(|s| !s.is_empty() && s.len() <= 1024 && !s.chars().any(char::is_control));
        if omitted != row.omission.is_some()
            || (omitted && !reason_valid)
            || (unavailable && !omitted)
            || (omitted
                && (row.original.is_some()
                    || row.added.is_some()
                    || row.replacement_witness.is_some()
                    || row.handoff.is_some()
                    || row.foreign_cargo.is_some()
                    || row.cargo.is_some()
                    || row.return_witness.is_some()
                    || row.rebuilding_held))
        {
            return Err(DISK.into());
        }
        let len = if opaque || missing || unavailable {
            row.original.as_ref().map_or(0, |stamp| stamp.len)
        } else {
            witness_size(&row.original_witness)?
        };
        if !relative_ok(&row.rel)
            || !row.rel.starts_with("Documents/")
            || !valid_key(&row.key)
            || !keys.insert(&row.key)
            || !paths.insert(row.rel.to_lowercase())
            || len > MAX_FILE
            || row.replacement.len > MAX_FILE
            || row.original.as_ref().is_some_and(|s| s.len != len)
            || row
                .replacement_witness
                .as_deref()
                .is_some_and(|w| witness_size(w) != Ok(row.replacement.len))
            || matches!(
                row.phase,
                Phase::Staged | Phase::Moving | Phase::Installed | Phase::Restoring
            ) && row.replacement_witness.is_none()
            || row
                .return_witness
                .as_deref()
                .is_some_and(|w| witness_size(w) != Ok(len))
            || !compare::valid(row)
            || !added::valid(row)
            || !opaque
                && !missing
                && (row.handoff.is_some() || row.cargo.is_some() || row.foreign_cargo.is_some())
            || (row.rebuilding_held || row.return_witness.is_some()) && row.original.is_none()
            || !missing && row.phase == Phase::Installed && row.original.is_none()
            || batch.state == "applied"
                && !matches!(
                    row.phase,
                    Phase::Installed | Phase::Skipped | Phase::Omitted
                )
            || batch.state == "restored"
                && !matches!(row.phase, Phase::Settled | Phase::Skipped | Phase::Omitted)
        {
            return Err(DISK.into());
        }
        if !omitted {
            old_bytes += len;
        }
        new_bytes += row.replacement.len;
    }
    if old_bytes > MAX_TOTAL || new_bytes > MAX_TOTAL {
        return Err(LIMIT.into());
    }
    Ok(())
}

fn needs_restore(row: &Item) -> bool {
    !matches!(
        row.phase,
        Phase::Waiting | Phase::Omitted | Phase::Skipped | Phase::Settled
    )
}

pub(super) fn report(batch: &Batch) -> Value {
    let restore_paths: Vec<_> = batch
        .items
        .iter()
        .rev()
        .filter(|row| needs_restore(row))
        .map(|row| row.rel.as_str())
        .collect();
    let created = batch
        .items
        .iter()
        .filter(|row| row.added.as_ref().is_some_and(|file| file.placed))
        .count();
    let preserved = batch
        .items
        .iter()
        .filter(|row| row.added.as_ref().is_some_and(|file| file.preserved))
        .count();
    let changed = batch
        .items
        .iter()
        .filter(|i| {
            i.phase == Phase::Installed
                || (i.phase == Phase::Settled
                    && (i.original.is_some() || i.added.as_ref().is_some_and(|file| file.placed)))
        })
        .count();
    let omitted: Vec<_> = batch
        .items
        .iter()
        .filter_map(|row| {
            row.omission
                .as_ref()
                .map(|reason| json!({"path":row.rel,"reason":reason}))
        })
        .collect();
    let skipped = batch
        .items
        .iter()
        .filter(|i| i.phase == Phase::Skipped)
        .count();
    let bytes: u64 = batch
        .items
        .iter()
        .filter(|i| i.phase == Phase::Installed)
        .map(|i| i.replacement.len)
        .sum();
    let message = match batch.state.as_str() {
        "applied" => {
            "AirLift đã thay tệp trong Documents và xác minh tại đường dẫn đích. Đã giữ bản gốc."
        }
        "restored" => "AirLift đã trả bản gốc về đúng đường dẫn và xác minh tệp.",
        _ => RECOVER,
    };
    let opaque_items = batch
        .items
        .iter()
        .filter(|item| item.original_witness == "opaque")
        .count();
    let message = if opaque_items > 0 && batch.state == "applied" {
        "AirLift đã đọc lại bản thay trong Media, đối chiếu SHA-256 rồi gửi về đúng đường dẫn. Với tệp riêng, iOS chỉ xác nhận sự hiện diện ở lần giao cuối."
    } else if opaque_items > 0 && batch.state == "restored" {
        "AirLift đã trả các bản gốc. Với tệp riêng, iOS xác nhận sự hiện diện ở lần giao cuối."
    } else {
        message
    };
    let message = match batch.state.as_str() {
        "applied" if created > 0 => format!(
            "AirLift đã thêm {created} tệp mới và kiểm tra SHA-256 của nội dung đưa về từ đường dẫn đích. Các tệp có sẵn đã thay đều có bản sao lưu."
        ),
        "restored" if preserved > 0 => format!(
            "Đã hoàn tất khôi phục. CC365 giữ lại {preserved} tệp do ứng dụng tạo hoặc chỉnh sửa sau đó."
        ),
        "restored" if created > 0 => {
            "CC365 đã khôi phục các tệp có bản gốc và dọn các tệp mới của patch.".to_owned()
        }
        _ => message.to_owned(),
    };
    json!({"restore_paths":restore_paths,"omitted":omitted.len(),"omitted_items":omitted,"created":created,"preserved":preserved,"opaque_items":opaque_items,"state":batch.state, "changed":changed, "skipped":skipped, "bytes":bytes,
           "message":message, "transport":"airlift_reverse_documents"})
}

fn omission_reason(reason: &str) -> String {
    let mut clean = String::new();
    for word in reason
        .split(|ch: char| ch.is_whitespace() || ch.is_control())
        .filter(|s| !s.is_empty())
    {
        if !clean.is_empty() && clean.len() < 1024 {
            clean.push(' ');
        }
        for ch in word.chars() {
            if clean.len() + ch.len_utf8() > 1024 {
                return clean.trim_end().to_owned();
            }
            clean.push(ch);
        }
    }
    if clean.trim().is_empty() {
        "iOS từ chối thao tác với mục này.".into()
    } else {
        clean.trim_end().to_owned()
    }
}

fn omit_row(slot: &Path, batch: &mut Batch, index: usize, reason: &str) -> Result<()> {
    let row = batch.items.get_mut(index).ok_or(INVALID)?;
    if !matches!(row.phase, Phase::Waiting | Phase::Settled) {
        return Err(UNCERTAIN.into());
    }
    row.phase = Phase::Omitted;
    row.omission = Some(omission_reason(reason));
    row.original = None;
    row.replacement_witness = None;
    row.added = None;
    row.handoff = None;
    row.cargo = None;
    row.foreign_cargo = None;
    row.rebuilding_held = false;
    row.return_witness = None;
    persist_row(slot, batch, index)
}

fn report_progress(ctl: &SyncControl, phase: &str, batch: &Batch, apply: bool, index: usize) {
    let total = batch.items.len();
    let done = batch
        .items
        .iter()
        .filter(|row| match row.phase {
            Phase::Skipped | Phase::Omitted => true,
            Phase::Installed => apply,
            Phase::Settled => !apply,
            _ => false,
        })
        .count()
        .min(total.saturating_sub(1));
    let path = batch.items.get(index).map_or("", |row| row.rel.as_str());
    ctl.patch_progress(phase, done, total, path);
}

async fn clear_verified_stage(
    link: &mut PatchLink,
    ctl: &SyncControl,
    replacement: &Stamp,
) -> Result<()> {
    let path = link.reverse_stage_path()?;
    match io::snapshot(
        link.reverse_media_afc()?,
        ctl,
        &path,
        std::io::sink(),
        MAX_FILE,
    )
    .await?
    {
        Some(observed) if observed == *replacement => {
            io::remove(link.reverse_media_afc()?, ctl, &path).await
        }
        Some(_) => Err(CONFLICT.into()),
        None => Ok(()),
    }
}

fn same_root(a: &str, b: &str) -> bool {
    a.strip_prefix("/private/var/")
        .or_else(|| a.strip_prefix("/var/"))
        .zip(
            b.strip_prefix("/private/var/")
                .or_else(|| b.strip_prefix("/var/")),
        )
        .is_some_and(|(a, b)| a == b)
}

impl DeviceSession {
    async fn plan_reverse(
        &mut self,
        bundle: &str,
        expected: Option<&str>,
        items: &[PatchItem],
        slot: &Path,
    ) -> Result<(Batch, Option<PatchLink>)> {
        let available = available_storage(slot)?;
        let sources = prepare::Sources::inspect(items, available, &self.control).await?;
        let input_bytes = sources.bytes;
        let plans: Vec<_> = items
            .iter()
            .map(|item| (item.relative_path.clone(), token()))
            .collect();
        let share = single_lease_plan(plans.len(), input_bytes) && reverse_plan_fits(&plans);
        let mut link = if share {
            self.open_reverse_batch(bundle, &plans).await?
        } else {
            self.open_patch_link_with_slots(bundle, "data", 0, true)
                .await?
        };
        let opened = std::time::Instant::now();
        let plan = async {
            if expected.is_some_and(|path| !same_root(path, &link.absolute_root)) {
                return Err(IDENTITY.into());
            }
            let stop = Arc::new(AtomicBool::new(false));
            let control = self.control.clone();
            let check_originals = async {
                let names: Vec<_> = items
                    .iter()
                    .map(|item| item.relative_path.clone())
                    .collect();
                let mut readers = self.preflight_readers(&link, bundle, names.len()).await?;
                let classifications = link
                    .reverse_scan_readers(&mut readers, &names, &control, &stop)
                    .await?;
                let mut witnesses = Vec::with_capacity(items.len());
                let mut old_total = 0;
                for classification in classifications {
                    let witness = match classification {
                        ReversePreflight::Ready(witness) => witness,
                        ReversePreflight::Unavailable(reason) => {
                            witnesses
                                .push(("unavailable".to_owned(), Some(omission_reason(&reason))));
                            continue;
                        }
                    };
                    let size = if matches!(witness.as_str(), "opaque" | "missing") {
                        0
                    } else {
                        witness_size(&witness)?
                    };
                    if size > MAX_FILE || size > MAX_TOTAL - old_total {
                        witnesses.push((
                            "unavailable".to_owned(),
                            Some("Bản gốc vượt dung lượng sao lưu còn lại của lượt này.".into()),
                        ));
                        continue;
                    }
                    old_total += size;
                    if old_total + input_bytes > available {
                        return Err(ScanFailure::Failed(DISK.to_owned()));
                    }
                    witnesses.push((witness, None));
                }
                Ok::<_, ScanFailure>((witnesses, old_total))
            };
            let read_originals = async {
                check_originals
                    .await
                    .inspect_err(|_| stop.store(true, Ordering::Release))
            };
            let copy_sources = sources.stage(slot, &control, stop.clone(), prepare::WORKERS);
            let (witnesses, stamps) = tokio::join!(read_originals, copy_sources);
            let (witnesses, known_original_bytes) = match witnesses {
                Ok(complete) => complete,
                Err(failure) => return Err(failure.reason(stamps.err())),
            };
            let stamps = stamps?;
            if witnesses.len() != items.len() || stamps.len() != items.len() {
                return Err(DISK.into());
            }
            let absent_stamp = io::local_copy(&[][..], std::io::sink())?;
            let rows = plans
                .into_iter()
                .zip(witnesses)
                .zip(stamps)
                .map(|(((rel, key), (witness, omission)), input)| {
                    let (witness, omission, replacement) = match input {
                        prepare::Prepared::Ready(stamp) => (witness, omission, stamp),
                        prepare::Prepared::Unavailable(reason) => (
                            "unavailable".into(),
                            Some(reason.into()),
                            absent_stamp.clone(),
                        ),
                    };
                    Item {
                        rel,
                        key,
                        original_witness: witness,
                        added: None,
                        replacement,
                        replacement_witness: None,
                        original: None,
                        handoff: None,
                        cargo: None,
                        foreign_cargo: None,
                        rebuilding_held: false,
                        return_witness: None,
                        phase: if omission.is_some() {
                            Phase::Omitted
                        } else {
                            Phase::Waiting
                        },
                        omission,
                    }
                })
                .collect();
            let mut batch = Batch {
                generation: None,
                version: RECEIPT_VERSION,
                identity: link.identity.clone(),
                root: link.absolute_root.clone(),
                items: rows,
                state: "pending".into(),
            };
            validate(&batch)?;
            self.control
                .check()
                .map_err(|_| "Đã dừng chuẩn bị patch.")?;
            persist(slot, &mut batch)?;
            for (index, row) in batch.items.iter().enumerate() {
                if row.phase == Phase::Omitted {
                    report_progress(&self.control, "omitted", &batch, true, index);
                }
            }
            Ok((batch, known_original_bytes))
        }
        .await;
        match plan {
            Ok((batch, original_bytes))
                if share
                    && batch.items.iter().all(|row| row.phase != Phase::Omitted)
                    && input_bytes + original_bytes <= REUSE_BYTES
                    && opened.elapsed() < REUSE_WINDOW =>
            {
                Ok((batch, Some(link)))
            }
            result => match (result, self.close_patch_link(link).await) {
                (Ok((batch, _)), Ok(())) => Ok((batch, None)),
                (Err(e), Err(cleanup)) => Err(format!("{e} {cleanup}")),
                (Err(e), _) | (_, Err(e)) => Err(e),
            },
        }
    }

    pub(super) async fn reverse_documents(
        &mut self,
        action: &str,
        bundle: &str,
        expected: Option<&str>,
        items: &[PatchItem],
        slot: &Path,
        prior: Option<Batch>,
    ) -> Result<Value> {
        let prior = match prior {
            Some(j) if j.state == "restored" => {
                remove_slot(slot)?;
                directory(slot)?;
                None
            }
            other => other,
        };
        let started = std::time::Instant::now();
        let (mut batch, first_lease) = match (action, prior) {
            ("status", Some(j)) => return Ok(report(&j)),
            ("status" | "restore", None) => return Ok(receipt(None, "none", "")),
            ("apply", Some(_)) => return Err(PENDING.into()),
            ("restore", Some(mut j)) => {
                j.state = "pending".into();
                persist(slot, &mut j)?;
                (j, None)
            }
            ("apply", None) => {
                remove_slot(slot)?;
                directory(slot)?;
                sync_dir(slot.parent().ok_or(DISK)?)?;
                match self.plan_reverse(bundle, expected, items, slot).await {
                    Ok(planned) => planned,
                    Err(e) => {
                        remove_slot(slot)?;
                        return Err(e);
                    }
                }
            }
            _ => return Err(INVALID.into()),
        };
        let apply = action == "apply";
        let result = self
            .drive_reverse(bundle, slot, &mut batch, apply, first_lease)
            .await;
        if let Err(e) = result {
            if e.contains(DISK) {
                return Err(format!("{e} {RECOVER}"));
            }
            if apply
                && batch.items.iter().all(|item| {
                    matches!(item.phase, Phase::Waiting | Phase::Skipped | Phase::Omitted)
                })
            {
                remove_slot(slot)?;
                return Err(e);
            }
            return Err(format!("{e} {RECOVER}"));
        }
        report_progress(&self.control, "finishing", &batch, apply, usize::MAX);
        let no_changes = apply
            && batch
                .items
                .iter()
                .all(|row| matches!(row.phase, Phase::Skipped | Phase::Omitted));
        batch.state = if apply && !no_changes {
            "applied"
        } else {
            "restored"
        }
        .into();
        persist(slot, &mut batch)?;
        let mut value = report(&batch);
        if no_changes {
            value["state"] = json!("unchanged");
            value["message"] = if batch.items.iter().any(|row| row.phase == Phase::Omitted) {
                json!("Đã kiểm tra xong các tệp. Xem lý do trong mục Tệp bỏ qua.")
            } else {
                json!("Các tệp đích đã khớp nội dung.")
            };
            remove_slot(slot)?;
        } else if !apply {
            remove_slot(slot)?;
        }
        self.control
            .patch_progress("complete", batch.items.len(), batch.items.len(), "");
        value["elapsed_ms"] = json!(started.elapsed().as_millis().min(u64::MAX as u128) as u64);
        Ok(value)
    }

    async fn drive_reverse(
        &mut self,
        bundle: &str,
        slot: &Path,
        batch: &mut Batch,
        apply: bool,
        mut first_lease: Option<PatchLink>,
    ) -> Result<()> {
        let mut order: Vec<_> = (0..batch.items.len())
            .filter(|&i| batch.items[i].phase != Phase::Omitted)
            .collect();
        if !apply {
            order.reverse();
            for row in &mut batch.items {
                if row.phase == Phase::Waiting {
                    row.phase = Phase::Settled;
                }
            }
            persist(slot, batch)?;
            order.retain(|&i| needs_restore(&batch.items[i]));
        }
        let mut conflicts = Vec::new();
        let mut workers = compare::ReadPool::default();
        let mut remaining = order.as_slice();
        while !remaining.is_empty() {
            let width = lease_width(batch, remaining);
            let (indices, rest) = remaining.split_at(width);
            remaining = rest;
            let plans: Vec<_> = indices
                .iter()
                .map(|&i| (batch.items[i].rel.clone(), batch.items[i].key.clone()))
                .collect();
            let mut link = match first_lease.take() {
                Some(link) => link,
                None => self.open_reverse_batch(bundle, &plans).await?,
            };
            let step = async {
                self.control.check().map_err(|_| "Đã dừng phiên AirLift.")?;
                if link.identity != batch.identity
                    || !same_root(&link.absolute_root, &batch.root)
                    || !link.declares_reverse_plan(&plans)
                {
                    return Err(IDENTITY.into());
                }
                link.verify().await?;
                if apply {
                    self.refresh_compare_pool(&mut workers).await?;
                    self.stage_reverse_batch(&mut link, slot, batch, indices, true)
                        .await?;
                }
                let mut pending = indices;
                while !pending.is_empty() {
                    let width = if apply {
                        compare::window(
                            batch,
                            pending,
                            if workers.upgraded {
                                super::super::airlift::MAX_GROUP_HANDOFFS
                            } else {
                                6
                            },
                        )
                    } else {
                        1
                    };
                    let (group, rest) = pending.split_at(width);
                    pending = rest;
                    if apply && compare::eligible(&batch.items[group[0]]) {
                        self.compare_originals(&mut link, slot, batch, group, &mut workers)
                            .await?;
                    }
                    for &idx in group {
                        if matches!(batch.items[idx].phase, Phase::Omitted | Phase::Skipped)
                            || apply && batch.items[idx].phase == Phase::Installed
                        {
                            continue;
                        }
                        let row = &batch.items[idx];
                        self.control.check().map_err(|_| "Đã dừng phiên AirLift.")?;
                        link.select_reverse_doc(&row.rel, &row.key)?;
                        report_progress(
                            &self.control,
                            if apply { "applying" } else { "restoring" },
                            batch,
                            apply,
                            idx,
                        );
                        let mut step = self
                            .process_reverse_item(&mut link, slot, batch, idx, apply)
                            .await;
                        if apply {
                            step = self
                                .handle_apply_result(&mut link, slot, batch, idx, step)
                                .await;
                        }
                        if !apply && matches!(step.as_ref(), Err(error) if error == CONFLICT) {
                            conflicts.push(batch.items[idx].rel.clone());
                            continue;
                        }
                        step.map_err(|e| format!("{}\n{e}", batch.items[idx].rel))?;
                        let phase = match batch.items[idx].phase {
                            Phase::Omitted => "omitted",
                            Phase::Skipped => "unchanged",
                            Phase::Installed => "applied",
                            _ if batch.items[idx]
                                .added
                                .as_ref()
                                .is_some_and(|file| file.preserved) =>
                            {
                                "preserved"
                            }
                            _ => "restored",
                        };
                        report_progress(&self.control, phase, batch, apply, idx);
                    }
                }
                Ok(())
            }
            .await;
            let close = self.close_patch_link(link).await;
            match (step, close) {
                (Err(e), Err(c)) => return Err(format!("{e} {c}")),
                (Err(e), _) | (_, Err(e)) => return Err(e),
                _ => (),
            }
        }
        if !conflicts.is_empty() {
            let shown = &conflicts[..conflicts.len().min(8)];
            return Err(format!(
                "Còn {} tệp cần khôi phục. {CONFLICT}\n{}",
                conflicts.len(),
                shown.join("\n")
            ));
        }
        Ok(())
    }

    async fn handle_apply_result(
        &mut self,
        link: &mut PatchLink,
        slot: &Path,
        batch: &mut Batch,
        i: usize,
        result: Result<()>,
    ) -> Result<()> {
        let Err(reason) = result else {
            return Ok(());
        };
        if !matches!(
            reason.as_str(),
            CONFLICT | LIMIT | io::PERMISSION_DENIED | io::CHANGED | io::UNSUPPORTED_LEAF
        ) && !PatchLink::is_local_patch_refusal(&reason)
        {
            return Err(reason);
        }
        if batch.items[i].phase != Phase::Waiting {
            self.process_reverse_item(link, slot, batch, i, false)
                .await?;
        }
        let explanation = if matches!(reason.as_str(), CONFLICT | io::CHANGED) {
            "Tệp đã thay đổi trong lúc áp dụng."
        } else {
            &reason
        };
        omit_row(slot, batch, i, explanation)
    }

    async fn process_reverse_item(
        &mut self,
        link: &mut PatchLink,
        slot: &Path,
        batch: &mut Batch,
        idx: usize,
        apply: bool,
    ) -> Result<()> {
        match (batch.items[idx].original_witness.as_str(), apply) {
            ("missing", true) => self.install_added(link, slot, batch, idx).await,
            ("missing", false) => self.restore_added(link, slot, batch, idx).await,
            ("opaque", true) => self.install_opaque(link, slot, batch, idx).await,
            ("opaque", false) => self.restore_opaque(link, slot, batch, idx).await,
            (_, true) => self.install_reverse(link, slot, batch, idx).await,
            (_, false) => self.rollback_reverse(link, slot, batch, idx).await,
        }
    }

    async fn install_reverse(
        &mut self,
        link: &mut PatchLink,
        slot: &Path,
        batch: &mut Batch,
        i: usize,
    ) -> Result<()> {
        let ctl = self.control.clone();
        let old = batch.items[i].original_witness.clone();
        let new = batch.items[i]
            .replacement_witness
            .clone()
            .ok_or(UNCERTAIN)?;
        if batch.items[i].phase != Phase::Staged
            || !link.reverse_matches(false, &old).await?
            || link.reverse_leaf_inode(true).await?.is_some()
            || !link.stage_matches(&new).await?
        {
            return Err(CONFLICT.into());
        }
        let stamp = batch.items[i].replacement.clone();
        batch.items[i].phase = Phase::Moving;
        persist_row(slot, batch, i)?;
        self.reverse_move_original(link, false, &old).await?;
        let held = link.reverse_media_path()?;
        let mut out = new_file(&artifact(slot, i, true))?;
        let original = io::snapshot(
            link.reverse_media_afc()?,
            &ctl,
            &held,
            &mut out,
            witness_size(&old)?,
        )
        .await?
        .ok_or(UNCERTAIN)?;
        if original.len != witness_size(&old)? || !link.reverse_matches(true, &old).await? {
            return Err(CONFLICT.into());
        }
        out.sync_all().map_err(|_| DISK)?;
        drop(out);
        batch.items[i].original = Some(original.clone());
        persist_row(slot, batch, i)?;
        ctl.log("AirLift reverse: original backup persisted.");
        ctl.check().map_err(|_| "Đã dừng sau khi lưu bản gốc.")?;
        if original == stamp {
            self.reverse_move_original(link, true, &old).await?;
            clear_verified_stage(link, &ctl, &stamp).await?;
            batch.items[i].phase = Phase::Skipped;
        } else {
            self.reverse_install_stage(link, &new).await?;
            batch.items[i].phase = Phase::Installed;
        }
        persist_row(slot, batch, i)
    }

    async fn rebuild_held_if_needed(
        &mut self,
        link: &mut PatchLink,
        slot: &Path,
        batch: &mut Batch,
        i: usize,
    ) -> Result<()> {
        let row = &batch.items[i];
        let Some(original) = row.original.clone() else {
            return Ok(());
        };
        let old = row
            .return_witness
            .as_ref()
            .unwrap_or(&row.original_witness)
            .clone();
        if !row.rebuilding_held {
            let have_held = link.reverse_leaf_inode(true).await?.is_some();
            if have_held || link.reverse_matches(false, &old).await? {
                return Ok(());
            }
        }
        let target = link.reverse_leaf_inode(false).await?;
        let expected_new = row.replacement_witness.as_ref().ok_or(UNCERTAIN)?;
        if target.is_some() && !link.reverse_matches(false, expected_new).await? {
            return Err(CONFLICT.into());
        }
        self.rebuild_owned_backup(link, slot, batch, i, &original, &old)
            .await
    }

    async fn rebuild_owned_backup(
        &mut self,
        link: &mut PatchLink,
        slot: &Path,
        batch: &mut Batch,
        i: usize,
        original: &Stamp,
        old: &str,
    ) -> Result<()> {
        let held = link.reverse_media_path()?;
        let ctl = self.control.clone();
        let local = artifact(slot, i, true);
        if io::local_copy(read_file(&local)?, std::io::sink())? != *original {
            return Err(DISK.into());
        }
        if !batch.items[i].rebuilding_held {
            batch.items[i].rebuilding_held = true;
            persist_row(slot, batch, i)?;
        }
        let copy = io::snapshot(
            link.reverse_media_afc()?,
            &ctl,
            &held,
            std::io::sink(),
            MAX_FILE,
        )
        .await?;
        if copy.as_ref() != Some(original) {
            if copy.is_some() {
                io::remove_owned_stage(link.reverse_media_afc()?, &ctl, &held, &local).await?;
            }
            io::upload(link.reverse_media_afc()?, &ctl, &held, &local, original).await?;
            if io::snapshot(
                link.reverse_media_afc()?,
                &ctl,
                &held,
                std::io::sink(),
                original.len,
            )
            .await?
            .as_ref()
                != Some(original)
            {
                return Err(CONFLICT.into());
            }
        }
        let actual = link.reverse_held_witness_as(old).await?.ok_or(UNCERTAIN)?;
        if witness_size(&actual)? != original.len {
            return Err(CONFLICT.into());
        }
        batch.items[i].return_witness = Some(actual);
        if batch.items[i].original_witness == "opaque" {
            batch.items[i].cargo = Some(
                link.reverse_opaque_cargo_witness(true)
                    .await?
                    .ok_or(UNCERTAIN)?,
            );
        }
        batch.items[i].rebuilding_held = false;
        persist_row(slot, batch, i)
    }

    async fn rollback_reverse(
        &mut self,
        link: &mut PatchLink,
        slot: &Path,
        batch: &mut Batch,
        i: usize,
    ) -> Result<()> {
        let ctl = self.control.clone();
        let row = &batch.items[i];
        let stage = link.reverse_stage_path()?;
        let held = link.reverse_media_path()?;
        let replacement_data = artifact(slot, i, false);
        if row.phase == Phase::Staged {
            clear_verified_stage(link, &ctl, &row.replacement).await?;
            batch.items[i].phase = Phase::Settled;
            return persist_row(slot, batch, i);
        }
        if row.phase == Phase::Staging {
            io::remove_owned_stage(link.reverse_media_afc()?, &ctl, &stage, &replacement_data)
                .await?;
            batch.items[i].phase = Phase::Settled;
            return persist_row(slot, batch, i);
        }
        self.rebuild_held_if_needed(link, slot, batch, i).await?;
        let row = &batch.items[i];
        let old = row
            .return_witness
            .as_ref()
            .unwrap_or(&row.original_witness)
            .clone();
        let new = row.replacement_witness.clone().ok_or(UNCERTAIN)?;
        let original_stamp = row.original.clone();
        let new_stamp = row.replacement.clone();
        let have_held = link.reverse_leaf_inode(true).await?.is_some();
        let have_target = link.reverse_leaf_inode(false).await?.is_some();
        let target_is_old = have_target && link.reverse_matches(false, &old).await?;
        let target_is_new =
            have_target && !target_is_old && link.reverse_matches(false, &new).await?;
        let resolution = locate_original(have_held, have_target, target_is_old, target_is_new)?;
        if resolution != Resolution::AlreadyReturned {
            if !link.reverse_matches(true, &old).await? {
                return Err(CONFLICT.into());
            }
            if let Some(stamp) = original_stamp.as_ref() {
                let observed = io::snapshot(
                    link.reverse_media_afc()?,
                    &ctl,
                    &held,
                    std::io::sink(),
                    stamp.len,
                )
                .await?;
                if observed.as_ref() != Some(stamp) {
                    return Err(CONFLICT.into());
                }
            }
            batch.items[i].phase = Phase::Restoring;
            persist_row(slot, batch, i)?;
            if resolution == Resolution::EvictReplacement {
                if link.reverse_stage_witness().await?.is_some() {
                    return Err(CONFLICT.into());
                }
                self.reverse_evict_stage(link, &new).await?;
                let evicted = io::snapshot(
                    link.reverse_media_afc()?,
                    &ctl,
                    &stage,
                    std::io::sink(),
                    MAX_FILE,
                )
                .await?;
                if evicted.as_ref() != Some(&new_stamp) {
                    if link.stage_matches(&new).await? {
                        self.reverse_install_stage(link, &new).await?;
                    }
                    return Err(CONFLICT.into());
                }
            } else if link.reverse_stage_witness().await?.is_some() {
                let evicted = io::snapshot(
                    link.reverse_media_afc()?,
                    &ctl,
                    &stage,
                    std::io::sink(),
                    MAX_FILE,
                )
                .await?;
                if evicted.as_ref() != Some(&new_stamp) {
                    return Err(CONFLICT.into());
                }
            }
            self.reverse_move_original(link, true, &old).await?;
        }
        if !link.reverse_matches(false, &old).await?
            || link.reverse_leaf_inode(true).await?.is_some()
        {
            return Err(UNCERTAIN.into());
        }
        clear_verified_stage(link, &ctl, &new_stamp).await?;
        batch.items[i].phase = Phase::Settled;
        persist_row(slot, batch, i)
    }
}

#[derive(PartialEq, Eq, Debug)]
enum Resolution {
    AlreadyReturned,
    Vacant,
    EvictReplacement,
}

fn locate_original(held: bool, target: bool, old: bool, new: bool) -> Result<Resolution> {
    match (held, target, old, new) {
        (false, true, true, _) => Ok(Resolution::AlreadyReturned),
        (true, false, false, false) => Ok(Resolution::Vacant),
        (true, true, false, true) => Ok(Resolution::EvictReplacement),
        _ => Err(UNCERTAIN.into()),
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn reverse_planner_uses_one_lease_only_when_the_entire_batch_fits() {
        assert!(single_lease_plan(1, 0));
        assert!(single_lease_plan(BATCH, REUSE_BYTES));
        assert!(!single_lease_plan(0, 0));
        assert!(!single_lease_plan(BATCH + 1, 0));
        assert!(!single_lease_plan(1, REUSE_BYTES + 1));
    }

    fn many_small_files(count: usize) -> Batch {
        let mut batch = plan();
        batch.items.clear();
        for index in 0..count {
            let mut row = plan().items.pop().unwrap();
            row.rel = format!("Documents/Resources/asset-{index:04}.bin");
            row.key = format!("{index:032x}");
            row.replacement.len = 32 * 1024;
            batch.items.push(row);
        }
        batch
    }

    fn lease_partition(batch: &Batch, order: &[usize]) -> Vec<Vec<usize>> {
        let mut leases = vec![];
        let mut remaining = order;
        while !remaining.is_empty() {
            let count = lease_width(batch, remaining);
            let (members, rest) = remaining.split_at(count);
            assert!((1..=MAX_REVERSE_PLAN_ITEMS).contains(&count));
            let plans: Vec<_> = members
                .iter()
                .map(|&i| (batch.items[i].rel.clone(), batch.items[i].key.clone()))
                .collect();
            assert!(reverse_plan_fits(&plans));
            let bytes: u64 = members
                .iter()
                .map(|&i| batch.items[i].replacement.len)
                .sum();
            assert!(count == 1 || bytes <= REUSE_BYTES);
            leases.push(members.to_vec());
            remaining = rest;
        }
        assert_eq!(leases.iter().flatten().copied().collect::<Vec<_>>(), order);
        leases
    }

    #[test]
    fn small_file_leases_reduce_bootstraps_without_enlarging_handoff_waves() {
        assert_eq!(super::super::super::airlift::MAX_GROUP_HANDOFFS, 8);
        for (count, expected) in [(336, 11), (522, 17)] {
            let batch = many_small_files(count);
            let order: Vec<_> = (0..count).collect();
            let leases = lease_partition(&batch, &order);
            assert_eq!(leases.len(), expected);
            assert_eq!(leases[0].len(), 32);
            let backwards: Vec<_> = order.into_iter().rev().collect();
            assert_eq!(lease_partition(&batch, &backwards).len(), expected);
        }
    }

    #[test]
    fn lease_partition_shrinks_for_encoded_paths_and_isolates_large_files() {
        let mut batch = many_small_files(32);
        let segment = "\"".repeat(230);
        for (index, row) in batch.items.iter_mut().enumerate() {
            row.rel = format!("Documents/{segment}/{segment}/{segment}/{segment}/a{index}");
        }
        let order: Vec<_> = (0..batch.items.len()).collect();
        let leases = lease_partition(&batch, &order);
        assert!(leases.len() > 1 && leases[0].len() < 32);
        let mut batch = many_small_files(4);
        for (row, size) in batch.items.iter_mut().zip([100, 20, 20, 1]) {
            row.replacement.len = size * 1024 * 1024;
        }
        assert_eq!(
            lease_partition(&batch, &[0, 1, 2, 3]),
            vec![vec![0], vec![1], vec![2, 3]]
        );
        assert_eq!(lease_width(&batch, &[]), 0);
    }

    pub(super) fn plan() -> Batch {
        let old = io::local_copy(&b"old"[..], std::io::sink()).unwrap();
        Batch {
            generation: None,
            version: 1,
            root: "/var/mobile/Containers/Data/Application/fixture".into(),
            identity: "fixture".into(),
            state: "pending".into(),
            items: vec![Item {
                rel: "Documents/dir/a.bin".into(),
                key: token(),
                omission: None,
                added: None,
                original_witness: format!("sha1:{}:3", "a".repeat(40)),
                replacement: old,
                replacement_witness: None,
                original: None,
                handoff: None,
                cargo: None,
                foreign_cargo: None,
                rebuilding_held: false,
                return_witness: None,
                phase: Phase::Waiting,
            }],
        }
    }
    #[test]
    fn safely_omitted_files_have_separate_counts_and_survive_both_receipt_formats() {
        for count in [3, 40] {
            let dir = tempfile::tempdir().unwrap();
            let mut batch = plan();
            for i in 1..count {
                let mut row = plan().items.pop().unwrap();
                row.rel = format!("Documents/dir/{i}.bin");
                batch.items.push(row);
            }
            let reason = "Thiếu thư mục cha trong ứng dụng.\nDocuments/không có";
            batch.items[0].phase = Phase::Omitted;
            batch.items[0].original_witness = "unavailable".into();
            batch.items[0].omission = Some(omission_reason(reason));
            batch.items[1].phase = Phase::Skipped;
            persist(dir.path(), &mut batch).unwrap();
            for i in 2..count {
                omit_row(dir.path(), &mut batch, i, reason).unwrap();
            }
            let stored = load_receipt(dir.path()).unwrap().unwrap();
            let value = report(&stored);
            assert_eq!(value["changed"], 0);
            assert_eq!(value["skipped"], 1);
            assert_eq!(value["omitted"], count - 1);
            assert_eq!(value["omitted_items"][0]["path"], "Documents/dir/a.bin");
            assert_eq!(
                value["omitted_items"][0]["reason"],
                "Thiếu thư mục cha trong ứng dụng. Documents/không có"
            );
            assert_eq!(
                value["omitted_items"][count - 2]["path"],
                format!("Documents/dir/{}.bin", count - 1)
            );
            batch.state = "restored".into();
            validate(&batch).unwrap();
        }
    }

    #[test]
    fn skipped_unavailable_preimage_budget_matches_live_backup_accounting() {
        let mut batch = plan();
        batch.items.clear();
        for index in 0..3 {
            let mut row = plan().items.pop().unwrap();
            row.rel = format!("Documents/dir/{index}");
            if index == 0 {
                row.original_witness = format!("ino:1:2:{MAX_FILE}");
                row.phase = Phase::Omitted;
                row.omission = Some("Tệp đích đã thay đổi.".into());
            } else {
                row.original_witness = "opaque".into();
                let mut original = row.replacement.clone();
                original.len = MAX_FILE;
                row.original = Some(original);
                row.phase = Phase::Installed;
                row.replacement_witness = Some(row.replacement.sha1_witness());
            }
            batch.items.push(row);
        }
        batch.state = "applied".into();
        let temp = tempfile::tempdir().unwrap();
        persist(temp.path(), &mut batch).unwrap();
        let stored = load_receipt(temp.path()).unwrap().unwrap();
        assert_eq!(report(&stored)["changed"], 2);
        assert_eq!(report(&stored)["omitted"], 1);
    }

    #[test]
    fn restore_preview_only_shows_unsettled_paths_in_traversal_order() {
        let mut batch = plan();
        batch.items.clear();
        for (i, phase) in [
            Phase::Installed,
            Phase::Waiting,
            Phase::Omitted,
            Phase::Skipped,
            Phase::Moving,
            Phase::Settled,
            Phase::Staging,
        ]
        .into_iter()
        .enumerate()
        {
            let mut row = plan().items.pop().unwrap();
            row.rel = format!("Documents/dir/{i}");
            row.phase = phase;
            batch.items.push(row);
        }
        assert_eq!(
            report(&batch)["restore_paths"],
            json!(["Documents/dir/6", "Documents/dir/4", "Documents/dir/0"])
        );
    }

    #[test]
    fn armed_transfer_cannot_be_marked_omitted_and_diagnostics_are_bounded_utf8() {
        let dir = tempfile::tempdir().unwrap();
        let mut batch = plan();
        batch.items[0].phase = Phase::Moving;
        assert_eq!(
            omit_row(dir.path(), &mut batch, 0, "refused").unwrap_err(),
            UNCERTAIN
        );
        assert_eq!(batch.items[0].phase, Phase::Moving);
        assert!(batch.items[0].omission.is_none());
        let clean = omission_reason(&format!("Thiếu đường dẫn\n{}", "ặ".repeat(1024)));
        assert!(clean.len() <= 1024 && !clean.chars().any(char::is_control));
        assert!(!omission_reason("\r\n\0").is_empty());
    }

    #[test]
    fn interrupted_reverse_receipt_survives_without_source_and_rejects_malformed_intent() {
        let temp = tempfile::tempdir().unwrap();
        let mut j = plan();
        persist(temp.path(), &mut j).unwrap();
        j.items[0].phase = Phase::Moving;
        j.items[0].replacement_witness = Some("ino:7:36:3".to_owned());
        persist(temp.path(), &mut j).unwrap();
        let stored = load_receipt(temp.path()).unwrap().unwrap();
        assert_eq!(stored.items[0].phase, Phase::Moving);
        assert_eq!(stored.items[0].key, j.items[0].key);
        j.items[0].rel = "Documents/../../another-app".into();
        persist(temp.path(), &mut j).unwrap();
        assert!(load_receipt(temp.path()).is_err());
    }
    #[test]
    fn reverse_cleanup_removes_receipt_after_owned_files() {
        let parent = tempfile::tempdir().unwrap();
        for receipt in ["journal.json", "reverse.json"] {
            let slot = parent.path().join("slot");
            directory(&slot).unwrap();
            fs::write(slot.join(receipt), "{}").unwrap();
            fs::write(artifact(&slot, 0, true), "fixture").unwrap();
            remove_slot(&slot).unwrap();
            assert!(!slot.exists());
        }
    }

    #[test]
    fn reverse_opaque_unknown_preimage_and_recovery_intent_survive_restart() {
        let temp = tempfile::tempdir().unwrap();
        let mut batch = plan();
        let row = &mut batch.items[0];
        row.original_witness = "opaque".into();
        row.phase = Phase::Moving;
        row.handoff = Some(Handoff::ExportOld);
        row.replacement_witness = Some("ino:1:12:3".into());
        persist(temp.path(), &mut batch).unwrap();
        let mut recovered = load_receipt(temp.path()).unwrap().unwrap();
        let row = &mut recovered.items[0];
        assert_eq!(row.handoff, Some(Handoff::ExportOld));
        assert_eq!(row.original, None);
        row.original = Some(row.replacement.clone());
        row.return_witness = Some("ino:2:13:3".into());
        row.rebuilding_held = true;
        row.handoff = Some(Handoff::EvictNew);
        persist(temp.path(), &mut recovered).unwrap();
        let recovering = load_receipt(temp.path()).unwrap().unwrap();
        assert!(recovering.items[0].rebuilding_held);
        recovered.items[0].original.as_mut().unwrap().len = MAX_FILE + 1;
        persist(temp.path(), &mut recovered).unwrap();
        assert!(load_receipt(temp.path()).is_err());
    }

    #[test]
    fn reverse_recovery_accepts_only_observed_owned_positions() {
        assert_eq!(
            locate_original(true, false, false, false).unwrap(),
            Resolution::Vacant
        );
        assert_eq!(
            locate_original(true, true, false, true).unwrap(),
            Resolution::EvictReplacement
        );
        assert_eq!(
            locate_original(false, true, true, false).unwrap(),
            Resolution::AlreadyReturned
        );
        for (held, target, old, new) in [
            (true, true, false, false),
            (false, false, false, false),
            (false, true, false, true),
            (true, true, true, true),
            (true, true, true, false),
        ] {
            assert!(locate_original(held, target, old, new).is_err());
        }
    }
}
