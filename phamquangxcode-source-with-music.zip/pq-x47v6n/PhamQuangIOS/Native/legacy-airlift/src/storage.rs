use std::{
    ffi::CString,
    fs::{self, File, OpenOptions},
    io::{Read, Write},
    os::{
        fd::{AsRawFd, FromRawFd},
        unix::{
            ffi::OsStrExt,
            fs::{MetadataExt, OpenOptionsExt, PermissionsExt},
        },
    },
    path::Path,
    sync::{
        Mutex,
        atomic::{AtomicBool, AtomicU64, Ordering},
    },
};

pub const MAXIMUM_FILE_SIZE: usize = 1_048_576;
static STORAGE_LOCK: Mutex<()> = Mutex::new(());
static TEMPORARY_ID: AtomicU64 = AtomicU64::new(0);

#[derive(Debug, Clone, PartialEq, Eq)]
pub enum StoreError {
    TooLarge,
    NotRegularFile,
    InvalidPropertyList,
    LockdownPairingFile,
    InvalidField(&'static str),
    UnsafeLocation,
    Io(&'static str),
}
impl std::fmt::Display for StoreError {
    fn fmt(&self, f: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
        match self {
            Self::TooLarge => f.write_str("The pairing file must be no larger than 1 MiB."),
            Self::NotRegularFile => f.write_str("Choose a regular pairing file."),
            Self::InvalidPropertyList => {
                f.write_str("This file is not a valid pairing property list.")
            }
            Self::LockdownPairingFile => {
                f.write_str("This is a Lockdown pairing record; choose Remote Pairing.")
            }
            Self::InvalidField(field) => {
                write!(f, "The Remote Pairing file has an invalid {field} field.")
            }
            Self::UnsafeLocation => {
                f.write_str("Pairing storage is not a regular private file or directory.")
            }
            Self::Io(operation) => write!(f, "Pairing storage failed to {operation}."),
        }
    }
}
impl std::error::Error for StoreError {}

pub fn is_lockdown(bytes: &[u8]) -> bool {
    plist::from_bytes::<plist::Value>(bytes)
        .ok()
        .and_then(|v| v.into_dictionary())
        .is_some_and(|d| d.contains_key("HostID") && !d.contains_key("identifier"))
}
pub fn validate(bytes: &[u8]) -> Result<(), StoreError> {
    if bytes.len() > MAXIMUM_FILE_SIZE {
        return Err(StoreError::TooLarge);
    }
    let value: plist::Value =
        plist::from_bytes(bytes).map_err(|_| StoreError::InvalidPropertyList)?;
    let dict = value
        .as_dictionary()
        .ok_or(StoreError::InvalidPropertyList)?;
    let required = ["public_key", "private_key", "identifier"];
    let lockdown = [
        "HostID",
        "SystemBUID",
        "HostCertificate",
        "RootCertificate",
        "HostPrivateKey",
    ];
    if !required.iter().all(|key| dict.contains_key(*key))
        && lockdown.iter().any(|key| dict.contains_key(*key))
    {
        idevice::pairing_file::PairingFile::from_bytes(bytes)
            .map_err(|_| StoreError::InvalidField("Lockdown certificates or keys"))?;
        return Ok(());
    }
    for key in ["public_key", "private_key"] {
        if dict
            .get(key)
            .and_then(plist::Value::as_data)
            .map(<[u8]>::len)
            != Some(32)
        {
            return Err(StoreError::InvalidField(key));
        }
    }
    let identifier = dict
        .get("identifier")
        .and_then(plist::Value::as_string)
        .ok_or(StoreError::InvalidField("identifier"))?;
    if identifier.trim().is_empty() || identifier.contains('\0') {
        return Err(StoreError::InvalidField("identifier"));
    }
    if let Some(irk) = dict.get("alt_irk") {
        if irk.as_data().map(<[u8]>::len) != Some(16) {
            return Err(StoreError::InvalidField("alt_irk"));
        }
    }
    Ok(())
}

struct Location {
    directory: File,
    name: CString,
}
impl Location {
    fn open(path: &Path, create: bool) -> Result<Option<Self>, StoreError> {
        let parent = path
            .parent()
            .filter(|p| !p.as_os_str().is_empty())
            .ok_or(StoreError::UnsafeLocation)?;
        let name = path.file_name().ok_or(StoreError::UnsafeLocation)?;
        let name = CString::new(name.as_bytes()).map_err(|_| StoreError::UnsafeLocation)?;
        if create {
            fs::create_dir_all(parent)
                .map_err(|_| StoreError::Io("create its private directory"))?;
        }
        let metadata = match fs::symlink_metadata(parent) {
            Ok(m) => m,
            Err(e) if e.kind() == std::io::ErrorKind::NotFound && !create => return Ok(None),
            Err(_) => return Err(StoreError::Io("inspect its private directory")),
        };
        if !metadata.file_type().is_dir() {
            return Err(StoreError::UnsafeLocation);
        }
        let directory = OpenOptions::new()
            .read(true)
            .custom_flags(libc::O_DIRECTORY | libc::O_NOFOLLOW | libc::O_CLOEXEC)
            .open(parent)
            .map_err(|_| StoreError::UnsafeLocation)?;
        if create {
            directory
                .set_permissions(fs::Permissions::from_mode(0o700))
                .map_err(|_| StoreError::Io("protect its private directory"))?;
        }
        Ok(Some(Self { directory, name }))
    }
    fn metadata(&self) -> Result<Option<libc::stat>, StoreError> {
        let mut info = std::mem::MaybeUninit::<libc::stat>::uninit();
        let result = unsafe {
            libc::fstatat(
                self.directory.as_raw_fd(),
                self.name.as_ptr(),
                info.as_mut_ptr(),
                libc::AT_SYMLINK_NOFOLLOW,
            )
        };
        if result == 0 {
            return Ok(Some(unsafe { info.assume_init() }));
        }
        if std::io::Error::last_os_error().kind() == std::io::ErrorKind::NotFound {
            Ok(None)
        } else {
            Err(StoreError::Io("inspect its file"))
        }
    }
    fn open_regular(&self) -> Result<File, StoreError> {
        let fd = unsafe {
            libc::openat(
                self.directory.as_raw_fd(),
                self.name.as_ptr(),
                libc::O_RDONLY | libc::O_NOFOLLOW | libc::O_NONBLOCK | libc::O_CLOEXEC,
            )
        };
        if fd < 0 {
            return Err(StoreError::Io("open its file"));
        }
        let file = unsafe { File::from_raw_fd(fd) };
        if !file
            .metadata()
            .map_err(|_| StoreError::Io("inspect its file"))?
            .is_file()
        {
            return Err(StoreError::NotRegularFile);
        }
        Ok(file)
    }
    fn read(&self) -> Result<Vec<u8>, StoreError> {
        bounded_regular_read(self.open_regular()?)
    }
    fn save(&self, bytes: &[u8]) -> Result<(), StoreError> {
        self.save_guarded(bytes, || true).map(|_| ())
    }
    fn save_guarded(
        &self,
        bytes: &[u8],
        can_commit: impl Fn() -> bool,
    ) -> Result<bool, StoreError> {
        self.save_with_receipt(bytes, false, can_commit)
    }
    fn save_with_receipt(
        &self,
        bytes: &[u8],
        retain_receipt: bool,
        can_commit: impl Fn() -> bool,
    ) -> Result<bool, StoreError> {
        if !can_commit() {
            return Ok(false);
        }
        if let Some(info) = self.metadata()? {
            if info.st_mode & libc::S_IFMT != libc::S_IFREG {
                return Err(StoreError::UnsafeLocation);
            }
        }
        let temporary = CString::new(format!(
            ".pairing-{}-{}.tmp",
            std::process::id(),
            TEMPORARY_ID.fetch_add(1, Ordering::Relaxed)
        ))
        .unwrap();
        let fd = unsafe {
            libc::openat(
                self.directory.as_raw_fd(),
                temporary.as_ptr(),
                libc::O_WRONLY | libc::O_CREAT | libc::O_EXCL | libc::O_NOFOLLOW | libc::O_CLOEXEC,
                0o600,
            )
        };
        if fd < 0 {
            return Err(StoreError::Io("create a private staging file"));
        }
        struct Cleanup<'a> {
            dir: &'a File,
            name: &'a CString,
        }
        impl Drop for Cleanup<'_> {
            fn drop(&mut self) {
                unsafe {
                    libc::unlinkat(self.dir.as_raw_fd(), self.name.as_ptr(), 0);
                }
            }
        }
        let cleanup = Cleanup {
            dir: &self.directory,
            name: &temporary,
        };
        let mut file = unsafe { File::from_raw_fd(fd) };
        file.set_permissions(fs::Permissions::from_mode(0o600))
            .map_err(|_| StoreError::Io("protect its staging file"))?;
        #[cfg(target_os = "ios")]
        if unsafe { libc::fcntl(file.as_raw_fd(), 64, 3) } != 0 {
            return Err(StoreError::Io("set pairing file protection"));
        }
        if retain_receipt {
            set_catalog_receipt(&file)?;
        }
        file.write_all(bytes)
            .map_err(|_| StoreError::Io("write its staging file"))?;
        file.sync_all()
            .map_err(|_| StoreError::Io("synchronize its staging file"))?;
        drop(file);
        if let Some(info) = self.metadata()? {
            if info.st_mode & libc::S_IFMT != libc::S_IFREG {
                return Err(StoreError::UnsafeLocation);
            }
        }
        if !can_commit() {
            return Ok(false);
        }
        let result = unsafe {
            libc::renameat(
                self.directory.as_raw_fd(),
                temporary.as_ptr(),
                self.directory.as_raw_fd(),
                self.name.as_ptr(),
            )
        };
        if result != 0 {
            return Err(StoreError::Io("commit its staging file"));
        }
        drop(cleanup);
        Ok(true)
    }
}

fn bounded_regular_read(file: File) -> Result<Vec<u8>, StoreError> {
    let metadata = file
        .metadata()
        .map_err(|_| StoreError::Io("inspect an open file"))?;
    if !metadata.is_file() {
        return Err(StoreError::NotRegularFile);
    }
    if metadata.len() > MAXIMUM_FILE_SIZE as u64 {
        return Err(StoreError::TooLarge);
    }
    let mut result = Vec::new();
    file.take(MAXIMUM_FILE_SIZE as u64 + 1)
        .read_to_end(&mut result)
        .map_err(|_| StoreError::Io("read its file"))?;
    if result.len() > MAXIMUM_FILE_SIZE {
        return Err(StoreError::TooLarge);
    }
    Ok(result)
}

pub fn read_import(path: &Path) -> Result<Vec<u8>, StoreError> {
    let file = OpenOptions::new()
        .read(true)
        .custom_flags(libc::O_NOFOLLOW | libc::O_NONBLOCK | libc::O_CLOEXEC)
        .open(path)
        .map_err(|_| StoreError::NotRegularFile)?;
    bounded_regular_read(file)
}
pub fn exists(path: &Path) -> bool {
    let _guard = STORAGE_LOCK.lock().unwrap_or_else(|p| p.into_inner());
    Location::open(path, false)
        .ok()
        .flatten()
        .and_then(|l| l.metadata().ok().flatten())
        .is_some_and(|s| s.st_mode & libc::S_IFMT == libc::S_IFREG)
}
pub fn read(path: &Path) -> Result<Vec<u8>, StoreError> {
    let _guard = STORAGE_LOCK.lock().unwrap_or_else(|p| p.into_inner());
    let location =
        Location::open(path, false)?.ok_or(StoreError::Io("find its private directory"))?;
    let bytes = location.read()?;
    validate(&bytes)?;
    Ok(bytes)
}
pub fn save(path: &Path, bytes: &[u8]) -> Result<(), StoreError> {
    validate(bytes)?;
    let _guard = STORAGE_LOCK.lock().unwrap_or_else(|p| p.into_inner());
    Location::open(path, true)?
        .ok_or(StoreError::UnsafeLocation)?
        .save(bytes)
}
pub fn snapshot(path: &Path) -> Result<Option<Vec<u8>>, StoreError> {
    let _guard = STORAGE_LOCK.lock().unwrap_or_else(|p| p.into_inner());
    let Some(location) = Location::open(path, false)? else {
        return Ok(None);
    };
    let Some(info) = location.metadata()? else {
        return Ok(None);
    };
    if info.st_mode & libc::S_IFMT != libc::S_IFREG {
        return Err(StoreError::UnsafeLocation);
    }
    location.read().map(Some)
}

pub fn save_if_unchanged(
    path: &Path,
    bytes: &[u8],
    expected: Option<&[u8]>,
    cancel: &AtomicBool,
) -> Result<bool, StoreError> {
    validate(bytes)?;
    if expected.is_some_and(|value| value.len() > MAXIMUM_FILE_SIZE) {
        return Err(StoreError::TooLarge);
    }
    let _guard = STORAGE_LOCK.lock().unwrap_or_else(|p| p.into_inner());
    if cancel.load(Ordering::Acquire) {
        return Ok(false);
    }
    let location = Location::open(path, true)?.ok_or(StoreError::UnsafeLocation)?;
    match (location.metadata()?, expected) {
        (None, None) => {}
        (Some(info), Some(expected)) => {
            if info.st_mode & libc::S_IFMT != libc::S_IFREG {
                return Err(StoreError::UnsafeLocation);
            }
            if info.st_size < 0
                || info.st_size as usize != expected.len()
                || location.read()? != expected
            {
                return Ok(false);
            }
        }
        (Some(info), None) if info.st_mode & libc::S_IFMT != libc::S_IFREG => {
            return Err(StoreError::UnsafeLocation);
        }
        _ => return Ok(false),
    }
    location.save_guarded(bytes, || !cancel.load(Ordering::Acquire))
}

const CONFIRMED: &[u8] = b"confirmed";

#[cfg(target_vendor = "apple")]
fn has_catalog_receipt(file: &File) -> bool {
    let mut buf = [0_u8; CONFIRMED.len()];
    let n = unsafe {
        libc::fgetxattr(
            file.as_raw_fd(),
            c"com.cc365.catalog-sync-v1".as_ptr(),
            buf.as_mut_ptr().cast(),
            buf.len(),
            0,
            0,
        )
    };
    n == buf.len() as isize && buf == CONFIRMED
}

#[cfg(target_vendor = "apple")]
fn set_catalog_receipt(file: &File) -> Result<(), StoreError> {
    let rc = unsafe {
        libc::fsetxattr(
            file.as_raw_fd(),
            c"com.cc365.catalog-sync-v1".as_ptr(),
            CONFIRMED.as_ptr().cast(),
            CONFIRMED.len(),
            0,
            0,
        )
    };
    if rc == 0 {
        Ok(())
    } else {
        Err(StoreError::Io("save the catalog sync receipt"))
    }
}

#[cfg(not(target_vendor = "apple"))]
fn has_catalog_receipt(_: &File) -> bool {
    false
}
#[cfg(not(target_vendor = "apple"))]
fn set_catalog_receipt(_: &File) -> Result<(), StoreError> {
    Err(StoreError::Io("save the catalog sync receipt"))
}

pub(crate) fn catalog_ready(path: &Path) -> bool {
    let _guard = STORAGE_LOCK.lock().unwrap_or_else(|p| p.into_inner());
    Location::open(path, false)
        .ok()
        .flatten()
        .and_then(|loc| loc.open_regular().ok())
        .is_some_and(|file| {
            has_catalog_receipt(&file)
                && bounded_regular_read(file).is_ok_and(|bytes| validate(&bytes).is_ok())
        })
}

pub(crate) fn open_pairing_session(path: &Path) -> Result<(File, Vec<u8>), StoreError> {
    let _guard = STORAGE_LOCK.lock().unwrap_or_else(|p| p.into_inner());
    let file = Location::open(path, false)?
        .ok_or(StoreError::UnsafeLocation)?
        .open_regular()?;
    let bytes = bounded_regular_read(
        file.try_clone()
            .map_err(|_| StoreError::Io("read its file"))?,
    )?;
    validate(&bytes)?;
    Ok((file, bytes))
}

fn same_inode(left: &File, right: &File) -> Result<bool, StoreError> {
    let a = left
        .metadata()
        .map_err(|_| StoreError::Io("inspect its file"))?;
    let b = right
        .metadata()
        .map_err(|_| StoreError::Io("inspect its file"))?;
    Ok((a.dev(), a.ino()) == (b.dev(), b.ino()))
}

fn same_pairing(before: &[u8], after: &[u8]) -> bool {
    let (Ok(a), Ok(b)) = (
        plist::from_bytes::<plist::Dictionary>(before),
        plist::from_bytes::<plist::Dictionary>(after),
    ) else {
        return false;
    };
    ["identifier", "public_key", "private_key", "alt_irk"]
        .iter()
        .all(|key| a.get(*key) == b.get(*key))
}

pub(crate) fn finish_pairing_handshake(
    path: &Path,
    opened: &File,
    before: &[u8],
    after: &[u8],
) -> Result<Option<File>, StoreError> {
    validate(after)?;
    let _guard = STORAGE_LOCK.lock().unwrap_or_else(|p| p.into_inner());
    let Some(location) = Location::open(path, false)? else {
        return Ok(None);
    };
    if location.metadata()?.is_none() {
        return Ok(None);
    }
    let current = location.open_regular()?;
    if !same_inode(&current, opened)? || location.read()? != before {
        return Ok(None);
    }
    if before == after {
        return Ok(Some(current));
    }
    let preserve = has_catalog_receipt(&current) && same_pairing(before, after);
    location.save_with_receipt(after, preserve, || true)?;
    location.open_regular().map(Some)
}

pub(crate) fn session_catalog_ready(path: &Path, opened: &File) -> bool {
    let _guard = STORAGE_LOCK.lock().unwrap_or_else(|p| p.into_inner());
    Location::open(path, false)
        .ok()
        .flatten()
        .and_then(|loc| loc.open_regular().ok())
        .is_some_and(|file| {
            same_inode(&file, opened).unwrap_or(false) && has_catalog_receipt(&file)
        })
}

pub(crate) fn record_confirmed_sync(path: &Path, opened: &File) -> Result<(), StoreError> {
    let _guard = STORAGE_LOCK.lock().unwrap_or_else(|p| p.into_inner());
    let current = Location::open(path, false)?
        .ok_or(StoreError::UnsafeLocation)?
        .open_regular()?;
    if !same_inode(&current, opened)? {
        return Err(StoreError::UnsafeLocation);
    }
    set_catalog_receipt(opened)
}

#[cfg(test)]
fn replace_if_current_matches(
    path: &Path,
    bytes: &[u8],
    expected: &[u8],
) -> Result<bool, StoreError> {
    if !exists(path) {
        return Ok(false);
    }
    let (file, _) = open_pairing_session(path)?;
    Ok(finish_pairing_handshake(path, &file, expected, bytes)?.is_some())
}
pub fn remove(path: &Path) -> Result<(), StoreError> {
    let _guard = STORAGE_LOCK.lock().unwrap_or_else(|p| p.into_inner());
    let Some(location) = Location::open(path, false)? else {
        return Ok(());
    };
    let Some(info) = location.metadata()? else {
        return Ok(());
    };
    if info.st_mode & libc::S_IFMT != libc::S_IFREG {
        return Err(StoreError::UnsafeLocation);
    }
    let result =
        unsafe { libc::unlinkat(location.directory.as_raw_fd(), location.name.as_ptr(), 0) };
    if result != 0 {
        return Err(StoreError::Io("remove its file"));
    }
    Ok(())
}

#[cfg(test)]
mod tests {
    use super::*;
    fn record(identifier: &str) -> Vec<u8> {
        let mut dict = plist::Dictionary::new();
        dict.insert("public_key".into(), plist::Value::Data(vec![1; 32]));
        dict.insert("private_key".into(), plist::Value::Data(vec![2; 32]));
        dict.insert("identifier".into(), identifier.into());
        let mut bytes = Vec::new();
        plist::Value::Dictionary(dict)
            .to_writer_binary(&mut bytes)
            .unwrap();
        bytes
    }
    fn directory() -> std::path::PathBuf {
        let path = std::env::temp_dir().join(format!(
            "cc365-store-test-{}-{}",
            std::process::id(),
            TEMPORARY_ID.fetch_add(1, Ordering::Relaxed)
        ));
        fs::create_dir(&path).unwrap();
        path
    }
    #[cfg(target_vendor = "apple")]
    #[test]
    fn catalog_requires_confirmation_on_the_current_pairing_even_across_restarts_and_imports() {
        let root = directory();
        let path = root.join("private/pairingFile.plist");
        let original = record("fixture-A");
        assert!(!catalog_ready(&path));
        save(&path, &original).unwrap();
        assert!(!catalog_ready(&path));
        let (opened, before) = open_pairing_session(&path).unwrap();
        let session = finish_pairing_handshake(&path, &opened, &before, &before)
            .unwrap()
            .unwrap();
        assert!(!catalog_ready(&path));
        record_confirmed_sync(&path, &session).unwrap();
        assert!(catalog_ready(&path));

        let mut normalized = Vec::new();
        let value: plist::Value = plist::from_bytes(&original).unwrap();
        value.to_writer_xml(&mut normalized).unwrap();
        assert_ne!(before, normalized);
        let normalized_session = finish_pairing_handshake(&path, &session, &before, &normalized)
            .unwrap()
            .unwrap();
        assert!(session_catalog_ready(&path, &normalized_session));
        assert!(!session_catalog_ready(&path, &session));

        let mut rotated = value.clone();
        rotated
            .as_dictionary_mut()
            .unwrap()
            .insert("public_key".into(), plist::Value::Data(vec![9; 32]));
        let mut rotated_bytes = Vec::new();
        rotated.to_writer_binary(&mut rotated_bytes).unwrap();
        let new_peer =
            finish_pairing_handshake(&path, &normalized_session, &normalized, &rotated_bytes)
                .unwrap()
                .unwrap();
        assert!(!catalog_ready(&path));
        assert!(record_confirmed_sync(&path, &normalized_session).is_err());
        record_confirmed_sync(&path, &new_peer).unwrap();
        assert!(catalog_ready(&path));

        let imported = read_import(&path).unwrap();
        save(&path, &imported).unwrap();
        assert!(!catalog_ready(&path));
        assert!(record_confirmed_sync(&path, &new_peer).is_err());
        assert!(
            finish_pairing_handshake(&path, &new_peer, &imported, &imported)
                .unwrap()
                .is_none()
        );
        let (current, _) = open_pairing_session(&path).unwrap();
        record_confirmed_sync(&path, &current).unwrap();
        remove(&path).unwrap();
        assert!(!catalog_ready(&path));
        assert!(record_confirmed_sync(&path, &current).is_err());
        fs::remove_dir_all(root).unwrap();
    }

    #[test]
    fn validation_rejects_malformed_or_wrong_schema() {
        assert_eq!(validate(b"not plist"), Err(StoreError::InvalidPropertyList));
        assert_eq!(
            validate(&vec![0; MAXIMUM_FILE_SIZE + 1]),
            Err(StoreError::TooLarge)
        );
        assert_eq!(
            validate(&record("  \n")),
            Err(StoreError::InvalidField("identifier"))
        );
        assert_eq!(
            validate(&record("a\0b")),
            Err(StoreError::InvalidField("identifier"))
        );
        let mut dict = plist::Dictionary::new();
        dict.insert("HostID".into(), "legacy".into());
        let mut bytes = Vec::new();
        plist::Value::Dictionary(dict)
            .to_writer_xml(&mut bytes)
            .unwrap();
        assert_eq!(
            validate(&bytes),
            Err(StoreError::InvalidField("Lockdown certificates or keys"))
        );
        for (field, n) in [("public_key", 31), ("private_key", 33), ("alt_irk", 15)] {
            let mut p: plist::Value = plist::from_bytes(&record("test")).unwrap();
            p.as_dictionary_mut()
                .unwrap()
                .insert(field.into(), plist::Value::Data(vec![0; n]));
            let mut bytes = Vec::new();
            p.to_writer_xml(&mut bytes).unwrap();
            assert_eq!(validate(&bytes), Err(StoreError::InvalidField(field)));
        }
    }
    #[test]
    fn atomic_store_cas_permissions_delete_and_symlinks() {
        let root = directory();
        let path = root.join("private/pairingFile.plist");
        let original = record("first");
        let newer = record("newer");
        assert!(!exists(&path));
        save(&path, &original).unwrap();
        assert!(exists(&path));
        assert_eq!(read(&path).unwrap(), original);
        assert_eq!(
            fs::metadata(&path).unwrap().permissions().mode() & 0o777,
            0o600
        );
        assert_eq!(
            fs::metadata(path.parent().unwrap())
                .unwrap()
                .permissions()
                .mode()
                & 0o777,
            0o700
        );
        assert!(!replace_if_current_matches(&path, &newer, b"stale").unwrap());
        assert!(replace_if_current_matches(&path, &newer, &original).unwrap());
        assert!(!replace_if_current_matches(&path, &original, &original).unwrap());
        remove(&path).unwrap();
        assert!(!replace_if_current_matches(&path, &original, &newer).unwrap());
        remove(&path).unwrap();
        let target = root.join("target");
        fs::write(&target, b"keep").unwrap();
        std::os::unix::fs::symlink(&target, &path).unwrap();
        assert!(!exists(&path));
        assert_eq!(save(&path, &original), Err(StoreError::UnsafeLocation));
        assert_eq!(remove(&path), Err(StoreError::UnsafeLocation));
        assert_eq!(fs::read(&target).unwrap(), b"keep");
        assert!(read_import(&path).is_err());
        fs::remove_dir_all(root).unwrap();
    }
    #[test]
    fn concurrent_compare_and_swap_has_single_winner() {
        let root = directory();
        let path = root.join("pairing.plist");
        let original = record("original");
        save(&path, &original).unwrap();
        let barrier = std::sync::Arc::new(std::sync::Barrier::new(8));
        let tasks: Vec<_> = (0..8)
            .map(|n| {
                let path = path.clone();
                let original = original.clone();
                let barrier = barrier.clone();
                std::thread::spawn(move || {
                    barrier.wait();
                    replace_if_current_matches(&path, &record(&format!("update-{n}")), &original)
                        .unwrap()
                })
            })
            .collect();
        assert_eq!(
            tasks
                .into_iter()
                .map(|t| t.join().unwrap())
                .filter(|winner| *winner)
                .count(),
            1
        );
        fs::remove_dir_all(root).unwrap();
    }
    #[test]
    fn pairing_commit_preserves_newer_import_deletion_and_absence() {
        let root = directory();
        let path = root.join("pairing.plist");
        let cancel = AtomicBool::new(false);
        let original = record("original");
        let generated = record("generated");
        let imported = record("imported");
        let absent = snapshot(&path).unwrap();
        assert!(absent.is_none());
        assert!(save_if_unchanged(&path, &original, absent.as_deref(), &cancel).unwrap());
        let initial = snapshot(&path).unwrap();
        save(&path, &imported).unwrap();
        assert!(!save_if_unchanged(&path, &generated, initial.as_deref(), &cancel).unwrap());
        assert_eq!(read(&path).unwrap(), imported);
        assert!(!save_if_unchanged(&path, &generated, None, &cancel).unwrap());
        let initial = snapshot(&path).unwrap();
        remove(&path).unwrap();
        assert!(!save_if_unchanged(&path, &generated, initial.as_deref(), &cancel).unwrap());
        assert!(!exists(&path));
        cancel.store(true, Ordering::Release);
        assert!(!save_if_unchanged(&path, &generated, None, &cancel).unwrap());
        assert!(!exists(&path));
        fs::remove_dir_all(root).unwrap();
    }
    #[test]
    fn cancellation_after_staging_preserves_old_record_and_cleans_temp() {
        let root = directory();
        let path = root.join("pairing.plist");
        let original = record("original");
        save(&path, &original).unwrap();
        let location = Location::open(&path, false).unwrap().unwrap();
        let checkpoints = std::cell::Cell::new(0);
        assert!(
            !location
                .save_guarded(&record("cancelled"), || {
                    let n = checkpoints.get() + 1;
                    checkpoints.set(n);
                    n == 1
                })
                .unwrap()
        );
        assert_eq!(checkpoints.get(), 2);
        assert_eq!(read(&path).unwrap(), original);
        assert_eq!(fs::read_dir(&root).unwrap().count(), 1);
        fs::remove_dir_all(root).unwrap();
    }
    #[test]
    fn concurrent_pair_commit_never_overwrites_later_import_or_resurrects_delete() {
        let root = directory();
        let path = root.join("pairing.plist");
        for delete in [false, true] {
            for _ in 0..20 {
                let original = record("original");
                let generated = record("generated");
                let imported = record("imported");
                save(&path, &original).unwrap();
                let barrier = std::sync::Arc::new(std::sync::Barrier::new(2));
                let commit = {
                    let path = path.clone();
                    let barrier = barrier.clone();
                    std::thread::spawn(move || {
                        barrier.wait();
                        save_if_unchanged(
                            &path,
                            &generated,
                            Some(&original),
                            &AtomicBool::new(false),
                        )
                        .unwrap()
                    })
                };
                barrier.wait();
                if delete {
                    remove(&path).unwrap();
                } else {
                    save(&path, &imported).unwrap();
                }
                let _ = commit.join().unwrap();
                if delete {
                    assert!(!exists(&path));
                } else {
                    assert_eq!(read(&path).unwrap(), imported);
                }
            }
        }
        fs::remove_dir_all(root).unwrap();
    }
}
