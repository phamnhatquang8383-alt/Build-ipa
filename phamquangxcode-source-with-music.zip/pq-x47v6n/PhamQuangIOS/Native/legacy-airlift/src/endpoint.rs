use serde::{Deserialize, Serialize};
use std::{collections::HashSet, ffi::CString, net::IpAddr};

const BSD_AF_INET: i32 = 2;
const BSD_AF_INET6: i32 = 30;
#[derive(Debug, Clone, PartialEq, Eq, Hash, Serialize, Deserialize)]
pub struct EndpointAddress {
    pub family: i32,
    pub bytes: Vec<u8>,
    pub scope_id: u32,
}
impl EndpointAddress {
    pub fn is_link_local_ipv6(&self) -> bool {
        self.family == BSD_AF_INET6
            && self.bytes.len() == 16
            && self.bytes[0] == 0xfe
            && self.bytes[1] & 0xc0 == 0x80
    }
    pub fn is_loopback(&self) -> bool {
        (self.family == BSD_AF_INET && self.bytes.len() == 4 && self.bytes[0] == 127)
            || (self.family == BSD_AF_INET6
                && self.bytes.len() == 16
                && self.bytes[..15].iter().all(|b| *b == 0)
                && self.bytes[15] == 1)
    }
    pub fn is_unspecified(&self) -> bool {
        self.bytes.iter().all(|b| *b == 0)
    }
    pub fn matches(&self, other: &Self) -> bool {
        if self.family != other.family || self.bytes != other.bytes {
            return false;
        }
        if self.is_link_local_ipv6() {
            self.scope_id != 0 && self.scope_id == other.scope_id
        } else {
            true
        }
    }
    pub fn socket_address(&self, port: u16) -> Option<std::net::SocketAddr> {
        use std::net::{Ipv4Addr, Ipv6Addr, SocketAddr, SocketAddrV6};
        if port == 0 {
            return None;
        }
        match self.family {
            BSD_AF_INET if self.bytes.len() == 4 && self.scope_id == 0 => {
                let bytes: [u8; 4] = self.bytes.as_slice().try_into().ok()?;
                Some(SocketAddr::new(Ipv4Addr::from(bytes).into(), port))
            }
            BSD_AF_INET6 if self.bytes.len() == 16 => {
                if self.is_link_local_ipv6() && self.scope_id == 0 {
                    return None;
                }
                let bytes: [u8; 16] = self.bytes.as_slice().try_into().ok()?;
                Some(SocketAddr::V6(SocketAddrV6::new(
                    Ipv6Addr::from(bytes),
                    port,
                    0,
                    self.scope_id,
                )))
            }
            _ => None,
        }
    }
    pub fn numeric_host(host: &str) -> Option<Self> {
        numeric_host(host)
    }
    pub fn sockaddr_bsd(bytes: &[u8], interface_index: u32) -> Option<Self> {
        sockaddr_bsd(bytes, interface_index)
    }
}
fn ipv6(mut bytes: [u8; 16], scope: u32, interface: u32) -> Option<EndpointAddress> {
    if bytes[0] != 0xfe || bytes[1] & 0xc0 != 0x80 {
        return Some(EndpointAddress {
            family: BSD_AF_INET6,
            bytes: bytes.to_vec(),
            scope_id: 0,
        });
    }
    let embedded = u16::from_be_bytes([bytes[2], bytes[3]]) as u32;
    let zones: HashSet<_> = [scope, interface, embedded]
        .into_iter()
        .filter(|zone| *zone != 0)
        .collect();
    if zones.len() > 1 {
        return None;
    }
    bytes[2] = 0;
    bytes[3] = 0;
    Some(EndpointAddress {
        family: BSD_AF_INET6,
        bytes: bytes.to_vec(),
        scope_id: zones.into_iter().next().unwrap_or(0),
    })
}
pub fn numeric_host(host: &str) -> Option<EndpointAddress> {
    let mut parts = host.split('%');
    let literal = parts.next()?;
    let zone = parts.next();
    if parts.next().is_some() || literal.is_empty() {
        return None;
    }
    match literal.parse::<IpAddr>().ok()? {
        IpAddr::V4(address) if zone.is_none() => Some(EndpointAddress {
            family: BSD_AF_INET,
            bytes: address.octets().to_vec(),
            scope_id: 0,
        }),
        IpAddr::V4(_) => None,
        IpAddr::V6(address) => {
            let scope = match zone {
                None => 0,
                Some(value) => {
                    if value.is_empty() {
                        return None;
                    }
                    let number = value.parse::<u32>().unwrap_or_else(|_| {
                        CString::new(value)
                            .ok()
                            .map(|v| unsafe { libc::if_nametoindex(v.as_ptr()) })
                            .unwrap_or(0)
                    });
                    if number == 0 {
                        return None;
                    }
                    number
                }
            };
            ipv6(address.octets(), scope, 0)
        }
    }
}
pub fn sockaddr_bsd(bytes: &[u8], interface_index: u32) -> Option<EndpointAddress> {
    if bytes.len() < 2 {
        return None;
    }
    match bytes[1] as i32 {
        BSD_AF_INET if bytes.len() >= 16 && bytes[0] == 16 => Some(EndpointAddress {
            family: BSD_AF_INET,
            bytes: bytes[4..8].to_vec(),
            scope_id: 0,
        }),
        BSD_AF_INET6 if bytes.len() >= 28 && bytes[0] == 28 => {
            let address: [u8; 16] = bytes[8..24].try_into().ok()?;
            let scope = u32::from_ne_bytes(bytes[24..28].try_into().ok()?);
            ipv6(address, scope, interface_index)
        }
        _ => None,
    }
}
#[derive(Debug, Clone, Copy, PartialEq, Eq, Serialize)]
pub enum Match {
    #[serde(rename = "matching address")]
    Target,
    #[serde(rename = "local loopback")]
    Loopback,
    #[serde(rename = "own-device interface address")]
    LocalInterface,
}
impl Match {
    pub fn as_str(self) -> &'static str {
        match self {
            Self::Target => "matching address",
            Self::Loopback => "local loopback",
            Self::LocalInterface => "own-device interface address",
        }
    }
}
pub fn match_endpoint(
    candidate: &EndpointAddress,
    target: &EndpointAddress,
    own_alias: bool,
    local_addresses: &[EndpointAddress],
) -> Option<Match> {
    if candidate.matches(target) {
        return Some(Match::Target);
    }
    if !own_alias {
        return None;
    }
    if candidate.is_loopback() {
        return Some(Match::Loopback);
    }
    if local_addresses
        .iter()
        .any(|address| candidate.matches(address))
    {
        return Some(Match::LocalInterface);
    }
    None
}
#[derive(Debug, Clone, Serialize)]
pub struct Inventory {
    pub addresses: Vec<EndpointAddress>,
    pub succeeded: bool,
}
pub fn current_up_addresses() -> Inventory {
    let mut first = std::ptr::null_mut();
    if unsafe { libc::getifaddrs(&mut first) } != 0 {
        return Inventory {
            addresses: vec![],
            succeeded: false,
        };
    }
    struct Cleanup(*mut libc::ifaddrs);
    impl Drop for Cleanup {
        fn drop(&mut self) {
            unsafe { libc::freeifaddrs(self.0) }
        }
    }
    let _cleanup = Cleanup(first);
    let mut addresses = HashSet::new();
    let mut next = first;
    while !next.is_null() {
        let entry = unsafe { &*next };
        next = entry.ifa_next;
        if entry.ifa_flags & libc::IFF_UP as u32 == 0 || entry.ifa_addr.is_null() {
            continue;
        }
        let family = unsafe { (*entry.ifa_addr).sa_family as i32 };
        let index = if entry.ifa_name.is_null() {
            0
        } else {
            unsafe { libc::if_nametoindex(entry.ifa_name) }
        };
        let address = match family {
            libc::AF_INET => {
                #[cfg(target_vendor = "apple")]
                if unsafe { (*entry.ifa_addr).sa_len as usize }
                    != std::mem::size_of::<libc::sockaddr_in>()
                {
                    continue;
                }
                let value =
                    unsafe { std::ptr::read_unaligned(entry.ifa_addr.cast::<libc::sockaddr_in>()) };
                Some(EndpointAddress {
                    family: BSD_AF_INET,
                    bytes: value.sin_addr.s_addr.to_ne_bytes().to_vec(),
                    scope_id: 0,
                })
            }
            libc::AF_INET6 => {
                #[cfg(target_vendor = "apple")]
                if unsafe { (*entry.ifa_addr).sa_len as usize }
                    != std::mem::size_of::<libc::sockaddr_in6>()
                {
                    continue;
                }
                let value = unsafe {
                    std::ptr::read_unaligned(entry.ifa_addr.cast::<libc::sockaddr_in6>())
                };
                ipv6(value.sin6_addr.s6_addr, value.sin6_scope_id, index)
            }
            _ => None,
        };
        if let Some(address) = address {
            if !address.is_unspecified() {
                addresses.insert(address);
            }
        }
    }
    let mut addresses: Vec<_> = addresses.into_iter().collect();
    addresses
        .sort_by(|a, b| (a.family, &a.bytes, a.scope_id).cmp(&(b.family, &b.bytes, b.scope_id)));
    Inventory {
        addresses,
        succeeded: true,
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    fn ip(value: &str) -> EndpointAddress {
        numeric_host(value).unwrap()
    }
    fn sockaddr(value: &str, scope: u32, embedded: u16) -> Vec<u8> {
        match value.parse::<IpAddr>().unwrap() {
            IpAddr::V4(ip) => {
                let mut bytes = vec![0; 16];
                bytes[0] = 16;
                bytes[1] = 2;
                bytes[4..8].copy_from_slice(&ip.octets());
                bytes
            }
            IpAddr::V6(ip) => {
                let mut bytes = vec![0; 28];
                bytes[0] = 28;
                bytes[1] = 30;
                bytes[8..24].copy_from_slice(&ip.octets());
                bytes[24..28].copy_from_slice(&scope.to_ne_bytes());
                if embedded != 0 {
                    bytes[10..12].copy_from_slice(&embedded.to_be_bytes());
                }
                bytes
            }
        }
    }
    #[test]
    fn local_alias_accepts_own_interfaces_but_not_foreign() {
        let alias = ip("10.7.0.1");
        let own = ip("192.168.1.31");
        let foreign = ip("192.168.1.90");
        let locals = vec![own.clone(), ip("127.0.0.1"), ip("::1"), ip("fe80::1234%4")];
        for (candidate, expected) in [
            (&own, Some(Match::LocalInterface)),
            (&foreign, None),
            (&alias, Some(Match::Target)),
            (&ip("127.0.0.9"), Some(Match::Loopback)),
            (&ip("::1"), Some(Match::Loopback)),
            (&ip("0.0.0.0"), None),
        ] {
            assert_eq!(match_endpoint(candidate, &alias, true, &locals), expected);
        }
        assert_eq!(match_endpoint(&own, &foreign, false, &locals), None);
        assert_eq!(
            match_endpoint(&foreign, &foreign, false, &locals),
            Some(Match::Target)
        );
        assert_eq!(match_endpoint(&ip("::1"), &foreign, false, &locals), None);
    }
    #[test]
    fn ipv6_zones_and_bsd_decoding() {
        let same = sockaddr_bsd(&sockaddr("fe80::1234", 4, 0), 0).unwrap();
        let other = sockaddr_bsd(&sockaddr("fe80::1234", 5, 0), 0).unwrap();
        let unknown = sockaddr_bsd(&sockaddr("fe80::1234", 0, 0), 0).unwrap();
        assert!(same.matches(&ip("fe80::1234%4")));
        assert!(!same.matches(&other));
        assert!(!unknown.matches(&unknown));
        assert!(same.matches(&sockaddr_bsd(&sockaddr("fe80::1234", 0, 0), 4).unwrap()));
        assert!(same.matches(&sockaddr_bsd(&sockaddr("fe80::1234", 0, 4), 0).unwrap()));
        assert!(sockaddr_bsd(&sockaddr("fe80::1234", 4, 0), 5).is_none());
        assert!(sockaddr_bsd(&sockaddr("fe80::1234", 5, 4), 0).is_none());
        assert!(
            ip("2001:db8::5").matches(&sockaddr_bsd(&sockaddr("2001:db8::5", 4, 0), 0).unwrap())
        );
        assert!(
            ip("192.168.1.31").matches(&sockaddr_bsd(&sockaddr("192.168.1.31", 0, 0), 0).unwrap())
        );
        let fixture = sockaddr("192.168.1.31", 0, 0);
        for end in 0..16 {
            assert!(sockaddr_bsd(&fixture[..end], 0).is_none());
        }
        let mut wrong = fixture.clone();
        wrong[0] = 0;
        assert!(sockaddr_bsd(&wrong, 0).is_none());
        let mut prefixed = vec![1];
        prefixed.extend_from_slice(&fixture);
        assert_eq!(sockaddr_bsd(&prefixed[1..], 0), sockaddr_bsd(&fixture, 0));
        for malformed in [
            "",
            "example.com",
            "999.1.1.1",
            "fe80::1234%",
            "fe80::1234%0",
            "fe80::1234%4%5",
            "192.168.1.31%4",
        ] {
            assert!(numeric_host(malformed).is_none());
        }
    }
    #[test]
    fn tcp_socket_conversion_keeps_zone_and_checks_identity() {
        assert_eq!(
            ip("10.7.0.1").socket_address(49152).unwrap().to_string(),
            "10.7.0.1:49152"
        );
        let scoped = ip("fe80::1234%4").socket_address(49152).unwrap();
        assert_eq!(scoped.to_string(), "[fe80::1234%4]:49152");
        let mut tunnel = scoped;
        tunnel.set_port(50000);
        assert_eq!(tunnel.to_string(), "[fe80::1234%4]:50000");
        assert!(ip("fe80::1234").socket_address(49152).is_none());
        assert!(ip("::1").socket_address(0).is_none());
        assert!(
            EndpointAddress {
                family: 30,
                bytes: vec![1; 4],
                scope_id: 0
            }
            .socket_address(1234)
            .is_none()
        );
        assert!(
            EndpointAddress {
                family: 2,
                bytes: vec![1; 4],
                scope_id: 4
            }
            .socket_address(1234)
            .is_none()
        );
    }
}
