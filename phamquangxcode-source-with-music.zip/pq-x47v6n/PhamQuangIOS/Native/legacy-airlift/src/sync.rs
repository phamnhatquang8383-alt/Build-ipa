
use plist::Dictionary;
use std::sync::{
    Arc,
    atomic::{AtomicBool, Ordering},
};
use std::{
    error::Error,
    fmt,
    future::Future,
    time::{Duration, Instant},
};

pub type PatchProgress = Arc<dyn Fn(&str, usize, usize, &str) + Send + Sync>;

pub type SyncLog = Arc<dyn Fn(&str) + Send + Sync>;

#[derive(Clone)]
pub struct SyncControl {
    pub cancelled: Arc<AtomicBool>,
    pub log: SyncLog,
    pub deadline: Option<Instant>,
    patch_sink: Option<PatchProgress>,
}
impl SyncControl {
    pub fn new(cancelled: Arc<AtomicBool>, log: SyncLog) -> Self {
        Self {
            cancelled,
            log,
            deadline: None,
            patch_sink: None,
        }
    }
    pub fn with_patch_progress(mut self, sink: PatchProgress) -> Self {
        self.patch_sink = Some(sink);
        self
    }
    pub fn patch_progress(&self, phase: &str, done: usize, total: usize, path: &str) {
        if let Some(sink) = &self.patch_sink {
            sink(phase, done, total, path);
        }
    }
    pub fn with_timeout(mut self, timeout: Duration) -> Self {
        self.deadline = Some(Instant::now() + timeout);
        self
    }
    pub fn check(&self) -> Result<(), SyncError> {
        if self.cancelled.load(Ordering::Acquire) {
            return Err(SyncError::Cancelled);
        }
        if self
            .deadline
            .is_some_and(|deadline| Instant::now() >= deadline)
        {
            return Err(SyncError::TimedOut);
        }
        Ok(())
    }
    pub fn log(&self, message: &str) {
        (self.log)(message);
    }
    pub async fn wait<T, F>(&self, timeout: Duration, operation: F) -> Result<T, SyncError>
    where
        F: Future<Output = Result<T, SyncError>>,
    {
        self.check()?;
        tokio::pin!(operation);
        let limited = async {
            loop {
                tokio::select! {
                    result = &mut operation => return result,
                    _ = tokio::time::sleep(Duration::from_millis(50)) => self.check()?,
                }
            }
        };
        tokio::time::timeout(timeout, limited)
            .await
            .map_err(|_| SyncError::TimedOut)?
    }
}

#[derive(Clone, Debug, PartialEq, Eq)]
pub enum SyncError {
    Cancelled,
    TimedOut,
    Connection {
        stage: &'static str,
        cause: Box<SyncError>,
    },
    Native {
        operation: &'static str,
        code: u32,
    },
    InvalidData(&'static str),
    Transport(&'static str),
    HttpStatus(u16),
    ServerStatus(u8),
}
impl fmt::Display for SyncError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        match self {
            Self::Cancelled => f.write_str("Session cancelled."),
            Self::TimedOut => f.write_str("Operation timed out."),
            Self::Connection { stage, cause } => write!(f, "Connection stage {stage}: {cause}"),
            Self::Native { operation, code } => write!(f, "{operation}: native error {code}."),
            Self::InvalidData(field) => write!(f, "Invalid or missing {field}."),
            Self::Transport(kind) => write!(f, "Transport: {kind}."),
            Self::HttpStatus(code) => write!(f, "HTTP status {code}."),
            Self::ServerStatus(code) => write!(f, "Authentication server status {code}."),
        }
    }
}
impl SyncError {
    pub fn connection_failure(&self) -> Option<(&'static str, &'static str, Option<u32>)> {
        let Self::Connection { stage, cause } = self else {
            return None;
        };
        let (kind, code) = match cause.as_ref() {
            Self::TimedOut => ("timeout", None),
            Self::Native { code, .. } => ("native", Some(*code)),
            _ => ("other", None),
        };
        Some((*stage, kind, code))
    }
}
impl Error for SyncError {}
#[allow(async_fn_in_trait)]
pub trait AtcChannel {
    async fn receive(&mut self) -> Result<Dictionary, SyncError>;
    async fn send(&mut self, plist: &Dictionary) -> Result<(), SyncError>;
}
