pub fn valid_bundle(s: &str) -> bool {
    s.len() <= 255
        && s.contains('.')
        && s.split('.')
            .all(|p| !p.is_empty() && p.bytes().all(|c| c.is_ascii_alphanumeric() || c == b'-'))
}
