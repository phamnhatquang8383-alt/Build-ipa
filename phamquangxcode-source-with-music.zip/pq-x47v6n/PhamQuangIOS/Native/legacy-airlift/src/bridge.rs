use std::path::Path;
pub(crate) fn valid_transfer_path(path: &Path, temp: &Path) -> bool {
    let Some(parent) = path.parent() else {
        return false;
    };
    let Some(uuid) = parent.file_name().and_then(|s| s.to_str()) else {
        return false;
    };
    let valid_uuid = uuid.len() == 36
        && uuid.bytes().enumerate().all(|(i, c)| {
            if [8, 13, 18, 23].contains(&i) {
                c == b'-'
            } else {
                c.is_ascii_hexdigit()
            }
        });
    if !valid_uuid
        || !path.is_absolute()
        || path.file_name().is_none()
        || path
            .components()
            .any(|c| matches!(c, std::path::Component::ParentDir))
    {
        return false;
    }
    let Ok(actual) = std::fs::canonicalize(parent) else {
        return false;
    };
    let Ok(temp) = std::fs::canonicalize(temp) else {
        return false;
    };
    actual == temp.join("CC365-Files").join(uuid)
        && !std::fs::symlink_metadata(path).is_ok_and(|m| m.is_symlink())
}

use crate::{device::DeviceSession, storage, sync::SyncControl};
use serde::Deserialize;
use serde_json::{Value, json};
use std::{
    ffi::c_void,
    panic::{AssertUnwindSafe, catch_unwind},
    sync::{
        Arc,
        atomic::{AtomicBool, Ordering},
    },
    time::Duration,
};
static OCCUPIED: AtomicBool = AtomicBool::new(false);
struct Slot;
impl Slot {
    fn acquire() -> Option<Self> {
        OCCUPIED
            .compare_exchange(false, true, Ordering::AcqRel, Ordering::Acquire)
            .ok()
            .map(|_| Self)
    }
}
impl Drop for Slot {
    fn drop(&mut self) {
        OCCUPIED.store(false, Ordering::Release);
    }
}
pub struct LegacyJob {
    cancelled: Arc<AtomicBool>,
}
pub type Callback = extern "C" fn(*mut c_void, *const u8, usize);
#[derive(Deserialize)]
struct Request {
    action: String,
    pairing_path: String,
    #[serde(default)]
    patch: bool,
    #[serde(default)]
    host: String,
    #[serde(default = "default_port")]
    port: u16,
    #[serde(default)]
    own_bundle: String,
    #[serde(default)]
    own_home: String,
    #[serde(default)]
    expected_os: String,
    #[serde(default)]
    bundle_id: String,
    #[serde(default)]
    declared_bundle_id: Option<String>,
    #[serde(default)]
    patch_scope: String,
    #[serde(default)]
    expected_root: Option<String>,
    #[serde(default)]
    target_id: Option<String>,
    #[serde(default)]
    patch_items: Vec<crate::device::patch::PatchItem>,
    #[serde(default)]
    path: String,
    #[serde(default)]
    local_path: Option<std::path::PathBuf>,
    #[serde(default)]
    offset: usize,
    #[serde(flatten)]
    options: crate::device::files::ListOptions,
}
fn default_port() -> u16 {
    49152
}
fn bounded(s: &str, max: usize) -> bool {
    !s.is_empty() && s.len() <= max && !s.chars().any(char::is_control)
}
fn validate(r: &Request) -> bool {
    if r.host != "10.7.0.1"
        || r.port == 0
        || !bounded(&r.pairing_path, 4096)
        || !Path::new(&r.pairing_path).is_absolute()
    {
        return false;
    }
    if r.patch && r.action == "history" {
        return r.patch_items.is_empty();
    }
    if !crate::identity::valid_bundle(&r.own_bundle)
        || !bounded(&r.own_home, 4096)
        || !r.own_home.starts_with('/')
        || !bounded(&r.expected_os, 32)
    {
        return false;
    }
    if r.action == "probe" {
        return !r.patch && r.patch_items.is_empty();
    }
    if r.patch {
        if r.declared_bundle_id
            .as_deref()
            .is_some_and(|id| id != r.bundle_id || !crate::identity::valid_bundle(id))
        {
            return false;
        }
        if r.action == "resolve" {
            return crate::identity::valid_bundle(&r.bundle_id) && r.patch_items.is_empty();
        }
        if !crate::device::patch::valid_request(
            &r.action,
            &r.bundle_id,
            &r.patch_scope,
            r.expected_root.as_deref(),
            &r.patch_items,
            &std::env::temp_dir(),
        ) {
            return false;
        }
        if matches!(r.action.as_str(), "apply" | "restore") && r.expected_root.is_none() {
            return false;
        }
        if r.target_id.as_deref().is_some_and(|v| {
            !v.starts_with("path:/var/mobile/Containers/Data/Application/") || v.len() > 512
        }) {
            return false;
        }
        true
    } else {
        matches!(r.action.as_str(), "list" | "download" | "details")
            && bounded(&r.path, 4096)
            && r.offset <= 1_000_000
            && r.options.valid()
            && (r.action != "download"
                || r.local_path
                    .as_deref()
                    .is_some_and(|p| valid_transfer_path(p, &std::env::temp_dir())))
    }
}
fn emit(callback: Callback, context: usize, event: Value) {
    if let Ok(bytes) = serde_json::to_vec(&event) {
        callback(context as *mut c_void, bytes.as_ptr(), bytes.len());
    }
}
#[unsafe(no_mangle)]
pub unsafe extern "C" fn viet99_airlift_job_start(
    bytes: *const u8,
    length: usize,
    callback: Option<Callback>,
    context: *mut c_void,
    out_job: *mut *mut LegacyJob,
) -> i32 {
    if out_job.is_null() {
        return 1;
    }
    unsafe {
        *out_job = std::ptr::null_mut();
    }
    catch_unwind(AssertUnwindSafe(||{
        if bytes.is_null()||length==0||length>4*1024*1024{return 1}
        let Some(callback)=callback else{return 1};
        let Ok(request)=serde_json::from_slice::<Request>(unsafe{std::slice::from_raw_parts(bytes,length)})else{return 1};
        if !validate(&request){return 1}
        let Some(slot)=Slot::acquire()else{return 2};
        let cancelled=Arc::new(AtomicBool::new(false));let job=Box::new(LegacyJob{cancelled:cancelled.clone()});let context=context as usize;
        match std::thread::Builder::new().name("Viet99 AirLift".into()).spawn(move||{
            let slot=slot;
            let read_only=matches!(request.action.as_str(),"probe"|"apps"|"resolve"|"list"|"details"|"download");
            let result=catch_unwind(AssertUnwindSafe(||run(request,cancelled.clone(),callback,context)));
            let result=match result {Ok(v)=>v,Err(_)=>Err("Phiên AirLift bị gián đoạn. Bản sao khôi phục được giữ lại; hãy mở Lịch sử patch để kiểm tra.".into())};
            drop(slot);
            match result {Ok(value)=>emit(callback,context,json!({"kind":"complete","result":value})),Err(message)=>emit(callback,context,json!({"kind":"error","message":message,"cancelled":read_only && cancelled.load(Ordering::Acquire)}))}
        }) {Ok(_)=>{unsafe{*out_job=Box::into_raw(job)};0},Err(_)=>3}
    })).unwrap_or(3)
}
fn run(
    r: Request,
    cancelled: Arc<AtomicBool>,
    callback: Callback,
    context: usize,
) -> Result<Value, String> {
    if r.patch && r.action == "history" {
        return crate::device::patch::history(Path::new(&r.pairing_path));
    }
    let runtime = tokio::runtime::Builder::new_current_thread()
        .enable_all()
        .build()
        .map_err(|_| "Không khởi tạo được kết nối AirLift.")?;
    runtime.block_on(Box::pin(async move{
        let control=SyncControl::new(cancelled,Arc::new(move|message|emit(callback,context,json!({"kind":"log","message":message}))))
            .with_patch_progress(Arc::new(move|phase,done,total,path|emit(callback,context,json!({"kind":"progress","progress":{"phase":phase,"done":done,"total":total,"path":path}}))));
        let mut device=DeviceSession::connect(Path::new(&r.pairing_path),&r.host,r.port,control).await.map_err(|_|"Chưa xác thực được pairing. Bật VPN nội bộ, mở khóa iPhone và kiểm tra tệp pairing.".to_string())?;
        let result=async{
            let report=device.probe(&r.expected_os).await?;
            device.verify_own_app(&r.own_bundle,&r.own_home).await?;
            if r.action=="probe" {let mut safe=report;safe.as_object_mut().map(|v|v.remove("udid"));return Ok(safe)}
            if !r.patch {return device.browse(&r.action,&r.path,r.offset,r.local_path.as_deref(),&r.options).await}
            if r.action=="apps" {return device.patch("apps","","",None,&[]).await}
            let app=device.selected_app(&r.bundle_id).await?;
            if r.target_id.as_deref().is_some_and(|v|app["target_id"].as_str()!=Some(v)){return Err("Container ứng dụng đã thay đổi. Chọn lại ứng dụng trước khi tiếp tục.".into())}
            if r.action=="resolve" {return Ok(json!({"app":app}))}
            let root=if r.patch_scope=="bundle"{app["bundle_path"].as_str()}else{app["data_path"].as_str()};
            let canonical=|s:&str|s.strip_prefix("/private").unwrap_or(s).to_owned();
            if r.expected_root.as_deref().is_some_and(|v|root.map(canonical)!=Some(canonical(v))){return Err("Ứng dụng đã đổi container; bản sao được giữ nguyên.".into())}
            if r.action=="apply" {crate::device::patch::remember_target(Path::new(&r.pairing_path),report["udid"].as_str().ok_or("Thiếu định danh iPhone.")?,&r.bundle_id,&r.patch_scope,app)?;}
            device.patch(&r.action,&r.bundle_id,&r.patch_scope,r.expected_root.as_deref(),&r.patch_items).await
        }.await;
        let _=tokio::time::timeout(Duration::from_secs(2),device.close()).await;
        result
    }))
}
#[unsafe(no_mangle)]
pub unsafe extern "C" fn viet99_airlift_job_cancel(job: *mut LegacyJob) {
    if let Some(j) = unsafe { job.as_ref() } {
        j.cancelled.store(true, Ordering::Release);
    }
}
#[unsafe(no_mangle)]
pub unsafe extern "C" fn viet99_airlift_job_release(job: *mut LegacyJob) {
    if !job.is_null() {
        let j = unsafe { Box::from_raw(job) };
        j.cancelled.store(true, Ordering::Release);
    }
}
#[repr(C)]
pub struct LegacyBuffer {
    pub data: *mut u8,
    pub length: usize,
}
fn buffer(v: Value) -> LegacyBuffer {
    let bytes = serde_json::to_vec(&v)
        .unwrap_or_default()
        .into_boxed_slice();
    let length = bytes.len();
    LegacyBuffer {
        data: Box::into_raw(bytes) as *mut u8,
        length,
    }
}
#[unsafe(no_mangle)]
pub unsafe extern "C" fn viet99_airlift_buffer_free(b: LegacyBuffer) {
    if !b.data.is_null() {
        unsafe {
            drop(Box::from_raw(std::ptr::slice_from_raw_parts_mut(
                b.data, b.length,
            )))
        }
    }
}
#[unsafe(no_mangle)]
pub unsafe extern "C" fn viet99_airlift_storage(bytes: *const u8, length: usize) -> LegacyBuffer {
    let result = catch_unwind(AssertUnwindSafe(|| -> Result<Value, String> {
        if bytes.is_null() || length == 0 || length > 32768 {
            return Err("Yêu cầu pairing không hợp lệ.".into());
        }
        let v: Value = serde_json::from_slice(unsafe { std::slice::from_raw_parts(bytes, length) })
            .map_err(|_| "Yêu cầu pairing không hợp lệ.")?;
        let path = Path::new(
            v["path"]
                .as_str()
                .filter(|s| bounded(s, 4096))
                .ok_or("Thiếu nơi lưu pairing.")?,
        );
        match v["action"].as_str() {
            Some("exists") => Ok(json!({"exists":storage::exists(path)})),
            Some("import") => {
                let _slot =
                    Slot::acquire().ok_or("AirLift đang chạy; chờ dọn phiên rồi đổi pairing.")?;
                let source = Path::new(
                    v["source"]
                        .as_str()
                        .filter(|s| bounded(s, 4096))
                        .ok_or("Thiếu tệp pairing.")?,
                );
                let data = storage::read_import(source)
                    .map_err(|_| "Không đọc được tệp pairing thông thường (tối đa 1 MiB).")?;
                storage::save(path,&data).map_err(|_|"Tệp pairing thiếu hoặc sai chứng chỉ/khóa. Hãy xuất lại từ thiết bị đã tin cậy.")?;
                Ok(json!({"saved":true}))
            }
            Some("remove") => {
                let _slot =
                    Slot::acquire().ok_or("AirLift đang chạy; chờ dọn phiên rồi xóa pairing.")?;
                storage::remove(path).map_err(|_| "Không xóa được pairing.")?;
                Ok(json!({"removed":true}))
            }
            _ => Err("Thao tác pairing không hợp lệ.".into()),
        }
    }));
    buffer(match result {
        Ok(Ok(v)) => v,
        Ok(Err(e)) => json!({"error":e}),
        Err(_) => json!({"error":"Không xử lý được pairing."}),
    })
}

#[cfg(test)]
mod tests {
    use super::*;
    fn request() -> Request {
        serde_json::from_value(json!({"action":"probe","pairing_path":"/private/fixture/pairing.plist","host":"10.7.0.1","own_bundle":"test.viet99","own_home":"/var/mobile/Containers/Data/Application/00000000-0000-0000-0000-000000000001","expected_os":"18.7.2"})).unwrap()
    }
    #[test]
    fn refuses_foreign_hosts_and_missing_current_app_identity() {
        let mut r = request();
        assert!(validate(&r));
        for host in ["127.0.0.1", "localhost", "192.168.1.4", "10.7.0.1.evil"] {
            r.host = host.into();
            assert!(!validate(&r));
        }
        r = request();
        r.own_home.clear();
        assert!(!validate(&r));
        r = request();
        r.own_bundle.clear();
        assert!(!validate(&r));
    }
    #[test]
    fn mutation_requires_fresh_explicit_root_and_no_unowned_sources() {
        let mut r = request();
        r.patch = true;
        r.action = "restore".into();
        r.bundle_id = "test.app".into();
        r.patch_scope = "data".into();
        assert!(!validate(&r));
        r.expected_root = Some(
            "/var/mobile/Containers/Data/Application/00000000-0000-0000-0000-000000000002".into(),
        );
        assert!(validate(&r));
        r.action = "apply".into();
        assert!(!validate(&r));
    }
    #[test]
    fn history_is_offline_but_still_rejects_remote_host() {
        let mut r = request();
        r.action = "history".into();
        r.patch = true;
        r.own_bundle.clear();
        r.own_home.clear();
        assert!(validate(&r));
        r.host = "192.168.0.1".into();
        assert!(!validate(&r));
    }
    #[test]
    fn details_and_valid_list_options_are_supported_but_unknown_options_fail() {
        let mut v=serde_json::to_value(json!({"action":"details","pairing_path":"/private/fixture/pairing.plist","host":"10.7.0.1","own_bundle":"test.viet99","own_home":"/var/mobile/Containers/Data/Application/00000000-0000-0000-0000-000000000001","expected_os":"18.7.2","path":"/var/mobile/Media/a","sort":"created"})).unwrap();
        let r: Request = serde_json::from_value(v.clone()).unwrap();
        assert!(validate(&r));
        v["sort"] = json!("unsupported");
        assert!(!validate(&serde_json::from_value(v).unwrap()));
    }
    #[test]
    fn partial_traversal_or_symlink_local_paths_are_not_accepted_as_patch_sources() {
        let root = tempfile::tempdir().unwrap();
        let parent = root
            .path()
            .join("CC365-Files/00000000-0000-0000-0000-000000000001");
        std::fs::create_dir_all(&parent).unwrap();
        let p = parent.join("file");
        std::fs::write(&p, b"fixture").unwrap();
        assert!(valid_transfer_path(&p, root.path()));
        assert!(!valid_transfer_path(
            &parent.join("../outside"),
            root.path()
        ));
        std::os::unix::fs::symlink(&p, parent.join("link")).unwrap();
        assert!(!valid_transfer_path(&parent.join("link"), root.path()));
    }
    extern "C" fn terminal(context: *mut c_void, bytes: *const u8, len: usize) {
        let value: Value =
            serde_json::from_slice(unsafe { std::slice::from_raw_parts(bytes, len) }).unwrap();
        if matches!(value["kind"].as_str(), Some("complete" | "error")) {
            let sender =
                unsafe { Box::from_raw(context as *mut std::sync::mpsc::Sender<(Value, bool)>) };
            let slot = Slot::acquire();
            let free = slot.is_some();
            drop(slot);
            sender.send((value, free)).unwrap();
        }
    }
    #[test]
    fn worker_releases_exclusive_slot_before_terminal_callback_and_history_needs_no_pairing() {
        let root = tempfile::tempdir().unwrap();
        let bytes=serde_json::to_vec(&json!({"action":"history","patch":true,"pairing_path":root.path().join("pairing.plist"),"host":"10.7.0.1"})).unwrap();
        let (tx, rx) = std::sync::mpsc::channel::<(Value, bool)>();
        let context = Box::into_raw(Box::new(tx));
        let mut job = std::ptr::null_mut();
        let code = unsafe {
            viet99_airlift_job_start(
                bytes.as_ptr(),
                bytes.len(),
                Some(terminal),
                context as *mut c_void,
                &mut job,
            )
        };
        if code != 0 {
            unsafe { drop(Box::from_raw(context)) }
        }
        assert_eq!(code, 0);
        let (value, free) = rx.recv_timeout(Duration::from_secs(5)).unwrap();
        assert_eq!(value["kind"], "complete");
        assert_eq!(value["result"]["patches"], json!([]));
        assert!(free);
        unsafe { viet99_airlift_job_release(job) };
        assert!(!root.path().join("pairing.plist").exists());
    }
}

#[cfg(test)]
mod source_owner_tests {
    use super::*;
    #[test]
    fn declared_source_owner_only_vetoes_and_never_overrides_the_selected_bundle() {
        let mut value = json!({"action":"status","patch":true,"pairing_path":"/private/fixture/pairing.plist","host":"10.7.0.1","own_bundle":"test.viet99","own_home":"/var/mobile/Containers/Data/Application/00000000-0000-0000-0000-000000000001","expected_os":"18.7.2","bundle_id":"fixture.app","patch_scope":"data","declared_bundle_id":"other.app"});
        assert!(!validate(&serde_json::from_value(value.clone()).unwrap()));
        value["declared_bundle_id"] = json!("fixture.app");
        assert!(validate(&serde_json::from_value(value).unwrap()));
    }
}
