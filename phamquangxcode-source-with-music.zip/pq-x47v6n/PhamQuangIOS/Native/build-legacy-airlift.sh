#!/bin/bash
set -euo pipefail
native_dir="$(cd "$(dirname "$0")" && pwd)"
project_dir="$(cd "$native_dir/.." && pwd)"
manifest="$native_dir/legacy-airlift/Cargo.toml"
build_root="${VIET99_AIRLIFT_BUILD_DIR:-$project_dir/build/rust/legacy}"
cargo_options=(--locked)
if [[ "${VIET99_AIRLIFT_OFFLINE:-0}" == 1 ]]; then cargo_options+=(--offline); fi
export CARGO_BUILD_JOBS="${CARGO_BUILD_JOBS:-4}"
case "${1:-ios}" in
  --test) CARGO_TARGET_DIR="$build_root" cargo test "${cargo_options[@]}" --manifest-path "$manifest" ;;
  --host) CARGO_TARGET_DIR="$build_root" cargo build "${cargo_options[@]}" --manifest-path "$manifest" ;;
  --simulator) IPHONEOS_DEPLOYMENT_TARGET=16.0 CARGO_TARGET_DIR="$build_root" cargo build "${cargo_options[@]}" --release --target aarch64-apple-ios-sim --manifest-path "$manifest" ;;
  ios)
    IPHONEOS_DEPLOYMENT_TARGET=16.0 CARGO_TARGET_DIR="$build_root" cargo build "${cargo_options[@]}" --release --target aarch64-apple-ios --manifest-path "$manifest"
    archive="$build_root/aarch64-apple-ios/release/libviet99_airlift.a"
    xcrun lipo "$archive" -verify_arch arm64
    install -m 644 "$archive" "$project_dir/Vendor/legacy-airlift/libviet99_airlift.a.new"
    mv "$project_dir/Vendor/legacy-airlift/libviet99_airlift.a.new" "$project_dir/Vendor/legacy-airlift/libviet99_airlift.a"
    ;;
  *) echo 'Usage: Native/build-legacy-airlift.sh [--test|--host|--simulator]' >&2; exit 2 ;;
esac
