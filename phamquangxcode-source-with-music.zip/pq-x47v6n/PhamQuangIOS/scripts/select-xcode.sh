#!/bin/bash
set -u
active=$(/usr/bin/xcode-select -p 2>/dev/null)
for candidate in "$active" /Applications/Xcode*.app/Contents/Developer "$HOME/Downloads/Xcode.app/Contents/Developer"; do
    [ -x "$candidate/usr/bin/xcodebuild" ] || continue
    for sdk in "$candidate"/Platforms/iPhoneOS.platform/Developer/SDKs/iPhoneOS*.sdk; do
        [ -d "$sdk" ] || continue
        version=$(/usr/libexec/PlistBuddy -c 'Print :Version' "$sdk/SDKSettings.plist" 2>/dev/null) || continue
        if [[ ${version%%.*} =~ ^[0-9]+$ ]] && (( ${version%%.*} >= 26 )); then
            printf '%s\n' "$candidate"
            exit 0
        fi
    done
done
exit 1
