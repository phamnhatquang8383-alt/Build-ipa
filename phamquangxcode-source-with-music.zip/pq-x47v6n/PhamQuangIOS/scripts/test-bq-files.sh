#!/bin/bash
set -euo pipefail
cd "$(dirname "$0")/.."
build_dir="${BUILD_DIR:-$PWD/build}/Tests"
scratch=$(mktemp -d "${TMPDIR:-/tmp}/cc365-bq-host.XXXXXX")
trap 'rm -rf "$scratch"' EXIT
mkdir -p "$build_dir" "$scratch/UIKit"
printf '#pragma once\n' > "$scratch/UIKit/UIKit.h"
xcrun --sdk macosx clang -fobjc-arc -fblocks -Wall -Wextra -Werror \
  -Drenameatx_np=CCBQTestRename \
  -I "$scratch" -I CC365-Apps/Files/BQCore \
  Tests/BQFileSystemTests.m CC365-Apps/Files/BQCore/CCBQFileSystem.m \
  -framework Foundation -o "$build_dir/BQFileSystemTests"
"$build_dir/BQFileSystemTests"
xcrun --sdk macosx clang -fobjc-arc -fblocks -Wall -Wextra -Werror \
  -I "$scratch" -I CC365-Apps/Files/BQCore \
  Tests/BQFileRootsTests.m -framework Foundation -o "$build_dir/BQFileRootsTests"
"$build_dir/BQFileRootsTests"
xcrun --sdk macosx clang -fobjc-arc -fblocks -Wall -Wextra -Werror \
  -I "$scratch" -I CC365-Apps/Files/BQCore \
  Tests/BQContainerCatalogTests.m -framework Foundation \
  -o "$build_dir/BQContainerCatalogTests"
"$build_dir/BQContainerCatalogTests"
