#!/usr/bin/env python3

import argparse
import hashlib
import os
from pathlib import Path
import plistlib
import shutil
import subprocess
import tempfile
import zipfile
from typing import Optional


def validate_app(app: Path, *, expected_bundle_id: Optional[str] = None,
                 expected_display_name: Optional[str] = None,
                 expected_version: Optional[str] = None,
                 expected_build: Optional[str] = None,
                 expected_tunnel_bundle_id: Optional[str] = None) -> str:
    if not app.is_dir() or app.suffix != ".app" or app.is_symlink():
        raise ValueError(f"Application bundle not found: {app}")
    with (app / "Info.plist").open("rb") as stream:
        info = plistlib.load(stream)
    executable = info.get("CFBundleExecutable")
    if not isinstance(executable, str) or not executable or Path(executable).name != executable:
        raise ValueError("Invalid CFBundleExecutable")
    if not (app / executable).is_file() or (app / executable).is_symlink():
        raise ValueError("Application executable is missing")
    if not os.access(app / executable, os.X_OK):
        raise ValueError("Application executable has no executable permission")
    if info.get("CFBundlePackageType") != "APPL" or info.get("CFBundleSupportedPlatforms") != ["iPhoneOS"]:
        raise ValueError("Expected an iPhoneOS application")
    for key, expected in (("CFBundleIdentifier", expected_bundle_id),
                          ("CFBundleDisplayName", expected_display_name),
                          ("CFBundleShortVersionString", expected_version),
                          ("CFBundleVersion", expected_build)):
        if expected is not None and info.get(key) != expected:
            raise ValueError(f"Unexpected application {key}: expected {expected!r}, got {info.get(key)!r}")


    for key in ("NSBonjourServices", "CFBundleURLTypes", "LSApplicationQueriesSchemes"):
        if key in info:
            raise ValueError("Files app must not contain pairing/network registration: " + key)
    if "NSLocalNetworkUsageDescription" in info and not (
            isinstance(info["NSLocalNetworkUsageDescription"], str) and info["NSLocalNetworkUsageDescription"].strip()):
        raise ValueError("Local network usage must explain AirLift access")
    allowed_extension = app / "PlugIns/Viet99Tunnel.appex" if expected_tunnel_bundle_id else None
    if allowed_extension:
        if not allowed_extension.is_dir() or allowed_extension.is_symlink():
            raise ValueError("Expected internal VPN extension is missing")
        with (allowed_extension / "Info.plist").open("rb") as stream:
            tunnel = plistlib.load(stream)
        expected = {"CFBundleIdentifier": expected_tunnel_bundle_id, "CFBundlePackageType": "XPC!",
                    "CFBundleSupportedPlatforms": ["iPhoneOS"],
                    "CFBundleShortVersionString": info.get("CFBundleShortVersionString"),
                    "CFBundleVersion": info.get("CFBundleVersion"), "MinimumOSVersion": "16.0"}
        if any(tunnel.get(key) != value for key, value in expected.items()):
            raise ValueError("Internal VPN extension metadata does not match app")
        if tunnel.get("NSExtension", {}).get("NSExtensionPointIdentifier") != "com.apple.networkextension.packet-tunnel":
            raise ValueError("Invalid internal VPN extension point")
        tunnel_executable = tunnel.get("CFBundleExecutable", "")
        if not tunnel_executable or Path(tunnel_executable).name != tunnel_executable or not os.access(allowed_extension / tunnel_executable, os.X_OK):
            raise ValueError("Internal VPN extension executable is missing")
    for path in app.rglob("*"):
        if path.name == "_CodeSignature" or path.suffix.lower() in (
                ".mobileprovision", ".provisionprofile", ".p12", ".pfx", ".cer", ".crt"):
            raise ValueError("Bundle contains signing material; rebuild unsigned")
        if path.name == "PlugIns" and path != app / "PlugIns":
            raise ValueError("Unexpected nested extension directory")
        if path.suffix.lower() == ".appex" and path != allowed_extension:
            raise ValueError("Unexpected app extension")
    if (app / "PlugIns").exists():
        if set((app / "PlugIns").iterdir()) != ({allowed_extension} if allowed_extension else set()):
            raise ValueError("Unexpected app extension contents")
    for bundle in [app] + ([allowed_extension] if allowed_extension else []):
        verification = subprocess.run(["/usr/bin/codesign", "--display", str(bundle)], capture_output=True, text=True)
        if verification.returncode == 0:
            raise ValueError("Application or extension is signed; an unsigned IPA was requested")
        if "not signed at all" not in verification.stderr:
            raise ValueError("Cannot establish unsigned state: " + verification.stderr.strip())
    return executable


def archive_app(app: Path, output: Path, executable: str) -> str:

    output.parent.mkdir(parents=True, exist_ok=True)
    fd, temporary = tempfile.mkstemp(prefix=".PhamQuangIOS-", suffix=".ipa", dir=output.parent)
    os.close(fd)
    temp = Path(temporary)
    try:
        with zipfile.ZipFile(temp, "w", compression=zipfile.ZIP_DEFLATED, compresslevel=6) as archive:
            for path in sorted(app.rglob("*")):
                if path.is_symlink():
                    raise ValueError(f"Unexpected symlink in application: {path.relative_to(app)}")
                if path.is_file():
                    archive.write(path, "Payload/" + app.name + "/" + path.relative_to(app).as_posix())
        with zipfile.ZipFile(temp) as archive:
            if archive.testzip() is not None:
                raise ValueError("IPA integrity check failed")
            names = archive.namelist()
            prefix = "Payload/" + app.name + "/"
            if not all(name.startswith(prefix) for name in names):
                raise ValueError("Unexpected file outside Payload application")
            if prefix + "Info.plist" not in names or prefix + executable not in names:
                raise ValueError("IPA is missing application metadata or executable")
            mode = archive.getinfo(prefix + executable).external_attr >> 16
            if not mode & 0o111:
                raise ValueError("IPA lost executable permissions")
        digest = hashlib.sha256(temp.read_bytes()).hexdigest()
        os.replace(temp, output)
        output.with_suffix(output.suffix + ".sha256").write_text(f"{digest}  {output.name}\n")
        return digest
    finally:
        temp.unlink(missing_ok=True)


def clean(path: Path) -> None:
    root = Path(__file__).resolve().parents[1]

    resolved = path.resolve()
    if resolved != root / "build" or path.is_symlink():
        raise ValueError("make clean only removes the project-local build directory")
    if resolved.exists():
        shutil.rmtree(resolved)


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--app", type=Path)
    parser.add_argument("--output", type=Path)
    parser.add_argument("--clean", type=Path)
    parser.add_argument("--expected-bundle-id")
    parser.add_argument("--expected-display-name")
    parser.add_argument("--expected-version")
    parser.add_argument("--expected-build")
    parser.add_argument("--expected-tunnel-bundle-id")
    args = parser.parse_args()
    if args.clean:
        clean(args.clean)
        return
    if not args.app or not args.output:
        parser.error("--app and --output are required")
    app = args.app.resolve()
    executable = validate_app(app,
                              expected_bundle_id=args.expected_bundle_id,
                              expected_display_name=args.expected_display_name,
                              expected_version=args.expected_version,
                              expected_build=args.expected_build,
                              expected_tunnel_bundle_id=args.expected_tunnel_bundle_id)
    digest = archive_app(app, args.output.resolve(), executable)
    print(f"Unsigned IPA: {args.output.resolve()}")
    print(f"SHA-256: {digest}")


if __name__ == "__main__":
    main()
