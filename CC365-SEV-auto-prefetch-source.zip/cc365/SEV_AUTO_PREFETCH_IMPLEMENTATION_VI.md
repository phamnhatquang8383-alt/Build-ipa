# SEV V2 — tự tải package vào CC365

## Đã chỉnh sửa

- `CC365-Apps/Runtime/SEVAccessManager.swift`: sau khi bootstrap hoặc kích hoạt key thành công, tạo tác vụ nền lấy `feature-catalog` và tự tải các package đang bật. Tác vụ nền không chặn giao diện khởi động.
- `CC365-Apps/Runtime/SEVFeaturePackageManager.swift`: thêm prefetch có kiểm tra URL HTTPS/Supabase, giới hạn 50 MiB, kích thước, SHA-256, định dạng ZIP/VPATCH, manifest gốc `sev-feature.json`, và đường dẫn archive. Cache nằm trong `Application Support/SEVManagedFeatures/<feature-id>` của CC365. Có coordinator để gộp các yêu cầu tải trùng nhau.
- `CC365-Apps/Files/AppPatchView.swift`: Feature Center hiển thị trạng thái đã tự tải/xác minh; mở màn hình sẽ đồng bộ catalogue và các package còn thiếu. Bật dùng cache đã xác minh; tắt gọi quy trình restore hiện có.
- `SEV-FEATURE-CATALOG-INTEGRATION.md` và `UPGRADE_NOTES_VI.md`: cập nhật hướng dẫn.

## Định dạng được hỗ trợ

- `.zip` hoặc `.vpatch` tương thích ZIP, có `sev-feature.json` ở thư mục gốc.
- `.vailon` không được dùng làm SEV Feature package. Archive chứa `Application/<bundle-id>/` bị loại bỏ ở bước kiểm tra.
- Gói chỉ được cài trong thư mục dữ liệu riêng của CC365; receipt/baseline/history giữ nguyên quy trình khôi phục.

## Kiểm tra đã chạy

- `swiftc -frontend -parse` trên ba file Swift đã chỉnh sửa: thành công (kiểm tra cú pháp, không phải build iOS).
- `python3 -m unittest discover -s Tests -p 'test_package_ipa.py' -v`: 9/9 tests passed.
- Chưa chạy được Xcode/iOS build hoặc tạo IPA trong môi trường này vì không có `xcodebuild`/iOS SDK.
