# SEV Remote Package Manager — package contract v1

## Package contents

A ZIP uploaded through SEV Admin must contain `sev-feature.json` at its root. The package is data-only. It must not contain Swift source, scripts, dynamic libraries, frameworks, app bundles, plug-ins, or executable payloads.

Example:

```json
{
  "schemaVersion": 1,
  "featureID": "tess",
  "moduleID": "cc365.feature-center.presentation",
  "settings": {
    "displayTitle": "Tess",
    "statusText": "Remote configuration active",
    "accentStyle": "violet"
  }
}
```

## Pre-integrated module allowlist

- `cc365.feature-center.presentation`: `displayTitle`, `statusText`, `accentStyle`
- `cc365.diagnostics.banner`: `message`, `severity`, `visible`
- `cc365.content.visibility`: `showAdvancedOptions`, `showDescriptions`

The iOS binary contains the module implementations. SEV packages only configure allowlisted modules; a package cannot introduce executable Swift code or arbitrary capabilities.

## Apply / restore

1. Refresh the SEV Feature Catalog to obtain the current short-lived HTTPS URL.
2. Download into a temporary location; enforce the 50 MiB limit, exact size and SHA-256.
3. Extract into a staging directory using safe relative paths.
4. Validate `sev-feature.json`, `featureID`, `schemaVersion`, module allowlist and settings keys.
5. Atomically swap the staged directory into `Application Support/SEVManagedFeatures/<feature-id>/active`, preserving any previous active directory as `baseline`.
6. Activate the allowlisted module settings in the app's namespaced UserDefaults store. The Feature Center consumes `displayTitle` and `statusText` at runtime.
7. On OFF, archive the applied package, restore the previous directory if one existed, clear the feature's runtime namespace, then reactivate the restored package's configuration.

All file writes are confined to this app's Application Support directory. No other app container, game process, app bundle, sandbox, kernel, exploit, or BQCore path is resolved or opened.
