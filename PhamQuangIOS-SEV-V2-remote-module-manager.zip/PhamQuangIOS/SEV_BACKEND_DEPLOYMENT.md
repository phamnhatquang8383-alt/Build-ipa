# SEV V2 backend deployment and connection

This source is connected to the existing production SEV V2 services.

- Vercel project: `phamquang-ios-sev-admin-v2`
- Production admin: `https://phamquang-ios-sev-admin-v2.vercel.app`
- Supabase project: `build-sev`
- Project ref: `bpnwzwpqfakwzduiiwvh`
- Edge Function: `sev-control`
- Function URL: `https://bpnwzwpqfakwzduiiwvh.supabase.co/functions/v1/sev-control`
- Current deployed Edge Function version: `9`
- Admin dashboard Edge Function: `sev-admin`, deployed version `4`

## Version 6 additions

- Adds the authenticated-device `feature-catalog` action.
- Adds admin `upsert-feature` and `delete-feature` actions.
- Adds feature rows to `admin-state`.
- Feature enablement requires a published Patch Center package ID and matching SHA-256.
- The V2 admin UI includes a Feature Toggles page and uses the existing server-side admin authorization.
- Existing bootstrap, validate-key, key/device/IP controls, app controls, patch upload/download and audit actions remain available.

## Client configuration

`CC365-Apps/Runtime/SEVAccessManager.swift` contains the public Supabase endpoint and publishable key. The publishable key is intended for client use. Never replace it with a service-role key.

## Admin account

Sign in at the production V2 admin URL using the existing Supabase Auth account with `app_metadata.role = admin`. Do not put passwords or service-role keys in this archive.

## Security and preservation

- The feature catalogue table has RLS enabled and is not granted to `anon` or `authenticated`; the Edge Function accesses it with its server-side service role.
- The public feature-catalog action requires a valid installation and, when key enforcement is on, an active unexpired license bound to that installation.
- Service-role/secret credentials remain server-side.
- Sandbox, Kernel and KExploit source files are preserved; this integration does not rewrite their implementation.
- No IPA build feature is added to SEV. The admin Patch Center is for patch files only.


## November 2026 live administration updates

- SEV Key creation accepts an omitted label (defaults to `SEV Key`).
- Device limit may be omitted in the admin form and defaults to 1; allowed range remains 1–500.
- Expiration may be omitted to create a key without a time-based expiry.
- Device IP is observed by the server from the incoming connection and stored as the device's latest IP during activation/bootstrap; administrators can review and block an address in the IP controls. IP addresses can be affected by VPN, carrier NAT, or network changes and should be treated as operational signals, not unique identity.
- The `app_closed` control blocks the app at its root access gate. iOS does not provide a supported API for an app to force-terminate itself; the gate prevents access to app content until SEV is reopened.
- The app distinguishes administrator app-closure from maintenance in its access gate.

## Package scope

SEV feature packages are downloaded and stored under this app's own Application Support/SEVManagedFeatures directory. This does not patch another app's private container, Free Fire, iOS kernel, or exploit components. A package affects app behavior only when a supported CC365/PhamQuang feature consumes the managed content.
