# SEV V2 Feature Catalog integration

The Free Fire VN Feature Center is now connected to the SEV V2 `feature-catalog` action (Edge Function version 6).

## Data flow

1. The app completes the existing SEV bootstrap/key authorization.
2. `SEVAccessManager.fetchFeatureCatalog()` sends the persistent installation ID to the Supabase Edge Function.
3. The Edge Function checks maintenance/app-closed state, IP blocks and the installation's active, unexpired license when key enforcement is enabled.
4. The Edge Function returns the admin-managed `sev_feature_catalog` rows.
5. The app displays a toggle only as ready when `enabledByAdmin`, package identity/version, SHA-256, signed download URL, file name and file size are present.
6. The app receives the short-lived `downloadURL`, `fileName` and `fileSize` fields for each published package.
7. Turning a feature ON downloads the package, checks its exact size and SHA-256, validates/extracts the archive, then atomically installs its files under the app-owned `Application Support/SEVManagedFeatures/<feature-id>/active` directory.
8. Turning a feature OFF moves the applied package into a local history folder and restores the previous contents from the preserved baseline. The UI state is refreshed from the on-disk receipt, not from a preference toggle.

## Admin workflow

1. Upload a patch in Patch Center (`.vpatch`, `.vailon` or `.zip`, max 50 MB).
2. Verify the server-side SHA-256 and explicitly publish the package.
3. Open Feature Toggles in SEV V2.
4. Add/update a feature ID, title, description and select the published package. The UI fills its package version and SHA-256 from the published package.
5. Enable the feature and save. The backend independently verifies that the selected package is published and the hash matches.

## Important runtime boundary

The feature package manager only writes beneath this app's own `Application Support/SEVManagedFeatures` directory. It does not resolve or open another app's container, game data, app bundle, process, Sandbox, Kernel, KExploit or BQCore. Package files are data only; no executable code or scripts are launched. The feature toggle represents installation into this managed data directory, not modification of Free Fire's runtime or game files.

The signed URL is short-lived (10 minutes) and comes from the existing `feature-catalog` response; the app refreshes the catalogue immediately before applying to obtain a fresh URL and current admin publication state. Package archives must contain relative data-file paths (no `Application/<bundle-id>` prefixes, absolute paths, hidden path components or traversal). The app enforces HTTPS and the configured Supabase host, a 50 MiB download limit, exact server-reported size, SHA-256, safe archive paths and the existing ZIP extractor's limits. Only `.zip` and ZIP-compatible `.vpatch` are currently accepted by this automatic flow; encrypted `.vailon` packages need a separate password/key UX and are rejected rather than guessed.

Sandbox, Kernel, KExploit, BQCore, LegacyDirect, AirLift and the existing patch/recovery implementation are not modified by this feature manager.
