import Foundation

/// Runtime bridge for data-driven modules that are compiled into CC365/PhamQuang iOS.
/// Remote packages may configure these modules but may never add executable code.
enum SEVFeatureModuleRuntime {
    struct PackageManifest: Decodable {
        let schemaVersion: Int
        let featureID: String
        let moduleID: String
        let settings: [String: String]
    }

    private static let preferencePrefix = "com.phamquang.cc365.sev-module."
    private static let supportedModules: [String: Set<String>] = [
        "cc365.feature-center.presentation": ["displayTitle", "statusText", "accentStyle"],
        "cc365.diagnostics.banner": ["message", "severity", "visible"],
        "cc365.content.visibility": ["showAdvancedOptions", "showDescriptions"]
    ]

    static func validatePackage(at directory: URL, expectedFeatureID: String) throws {
        let manifest = try readManifest(at: directory)
        guard manifest.schemaVersion == 1,
              manifest.featureID == expectedFeatureID,
              let allowedKeys = supportedModules[manifest.moduleID],
              Set(manifest.settings.keys).isSubset(of: allowedKeys) else {
            throw RuntimeError.unsupportedModule
        }
        for (key, value) in manifest.settings {
            guard !key.isEmpty, value.utf8.count <= 2_048 else { throw RuntimeError.invalidSetting }
        }
        let files = try FileManager.default.contentsOfDirectory(at: directory, includingPropertiesForKeys: nil)
        let forbidden = files.filter { ["dylib", "framework", "appex", "app", "sh", "command", "bin", "so"].contains($0.pathExtension.lowercased()) }
        guard forbidden.isEmpty else { throw RuntimeError.executablePayloadRejected }
    }

    static func activate(featureID: String, packageDirectory: URL) throws {
        let manifest = try readManifest(at: packageDirectory)
        try validatePackage(at: packageDirectory, expectedFeatureID: featureID)
        let defaults = UserDefaults.standard
        let prefix = preferencePrefix + featureID + "."
        // Clear only this feature's namespaced values, then install its allowlisted settings.
        for key in defaults.dictionaryRepresentation().keys where key.hasPrefix(prefix) {
            defaults.removeObject(forKey: key)
        }
        for (key, value) in manifest.settings {
            defaults.set(value, forKey: prefix + key)
        }
        defaults.set(manifest.moduleID, forKey: preferencePrefix + featureID + ".moduleID")
    }

    static func deactivate(featureID: String) {
        let defaults = UserDefaults.standard
        let prefix = preferencePrefix + featureID + "."
        for key in defaults.dictionaryRepresentation().keys where key.hasPrefix(prefix) {
            defaults.removeObject(forKey: key)
        }
    }

    static func string(_ key: String, featureID: String) -> String? {
        UserDefaults.standard.string(forKey: preferencePrefix + featureID + "." + key)
    }

    static func bool(_ key: String, featureID: String) -> Bool? {
        let name = preferencePrefix + featureID + "." + key
        guard UserDefaults.standard.object(forKey: name) != nil else { return nil }
        return UserDefaults.standard.bool(forKey: name)
    }

    private static func readManifest(at directory: URL) throws -> PackageManifest {
        let url = directory.appendingPathComponent("sev-feature.json")
        guard FileManager.default.fileExists(atPath: url.path) else { throw RuntimeError.manifestMissing }
        do { return try JSONDecoder().decode(PackageManifest.self, from: Data(contentsOf: url)) }
        catch { throw RuntimeError.invalidManifest }
    }

    enum RuntimeError: LocalizedError {
        case manifestMissing, invalidManifest, unsupportedModule, invalidSetting, executablePayloadRejected
        var errorDescription: String? {
            switch self {
            case .manifestMissing: return "Package thiếu sev-feature.json."
            case .invalidManifest: return "Manifest package không hợp lệ."
            case .unsupportedModule: return "Module hoặc trường cấu hình chưa được tích hợp trong phiên bản app này."
            case .invalidSetting: return "Giá trị cấu hình vượt giới hạn cho phép."
            case .executablePayloadRejected: return "Package chứa mã thực thi không được hỗ trợ. Chỉ nhận dữ liệu cấu hình."
            }
        }
    }
}
