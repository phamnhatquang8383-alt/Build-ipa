import SwiftUI
import UIKit

struct SEVAccessGateView: View {
    @ObservedObject var sev: SEVAccessManager
    @State private var key = ""
    @FocusState private var keyFocused: Bool
    @Environment(\.accessibilityReduceMotion) private var reduceMotion

    @State private var appeared = false
    @State private var ambientPhase = false
    @State private var breathing = false
    @State private var sheenPhase = false
    @State private var shakeCount = 0

    private var isBlocked: Bool { sev.state == .maintenance || sev.state == .updateRequired }

    private var trimmedKey: String { key.trimmingCharacters(in: .whitespacesAndNewlines) }

    private var canSubmit: Bool { !sev.isWorking && !trimmedKey.isEmpty }

    var body: some View {
        ZStack {
            background

            VStack(spacing: 0) {
                Spacer(minLength: 44)
                header
                    .padding(.bottom, 0)

                card
                    .padding(.top, 30)

                Spacer()
                footer
                    .padding(.bottom, 24)
            }
            .padding(.horizontal, 24)
            .frame(maxWidth: 480)
            .opacity(appeared ? 1 : 0)
            .offset(y: appeared ? 0 : 24)
        }
        .preferredColorScheme(.dark)
        .animation(.spring(response: 0.42, dampingFraction: 0.86), value: sev.state)
        .onAppear {
            withAnimation(.spring(response: 0.6, dampingFraction: 0.85)) { appeared = true }
            guard !reduceMotion else { return }
            withAnimation(.easeInOut(duration: 7).repeatForever(autoreverses: true)) { ambientPhase.toggle() }
            withAnimation(.easeInOut(duration: 2.4).repeatForever(autoreverses: true)) { breathing.toggle() }
            withAnimation(.linear(duration: 1.6).repeatForever(autoreverses: false)) { sheenPhase.toggle() }
        }
    }

    // MARK: - Background

    private var background: some View {
        ZStack {
            LinearGradient(
                colors: [Color(red: 0.035, green: 0.055, blue: 0.10), Color(red: 0.08, green: 0.10, blue: 0.17), .black],
                startPoint: .topLeading,
                endPoint: .bottomTrailing
            )
            .ignoresSafeArea()

            Circle()
                .fill(
                    RadialGradient(colors: [Color.blue.opacity(0.30), .clear], center: .center, startRadius: 0, endRadius: 150)
                )
                .frame(width: 300, height: 300)
                .offset(x: ambientPhase ? 150 : 95, y: ambientPhase ? -250 : -300)

            Circle()
                .fill(
                    RadialGradient(colors: [Color.cyan.opacity(0.18), .clear], center: .center, startRadius: 0, endRadius: 130)
                )
                .frame(width: 260, height: 260)
                .offset(x: ambientPhase ? -140 : -95, y: ambientPhase ? 260 : 220)
        }
        .ignoresSafeArea()
    }

    // MARK: - Header

    private var header: some View {
        VStack(spacing: 0) {
            ZStack {
                Circle()
                    .fill(Color.cyan.opacity(breathing ? 0.22 : 0.08))
                    .frame(width: 120, height: 120)
                    .blur(radius: 26)

                RoundedRectangle(cornerRadius: 25, style: .continuous)
                    .fill(.ultraThinMaterial)
                    .overlay(
                        RoundedRectangle(cornerRadius: 25, style: .continuous)
                            .stroke(.white.opacity(0.14), lineWidth: 1)
                    )
                    .frame(width: 76, height: 76)
                    .scaleEffect(breathing ? 1.03 : 1.0)

                Image(systemName: isBlocked ? "wrench.and.screwdriver.fill" : "key.horizontal.fill")
                    .font(.system(size: 30, weight: .semibold))
                    .foregroundStyle(Color.cyan)
                    .scaleEffect(breathing ? 1.05 : 1.0)
            }
            .padding(.bottom, 24)

            Text(isBlocked ? (sev.state == .updateRequired ? "Cần cập nhật" : "Đang bảo trì") : "KEY")
                .font(.system(size: 30, weight: .bold, design: .rounded))
                .foregroundStyle(.white)
                .contentTransition(.opacity)

            if isBlocked {
                Text("Thông báo từ hệ thống")
                    .font(.system(size: 15, weight: .medium))
                    .foregroundStyle(.white.opacity(0.58))
                    .padding(.top, 7)
                    .contentTransition(.opacity)
            }
        }
    }

    // MARK: - Card

    private var card: some View {
        VStack(alignment: .leading, spacing: 16) {
            if sev.state == .keyRequired {
                Text("KEY")
                    .font(.system(size: 11, weight: .bold, design: .rounded))
                    .tracking(1.5)
                    .foregroundStyle(.white.opacity(0.55))

                keyField
                    .modifier(ShakeEffect(shakes: CGFloat(shakeCount)))

                submitButton
            }

            Text(sev.message)
                .font(.system(size: 13))
                .foregroundStyle(.white.opacity(0.68))
                .fixedSize(horizontal: false, vertical: true)
                .frame(maxWidth: .infinity, alignment: .leading)
                .contentTransition(.opacity)
                .animation(.easeInOut(duration: 0.25), value: sev.message)

            if sev.state == .error || sev.state == .maintenance {
                Button { Task { await sev.refresh() } } label: {
                    Label("Thử kết nối lại", systemImage: "arrow.clockwise")
                        .font(.system(size: 14, weight: .semibold))
                        .frame(maxWidth: .infinity)
                        .frame(height: 46)
                        .foregroundStyle(.white)
                        .background(.white.opacity(0.09), in: RoundedRectangle(cornerRadius: 14, style: .continuous))
                }
                .buttonStyle(PressableButtonStyle())
                .disabled(sev.isWorking)
            }

            if sev.state == .updateRequired, let url = sev.updateURL {
                Link(destination: url) {
                    Label("Cập nhật ngay", systemImage: "arrow.down.circle.fill")
                        .font(.system(size: 15, weight: .semibold))
                        .frame(maxWidth: .infinity)
                        .frame(height: 50)
                        .foregroundStyle(.white)
                        .background(Color.blue, in: RoundedRectangle(cornerRadius: 14, style: .continuous))
                }
            }

            if let url = sev.announcementURL {
                Link("Xem thông báo", destination: url)
                    .font(.system(size: 13, weight: .medium))
                    .foregroundStyle(.cyan)
            }
        }
        .padding(22)
        .background(.ultraThinMaterial, in: RoundedRectangle(cornerRadius: 26, style: .continuous))
        .overlay(
            RoundedRectangle(cornerRadius: 26, style: .continuous)
                .stroke(
                    LinearGradient(colors: [.white.opacity(0.22), .white.opacity(0.04)], startPoint: .top, endPoint: .bottom),
                    lineWidth: 1
                )
        )
        .shadow(color: .black.opacity(0.35), radius: 24, x: 0, y: 14)
    }

    private var keyField: some View {
        HStack(spacing: 10) {
            Image(systemName: "key.fill")
                .foregroundStyle(keyFocused ? Color.cyan : Color.white.opacity(0.5))
                .animation(.easeInOut(duration: 0.2), value: keyFocused)

            SecureField("Nhập key của bạn", text: $key)
                .textInputAutocapitalization(.characters)
                .autocorrectionDisabled()
                .focused($keyFocused)
                .submitLabel(.go)
                .onSubmit { Task { await activate() } }
                .foregroundStyle(.white)
                .disabled(sev.isWorking)
        }
        .padding(.horizontal, 16)
        .frame(height: 56)
        .background(.black.opacity(keyFocused ? 0.34 : 0.22), in: RoundedRectangle(cornerRadius: 16, style: .continuous))
        .overlay(
            RoundedRectangle(cornerRadius: 16, style: .continuous)
                .strokeBorder(
                    LinearGradient(colors: [.cyan, .blue], startPoint: .leading, endPoint: .trailing),
                    lineWidth: 1.5
                )
                .opacity(keyFocused ? 1 : 0)
        )
        .overlay(
            RoundedRectangle(cornerRadius: 16, style: .continuous)
                .stroke(.white.opacity(0.10), lineWidth: 1)
                .opacity(keyFocused ? 0 : 1)
        )
        .shadow(color: Color.cyan.opacity(keyFocused ? 0.25 : 0), radius: 12)
        .animation(.easeInOut(duration: 0.22), value: keyFocused)
    }

    private var submitButton: some View {
        Button { Task { await activate() } } label: {
            ZStack {
                RoundedRectangle(cornerRadius: 16, style: .continuous)
                    .fill(
                        LinearGradient(
                            colors: [Color.blue, Color(red: 0.10, green: 0.58, blue: 0.94)],
                            startPoint: .leading,
                            endPoint: .trailing
                        )
                    )

                sheen
                    .opacity(sev.isWorking ? 1 : 0)
                    .clipShape(RoundedRectangle(cornerRadius: 16, style: .continuous))

                HStack(spacing: 9) {
                    if sev.isWorking { ProgressView().tint(.white) }
                    Text(sev.isWorking ? "Đang xác thực…" : "Kích hoạt")
                        .font(.system(size: 16, weight: .semibold))
                    if !sev.isWorking { Image(systemName: "arrow.right") }
                }
                .foregroundStyle(.white)
            }
            .frame(maxWidth: .infinity)
            .frame(height: 54)
        }
        .buttonStyle(PressableButtonStyle())
        .disabled(!canSubmit)
        .opacity(canSubmit || sev.isWorking ? 1 : 0.55)
        .animation(.easeInOut(duration: 0.2), value: canSubmit)
    }

    private var sheen: some View {
        GeometryReader { geo in
            LinearGradient(
                colors: [.clear, .white.opacity(0.35), .clear],
                startPoint: .leading,
                endPoint: .trailing
            )
            .frame(width: geo.size.width * 0.5)
            .offset(x: sheenPhase ? geo.size.width : -geo.size.width * 0.5)
        }
    }

    // MARK: - Footer

    /// Reads the device iOS version and checks it against the same policy the app uses after authorization.
    private var deviceSupported: Bool {
        DeviceSupportPolicy.mode(for: ProcessInfo.processInfo.operatingSystemVersion) != .unsupported
    }

    private var footer: some View {
        let tint: Color = deviceSupported ? .green : .red
        return HStack(spacing: 6) {
            Circle()
                .fill(tint)
                .frame(width: 6, height: 6)
                .shadow(color: tint.opacity(0.8), radius: breathing ? 5 : 1)
            Text(deviceSupported ? "IOS CỦA BẠN HỖ TRỢ" : "IOS CỦA BẠN KHÔNG HỖ TRỢ !!")
                .font(.system(size: 10, weight: .bold, design: .rounded))
                .tracking(1.7)
                .foregroundStyle(tint.opacity(0.9))
        }
    }

    // MARK: - Actions

    private func activate() async {
        guard canSubmit else { return }
        await sev.activate(key: key)
        if sev.state == .authorized {
            UINotificationFeedbackGenerator().notificationOccurred(.success)
            key = ""
            keyFocused = false
        } else if sev.state == .keyRequired {
            UINotificationFeedbackGenerator().notificationOccurred(.error)
            if !reduceMotion {
                withAnimation(.linear(duration: 0.42)) { shakeCount += 1 }
            }
        }
    }
}

// MARK: - Effects

/// Horizontal shake driven by an animatable counter. Each whole-number step is one full shake cycle.
private struct ShakeEffect: GeometryEffect {
    var travel: CGFloat = 12
    var shakes: CGFloat

    var animatableData: CGFloat {
        get { shakes }
        set { shakes = newValue }
    }

    func effectValue(size: CGSize) -> ProjectionTransform {
        ProjectionTransform(CGAffineTransform(translationX: travel * sin(shakes * .pi * 6), y: 0))
    }
}

/// Press feedback: a quick spring scale-down while the button is held.
private struct PressableButtonStyle: ButtonStyle {
    func makeBody(configuration: Configuration) -> some View {
        configuration.label
            .scaleEffect(configuration.isPressed ? 0.97 : 1.0)
            .opacity(configuration.isPressed ? 0.92 : 1.0)
            .animation(.spring(response: 0.25, dampingFraction: 0.7), value: configuration.isPressed)
    }
}
