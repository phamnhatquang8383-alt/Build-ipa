import Foundation
import Combine
import UIKit

@MainActor
final class SEVAccessManager: ObservableObject {
    static let shared = SEVAccessManager()

    enum State: Equatable {
        case loading
        case keyRequired
        case authorized
        case maintenance
        case updateRequired
        case error
    }

    @Published private(set) var state: State = .loading
    @Published private(set) var message = "Đang kết nối máy chủ SEV…"
    @Published private(set) var isWorking = false
    @Published private(set) var updateURL: URL?
    @Published private(set) var announcementURL: URL?
    @Published private(set) var minimumVersion: String?

    private let endpoint = URL(string: "https://bpnwzwpqfakwzduiiwvh.supabase.co/functions/v1/sev-control")!
    // Supabase publishable/anon key. This key is intended for public clients; privileged keys stay server-side.
    private let publishableKey = "sb_publishable_qOECks3L-Gbg-Ja8p96_OA_VkAOpVNR"
    private let defaults = UserDefaults.standard
    private let installationKey = "phamquang.sev.installation-id"

    private init() { }

    func start() async {
        await refresh()
    }

    func refresh() async {
        guard !isWorking else { return }
        isWorking = true
        state = .loading
        message = "Đang kiểm tra trạng thái ứng dụng…"
        defer { isWorking = false }
        do {
            let payload = try await request([
                "action": "bootstrap",
                "installation_id": installationID,
                "app_version": appVersion
            ])
            apply(payload)
        } catch {
            state = .error
            message = "Không thể kết nối máy chủ SEV. Kiểm tra Internet rồi thử lại. (\(error.localizedDescription))"
        }
    }

    func activate(key: String) async {
        let trimmed = key.trimmingCharacters(in: .whitespacesAndNewlines)
        guard !trimmed.isEmpty, !isWorking else { return }
        isWorking = true
        message = "Đang xác thực SEV Key…"
        defer { isWorking = false }
        do {
            let payload = try await request([
                "action": "validate-key",
                "key": trimmed,
                "installation_id": installationID,
                "device_name": deviceName,
                "platform": "iOS",
                "app_version": appVersion
            ])
            let authorized = payload["authorized"] as? Bool == true
            if authorized {
                let latest = try await request([
                    "action": "bootstrap",
                    "installation_id": installationID,
                    "app_version": appVersion
                ])
                apply(latest)
                if state == .authorized { message = "Kích hoạt thành công. Thiết bị đã được liên kết với SEV." }
            } else {
                state = .keyRequired
                message = payload["message"] as? String ?? "SEV Key không hợp lệ hoặc đã bị khóa."
            }
        } catch {
            state = .keyRequired
            message = "Không thể xác thực key. Kiểm tra kết nối và thử lại."
        }
    }

    /// Fetches the server-managed SEV feature catalogue for this authorized installation.
    func fetchFeatureCatalog() async throws -> Data {
        let payload = try await request([
            "action": "feature-catalog",
            "installation_id": installationID
        ])
        return try JSONSerialization.data(withJSONObject: payload)
    }

    private var installationID: String {
        if let existing = defaults.string(forKey: installationKey), !existing.isEmpty { return existing }
        let value = UUID().uuidString
        defaults.set(value, forKey: installationKey)
        return value
    }

    private var appVersion: String {
        Bundle.main.infoDictionary?["CFBundleShortVersionString"] as? String ?? "1.0"
    }

    private var deviceName: String {
        #if canImport(UIKit)
        return UIDevice.current.name
        #else
        return "iOS device"
        #endif
    }

    private func request(_ body: [String: Any]) async throws -> [String: Any] {
        var request = URLRequest(url: endpoint)
        request.httpMethod = "POST"
        request.timeoutInterval = 20
        request.setValue(publishableKey, forHTTPHeaderField: "apikey")
        request.setValue("Bearer \(publishableKey)", forHTTPHeaderField: "Authorization")
        request.setValue("application/json", forHTTPHeaderField: "Content-Type")
        request.httpBody = try JSONSerialization.data(withJSONObject: body)
        let (data, response) = try await URLSession.shared.data(for: request)
        guard let http = response as? HTTPURLResponse else { throw SEVError.invalidResponse }
        guard (200..<300).contains(http.statusCode) else { throw SEVError.server(http.statusCode) }
        guard let object = try JSONSerialization.jsonObject(with: data) as? [String: Any] else {
            throw SEVError.invalidResponse
        }
        return object
    }

    private func apply(_ payload: [String: Any]) {
        let control = payload["control"] as? [String: Any] ?? payload
        let keyRequired = control["keyRequired"] as? Bool ?? true
        let maintenance = control["maintenance"] as? Bool ?? false
        let appClosed = control["appClosed"] as? Bool ?? false
        minimumVersion = control["minimumVersion"] as? String
        updateURL = validURL(control["updateURL"] as? String)
        announcementURL = validURL(control["announcementURL"] as? String)

        if maintenance || appClosed {
            state = .maintenance
            message = control["maintenanceMessage"] as? String ?? "Ứng dụng đang tạm bảo trì. Vui lòng quay lại sau."
            return
        }
        if let minimumVersion, isVersion(appVersion, olderThan: minimumVersion) {
            state = .updateRequired
            message = "Vui lòng cập nhật PhamQuang IOS lên phiên bản \(minimumVersion) để tiếp tục."
            return
        }
        if keyRequired && payload["authorized"] as? Bool != true {
            state = .keyRequired
            message = "Nhập Key Để Kích Hoạt Phần Mềm"
            return
        }
        state = .authorized
        message = "Đã kết nối hệ thống SEV."
    }

    private func validURL(_ value: String?) -> URL? {
        guard let value, let url = URL(string: value), ["https", "http"].contains(url.scheme?.lowercased() ?? "") else { return nil }
        return url
    }

    private func isVersion(_ current: String, olderThan minimum: String) -> Bool {
        let lhs = current.split(separator: ".").compactMap { Int($0) }
        let rhs = minimum.split(separator: ".").compactMap { Int($0) }
        for index in 0..<max(lhs.count, rhs.count) {
            let a = index < lhs.count ? lhs[index] : 0
            let b = index < rhs.count ? rhs[index] : 0
            if a != b { return a < b }
        }
        return false
    }

    private enum SEVError: LocalizedError {
        case invalidResponse
        case server(Int)
        var errorDescription: String? {
            switch self {
            case .invalidResponse: return "Phản hồi máy chủ không hợp lệ."
            case .server(let code): return "Máy chủ SEV trả về lỗi HTTP \(code)."
            }
        }
    }
}
