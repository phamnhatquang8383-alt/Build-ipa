# SEV V2 Feature Catalog integration

The Free Fire VN Feature Center is now connected to the SEV V2 `feature-catalog` action (Edge Function version 6).

## Data flow

1. The app completes the existing SEV bootstrap/key authorization.
2. `SEVAccessManager.fetchFeatureCatalog()` sends the persistent installation ID to the Supabase Edge Function.
3. The Edge Function checks maintenance/app-closed state, IP blocks and the installation's active, unexpired license when key enforcement is enabled.
4. The Edge Function returns the admin-managed `sev_feature_catalog` rows.
5. The app displays a toggle only as ready when `enabledByAdmin`, `packageID` and `sha256` are present.
6. The user's toggle choice is stored locally in `UserDefaults`.

## Admin workflow

1. Upload a patch in Patch Center (`.vpatch`, `.vailon` or `.zip`, max 50 MB).
2. Verify the server-side SHA-256 and explicitly publish the package.
3. Open Feature Toggles in SEV V2.
4. Add/update a feature ID, title, description and select the published package. The UI fills its package version and SHA-256 from the published package.
5. Enable the feature and save. The backend independently verifies that the selected package is published and the hash matches.

## Important runtime boundary

The catalogue is configuration and user preference only. It does not itself download, decrypt, execute or apply a package, and it does not invoke Sandbox, Kernel or KExploit. Applying a package still requires the app's separately verified, allowlisted and reversible patch runtime. Do not present a catalogue toggle as proof that an exploit or patch operation has run.

Sandbox, Kernel, KExploit, BQCore, LegacyDirect, AirLift and the existing patch/recovery implementation are preserved.
