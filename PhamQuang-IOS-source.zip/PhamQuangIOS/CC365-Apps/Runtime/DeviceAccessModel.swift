import Foundation
import Combine

@MainActor
final class DeviceAccessModel: ObservableObject {
    static let shared = DeviceAccessModel()
    let version: OperatingSystemVersion
    let mode: DeviceAccessMode
    @Published private(set) var isChecking = false
    @Published private(set) var isReady = false
    @Published private(set) var hasPairing = false
    @Published private(set) var message: String?
    @Published private(set) var hasIssue = false
    @Published private(set) var legacyState: String?
    @Published private(set) var vpnPausedAfterPatch = false
    @Published private(set) var enteredApp = false
    private var started = false
    private var legacyAttemptFinished = false
    private struct LegacyPreparationResult: Sendable {
        let ready: Bool
        let state: String?
        let message: String?
    }

    init(version: OperatingSystemVersion = ProcessInfo.processInfo.operatingSystemVersion) {
        self.version = version
        mode = DeviceSupportPolicy.mode(for: version)
    }

    var versionText: String { "iOS \(version.majorVersion).\(version.minorVersion).\(version.patchVersion)" }
    var title: String {
        switch mode {
        case .directLegacy: return "Truy cập trực tiếp"
        case .airLift: return "Kết nối AirLift"
        case .bqCore: return "Truy cập bằng BQCore"
        case .unsupported: return "Dùng tệp trong PhamQuang IOS"
        }
    }
    var detail: String {
        switch mode {
        case .directLegacy: return "PhamQuang IOS chuẩn bị quyền truy cập trên thiết bị. Không cần pairing hoặc VPN."
        case .airLift: return "Phiên bản này cần pairing file từ máy tính và VPN nội bộ của PhamQuang IOS để truy cập ứng dụng."
        case .bqCore: return "PhamQuang IOS dùng BQCore khi mở thư mục ứng dụng. Không cần pairing hoặc VPN."
        case .unsupported: return "Phiên bản này nằm ngoài dải hỗ trợ. Bạn vẫn có thể quản lý tệp riêng và tạo gói patch."
        }
    }
    private var directAttemptKey: String { "viet99.directPreparationInterrupted.\(versionText)" }
    var requiresRelaunch: Bool { mode == .directLegacy && legacyAttemptFinished && !isReady }
    var canRetry: Bool {
        !isChecking && ((mode == .directLegacy && !legacyAttemptFinished) ||
            (mode == .airLift && hasPairing))
    }
    var canAutomaticallyPrepare: Bool {
        mode == .airLift && hasPairing && !isChecking && !vpnPausedAfterPatch
    }

    func start() async {
        guard !started else { return }
        started = true
        if mode == .directLegacy, UserDefaults.standard.bool(forKey: directAttemptKey) {
            message = "Lần chuẩn bị trước bị gián đoạn. Bạn có thể thử lại hoặc tiếp tục với tệp riêng."
            hasIssue = true
            return
        }
        await prepare()
    }

    func prepare(automatically: Bool = false) async {
        if automatically && !canAutomaticallyPrepare { return }
        guard !isChecking, !(mode == .directLegacy && legacyAttemptFinished) else { return }
        isChecking = true
        message = nil
        hasIssue = false
        defer { isChecking = false }
        switch mode {
        case .bqCore:


            isReady = true
            enteredApp = true
        case .unsupported:
            isReady = false
        case .directLegacy:
            UserDefaults.standard.set(true, forKey: directAttemptKey)
            let result: LegacyPreparationResult = await withCheckedContinuation { continuation in
                VVLegacyDirectAccess.prepare { result in
                    continuation.resume(returning: LegacyPreparationResult(ready: result["ready"] as? Bool == true,
                        state: result["state"] as? String, message: result["message"] as? String))
                }
            }
            UserDefaults.standard.removeObject(forKey: directAttemptKey)
            legacyAttemptFinished = true
            legacyState = result.state
            isReady = result.ready && VVLegacyDirectAccess.isReady()
            hasIssue = !isReady
            message = result.message
            if isReady { enteredApp = true }
        case .airLift:
            vpnPausedAfterPatch = false
            isReady = false
            hasPairing = LegacyAirLiftService.hasPairing
            guard hasPairing else { isReady = false; return }
            do {
                message = try await LegacyAirLiftService.checkConnection()
                try Task.checkCancellation()
                isReady = true
                enteredApp = true
            } catch is CancellationError {
                message = nil
            } catch {
                hasIssue = true
                message = FileTransferSupport.message(error)
            }
        }
    }

    func importPairing(from url: URL) async {
        guard mode == .airLift, !isChecking else { return }
        isChecking = true
        message = nil
        hasIssue = false
        do {
            try await LegacyAirLiftService.importPairing(from: url)
            hasPairing = LegacyAirLiftService.hasPairing

            isReady = false
            try Task.checkCancellation()
        } catch is CancellationError {
            isChecking = false
            return
        } catch {


            hasIssue = true
            message = FileTransferSupport.message(error)
            isChecking = false
            return
        }
        isChecking = false
        await prepare()
    }

    func removePairing() {
        guard mode == .airLift, !isChecking else { return }
        do {
            try LegacyAirLiftService.removePairing()
            hasPairing = false
            isReady = false
            message = nil
            hasIssue = false
        } catch { hasIssue = true; message = FileTransferSupport.message(error) }
    }

    func continueLocally() { enteredApp = true }
    func configureVPN() async {
        guard mode == .airLift, !isChecking else { return }
        isChecking = true
        isReady = false
        hasIssue = false
        message = nil
        do {
            try await LegacyInternalVPN.shared.authorizeAndConnect()
            vpnPausedAfterPatch = false
        } catch {
            hasIssue = true
            message = FileTransferSupport.message(error)
            isChecking = false
            return
        }
        isChecking = false
        if hasPairing { await prepare() }
        else { message = "VPN nội bộ đã bật. Chọn pairing file để hoàn tất kết nối." }
    }
    func pauseAfterPatch(message: String = "Phiên patch đã kết thúc. VPN nội bộ sẽ tự bật lại khi cần truy cập ứng dụng.") {
        guard mode == .airLift else { return }
        vpnPausedAfterPatch = true
        isReady = false
        hasIssue = false
        self.message = message
    }
    func connectionIssue(_ text: String) {
        if mode == .airLift { isReady = false }
        hasIssue = true
        message = text
    }

    func requireDirectAccess() throws {
        guard mode == .bqCore || (mode == .directLegacy && isReady && VVLegacyDirectAccess.isReady()) else {
            throw PatchInputError("Chưa sẵn sàng truy cập ứng dụng. Vào Cài đặt → Truy cập thiết bị để hoàn tất thiết lập.")
        }
    }
}
