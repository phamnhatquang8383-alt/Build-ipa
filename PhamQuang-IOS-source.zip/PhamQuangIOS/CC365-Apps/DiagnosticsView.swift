import SwiftUI
import Foundation

struct DiagnosticsView: View {
    @ObservedObject var access: DeviceAccessModel
    @State private var refreshedAt = Date()

    private var appVersion: String {
        let info = Bundle.main.infoDictionary ?? [:]
        let version = info["CFBundleShortVersionString"] as? String ?? "Không rõ"
        let build = info["CFBundleVersion"] as? String ?? "Không rõ"
        return "\(version) (\(build))"
    }

    private var storage: (free: Int64?, total: Int64?) {
        guard let values = try? FileManager.default.attributesOfFileSystem(forPath: NSHomeDirectory()) else {
            return (nil, nil)
        }
        let free = (values[.systemFreeSize] as? NSNumber)?.int64Value
        let total = (values[.systemSize] as? NSNumber)?.int64Value
        return (free, total)
    }

    private var accessStatus: String {
        if access.isChecking { return "Đang kiểm tra" }
        if access.isReady { return "Sẵn sàng" }
        if access.enteredApp { return "Đang chạy chế độ cục bộ" }
        if access.hasIssue { return "Có vấn đề cần kiểm tra" }
        if access.mode == .unsupported { return "Chế độ truy cập giới hạn" }
        return "Chưa hoàn tất thiết lập"
    }

    private var report: String {
        let disk = storage
        let free = disk.free.map { ByteCountFormatter.string(fromByteCount: $0, countStyle: .file) } ?? "Không khả dụng"
        let total = disk.total.map { ByteCountFormatter.string(fromByteCount: $0, countStyle: .file) } ?? "Không khả dụng"
        let pairing = access.mode == .airLift ? (access.hasPairing ? "Đã nhập" : "Chưa nhập") : "Không áp dụng"
        return [
            "PhamQuang IOS — Báo cáo chẩn đoán",
            "Thời gian: \(ISO8601DateFormatter().string(from: refreshedAt))",
            "Phiên bản ứng dụng: \(appVersion)",
            "Hệ điều hành: \(access.versionText)",
            "Chế độ truy cập: \(access.title)",
            "Dải phiên bản: \(access.mode.supportedVersions)",
            "Trạng thái: \(accessStatus)",
            "Pairing AirLift: \(pairing)",
            "Dung lượng trống: \(free)",
            "Tổng dung lượng: \(total)",
            "",
            "Báo cáo không chứa pairing file, khóa, đường dẫn riêng tư hoặc nội dung tệp."
        ].joined(separator: "\\n")
    }

    var body: some View {
        Form {
            Section("Tổng quan") {
                LabeledContent("Trạng thái", value: accessStatus)
                LabeledContent("Phiên bản PhamQuang IOS", value: appVersion)
                LabeledContent("Hệ điều hành", value: access.versionText)
                LabeledContent("Chế độ", value: access.title)
                LabeledContent("Dải hỗ trợ", value: access.mode.supportedVersions)
            }

            Section("Thiết bị") {
                if let free = storage.free {
                    LabeledContent("Dung lượng trống", value: ByteCountFormatter.string(fromByteCount: free, countStyle: .file))
                } else {
                    LabeledContent("Dung lượng trống", value: "Không khả dụng")
                }
                if let total = storage.total {
                    LabeledContent("Tổng dung lượng", value: ByteCountFormatter.string(fromByteCount: total, countStyle: .file))
                } else {
                    LabeledContent("Tổng dung lượng", value: "Không khả dụng")
                }
                if access.mode == .airLift {
                    LabeledContent("Pairing AirLift", value: access.hasPairing ? "Đã nhập" : "Chưa nhập")
                }
            }

            if let message = access.message, !message.isEmpty {
                Section("Thông tin gần nhất") {
                    Text(message).textSelection(.enabled)
                }
            }

            Section {
                ShareLink(item: report) {
                    Label("Xuất báo cáo chẩn đoán", systemImage: "square.and.arrow.up")
                }
                Button {
                    refreshedAt = Date()
                } label: {
                    Label("Làm mới báo cáo", systemImage: "arrow.clockwise")
                }
            } footer: {
                Text("Báo cáo chỉ chứa thông tin phiên bản, trạng thái truy cập và dung lượng. Không xuất pairing file, khóa hoặc dữ liệu cá nhân.")
            }
        }
        .cc365Canvas()
        .navigationTitle("Chẩn đoán")
        .navigationBarTitleDisplayMode(.inline)
    }
}
