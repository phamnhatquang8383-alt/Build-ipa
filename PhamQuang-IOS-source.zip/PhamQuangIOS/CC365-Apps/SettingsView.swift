import SwiftUI

struct SettingsView: View {
    @AppStorage(AppFileSettings.workModeKey) private var workMode = FileWorkPreset.automatic.rawValue
    @AppStorage(AppFileSettings.showFilesTabKey) private var showFilesTab = false
    @ObservedObject private var access = DeviceAccessModel.shared

    var body: some View {
        Form {
            Section("Giao diện") {
                Toggle("Hiển thị tab Tệp", isOn: $showFilesTab)
            }
            Section {
                NavigationLink {
                    DeviceAccessView(access: access)
                } label: {
                    VStack(alignment: .leading, spacing: 4) {
                        Text("Truy cập thiết bị")
                        Text("\(access.versionText) · \(access.title)")
                            .font(.footnote).foregroundStyle(.secondary)
                    }
                }
            }
            Section {
                Picker("Mức xử lý", selection: $workMode) {
                    ForEach(FileWorkPreset.allCases) { mode in Text(mode.title).tag(mode.rawValue) }
                }
            } header: { Text("Tệp và patch") } footer: {
                Text((FileWorkPreset(rawValue: workMode) ?? .automatic).detail + " Áp dụng từ lần chạy tiếp theo.")
            }

            Section("Chẩn đoán") {
                NavigationLink {
                    DiagnosticsView(access: access)
                } label: {
                    Label {
                        VStack(alignment: .leading, spacing: 4) {
                            Text("Trung tâm chẩn đoán")
                            Text("Kiểm tra trạng thái và xuất báo cáo hỗ trợ")
                                .font(.footnote).foregroundStyle(.secondary)
                        }
                    } icon: {
                        Image(systemName: "stethoscope")
                    }
                }
            }

            Section("Ứng dụng") {
                LabeledContent("Tên", value: "PhamQuang IOS")
                LabeledContent("Phiên bản", value: Bundle.main.object(forInfoDictionaryKey: "CFBundleShortVersionString") as? String ?? "1.4.1")
                LabeledContent("Ứng dụng và mã nguồn", value: "SATO")
                NavigationLink("Đóng góp và mã nguồn mở") { SourceLicensesView() }
            }
        }
        .cc365Canvas()
        .navigationTitle("Cài đặt")
        .navigationBarTitleDisplayMode(.inline)
        .onAppear {
            if FileWorkPreset(rawValue: workMode) == nil { workMode = FileWorkPreset.automatic.rawValue }
        }
    }
}
