import Foundation

struct PatchInputError: LocalizedError {
    let errorDescription: String?
    init(_ message: String) { errorDescription = message }
}
enum FileTransferSupport {
    static func message(_ error: Error) -> String { error.localizedDescription }
}
@MainActor enum VVLegacyDirectAccess {
    static var ready = false
    static var calls = 0
    static var hold = false
    static var pending: (([String: Any]) -> Void)?
    static var result: [String: Any] = ["ready": false, "state": "failed", "message": "Không thể chuẩn bị quyền truy cập trực tiếp."]
    static func isReady() -> Bool { ready }
    static func prepare(completion: @escaping ([String: Any]) -> Void) {
        calls += 1
        if hold { pending = completion; return }
        completion(result)
    }
    static func finishPending() { let callback = pending; pending = nil; callback?(result) }
}
@MainActor enum LegacyAirLiftService {
    static var hasPairing = false
    static var connectionCalls = 0
    static var hold = false
    static var pending: CheckedContinuation<String, Error>?
    static var importFailure = false
    static func checkConnection() async throws -> String {
        connectionCalls += 1
        if hold { return try await withCheckedThrowingContinuation { pending = $0 } }
        return "Đã kiểm tra pairing và kết nối trên thiết bị."
    }
    static func importPairing(from url: URL) async throws {
        if importFailure { throw PatchInputError("Pairing file không hợp lệ.") }
        hasPairing = true
    }
    static func removePairing() throws { hasPairing = false }
}
@MainActor final class LegacyInternalVPN {
    static let shared = LegacyInternalVPN()
    var setupCalls = 0
    func authorizeAndConnect() async throws { setupCalls += 1 }
}

import Foundation

@MainActor @main struct DeviceAccessModelTests {
    static var count = 0
    static func check(_ condition: Bool, _ name: String) {
        precondition(condition, name); count += 1; print("PASS " + name)
    }
    static func main() async throws {
        let modern = DeviceAccessModel(version: .init(majorVersion: 26, minorVersion: 5, patchVersion: 0))
        let nativeBeforeModern = VVLegacyDirectAccess.calls
        let airLiftBeforeModern = LegacyAirLiftService.connectionCalls
        await modern.start()
        check(modern.isReady && modern.enteredApp && !modern.hasIssue &&
              VVLegacyDirectAccess.calls == nativeBeforeModern && LegacyAirLiftService.connectionCalls == airLiftBeforeModern,
              "modern-startup-enters-existing-app-without-calling-legacy-services")
        let air = DeviceAccessModel(version: .init(majorVersion: 18, minorVersion: 7, patchVersion: 2))
        await air.prepare()
        check(!air.isReady && !air.isChecking && !air.hasPairing && LegacyAirLiftService.connectionCalls == 0,
              "missing-pairing-does-not-check-connection")
        LegacyAirLiftService.hasPairing = true
        await air.prepare()
        check(air.isReady && air.enteredApp && !air.hasIssue, "successful-connection-enters-app")
        air.pauseAfterPatch()
        check(!air.isReady && air.vpnPausedAfterPatch && !air.hasIssue && !air.canAutomaticallyPrepare,
              "automatic-vpn-off-pauses-readiness-without-error-or-automatic-reconnect")
        let beforeAutomatic = LegacyAirLiftService.connectionCalls
        await air.prepare(automatically: true)
        check(air.vpnPausedAfterPatch && LegacyAirLiftService.connectionCalls == beforeAutomatic,
              "queued-automatic-check-rechecks-pause-state-before-starting")
        await air.configureVPN()
        check(air.isReady && !air.vpnPausedAfterPatch && air.canAutomaticallyPrepare && LegacyInternalVPN.shared.setupCalls == 1,
              "explicit-internal-vpn-setup-allows-new-connection-check")
        await air.prepare()
        modern.pauseAfterPatch()
        check(modern.isReady && !modern.vpnPausedAfterPatch, "internal-vpn-stop-cannot-change-modern-bq-state")
        LegacyAirLiftService.importFailure = true
        await air.importPairing(from: URL(fileURLWithPath: "/invalid.plist"))
        check(air.isReady && air.hasPairing && air.hasIssue && !air.isChecking,
              "invalid-replacement-reports-error-and-preserves-existing-ready-pair")
        air.connectionIssue("VPN không còn kết nối")
        check(!air.isReady && air.hasIssue, "connection-error-invalidates-ready-state")
        await air.prepare()
        check(air.isReady && !air.hasIssue, "successful-recheck-clears-previous-error")
        air.removePairing()
        check(!air.isReady && !air.hasPairing && !air.hasIssue && air.enteredApp,
              "removal-locks-protected-access-and-keeps-local-app-open")

        LegacyAirLiftService.hasPairing = true
        LegacyAirLiftService.hold = true
        let canceled = Task { await air.prepare() }
        while LegacyAirLiftService.pending == nil { await Task.yield() }
        check(air.isChecking && !air.isReady, "recheck-clears-readiness-while-in-flight")
        canceled.cancel()
        LegacyAirLiftService.pending?.resume(returning: "Late success")
        LegacyAirLiftService.pending = nil
        await canceled.value
        check(!air.isChecking && !air.isReady && air.message == nil && !air.hasIssue,
              "canceled-check-cannot-publish-late-success")
        LegacyAirLiftService.hold = false

        let failed = DeviceAccessModel(version: .init(majorVersion: 16, minorVersion: 7, patchVersion: 1))
        await failed.prepare()
        let attempts = VVLegacyDirectAccess.calls
        await failed.prepare()
        check(VVLegacyDirectAccess.calls == attempts && failed.requiresRelaunch && !failed.canRetry && failed.hasIssue,
              "native-one-shot-failure-does-not-offer-useless-retry")
        failed.continueLocally()
        check(failed.enteredApp && !failed.isReady, "failed-setup-can-enter-local-workspace")

        VVLegacyDirectAccess.ready = true
        VVLegacyDirectAccess.result = ["ready": true, "state": "ready", "message": "Đã kiểm tra quyền truy cập."]
        let ready = DeviceAccessModel(version: .init(majorVersion: 17, minorVersion: 0, patchVersion: 0))
        await ready.prepare()
        try ready.requireDirectAccess()
        check(ready.isReady && ready.enteredApp && !ready.requiresRelaunch && ready.legacyState == "ready",
              "native-ready-state-is-retained-and-enters-app")
        VVLegacyDirectAccess.ready = false
        do { try ready.requireDirectAccess(); preconditionFailure("Must fail after native readiness is lost") }
        catch { check(ready.isReady, "gate-checks-native-status-even-if-ui-readiness-was-true") }

        let key = "viet99.directPreparationInterrupted.iOS 16.0.0"
        let oldValue = UserDefaults.standard.object(forKey: key)
        defer { if let oldValue { UserDefaults.standard.set(oldValue, forKey: key) } else { UserDefaults.standard.removeObject(forKey: key) } }
        UserDefaults.standard.set(true, forKey: key)
        let interrupted = DeviceAccessModel(version: .init(majorVersion: 16, minorVersion: 0, patchVersion: 0))
        let beforeStart = VVLegacyDirectAccess.calls
        await interrupted.start()
        check(interrupted.hasIssue && interrupted.canRetry && VVLegacyDirectAccess.calls == beforeStart,
              "previous-process-interruption-requires-explicit-retry")
        VVLegacyDirectAccess.ready = true
        await interrupted.prepare()
        check(interrupted.isReady && !UserDefaults.standard.bool(forKey: key) && VVLegacyDirectAccess.calls == beforeStart + 1,
              "explicit-retry-after-relaunch-completes-once-and-clears-interruption-marker")

        let unsupported = DeviceAccessModel(version: .init(majorVersion: 28, minorVersion: 0, patchVersion: 0))
        await unsupported.start()
        check(!unsupported.isReady && !unsupported.enteredApp && !unsupported.canRetry,
              "unsupported-release-waits-for-local-workspace-choice")
        print("Device access model: \(count) state checks passed")
    }
}
